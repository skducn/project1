# -*- coding: utf-8 -*-
# *****************************************************************
# Author     : John
# Date       : 2023-11-6
# Description: # dm for win
# ***************************************************************u**

from Dm_chcPO import *
Dm_chcPO = Dm_chcPO("")

Dm_chcPO.insertTbl('健康评估', '健康评估')
# Dm_chcPO.insertTbl('健康干预', '健康干预')
# Dm_chcPO.insertTbl('中医体质辨识', '中医体质辨识')
# Dm_chcPO.insertTbl('儿童健康干预', '儿童健康干预')
# Dm_chcPO.insertTbl('已患和高风险疾病评估', '疾病评估')

# Dm_chcPO.insertTbl('疾病身份证', '疾病身份证')
# Dm_chcPO.insertTbl('测试规则', '测试规则')

