# coding=utf-8
#***************************************************************
# Author     : John
# Created on : 2023-8-1
# Description: DM for chc
#***************************************************************
from Dm_chcPO import *

r = Dm_chcPO("健康评估")
# r = Dm_chcPO("健康干预")
# r = Dm_chcPO("中医体质辨识")
# r = Dm_chcPO("儿童健康干预")
# r = Dm_chcPO("疾病评估")
# r.run(19)
r.run(1)


# r.i_startAssess("110101196407281501")
# r.i_startAssess("310101199004110011")

