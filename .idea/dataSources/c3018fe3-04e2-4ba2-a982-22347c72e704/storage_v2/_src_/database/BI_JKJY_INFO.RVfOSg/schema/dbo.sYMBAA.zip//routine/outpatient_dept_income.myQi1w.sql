CREATE proc [dbo].[outpatient_dept_income]
@condition nvarchar(50)
        as
        begin
        DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
        IF (@condition IS NOT NULL AND @condition != '')
        BEGIN
        SET @startTime = SUBSTRING(@condition,0,20)
        SET @endTime = SUBSTRING(@condition,21,20)
        END

 select t3.deptCode as 科室代码,t3.deptName as 科室名称,t3.xiyaofei as 西药费,t3.zhongchengyaofei as 中成药费,
				       t3.zhongcaoyaofei as 中草要费,t3.cailiaofei as 材料费,t3.zhiliaofei as 治疗费,t3.huayanfei as 化验费,
							 t3.jianchafei as 检查费,t3.gonbenfei as 工本费,t3.guahaofei as 挂号费,
               t3.heji as 合计,t3.qita as 其它
        from
        (
        select t1.deptCode,t1.deptName,
				       t1.xiyaofei,t1.zhongchengyaofei,t1.zhongcaoyaofei,t1.cailiaofei,t1.zhiliaofei,t1.huayanfei,t1.jianchafei,
				       t1.gonbenfei,t1.kuaijieguahaofei + isnull(t2.guahaofei,0.00) as guahaofei,
							 t1.heji + isnull(t2.guahaofei,0.00) as heji,
				       t1.heji - t1.xiyaofei-t1.zhongchengyaofei-t1.zhongcaoyaofei-t1.cailiaofei-t1.zhiliaofei-t1.huayanfei-t1.jianchafei - t1.gonbenfei- t1.kuaijieguahaofei + isnull(t2.guahaofei,0.00) as qita
        from
        (select department.deptCode,department.deptName,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=03 then detail.amount else 0 end), 2 ) ) as xiyaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=06 then detail.amount else 0 end), 2 ) ) as zhongchengyaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=09 then detail.amount else 0 end), 2 ) ) as zhongcaoyaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=08 or detail.itemType=99 then detail.amount else 0 end), 2 ) ) as cailiaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=10 then detail.amount else 0 end), 2 ) ) as zhiliaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=05 then detail.amount else 0 end), 2 ) ) as huayanfei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=07 then detail.amount else 0 end), 2 ) ) as jianchafei,
				Convert(decimal(18,2), Round( sum(case when detail.itemType=20 then detail.amount else 0 end), 2 ) ) as gonbenfei,
				Convert(decimal(18,2), Round( sum(case when detail.itemType=55 then detail.amount else 0 end), 2 ) ) as kuaijieguahaofei,
        Convert(decimal(18,2), Round( sum(detail.amount), 2 ) ) as heji
        from bmlpimpro.dbo.t_outpatient_cashier_invoice invoice
        left join bmlpimpro.dbo.t_outpatient_cashier_detail detail on invoice.invoiceId=detail.invoiceId
        left join bmlpimpro.dbo.t_outpatient_registration_info info on detail.visitId = info.visitId
        left join bmlpimpro.dbo.t_code_department_information department on info.deptCode = department.deptCode
        where info.deptCode is not null and invoice.payDate >@startTime and invoice.payDate < @endTime and invoice.invoiceStatus in (0,1,2)
        group by department.deptCode,department.deptName ) t1
        left join
        (select department.deptName,sum(invoice.totalFee) as guahaofei
        from bmlpimpro.dbo.t_outpatient_registration_invoice invoice
        left join bmlpimpro.dbo.t_outpatient_registration_data data on invoice.invoiceId=data.invoiceId
        left join bmlpimpro.dbo.t_outpatient_registration_info info on data.visitId=info.id
        left join bmlpimpro.dbo.t_code_department_information department on info.deptCode = department.deptCode
        where info.deptCode is not null
        group by department.deptName) t2
        on t1.deptName=t2.deptName
        ) t3

        union all

        select '', '合计',sum(t3.xiyaofei),sum(t3.zhongchengyaofei),sum(t3.zhongcaoyaofei),sum(t3.cailiaofei),sum(t3.zhiliaofei),
        sum(t3.huayanfei),sum(t3.jianchafei),sum(t3.gonbenfei),sum(t3.guahaofei),sum(t3.heji),sum(t3.qita)
        from
        (
        select t1.deptCode,t1.deptName,
				       t1.xiyaofei,t1.zhongchengyaofei,t1.zhongcaoyaofei,t1.cailiaofei,t1.zhiliaofei,t1.huayanfei,t1.jianchafei,
				       t1.gonbenfei,t1.kuaijieguahaofei + isnull(t2.guahaofei,0.00) as guahaofei,
							 t1.heji + isnull(t2.guahaofei,0.00) as heji,
				       t1.heji - t1.xiyaofei-t1.zhongchengyaofei-t1.zhongcaoyaofei-t1.cailiaofei-t1.zhiliaofei-t1.huayanfei-t1.jianchafei - t1.gonbenfei- t1.kuaijieguahaofei + isnull(t2.guahaofei,0.00) as qita
        from
        (select department.deptCode,department.deptName,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=03 then detail.amount else 0 end), 2 ) ) as xiyaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=06 then detail.amount else 0 end), 2 ) ) as zhongchengyaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=09 then detail.amount else 0 end), 2 ) ) as zhongcaoyaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=08 or detail.itemType=99 then detail.amount else 0 end), 2 ) ) as cailiaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=10 then detail.amount else 0 end), 2 ) ) as zhiliaofei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=05 then detail.amount else 0 end), 2 ) ) as huayanfei,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=07 then detail.amount else 0 end), 2 ) ) as jianchafei,
				Convert(decimal(18,2), Round( sum(case when detail.itemType=20 then detail.amount else 0 end), 2 ) ) as gonbenfei,
				Convert(decimal(18,2), Round( sum(case when detail.itemType=55 then detail.amount else 0 end), 2 ) ) as kuaijieguahaofei,
        Convert(decimal(18,2), Round( sum(detail.amount), 2 ) ) as heji
        from bmlpimpro.dbo.t_outpatient_cashier_invoice invoice
        left join bmlpimpro.dbo.t_outpatient_cashier_detail detail on invoice.invoiceId=detail.invoiceId
        left join bmlpimpro.dbo.t_outpatient_registration_info info on detail.visitId = info.visitId
        left join bmlpimpro.dbo.t_code_department_information department on info.deptCode = department.deptCode
        where info.deptCode is not null and invoice.payDate >@startTime and invoice.payDate < @endTime and invoice.invoiceStatus in (0,1,2)
        group by department.deptCode,department.deptName ) t1
        left join
        (select department.deptName,sum(invoice.totalFee) as guahaofei
        from bmlpimpro.dbo.t_outpatient_registration_invoice invoice
        left join bmlpimpro.dbo.t_outpatient_registration_data data on invoice.invoiceId=data.invoiceId
        left join bmlpimpro.dbo.t_outpatient_registration_info info on data.visitId=info.id
        left join bmlpimpro.dbo.t_code_department_information department on info.deptCode = department.deptCode
        where info.deptCode is not null
        group by department.deptName) t2
        on t1.deptName=t2.deptName
        ) t3

        end
go

