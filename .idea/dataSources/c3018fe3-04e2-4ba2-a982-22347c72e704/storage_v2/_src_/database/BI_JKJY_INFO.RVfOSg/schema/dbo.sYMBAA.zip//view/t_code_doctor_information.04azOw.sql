CREATE VIEW [dbo].[t_code_doctor_information] AS select * from bmlpimpro.dbo.t_code_doctor_information
go

