CREATE VIEW [dbo].[t_inpatient_invoice_info] AS select * from bmlinppro.dbo.t_inpatient_invoice_info
go

