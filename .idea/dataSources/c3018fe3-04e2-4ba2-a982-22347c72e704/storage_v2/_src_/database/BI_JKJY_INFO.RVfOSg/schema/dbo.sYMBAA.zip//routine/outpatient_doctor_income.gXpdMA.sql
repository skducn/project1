CREATE proc [dbo].[outpatient_doctor_income]
@condition nvarchar(50)
        as
        begin
        DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
        IF (@condition IS NOT NULL AND @condition != '')
        BEGIN
        SET @startTime = SUBSTRING(@condition,0,20)
        SET @endTime = SUBSTRING(@condition,21,20)
        END
        select recipe.docUserCode as 医生工号,doctor.docName as 医生姓名,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=03 then detail.amount else 0 end), 2 ) ) as 西药费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=06 then detail.amount else 0 end), 2 ) ) as 中成药费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=09 then detail.amount else 0 end), 2 ) ) as 中草药费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=08 or detail.itemType=99 then detail.amount else 0 end), 2 ) ) as 材料费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=10 then detail.amount else 0 end), 2 ) ) as 治疗费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=05 then detail.amount else 0 end), 2 ) ) as 化验费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=07 then detail.amount else 0 end), 2 ) ) as 检查费,
        Convert(decimal(18,2), Round( sum(detail.amount), 2 ) ) as 合计
        from bmlpimpro.dbo.t_outpatient_cashier_recipe recipe
        left join bmlpimpro.dbo.t_outpatient_cashier_invoice invoice on recipe.invoiceId = invoice.invoiceId
        left join bmlpimpro.dbo.t_outpatient_cashier_detail detail on invoice.invoiceId = detail.invoiceId
        left join bmlpimpro.dbo.t_code_doctor_information doctor on recipe.docUserId = doctor.docId
        where invoice.payDate > @startTime and invoice.payDate < @endTime and invoice.invoiceStatus in (0,1,2)
        group by recipe.docUserCode,doctor.docName
        union all
        select  '合计','',
        Convert(decimal(18,2), Round( sum(case when detail.itemType=03 then detail.amount else 0 end), 2 ) ) as 西药费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=06 then detail.amount else 0 end), 2 ) ) as 中成药费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=09 then detail.amount else 0 end), 2 ) ) as 中草药费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=08 or detail.itemType=99 then detail.amount else 0 end), 2 ) ) as 材料费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=10 then detail.amount else 0 end), 2 ) ) as 治疗费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=05 then detail.amount else 0 end), 2 ) ) as 化验费,
        Convert(decimal(18,2), Round( sum(case when detail.itemType=07 then detail.amount else 0 end), 2 ) ) as 检查费,
        Convert(decimal(18,2), Round( sum(detail.amount), 2 ) ) as heji
        from bmlpimpro.dbo.t_outpatient_cashier_recipe recipe
        left join bmlpimpro.dbo.t_outpatient_cashier_invoice invoice on recipe.invoiceId = invoice.invoiceId
        left join bmlpimpro.dbo.t_outpatient_cashier_detail detail on invoice.invoiceId = detail.invoiceId
        left join bmlpimpro.dbo.t_code_doctor_information doctor on recipe.docUserId = doctor.docId
        where invoice.payDate > @startTime and invoice.payDate < @endTime and invoice.invoiceStatus in (0,1,2)
        end
go

