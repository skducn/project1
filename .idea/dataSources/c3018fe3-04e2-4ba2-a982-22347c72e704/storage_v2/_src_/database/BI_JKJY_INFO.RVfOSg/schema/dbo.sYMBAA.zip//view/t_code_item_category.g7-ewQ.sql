CREATE VIEW [dbo].[t_code_item_category] AS select * from bmlpimpro.dbo.t_code_item_category
go

