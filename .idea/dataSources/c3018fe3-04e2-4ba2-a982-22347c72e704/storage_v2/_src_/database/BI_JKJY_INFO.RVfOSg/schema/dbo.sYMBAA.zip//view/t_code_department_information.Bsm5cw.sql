CREATE VIEW [dbo].[t_code_department_information] AS select * from bmlpimpro.dbo.t_code_department_information
go

