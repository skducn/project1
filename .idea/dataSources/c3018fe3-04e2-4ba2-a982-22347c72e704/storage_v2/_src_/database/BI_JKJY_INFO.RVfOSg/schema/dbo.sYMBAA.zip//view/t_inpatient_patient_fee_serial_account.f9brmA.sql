CREATE VIEW [dbo].[t_inpatient_patient_fee_serial_account] AS select * from bmlinppro.dbo.t_inpatient_patient_fee_serial_account
go

