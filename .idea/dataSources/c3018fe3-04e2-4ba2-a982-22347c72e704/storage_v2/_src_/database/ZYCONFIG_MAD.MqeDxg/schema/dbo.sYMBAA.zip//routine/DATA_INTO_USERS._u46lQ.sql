CREATE PROCEDURE [dbo].[DATA_INTO_USERS] 
(
    @USER_NAME NVARCHAR(50),
    @NAME VARCHAR(50)
) 
AS 
BEGIN
    SET NOCOUNT ON;
	  --  统一注入为默认值 后续权限系统调整，及细节调整需手动修改
		
		
		
		
    -- 检查 SQL 注入
		-- 添加用户默认密码 12345678
		-- 添加默认性别 男
		-- 添加默认 职称 医生
		-- 插入到 SYS_USER_ROLE 表 到中所有的权限
    IF CHARINDEX(';', @USER_NAME) > 0 OR CHARINDEX('--', @USER_NAME) > 0
    BEGIN
        RAISERROR('输入变量值中包含 SQL 注入！', 16, 1);
        RETURN;
    END;

    BEGIN TRY
        -- 开始事务
        BEGIN TRANSACTION;

        -- 插入到 SYS_USER 表
        INSERT INTO [dbo].[SYS_USER] (
            [USER_NAME],
            [PASSWORD],
            [NAME],
            [SEX],
            [SALT],
            [CATEGORY_CODE],
            [CATEGORY_NAME],
            [SEX_NAME]
        )
        VALUES (
            @USER_NAME,
            'f101de8c929061a56e1decc957c3ca23ecdeff782cd9e63681169f36560906d2', -- 默认密码
            @NAME,
            '1', -- 默认性别
            '9hINb+whLB3xwZtZZ0fdWw==', -- 默认盐值
            '01', -- 默认类别代码
            '医生', -- 默认类别名称
            '男' -- 默认性别名称
        );

        -- 获取新插入用户的 ID
        DECLARE @USER_ID INT = SCOPE_IDENTITY();

        -- 插入到 SYS_USER_ROLE 表
        INSERT INTO SYS_USER_ROLE (USER_ID, SYSTEM_ID, ROLE_ID)
        SELECT @USER_ID, SYSTEM_ID,SYS_ROLE.ID
        FROM SYS_ROLE

        -- 提交事务
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- 如果发生错误，则回滚事务
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        -- 引发错误
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END CATCH;
END;
go

