CREATE FUNCTION [dbo].[FN_GETPERCENT0](
    @分子 INT,@分母 INT
)
    RETURNS VARCHAR(10)
AS

BEGIN

    DECLARE @RETURN NUMERIC(8,0)

    IF (@分母 IS NULL OR @分母 = 0)
        BEGIN
            SET @RETURN=0.0
        END
    ELSE
        BEGIN
            SET @RETURN=CAST(CAST(ROUND(@分子/CONVERT(FLOAT,@分母), 4) * 100   AS   NUMERIC(8,0)) AS VARCHAR)
        END

    RETURN @RETURN
END
go

