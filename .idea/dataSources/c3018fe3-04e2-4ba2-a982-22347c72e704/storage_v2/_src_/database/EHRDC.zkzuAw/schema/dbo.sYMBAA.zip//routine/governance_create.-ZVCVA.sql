CREATE PROCEDURE [dbo].[governance_create] @startTime datetime,
@endTime datetime AS BEGIN

with
exerciseTimeList as (
SELECT  * FROM (VALUES ('30'), ('40'), ('50'), ('60'))  AS X(name)
),
exerciseStyleList as (
SELECT  * FROM (VALUES ('跑步'), ('走路'), ('打球'))  AS X(name)
)

-- 新增体检表治理 --
INSERT INTO tb_dc_examination_info ( guid, ehrNum, examinationId, orgCode, NAME, empiGuid, isGovernance, examinationDate, symptomCode, symptomName, temperature, pulseRate, breathRate, rightDBP, rightSBP, leftDBP, leftSBP, height, weight, waistline, oldAssessHealthCode, oldCareAbilityCode, oldCareAbilityName, exerciseFrequencyCode, exerciseTime, exerciseDuration, exerciseStyle, eatingHabitsCode, eatingHabitsName, smokingCode, smokingName, drinkingFrequencyCode, drinkingFrequencyName, osAppearanceCode, osAppearanceName, dentitionCategoryCode, dentitionCategoryName, throatCheckCode, throatCheckName, leftNakedEyesight, rightNakedEyesight, hearingCheckCode, hearingCheckName, sportFunctionCode, sportFunctionName, skinCheckCode, skinCheckName, scleraCheckCode, scleraCheckName, lymphCheckCode, lymphCheckName, barrelChestSign, breathSoundsSign, lungRalesCode, lungRalesName, heartRate, heartRateTypeCode, heartRateTypeName, heartMurmurSign, abdomenTendernessSign, abdomenBlockSign, abdomenHepatomegalySign, abdomenSplenomegalySign, shiftingDullnessSign, limbEdemaCode, dorsalArteryOfFootCode, dorsalArteryOfFootName, cerebrovascularCode, cerebrovascularName, kidneyCode, kidneyName, heartCode, heartName, bloodVesselsCode, bloodVesselsName, eyeCode, eyeName, nervousSystemSign, otherDiseasesSign ) SELECT
  newid ( ) AS guid,
CASE
	
	WHEN len ( sfzh ) = 18 THEN
	substring( sfzh, 2, 17 ) ELSE sfzh 
	END AS ehrNum,
	NEWID() AS examinationId,
	org_code AS orgCode,
	NAME,
	guid AS empiGuid,
	1 AS isGovernance,
	dateadd (
		MINUTE,
		abs( CHECKSUM ( newid ( ) ) ) % ( datediff( MINUTE, @startTime, @endTime ) + 1 ),
		@startTime 
	) AS examinationDate,
	'01' AS symptomCode,
	'无症状' AS symptomName,
	cast( ( rand( ) * ( 37-36.5 ) + 36.5 ) AS DEC ( 14, 1 ) ) AS temperature,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 100+ 1-80 ) + 80 ) AS pulseRate,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 20+ 1-12 ) + 12 ) AS breathRate,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 90+ 1-60 ) + 60 ) AS rightDBP,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 120+ 1-90 ) + 90 ) AS rightSBP,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 90+ 1-60 ) + 60 ) AS leftDBP,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 120+ 1-90 ) + 90 ) AS leftSBP,
	cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 180+ 1-160 ) + 160 ) AS VARCHAR ( 10 ) ) + '.0' AS height,
	cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 60+ 1-45 ) + 45 ) AS VARCHAR ( 10 ) ) + '.' + cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 9+ 1-1 ) + 1 ) AS VARCHAR ( 10 ) ) AS weight,
	cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 85+ 1-60 ) + 60 ) AS VARCHAR ( 10 ) ) + '.0' AS waistline,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 2+ 1-1 ) + 1 ) AS oldAssessHealthCode,
	'1' AS oldCareAbilityCode,
	'可自理' AS oldCareAbilityName,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 3+ 1-2 ) + 2 ) AS exerciseFrequencyCode,
	( SELECT top 1 * FROM exerciseTimeList ORDER BY newid ( ) ) AS exerciseTime,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 5+ 1-1 ) + 1 ) AS exerciseDuration,
	( SELECT top 1 * FROM exerciseStyleList ORDER BY newid ( ) ) AS exerciseStyle,
	'1' AS eatingHabitsCode,
	'荤素均衡' AS eatingHabitsName,
	'1' AS smokingCode,
	'从不吸烟' AS smokingName,
	'1' AS drinkingFrequencyCode,
	'从不' AS drinkingFrequencyName,
	'1' AS osAppearanceCode,
	'红润' AS osAppearanceName,
	'1' AS dentitionCategoryCode,
	'正常' AS dentitionCategoryName,
	'1' AS throatCheckCode,
	'无充血' AS throatCheckName,
	cast( ( rand( ) * ( 5-4.5 ) + 4.5 ) AS DEC ( 14, 1 ) ) AS leftNakedEyesight,
	cast( ( rand( ) * ( 5-4.5 ) + 4.5 ) AS DEC ( 14, 1 ) ) AS rightNakedEyesight,
	'1' AS hearingCheckCode,
	'听见' AS hearingCheckName,
	'1' AS sportFunctionCode,
	'可顺利完成' AS sportFunctionName,
	'1' AS skinCheckCode,
	'正常' AS skinCheckName,
	'1' AS scleraCheckCode,
	'正常' AS scleraCheckName,
	'1' AS lymphCheckCode,
	'未触及' AS lymphCheckName,
	'1' AS barrelChestSign,
	'1' AS breathSoundsSign,
	'1' AS lungRalesCode,
	'无' AS lungRalesName,
	( abs( CHECKSUM ( NEWID ( ) ) ) % ( 100+ 1-80 ) + 80 ) AS heartRate,
	'1' AS heartRateTypeCode,
	'齐' AS heartRateTypeName,
	'1' AS heartMurmurSign,
	'1' AS abdomenTendernessSign,
	'1' AS abdomenBlockSign,
	'1' AS abdomenHepatomegalySign,
	'1' AS abdomenSplenomegalySign,
	'1' AS shiftingDullnessSign,
	'1' AS limbEdemaCode,
	'2' AS dorsalArteryOfFootCode,
	'触及双侧对称' AS dorsalArteryOfFootName,
	'1' AS cerebrovascularCode,
	'未发现' AS cerebrovascularName,
	'1' AS kidneyCode,
	'未发现' AS kidneyName,
	'1' AS heartCode,
	'未发现' AS heartName,
	'1' AS bloodVesselsCode,
	'未发现' AS bloodVesselsName,
	'1' AS eyeCode,
	'未发现' AS eyeName,
	'1' AS nervousSystemSign,
	'1' AS otherDiseasesSign 
FROM
	( SELECT sfzh, org_code FROM report_qyyh WHERE ( B3 - B4 ) > 0 and A4 = 1) a
	INNER JOIN tb_empi_index_root b ON a.sfzh = b.idcardNo; 
	
	-- 新增封面治理 --
-- INSERT INTO HrCover ( ehrNum, ArchiveNum, NAME, ArchiveUnitCode, ArchiverId, Archiver, ResponsibleDoctorId, ResponsibleDoctor, DateOfCreateArchive, isGovernance ) SELECT
-- CASE
-- 	
-- 	WHEN len ( sfzh ) = 18 THEN
-- 	substring( sfzh, 2, 17 ) ELSE sfzh 
-- 	END AS ehrNum,
-- sfzh,
-- JMXM,
-- org_code,
-- CZRYBM,
-- CZRYXM,
-- CZRYBM,
-- CZRYXM,
-- dateadd (
-- 	MINUTE,
-- 	abs( CHECKSUM ( newid ( ) ) ) % ( datediff( MINUTE, @startTime, @endTime ) + 1 ),
-- 	@startTime 
-- ),
-- 1 
-- FROM report_qyyh WHERE A4 = 0; 
-- 		-- 新增基本信息表治理 --
-- INSERT INTO HrPersonBasicInfo (
-- 	ArchiveNum,
-- 	NAME,
-- 	IdCard,
-- 	workUnit,
-- 	residenceType,
-- 	bloodType,
-- 	rhBloodType,
-- 	degree,
-- 	occupation,
-- 	maritalStatus,
-- 	EnvironmentKitchenAeration,
-- 	environmentFuelType,
-- 	environmentWater,
-- 	environmentToilet,
-- 	environmentCorral,
-- 	isGovernance 
-- ) SELECT
-- sfzh,
-- JMXM,
-- sfzh,
-- CASE
-- 		
-- 		WHEN dbo.Fn_GetAge ( sfzh, @endTime ) < 16 THEN
-- 		'不详' ELSE '无' 
-- 	END,
-- 	1,
-- 	5,
-- 	3,
-- 	90,
-- 	999,
-- 	90,
-- 	1,
-- 	3,
-- 	1,
-- 	1,
-- 	0,
-- 	1 
-- FROM report_qyyh WHERE A4 = 0; 
-- 
-- 	-- 一对多 支付方式
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'pay_method',
-- '01',
-- '城镇职工基本医疗保险' 
-- FROM 
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	-- 一对多 暴露史
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'history_of_exposure',
-- '1',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 既往史疾病
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'history_of_disease',
-- '01',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 手术
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'history_of_operation',
-- '2',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 外伤
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'history_of_trauma',
-- '2',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 输血
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'history_of_blood',
-- '2',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 既往史疾病父亲
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'family_history_of_father',
-- '01',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 既往史疾病母亲
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'family_history_of_mother',
-- '01',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 既往史疾病兄弟姐妹
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'family_history_of_siblings',
-- '01',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 既往史疾病子女
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'family_history_of_children',
-- '01',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 		-- 一对多 遗传病史
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'heredity_history',
-- '0',
-- '无' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
-- 	
-- 	-- 一对多 遗传病史
-- INSERT INTO HrAssociationInfo ( TableSource, Pid, AssociationType, CODE, Msg ) SELECT
-- 'HrPersonBasicInfo',
-- b.id,
-- 'disablity_type',
-- '01',
-- '无残疾' 
-- FROM
-- 	( SELECT * FROM report_qyyh WHERE A4 = 0) a
-- 	INNER JOIN HrPersonBasicInfo b ON a.sfzh = b.archiveNum;
END
go

