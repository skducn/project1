CREATE PROCEDURE [dbo].[getReportInfoByIdCardNo] @idCardNo VARCHAR (100),@visitDate Date
AS 
BEGIN 

   declare @empiGuid varchar(100)
    
  set @empiGuid = (select guid from tb_empi_index_root where idCardNo = @idCardNo)

  declare @count int 

  set @count =(select count(1) from tb_lis_report_indicator WHERE  empiGuid = @empiGuid  ) 

 IF(@count>0) 
 begin 


 IF OBJECT_ID( N'tempdb..#T', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T
    end 
  CREATE table #T (
   reportNo VARCHAR(100),
   orgCode varchar(100)
  )
    -- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index ON #T ( reportNo,orgCode)


INSERT INTO #T select reportNo,orgCode from tb_lis_report where empiGuid = @empiGuid
and reportDate BETWEEN DATEADD(month, -3, @visitDate)  and @visitDate


  
 IF OBJECT_ID( N'tempdb..#T1', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T1
    end 
  CREATE table #T1 (
  itemName varchar(50),
  resultValue varchar(50), 
  resultUnit varchar(50),
   reportNo VARCHAR(100),
   orgCode varchar(100)
  )
    -- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index ON #T1 ( reportNo,orgCode)


INSERT INTO #T1 select  itemName, resultValue, resultUnit,reportNo,orgCode from tb_lis_report_indicator where empiGuid = @empiGuid


select  itemName, resultValue, resultUnit from #T1 b 
INNER JOIN #T t ON b.reportNo =t.reportNo and b.orgCode=t.orgCode 

GROUP BY itemName, resultValue, resultUnit

drop table #T
drop table #T1
end
else 
begin
 select  itemName,  resultValue,  resultUnit from tb_lis_report_indicator where 1<>1
end


END
go

