CREATE PROCEDURE [dbo].[proc_ZKTypeTrendcount]
as
WITH a as (
    select top 1  substring (zksj , 1,4)+'-'+substring (zksj ,5,2)+'-'+substring (zksj ,7,2) as ControlTime,zkbm  from ZKJLB
    ORDER BY id DESC
),b as (
    select t3.value as ControlFields ,COUNT(value) as WrongNum,GETDATE() as 'CreateTime',0 as 'Symbol' from HrRuleRecord  t1
                                                                                                                LEFT JOIN HrRuleProps t2 on t1.RuleId = t2.RuleId
                                                                                                                LEFT JOIN HrRuleType t3 on t2.typeCode = t3.code
    GROUP BY t3.value
)
insert into ZKTypeTrend(ControlTime,ControlFields,WrongNum,createtime,Symbol,zkbm)
select a.ControlTime,b.*,a.zkbm from a,b
go

