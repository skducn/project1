CREATE PROCEDURE [dbo].[computeBasicData]
  @质控数据开始时间 varchar(20),
  @质控数据截止时间 varchar(20)
AS
BEGIN

/**
以人为维度，统计单个患者的指标，主要包括

https://www.yuque.com/docs/share/be941270-dbcf-41c7-afda-5fdb7d724ce5?#rf7C 《个人统计信息汇总表字段》

修改时间 2020-11-30   wuzhipeng
该表作为统计表，后面的报表数据指标统一从该表获取，防止数据不统一
*/

-- 档案封面字段总数
declare @A float=11
-- 个人基本信息表
declare @B float=38
-- 健康体检表
declare @C float=143
-- 高血压随访表
declare @D float=57
-- 糖尿病随访表
declare @E float=58

-- 记录 sql执行开始时间 和 耗时
declare @SQL开始执行时间 datetime
declare @耗时 int




-- 签约信息插入汇总表
set @SQL开始执行时间 = GETDATE()
truncate table report_qyyh
truncate table temp_tables
Insert into report_qyyh(CZRYBM, CZRYXM, sfzh, jmxm, org_code, org_code1, hr_service_code, org_name, dist_code,dist_name, update_date)
select isnull(CZRYBM, 'null')          CZRYBM,
       isnull(CZRYXM, 'null')          CZRYXM,
       isnull(sfzh, 'null')            sfzh,
       isnull(jmxm, 'null')            jmxm,
       isnull(ArchiveUnitCode, 'null') org_code,
       isnull(ArchiveUnitCode, 'null') org_code1,
       ''                              hr_service_code,
       ''                              org_name,
       ''                              dist_code,
       ''                              dist_name,
       @质控数据截止时间               update_date
from QYYH a
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print '签约信息插入汇总表' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- 删除最终报告中不属于社区机构的数据
delete
from report_qyyh
where org_code not in (select distinct cover_org_code from dict_org_info)

-- 更新机构信息数据
set @SQL开始执行时间 = GETDATE()
update a
set a.org_code=b.cover_org_code,
    a.org_name=b.org_name,
    a.dist_code=b.dist_code,
    a.dist_name=b.dist_name,
    a.live_people_num=b.live_people_num,
    a.registered_people_num=b.registered_people_num,
    a.old_people_65_num=b.old_people_65_num,
    a.old_people_60_num=b.old_people_60_num,
    a.hypertension_num=b.hypertension_num,
    a.diabetes_num=b.diabetes_num,
    a.child_num=b.child_num,
    a.pregnant_woman_num=b.pregnant_woman_num,
    a.tuberculosis_patients_num=b.tuberculosis_patients_num,
    a.family_planning_num=b.family_planning_num,
    a.handicapped_num=b.handicapped_num,
    a.difficult_people_num=b.difficult_people_num,
    a.psychogeny_patients_num=b.psychogeny_patients_num,
    a.hr_service_code=isnull(b.hr_service_code, '')
from report_qyyh a
INNER JOIN dict_org_info b ON a.org_code = b.cover_org_code
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print '更新机构信息数据' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh', GETDATE())




-- A4
-- 更新是否建档
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A4 = 1
where sfzh in (
    -- 0~6岁儿童有“新生儿访视服务记录表”能判断已建档
    select DISTINCT a.sfzh
    from QYYH a
    INNER JOIN tb_empi_index_root c ON a.SFZH = c.idCardNo
    INNER JOIN tb_dc_child_main_info d ON c.guid = d.empiGuid
    INNER JOIN tb_dc_child_newborn_visit e ON d.childMainId = e.childMainId
    where dbo.Fn_GetAge(a.SFZH, @质控数据截止时间) <= 6 and dbo.Fn_GetAge(a.SFZH, @质控数据截止时间) >= 0
    union all
    -- 同时有档案封面和个人基本信息表能判定已建档
  -- 必须是在签约机构建档的，因为存在签约机构 和建档 机构不一致
  -- 在 质控数据截止时间 之前建档
    select DISTINCT a.sfzh
    from QYYH a
    INNER JOIN HrCover b ON a.SFZH = b.ArchiveNum
    INNER JOIN HrPersonBasicInfo c ON b.ArchiveNum = c.ArchiveNum
    where 
      -- a.ArchiveUnitCode = b.ArchiveUnitCode and 
      b.DateOfCreateArchive BETWEEN '1900-01-01' and @质控数据截止时间
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A4)', GETDATE())


-- A412
-- 报告用是否建档，核心字段错误也计算为未建档
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A412 = 1
where A4 = 1 and sfzh not in (
		select ArchiveNum from 
			(select ArchiveNum,weight,count(1) as weightNum from 
				(select RuleId,weight from HrRule where (TargetTable='HrCover' or TargetTable='HrPersonBasicInfo') and weight = '1') a 
					inner join HrRuleRecord b 
					on a.RuleId = b.RuleId 
					group by ArchiveNum,weight) t 
					where weightNum > 0 group by ArchiveNum
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A412' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A412)', GETDATE())


-- A411 
-- 更新建档，签约机构与档案管理机构不一致
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A411 = 1
where sfzh in (
  -- 签约机构与档案管理机构不一致的
    select DISTINCT a.sfzh
    from QYYH a
    INNER JOIN HrCover b ON a.SFZH = b.ArchiveNum
    INNER JOIN HrPersonBasicInfo c ON b.ArchiveNum = c.ArchiveNum
    where 
      a.ArchiveUnitCode <> b.ArchiveUnitCode 
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A411' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A411)', GETDATE())


-- A5
-- 更新是否 ≥65岁老年人
-- 质控截止日期所在年份的1月1日
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A5 = 1
where dbo.Fn_GetAge(SFZH, dateadd(year, datediff(year, 0, @质控数据开始时间), 0)) >= 65
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A5' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A5)', GETDATE())






-- A6
-- 更新是否有高血压登记 visitTypeCode like '%31%'
-- 建档机构 必须是在 签约机构
-- 高血压的登记机构 必须是在 签约机构
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A6=1
where sfzh in (
    select DISTINCT b.idCardNo
    from HrCover a
    INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
    INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
    INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
		INNER JOIN report_qyyh e ON b.idcardNo = e.SFZH
    where 
      -- a.ArchiveUnitCode = e.org_code and 
		c.orgCode = e.org_code
			and d.orgCode = e.org_code
      and d.visitTypeCode like '%31%'
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A6' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A6)', GETDATE())







-- A7
-- 更新 是否有糖尿病登记 visitTypeCode like '%33%'
-- 建档机构 必须是在 签约机构
-- 糖尿病的登记机构 必须是在 签约机构
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A7 = 1
where sfzh in (
    select DISTINCT b.idCardNo
    from HrCover a
    INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
    INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
    INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
		INNER JOIN report_qyyh e ON e.sfzh = b.idcardNo 
		where 
      -- a.ArchiveUnitCode = e.org_code and 
	  d.orgCode = e.org_code
      and c.orgCode = e.org_code
      and d.visitTypeCode like '%33%'
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A7' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A7)', GETDATE())







-- A8
-- 更新 是否重点人群 签约居民中＜65岁，且无高血压和糖尿病登记的是【非重点人群】
-- 老人 都是重点人群
-- 小于65岁的有一部分是重点人群
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A8 = 1
where A5 = 1
OR (A5 = 0 and A6 = 1)
OR (A5 = 0 and A7 = 1)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A8' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A8)', GETDATE())






-- A10 
-- 是否有调阅记录。1年内签约居民建立了健康档案，并且有门诊记录或转诊记录的人数
-- （满足其中一项即存在健康档案调阅）
-- 1年内指从质控时间往前推算1年。
		-- 建档机构 必须是在 签约机构
		--  有门诊记录或转诊记录
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A10 = 1
where A4 = 1 and 
sfzh in (
    select DISTINCT hr.ArchiveNum
    from HrCover hr 
	  INNER JOIN report_qyyh rq ON hr.ArchiveNum = rq.SFZH
    where -- hr.ArchiveUnitCode = rq.org_code and 
		--hr.DateOfCreateArchive BETWEEN DATEADD(MM, -12, @质控数据截止时间) and @质控数据截止时间 and 
		ArchiveNum in (
					-- 查询门诊记录
					select DISTINCT b.idCardNo
					from tb_empi_index_root b
					INNER JOIN tb_his_op_medical_record c ON b.guid = c.empiGuid
					INNER JOIN report_qyyh d ON b.idcardNo = d.SFZH
					where 
						c.orgCode = d.org_code
						and c.visitTime BETWEEN DATEADD(MM, -12, @质控数据截止时间) and @质控数据截止时间
					union all
					-- 查询转诊记录
					select DISTINCT idCardNo
					from tb_referral_record e
					INNER JOIN report_qyyh f ON e.idCardNo = f.SFZH
					where 
						e.referralDate BETWEEN DATEADD(MM, -12, @质控数据截止时间) and  @质控数据截止时间
						and (e.transferInOrgCode = f.org_code or e.transferOutOrgCode = f.org_code)
				)	
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A10' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A10)', GETDATE())








-- A11 高血压患者血压控制是否满意
-- 数据截止时间前3个月范围内最近一次高血压随访记录中
-- 【(年龄＜65岁且收缩压＜140且舒张压＜90的人数）或者 （年龄≥65岁且收缩压＜150且舒张压＜90的）】
-- 高血压统计1，统计数据截止时间前3个月范围内，每个人的高血压情况
-- visitDate  随访日期,sbp 血压收缩压,dbp  血压舒张压
set @SQL开始执行时间 = GETDATE()
if OBJECT_ID('tempdb..##高血压统计1') is not null
drop table ##高血压统计1
select *
into ##高血压统计1
from 
(
 select b.idCardNo,
        e.cardId,
        e.orgCode,
        dbo.Fn_GetAge(b.idCardNo, dateadd(year, datediff(year, 0, @质控数据截止时间), 0)) age,
        e.visitDate,
        e.sbp,
        e.dbp
 from tb_empi_index_root b
 INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
 INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
 INNER JOIN tb_dc_htn_visit e ON d.visitNum = e.cardId
 where c.orgCode = d.orgCode
			and d.orgCode = e.orgCode
			and visitDate BETWEEN DATEADD(MM, -3, @质控数据截止时间) and @质控数据截止时间
      and d.visitTypeCode like '%31%'     
) temp


-- 根据 高血压统计1 的结果，按照 idCardNo 分组，
-- 按照 visitDate 排序，取到 3个月范围内最近一次高血压随访记录
if OBJECT_ID('tempdb..##高血压统计2') is not null
drop table ##高血压统计2
select *
into ##高血压统计2
from 
(
  select *
  From 
	(
		Select Row_Number() Over (Partition By [idCardNo] order By [visitDate] desc) As RowNumber, *
    From ##高血压统计1
	) T
  Where T.RowNumber = 1
) temp


-- 【(年龄＜65岁且收缩压＜140且舒张压＜90的人数）或者 （年龄≥65岁且收缩压＜150且舒张压＜90的）】
-- 并且 慢病的登记机构 必须是在 签约机构
update report_qyyh
set A11 = 1
where 
	A6 = 1
  and sfzh in 
						(
							select DISTINCT idCardNo
              from ##高血压统计2 a
							INNER JOIN report_qyyh b ON a.idCardNo = b.SFZH
              where 
								(age < 65 and sbp is not null and dbp is not null and CONVERT(float, sbp) < 140 and CONVERT(float, dbp) < 90 and a.orgCode = b.org_code)
                or 
								(age >= 65 and sbp is not null and dbp is not null and CONVERT(float, sbp) < 150 and CONVERT(float, dbp) < 90 and a.orgCode = b.org_code)
						)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A11' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A11)', GETDATE())











-- A12 糖尿病患者血糖控制是否满意。
-- 数据截止时间前3个月范围内，血糖值小于7mmol/L，则认为血糖控制满意
-- 糖尿病统计1，统计数据截止时间前3个月范围内，每个人的糖尿病情况
-- ##待补充##
set @SQL开始执行时间 = GETDATE()
if OBJECT_ID('tempdb..##糖尿病统计1') is not null
drop table ##糖尿病统计1
select *
into ##糖尿病统计1
from 
(
 select b.idCardNo,
        e.cardId,
        e.orgCode,
        dbo.Fn_GetAge(b.idCardNo, dateadd(year, datediff(year, 0, @质控数据截止时间), 0)) age,
        e.visitDate,
        -- 空腹血糖值
        e.fastingBloodSugarValue
  from tb_empi_index_root b
  INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
  INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
  INNER JOIN tb_dc_dm_visit e ON d.visitNum = e.cardId
  where c.orgCode = d.orgCode
	      and d.orgCode = e.orgCode
				and visitDate BETWEEN DATEADD(MM, -3, @质控数据截止时间) and @质控数据截止时间
        and d.visitTypeCode like '%33%' 
) temp


-- 根据 糖尿病统计1 的结果，按照 idCardNo 分组，按照 visitDate 排序，取到 3个月范围内最近一次糖尿病随访记录
if OBJECT_ID('tempdb..##糖尿病统计2') is not null
drop table ##糖尿病统计2
select *
into ##糖尿病统计2
from 
(
  select *
  From 
	(
		Select Row_Number() Over (Partition By [idCardNo] order By [visitDate] desc) As RowNumber, *
    From ##糖尿病统计1
	) T
  Where T.RowNumber = 1
) temp


update report_qyyh
set A12 = 1
where 
	A7 = 1
	and sfzh in 
						(
							select DISTINCT idCardNo
              from ##糖尿病统计2 a
							INNER JOIN report_qyyh b ON a.idCardNo = b.SFZH
              where 
								a.orgCode = b.org_code
								and CONVERT(float, a.fastingBloodSugarValue) < 7
                and a.fastingBloodSugarValue is not null
						)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A12' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(A12)', GETDATE())












-- A13 有门诊就诊记录或转诊记录、但记录不是签约居民管理机构的记录人数
							
							-- 建档机构 必须是在 签约机构，
							--  有门诊记录或转诊记录
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A13 = 1
where sfzh in 
						(
							select DISTINCT hr.ArchiveNum
							from HrCover hr
							INNER JOIN report_qyyh rq ON hr.ArchiveNum = rq.SFZH
							where
									--hr.ArchiveUnitCode = rq.org_code and 
									--hr.DateOfCreateArchive BETWEEN DATEADD(MM, -12, @质控数据截止时间) and  @质控数据截止时间 and 
									ArchiveNum in 
																	(
																		-- 查询门诊记录
																		select DISTINCT b.idCardNo
																		from tb_empi_index_root b
																		INNER JOIN tb_his_op_medical_record c ON b.guid = c.empiGuid
																		INNER JOIN report_qyyh d ON b.idcardNo = d.SFZH
																		where 
																					c.orgCode != d.org_code
																					and visitTime BETWEEN DATEADD(MM, -12, @质控数据截止时间) and @质控数据截止时间
																		union all
																		-- 查询转诊记录
																		select DISTINCT idCardNo
																		from tb_referral_record a
																		INNER JOIN report_qyyh b ON a.idCardNo = b.SFZH  
																		where a.referralDate BETWEEN DATEADD(MM, -12, @质控数据截止时间) and @质控数据截止时间
																					and a.transferInOrgCode != b.org_code 
																					and a.transferOutOrgCode != b.org_code
																	)
						)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A13' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'



-- A14
-- 更新是否 ≥60岁老年人
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A14 = 1
where dbo.Fn_GetAge(SFZH, dateadd(year, datediff(year, 0, @质控数据截止时间), 0)) >= 60
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A14' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'



-- 更新是否 0~6岁儿童
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A15 = 1
where dbo.Fn_GetAge(SFZH, @质控数据截止时间) <= 6
  and dbo.Fn_GetAge(SFZH, @质控数据截止时间) >= 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A15' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 更新是否 0~3岁儿童
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A16 = 1
where A15 = 1 and dbo.Fn_GetAge(SFZH, @质控数据截止时间) < 3
  and dbo.Fn_GetAge(SFZH, @质控数据截止时间) >= 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A16' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 更新是否 3~6岁儿童
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A17 = 1
where A15 = 1 and dbo.Fn_GetAge(SFZH, @质控数据截止时间) <= 6
  and dbo.Fn_GetAge(SFZH, @质控数据截止时间) >= 3
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A17' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 是否有儿童登记
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A18 = 1
where A15 = 1 and sfzh in (
    select a.idCardNo
    from tb_empi_index_root a 
		inner join tb_dc_child_main_info b 
		on a.guid = b.empiGuid 
		group by a.idCardNo
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A18' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 是否有儿童体检
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A19 = 1
where A15 = 1 and sfzh in (
    select a.idCardNo
    from tb_empi_index_root a 
		inner join tb_dc_child_main_info b 
		on a.guid = b.empiGuid 
		inner join tb_dc_child_examination c 
		on b.childMainId = c.childMainId
		group by a.idCardNo
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A19' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- 是否有孕妇登记
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A20 = 1
where sfzh in (
    select a.idCardNo
    from tb_empi_index_root a 
		inner join tb_dc_pregnant_main_info b 
		on a.guid = b.empiGuid 
		group by a.idCardNo
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A20' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'



-- R1 签约居民中≥65岁老年人，且无高血压和糖尿病登记（R1)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R1=1
where A5 = 1
  and A6 = 0
  and A7 = 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R1' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(R1)', GETDATE())


--  签约居民中≥65岁老年人，且同时有高血压和糖尿病登记（R2)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R2=1
where A5 = 1
  and A6 = 1
  and A7 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(R2)', GETDATE())


-- 签约居民中≥65岁老年人，有高血压，无糖尿病登记（R3)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R3=1
where A5 = 1
  and A6 = 1
  and A7 = 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R3' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 签约居民中≥65岁老年人，无高血压，有糖尿病登记（R4)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R4=1
where A5 = 1
  and A6 = 0
  and A7 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(R4)', GETDATE())


-- 签约居民中＜65岁，且无高血压和糖尿病登记（R5)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R5=1
where A5 = 0
  and A6 = 0
  and A7 = 0

set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R5' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 签约居民中＜65岁，且同时有高血压和糖尿病登记（R6)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R6=1
where A5 = 0
  and A6 = 1
  and A7 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R6' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(R6)', GETDATE())


-- 签约居民中＜65岁，有高血压，无糖尿病登记（R7)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R7=1
where A5 = 0
  and A6 = 1
  and A7 = 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R7' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 签约居民中＜65岁，无高血压，有糖尿病登记（R8)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set R8=1
where A5 = 0
  and A6 = 0
  and A7 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'R8' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(R8)', GETDATE())


-- B1	封面表 理论张数
-- 全部人群都需要有一张封面表
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B1' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(B1)', GETDATE())







-- B2	封面表 实际张数
-- 必须是在签约机构建档的，因为存在签约机构 和建档 机构不一致
-- 在 质控数据截止时间 之前建档
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B2 = 1
where A4 = 1 and
sfzh in 
			(
			 select DISTINCT ArchiveNum
       from HrCover a
       where 
			 --a.ArchiveUnitCode = report_qyyh.org_code and 
			 a.DateOfCreateArchive BETWEEN '1900-01-01' and @质控数据截止时间
			)

set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(B2)', GETDATE())











-- B3	健康体检表理论张数
-- 只算签约居民中>=65岁】 这部分人群以外的其他人群，都需要有一张 健康体检表
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B3 = 1
where R1 = 1 or R2 = 1 or R3 = 1 or R4 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B3' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(B3)', GETDATE())






-- B4	健康体检表实际张数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B4 = (
					select count(*)
					from tb_dc_examination_info t
          INNER JOIN tb_empi_index_root t1 ON t.empiGuid = t1.guid
          INNER JOIN HrCover t2 ON t2.archiveNum = t1.idcardNo
					where 
					  report_qyyh.A4 = 1 
						and t.orgCode = report_qyyh.org_code
						-- and t2.ArchiveUnitCode = report_qyyh.org_code
						and t1.idCardNo = report_qyyh.sfzh
						and t.examinationDate BETWEEN @质控数据开始时间 and @质控数据截止时间
						and t2.DateOfCreateArchive BETWEEN '1900-01-01' and @质控数据截止时间
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'





-- B5	高血压随访表理论张数
-- set @SQL开始执行时间 = GETDATE()
-- update report_qyyh
-- set B5 = isnull(
-- 								(select top 1
-- 												 datediff(day, case when d.registTime < @质控数据开始时间 or d.registTime is null then @质控数据开始时间 else d.registTime end, @质控数据截止时间) / 90
-- 								 from HrCover a
-- 								 INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
-- 								 INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
-- 								 INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
-- 								 where 
-- 									 --a.ArchiveUnitCode = report_qyyh.org_code and 
-- 									 report_qyyh.SFZH = b.idCardNo
-- 									 and c.orgCode = d.orgCode
-- 									 and d.visitTypeCode like '%31%'
-- 								), 0)
-- set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
-- print 'B5' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'









-- B6	高血压随访表实际张数
-- 高血压的登记机构 必须是在 签约机构
-- 高血压的登记机构 必须是在 签约机构
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B6 = (
					select count(*)
					from HrCover a
					INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
					INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
					INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
					INNER JOIN tb_dc_htn_visit e ON d.visitNum = e.cardId
					where
						report_qyyh.A4 = 1	
						and report_qyyh.SFZH = b.idCardNo
						-- and a.ArchiveUnitCode = report_qyyh.org_code
						and c.orgCode = report_qyyh.org_code
						and d.orgCode = report_qyyh.org_code
						and e.orgCode = report_qyyh.org_code
						and d.visitTypeCode like '%31%'
						and e.visitDate >= @质控数据开始时间
          				and e.visitDate <= @质控数据截止时间

					)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B6' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(B6)', GETDATE())








-- B7	糖尿病随访表理论张数
-- set @SQL开始执行时间 = GETDATE()
-- update report_qyyh
-- set B7 = isnull(
-- 								(
-- 								 select top 1
-- 												 datediff(day, case when d.registTime < @质控数据开始时间 or d.registTime is null then @质控数据开始时间 else d.registTime end, @质控数据截止时间) / 90
-- 								 from HrCover a
-- 								 INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
-- 								 INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
-- 								 INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
-- 								 where 
-- 								   report_qyyh.SFZH = b.idCardNo 
-- 									 -- and a.ArchiveUnitCode = report_qyyh.org_code
-- 									 and c.orgCode = d.orgCode
-- 									 and d.visitTypeCode like '%33%'
-- 								), 0)
-- set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
-- print 'B7' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'





-- B8	糖尿病随访表实际张数
-- 糖尿病的登记机构 必须是在 签约机构
-- 糖尿病的登记机构 必须是在 签约机构
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B8 = 
(
	select count(*)
  from HrCover a
  INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
  INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
  INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
  INNER JOIN tb_dc_dm_visit e ON d.visitNum = e.cardId
  where 
				report_qyyh.A4 = 1
				and report_qyyh.SFZH = b.idCardNo
        -- and a.ArchiveUnitCode = report_qyyh.org_code
        and c.orgCode = report_qyyh.org_code
        and d.orgCode = report_qyyh.org_code
				and e.orgCode = report_qyyh.org_code
				and e.visitDate BETWEEN @质控数据开始时间 and @质控数据截止时间
        and d.visitTypeCode like '%33%'  
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B8' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'









-- B9   基本信息表理论张数
-- 全部人群都需要有一张基本信息表
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B9 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B9' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'




-- B10  基本信息表实际张数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set B10 = 1
where A4 = 1 
and sfzh in 
(
	select DISTINCT a.ArchiveNum
  from HrCover a
  INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
  where 
  -- a.ArchiveUnitCode = report_qyyh.org_code and 
  a.DateOfCreateArchive BETWEEN '1900-01-01' and @质控数据截止时间
)  
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'B10' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(B10)', GETDATE())






END
go

