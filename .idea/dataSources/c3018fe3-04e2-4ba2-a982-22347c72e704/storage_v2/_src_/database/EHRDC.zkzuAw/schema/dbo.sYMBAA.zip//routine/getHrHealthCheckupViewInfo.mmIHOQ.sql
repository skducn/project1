CREATE PROCEDURE [dbo].[getHrHealthCheckupViewInfo]
	-- Add the parameters for the stored procedure here
	@targetFiled varchar(250),
	@archiveNum varchar(250),
	@idOfTargetTable varchar(250)
AS
BEGIN
 DECLARE @maxId varchar(50);
 set @maxId= (select max(id) id  from backup_history);
 DECLARE @SqlStr nvarchar(max) ='';

 set @SqlStr ='select ['+@targetFiled+'] from (SELECT 
	HrPersonBasicInfo.IdCard AS "HrPersonBasicInfo.ArchiveNum",
	tb_dc_examination_info.guid AS "HrHealthCheckup.guid",
	tb_dc_examination_exposure.exposureOccupation "tb_dc_examination_exposure.exposureOccupation",
	tb_dc_examination_exposure.exposureRiskTypeCode "tb_dc_examination_exposure.exposureRiskTypeCode",
	tb_dc_examination_exposure.exposureRiskTypeName "tb_dc_examination_exposure.exposureRiskTypeName",
	tb_dc_examination_exposure.exposureWorkingTime "tb_dc_examination_exposure.exposureWorkingTime",
	tb_dc_examination_exposure.protectiveMeasures "tb_dc_examination_exposure.protectiveMeasures",
	tb_dc_examination_family_history.buildBedDate "tb_dc_examination_family_history.buildBedDate",
	tb_dc_examination_family_history.buildOrgName "tb_dc_examination_family_history.buildOrgName",
	tb_dc_examination_family_history.reason "tb_dc_examination_family_history.reason",
	tb_dc_examination_family_history.recordNum "tb_dc_examination_family_history.recordNum",
	tb_dc_examination_family_history.removeBedDate "tb_dc_examination_family_history.removeBedDate",
	tb_dc_examination_immunization.vaccinationDate "tb_dc_examination_immunization.vaccinationDate",
	tb_dc_examination_immunization.vaccineName "tb_dc_examination_immunization.vaccineName",
	tb_dc_examination_immunization.vaccineOrgName "tb_dc_examination_immunization.vaccineOrgName",
	tb_dc_examination_info.abdomenBlockSign "tb_dc_examination_info.abdomenBlockSign",
	tb_dc_examination_info.abdomenHepatomegalySign "tb_dc_examination_info.abdomenHepatomegalySign",
	tb_dc_examination_info.abdomenSplenomegalySign "tb_dc_examination_info.abdomenSplenomegalySign",
	tb_dc_examination_info.abdomenTendernessSign "tb_dc_examination_info.abdomenTendernessSign",
	HrPersonBasicInfo.IdCard "tb_dc_examination_info.ArchiveNum",
	tb_dc_examination_info.attachmentAbnormalSign "tb_dc_examination_info.attachmentAbnormalSign",
	tb_dc_examination_info.auxiliaryCheckOther "tb_dc_examination_info.auxiliaryCheckOther",
	tb_dc_examination_info.barrelChestSign "tb_dc_examination_info.barrelChestSign",
	tb_dc_examination_info.bld "tb_dc_examination_info.bld",
	tb_dc_examination_info.bloodUrea "tb_dc_examination_info.bloodUrea",
	tb_dc_examination_info.BMI "tb_dc_examination_info.BMI",
	tb_dc_examination_info.breathRate "tb_dc_examination_info.breathRate",
	tb_dc_examination_info.breathSoundsSign "tb_dc_examination_info.breathSoundsSign",
	tb_dc_examination_info.BscanAbnormalSign "tb_dc_examination_info.BscanAbnormalSign",
	tb_dc_examination_info.cervixAbnormalSign "tb_dc_examination_info.cervixAbnormalSign",
	tb_dc_examination_info.checkOther "tb_dc_examination_info.checkOther",
	tb_dc_examination_info.cholesterolTotal "tb_dc_examination_info.cholesterolTotal",
	tb_dc_examination_info.dailyDrinking "tb_dc_examination_info.dailyDrinking",
	tb_dc_examination_info.dailySmoking "tb_dc_examination_info.dailySmoking",
	tb_dc_examination_info.dentitionCategoryCode "tb_dc_examination_info.dentitionCategoryCode",
	tb_dc_examination_info.docName "tb_dc_examination_info.docName",
	tb_dc_examination_info.dorsalArteryOfFootCode "tb_dc_examination_info.dorsalArteryOfFootCode",
	tb_dc_examination_info.drinkingFrequencyCode "tb_dc_examination_info.drinkingFrequencyCode",
	tb_dc_examination_info.drinkingTypeCode "tb_dc_examination_info.drinkingTypeCode",
	tb_dc_examination_info.eatingHabitsCode "tb_dc_examination_info.eatingHabitsCode",
	tb_dc_examination_info.ECGAbnormalSign "tb_dc_examination_info.ECGAbnormalSign",
	convert(varchar(10),tb_dc_examination_info.examinationDate,120)
	"tb_dc_examination_info.examinationDate",
	tb_dc_examination_info.exerciseDuration "tb_dc_examination_info.exerciseDuration",
	tb_dc_examination_info.exerciseFrequencyCode "tb_dc_examination_info.exerciseFrequencyCode",
	tb_dc_examination_info.exerciseTime "tb_dc_examination_info.exerciseTime",
	tb_dc_examination_info.fastingBloodGlucose1 "tb_dc_examination_info.fastingBloodGlucose1",
	tb_dc_examination_info.fecalOccultBlood "tb_dc_examination_info.fecalOccultBlood",
	tb_dc_examination_info.fingerAnusCode "tb_dc_examination_info.fingerAnusCode",
	tb_dc_examination_info.fundusAbnormalSign "tb_dc_examination_info.fundusAbnormalSign",
	tb_dc_examination_info.galactophoreCheckCode "tb_dc_examination_info.galactophoreCheckCode",
	tb_dc_examination_info.glycosylatedHemoglobin "tb_dc_examination_info.glycosylatedHemoglobin",
	tb_dc_examination_info.hbsag "tb_dc_examination_info.hbsag",
	tb_dc_examination_info.healthAssessAbnormalSign "tb_dc_examination_info.healthAssessAbnormalSign",
	tb_dc_examination_info.healthGuidanceCode "tb_dc_examination_info.healthGuidanceCode",
	tb_dc_examination_info.hearingCheckCode "tb_dc_examination_info.hearingCheckCode",
	tb_dc_examination_info.heartMurmurSign "tb_dc_examination_info.heartMurmurSign",
	tb_dc_examination_info.heartRate "tb_dc_examination_info.heartRate",
	tb_dc_examination_info.heartRateTypeCode "tb_dc_examination_info.heartRateTypeCode",
	tb_dc_examination_info.height "tb_dc_examination_info.height",
	tb_dc_examination_info.hemameba "tb_dc_examination_info.hemameba",
	tb_dc_examination_info.hemoglobin "tb_dc_examination_info.hemoglobin",
	tb_dc_examination_info.isDrunkYear "tb_dc_examination_info.isDrunkYear",
	tb_dc_examination_info.isQuitDrinking "tb_dc_examination_info.isQuitDrinking",
	tb_dc_examination_info.leftCorrectionEyesight "tb_dc_examination_info.leftCorrectionEyesight",
	cast(tb_dc_examination_info.leftSBP as varchar)+''/''+cast(tb_dc_examination_info.leftDBP as varchar) "tb_dc_examination_info.leftDBP",
	tb_dc_examination_info.leftNakedEyesight "tb_dc_examination_info.leftNakedEyesight",
	tb_dc_examination_info.limbEdemaCode "tb_dc_examination_info.limbEdemaCode",
	tb_dc_examination_info.lungRalesCode "tb_dc_examination_info.lungRalesCode",
	tb_dc_examination_info.lymphCheckCode "tb_dc_examination_info.lymphCheckCode",
	tb_dc_examination_info.microalbuminuria "tb_dc_examination_info.microalbuminuria",
	tb_dc_examination_info.oldAssessHealthCode "tb_dc_examination_info.oldAssessHealthCode",
	tb_dc_examination_info.oldCareAbilityCode "tb_dc_examination_info.oldCareAbilityCode",
	tb_dc_examination_info.oldCognitiveCode "tb_dc_examination_info.oldCognitiveCode",
	tb_dc_examination_info.oldEmotionalStateCode "tb_dc_examination_info.oldEmotionalStateCode",
	tb_dc_examination_info.osAppearanceCode "tb_dc_examination_info.osAppearanceCode",
	tb_dc_examination_info.otherDiseasesSign "tb_dc_examination_info.otherDiseasesSign",
	tb_dc_examination_info.papSmearAbnormalSign "tb_dc_examination_info.papSmearAbnormalSign",
	tb_dc_examination_info.platelet "tb_dc_examination_info.platelet",
	tb_dc_examination_info.pulseRate "tb_dc_examination_info.pulseRate",
	tb_dc_examination_info.quitDrinkingAge "tb_dc_examination_info.quitDrinkingAge",
	tb_dc_examination_info.quitSmokingAge "tb_dc_examination_info.quitSmokingAge",
	tb_dc_examination_info.registerTypeCode "tb_dc_examination_info.registerTypeCode",
	tb_dc_examination_info.rightCorrectionEyesight "tb_dc_examination_info.rightCorrectionEyesight",
	cast (tb_dc_examination_info.rightSBP as varchar)+''/''+cast(tb_dc_examination_info.rightDBP as varchar) "tb_dc_examination_info.rightDBP",
	tb_dc_examination_info.rightNakedEyesight "tb_dc_examination_info.rightNakedEyesight",
	tb_dc_examination_info.scleraCheckCode "tb_dc_examination_info.scleraCheckCode",
	tb_dc_examination_info.scr "tb_dc_examination_info.scr",
	tb_dc_examination_info.serumHighDensity "tb_dc_examination_info.serumHighDensity",
	tb_dc_examination_info.serumLowDensity "tb_dc_examination_info.serumLowDensity",
	tb_dc_examination_info.sgot "tb_dc_examination_info.sgot",
	tb_dc_examination_info.sgpt "tb_dc_examination_info.sgpt",
	tb_dc_examination_info.shiftingDullnessSign "tb_dc_examination_info.shiftingDullnessSign",
	tb_dc_examination_info.skinCheckCode "tb_dc_examination_info.skinCheckCode",
	tb_dc_examination_info.smokingCode "tb_dc_examination_info.smokingCode",
	tb_dc_examination_info.sportFunctionCode "tb_dc_examination_info.sportFunctionCode",
	tb_dc_examination_info.startDrinkingAge "tb_dc_examination_info.startDrinkingAge",
	tb_dc_examination_info.startSmokingAge "tb_dc_examination_info.startSmokingAge",
	tb_dc_examination_info.symptomCode "tb_dc_examination_info.symptomCode",
	tb_dc_examination_info.temperature "tb_dc_examination_info.temperature",
	tb_dc_examination_info.throatCheckCode "tb_dc_examination_info.throatCheckCode",
	tb_dc_examination_info.totalBilirubin "tb_dc_examination_info.totalBilirubin",
	tb_dc_examination_info.triglyceride "tb_dc_examination_info.triglyceride",
	tb_dc_examination_info.urineAcetoneBodies "tb_dc_examination_info.urineAcetoneBodies",
	tb_dc_examination_info.urineProtein "tb_dc_examination_info.urineProtein",
	tb_dc_examination_info.urineSugar "tb_dc_examination_info.urineSugar",
	tb_dc_examination_info.uterusAbnormalSign "tb_dc_examination_info.uterusAbnormalSign",
	tb_dc_examination_info.vaginalAbnormalSign "tb_dc_examination_info.vaginalAbnormalSign",
	tb_dc_examination_info.vulvaAbnormalSign "tb_dc_examination_info.vulvaAbnormalSign",
	tb_dc_examination_info.waistline "tb_dc_examination_info.waistline",
	tb_dc_examination_info.weight "tb_dc_examination_info.weight",
	tb_dc_examination_info.XrayAbnormalSign "tb_dc_examination_info.XrayAbnormalSign",
	tb_dc_examination_ip_history.admissionDate "tb_dc_examination_ip_history.admissionDate",
	tb_dc_examination_ip_history.admissionOrgName "tb_dc_examination_ip_history.admissionOrgName",
	tb_dc_examination_ip_history.leaveDate "tb_dc_examination_ip_history.leaveDate",
	tb_dc_examination_ip_history.reason "tb_dc_examination_ip_history.reason",
	tb_dc_examination_ip_history.recordNum "tb_dc_examination_ip_history.recordNum",
	tb_dc_examination_info.name "tb_dc_examination_info.name",
	tb_dc_examination_info.bloodVesselsCode "tb_dc_examination_info.bloodVesselsCode",
	tb_dc_examination_info.ehrNum "tb_dc_examination_info.ehrNum",
	tb_dc_examination_info.cerebrovascularCode "tb_dc_examination_info.cerebrovascularCode",
	tb_dc_examination_info.eyeCode "tb_dc_examination_info.eyeCode",
	tb_dc_examination_info.heartCode "tb_dc_examination_info.heartCode",
	tb_dc_examination_info.kidneyCode "tb_dc_examination_info.kidneyCode",
	tb_dc_examination_info.nervousSystemSign "tb_dc_examination_info.nervousSystemSign",
	tb_dc_examination_info.exerciseStyle "tb_dc_examination_info.exerciseStyle",
	tb_empi_index_root.name "tb_empi_index_root.name",
	tb_dc_examination_info.albumin "tb_dc_examination_info.albumin",
	tb_dc_examination_info.conjugatedBilirubin "tb_dc_examination_info.conjugatedBilirubin",
	tb_dc_examination_info.bloodPotassiumConcentratio "tb_dc_examination_info.bloodPotassiumConcentratio",
	tb_dc_examination_info.bloodSodiumConcentration "tb_dc_examination_info.bloodSodiumConcentration"
FROM
	tb_dc_examination_info_third_'+@maxId+' tb_dc_examination_info
	LEFT JOIN tb_empi_index_root_third_'+@maxId+'  tb_empi_index_root   ON tb_dc_examination_info.empiGuid = tb_empi_index_root.guid
	LEFT JOIN HrPersonBasicInfo_third_'+@maxId+'  HrPersonBasicInfo ON tb_empi_index_root.idCardNo = HrPersonBasicInfo.idCard
	LEFT JOIN tb_dc_examination_ip_history_third_'+@maxId+'  tb_dc_examination_ip_history ON tb_dc_examination_ip_history.orgCode = tb_dc_examination_info.orgCode 
	AND tb_dc_examination_ip_history.examinationId = tb_dc_examination_info.examinationId
	LEFT JOIN tb_dc_examination_family_history_third_'+@maxId+'  tb_dc_examination_family_history ON tb_dc_examination_family_history.orgCode = tb_dc_examination_info.orgCode 
	AND tb_dc_examination_family_history.examinationId = tb_dc_examination_info.examinationId
	LEFT JOIN tb_dc_examination_exposure_third_'+@maxId+'   tb_dc_examination_exposure ON tb_dc_examination_exposure.orgCode = tb_dc_examination_info.orgCode 
	AND tb_dc_examination_exposure.examinationId = tb_dc_examination_info.examinationId
	LEFT JOIN tb_dc_examination_immunization_third_'+@maxId+'  tb_dc_examination_immunization ON tb_dc_examination_immunization.orgCode = tb_dc_examination_info.orgCode 
	AND tb_dc_examination_immunization.examinationId = tb_dc_examination_info.examinationId 
	where HrPersonBasicInfo.ArchiveNum ='''+@archiveNum+'''and tb_dc_examination_info.guid='''+@idOfTargetTable+''' ) a '

	exec(@SqlStr)
	

END
go

