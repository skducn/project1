CREATE FUNCTION [dbo].[GetAllMonths](@startDate varchar(20),@endDate varchar(20))
    returns @r table(month varchar(20))
AS
BEGIN
    if LEN(@startDate)=7
        set @startDate = @startDate+'-01'

    if LEN(@endDate)=7
        set @endDate = @endDate+'-01'
    insert @r SELECT CONVERT(NVARCHAR(7),DATEADD(MONTH,number,@startDate),120) month
    FROM master..spt_values
    WHERE TYPE = 'p'
      AND CONVERT(nvarchar(10),dateadd(MONTH,number,@startDate),120)<=@endDate
    return
END
go

