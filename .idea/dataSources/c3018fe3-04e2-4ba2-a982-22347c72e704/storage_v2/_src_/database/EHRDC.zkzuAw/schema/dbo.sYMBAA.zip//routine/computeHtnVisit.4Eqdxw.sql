CREATE PROCEDURE [dbo].[computeHtnVisit]
  @质控数据开始时间 AS varchar(20), 
  @质控数据截止时间 AS varchar(20) 
AS
BEGIN

  /**
  1. 理论随访次数
  2. 实际随访次数
  3. 实际有效随访次数
  4. 第1次随访标志
  5. 第1次随访时间范围
  6. 第2次随访标志
  7. 第2次随访时间范围
  8. 第3次随访标志
  9. 第3次随访时间范围
  10. 第4次随访标志
  11. 第4次随访时间范围
 */

--  5005672691  310110193604010010  左*煦

/**
  1. 先确定第一次随访时间 和 时间范围
 */

truncate table temp_高血压随访次数统计

INSERT into temp_高血压随访次数统计(archive_num, target_time, index_time)
select sfzh, B5 '高血压理论张数', 0
from report_qyyh
where A6 = 1
-- and sfzh = '310110193604010010'


-- 随访信息临时表
-- 高血压的登记机构 必须是在 签约机构
if OBJECT_ID('tempdb..##高血压随访信息') is not null
    drop table ##高血压随访信息
select *
into ##高血压随访信息
from (
         select a.archiveNum, e.visitDate, d.registTime
         from HrCover a
              INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
              INNER JOIN tb_dc_chronic_info c ON b.guid = c.empiGuid
              INNER JOIN tb_dc_chronic_main d ON c.manageNum = d.manageNum
              INNER JOIN tb_dc_htn_visit e ON d.visitNum = e.cardId
              INNER JOIN report_qyyh f ON a.archiveNum = f.SFZH
         where f.A4 = 1
           and c.orgCode = a.ArchiveUnitCode
           and d.orgCode = a.ArchiveUnitCode
           and e.orgCode = a.ArchiveUnitCode
					 -- and f.org_code = a.ArchiveUnitCode
					 and d.visitTypeCode like '%31%'
         -- and sfzh = '310110193604010010'
     ) temp


/**
  计算第1次随访
 */

-- 插入第1次随访基础数据
insert into temp_高血压随访次数统计(archive_num, target_time, visit_date, irregular_visit_date, start_date, end_date, index_time)
select archive_num, target_time, null, null, null start_date, null end_date, 1 index_time
from temp_高血压随访次数统计 a
where a.index_time = 0


-- 更新 第1次有随访的开始时间、截止时间
update temp_高血压随访次数统计
set start_date = (case
                      when b.registTime < @质控数据开始时间 or b.registTime is null 
											then @质控数据开始时间
                      else b.registTime 
									end),
    end_date   = DATEADD(DD, 90 + 14, (case
                                           when b.registTime < @质控数据开始时间 or b.registTime is null 
																					 then @质控数据开始时间
                                           else b.registTime 
																			end))
from temp_高血压随访次数统计 a
     INNER JOIN ##高血压随访信息 b ON a.archive_num = b.ArchiveNum
where a.index_time = 1


-- 更新 第1次 实际随访时间
update temp_高血压随访次数统计
set visit_date = a.visitDate
from (select a.ArchiveNum     ArchiveNum,
             max(a.visitDate) visitDate
      from ##高血压随访信息 a
           INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
      where b.index_time = 1
        and a.visitDate >= b.start_date
        and a.visitDate <= b.end_date
      group by a.ArchiveNum
     ) a
     INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
where b.index_time = 1


-- 更新第一次 无随访的时候，预计的开始时间 和截止时间
-- visit_date_1 is null,就是没有匹配到第一次随访记录

update temp_高血压随访次数统计
set start_date= (case
                     when b.registTime < @质控数据开始时间 or b.registTime is null 
										 then @质控数据开始时间
                     else b.registTime 
								 end),
    end_date=DATEADD(DD, 90, (case
                                  when b.registTime < @质控数据开始时间 or b.registTime is null 
																	then @质控数据开始时间
                                  else b.registTime 
															end))
from temp_高血压随访次数统计 a
     INNER JOIN ##高血压随访信息 b ON a.archive_num = b.ArchiveNum
where visit_date is null
      and a.index_time = 1


/**
  计算第2次随访
 */

/**
 先计算第二次有效随访的开始时间  和 结束 时间
  情况1： 第一次无随访，开始时间=end_date_1  结束时间=end_date_1+90
  情况2： 第一次有随访，开始时间要从实际随访时间开始计算，开始时间= visit_date_1+90-14,结束时间=visit_date_1+90+14
*/


-- 插入第二次随访基础数据
insert into temp_高血压随访次数统计(archive_num, target_time, visit_date, irregular_visit_date, start_date, end_date, index_time)
select archive_num, target_time, null, null, null start_date, null end_date, 2 index_time
from temp_高血压随访次数统计 a
where a.index_time = 0


-- 情况1： 第一次无随访

/*
update temp_高血压随访次数统计
set start_date_2=end_date_1,
    end_date_2=DATEADD(DD, 90, end_date_1)
where visit_date_1 is null
*/

update now
set now.start_date = last.end_date,
    now.end_date = DATEADD(DD, 90, last.end_date)
from temp_高血压随访次数统计 last
     INNER JOIN temp_高血压随访次数统计 now ON last.archive_num = now.archive_num
where last.index_time = 1
  and now.index_time = 2
  and last.visit_date is null


-- 情况2： 第一次有随访
/*
update temp_高血压随访次数统计
set start_date_2=DATEADD(DD, 90 - 14, visit_date_1),
    end_date_2=DATEADD(DD, 90 + 14, visit_date_1)
where visit_date_1 is not null
*/

update now
set now.start_date = DATEADD(DD, 90 - 14, last.visit_date),
    now.end_date = DATEADD(DD, 90 + 14, last.visit_date)
from temp_高血压随访次数统计 last
     INNER JOIN temp_高血压随访次数统计 now ON last.archive_num = now.archive_num
where last.index_time = 1
  and now.index_time = 2
  and last.visit_date is not null


/**
 更新 第2次有效随访的随访时间
 */

update temp_高血压随访次数统计
set visit_date= a.visitDate
from (select a.ArchiveNum     ArchiveNum,
             max(a.visitDate) visitDate
      from ##高血压随访信息 a
           INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
      where a.visitDate >= b.start_date
        and a.visitDate <= b.end_date
        and b.index_time = 2
      group by a.ArchiveNum
     ) a
     INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
where b.index_time = 2

/**
 更新 第2次无效随访的随访时间
  时间范围  开始时间=end_date_1   结束时间=start_date_2
 */

update temp_高血压随访次数统计
set irregular_visit_date= a.visitDate
from (select a.ArchiveNum     ArchiveNum,
             max(a.visitDate) visitDate
      from ##高血压随访信息 a
           INNER JOIN temp_高血压随访次数统计 last ON last.archive_num = a.ArchiveNum
           INNER JOIN temp_高血压随访次数统计 now ON last.archive_num = now.archive_num
      where last.index_time = 1
        and now.index_time = 2
        and a.visitDate >= last.end_date
        and a.visitDate <= now.start_date
      group by a.ArchiveNum
     ) a
     INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
where b.index_time = 2


/**
  计算第3次随访
 */

/**
 先计算第3次有效随访的开始时间  和 结束 时间
  情况1： 上一次无随访， 开始时间=end_date_2  结束时间=end_date_2+90
  情况2： 第一次有随访（包括有效随访和 无效随访），开始时间要从实际随访时间开始计算，开始时间= visit_date_1+90-14,结束时间=visit_date_1+90+14
*/

-- 插入第3次随访基础数据
insert into temp_高血压随访次数统计(archive_num, target_time, visit_date, irregular_visit_date, start_date, end_date, index_time)
select archive_num, target_time, null, null, null start_date, null end_date, 3 index_time
from temp_高血压随访次数统计 a
where a.index_time = 0


-- 情况1： 上次无随访

update now
set now.start_date=last.end_date,
    now.end_date=DATEADD(DD, 90, last.end_date)
from temp_高血压随访次数统计 last
     INNER JOIN temp_高血压随访次数统计 now ON last.archive_num = now.archive_num
where last.index_time = 2
  and now.index_time = 3
  and last.visit_date is null


-- 情况2： 上次有随访（包括有效随访和 无效随访）

update now
set now.start_date=DATEADD(DD, 90 - 14, case
                                            when last.visit_date is not null 
																						then last.visit_date
                                            when last.irregular_visit_date is not null
                                            then last.irregular_visit_date 
																				end),
    now.end_date=DATEADD(DD, 90 + 14, case
                                          when last.visit_date is not null 
																					then last.visit_date
                                          when last.irregular_visit_date is not null 
																					then last.irregular_visit_date 
																			end)
from temp_高血压随访次数统计 last
     INNER JOIN temp_高血压随访次数统计 now ON last.archive_num = now.archive_num
where last.index_time = 2
  and now.index_time = 3
  and (last.visit_date is not null or last.irregular_visit_date is not null)


/**
 更新 第3次有效随访的随访时间
 */


update temp_高血压随访次数统计
set visit_date= a.visitDate
from (select a.ArchiveNum     ArchiveNum,
             max(a.visitDate) visitDate
      from ##高血压随访信息 a
           INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
      where a.visitDate >= b.start_date
        and a.visitDate <= b.end_date
        and b.index_time = 3
      group by a.ArchiveNum
     ) a
     INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
where b.index_time = 3


/**
 更新 第3次无效随访的随访时间
  时间范围  开始时间=end_date_2   结束时间=start_date_3
 */

update temp_高血压随访次数统计
set irregular_visit_date= a.visitDate
from (select a.ArchiveNum     ArchiveNum,
             max(a.visitDate) visitDate
      from ##高血压随访信息 a
           INNER JOIN temp_高血压随访次数统计 last ON last.archive_num = a.ArchiveNum
           INNER JOIN temp_高血压随访次数统计 now ON last.archive_num = now.archive_num
      where last.index_time = 2
        and now.index_time = 3
        and a.visitDate >= last.end_date
        and a.visitDate <= now.start_date
      group by a.ArchiveNum
     ) a
     INNER JOIN temp_高血压随访次数统计 b ON b.archive_num = a.ArchiveNum
where b.index_time = 3

/*
 第四次随访
 从第3次 开始  后面都是循环
 */
declare @最大随访次数 int=(select max(target_time)
                     from temp_高血压随访次数统计)
PRINT ('当前最大随访次数:' + cast(@最大随访次数 as varchar))
--  执行循环逻辑
-- 当前随访次数
DECLARE @当前随访次数 int
set @当前随访次数 = 4
WHILE @当前随访次数 <= @最大随访次数
    BEGIN
        --  循环执行语句开始
        PRINT ('当前随访次数:' + cast(@当前随访次数 as varchar))
        --------- 步骤1.插入基础数据开始
        declare @插入基础数据sql varchar(1000)='insert into temp_高血压随访次数统计(archive_num, target_time, visit_date, irregular_visit_date,' +
                                         ' start_date, end_date, index_time) ' +
                                         'select  archive_num, target_time, null, null, null start_date, null end_date, ' +
                                         cast(@当前随访次数 as varchar) + ' index_time' +
                                         ' from temp_高血压随访次数统计 a where a.index_time = 0 and a.target_time>=' +
                                         cast(@当前随访次数 as varchar)
        PRINT (@插入基础数据sql)
        EXEC ( @插入基础数据sql)
        --------- 步骤1.插入基础数据结束


        --------- 步骤2.更新情况1： 上次无随访时，start_date 和  end_date   开始
        declare @更新情况1sql varchar(1000)='update now set ' +
                                        'now.start_date=last.end_date,' +
                                        'now.end_date=DATEADD(DD, 90, last.end_date) ' +
                                        'from temp_高血压随访次数统计 last,temp_高血压随访次数统计 now ' +
                                        'where last.archive_num = now.archive_num and last.index_time =' +
                                        cast(@当前随访次数 - 1 as varchar) +
                                        'and now.index_time = ' + cast(@当前随访次数 as varchar) +
                                        ' and last.visit_date is null'
        PRINT (@更新情况1sql)
        EXEC ( @更新情况1sql)
        --------- 步骤2.更新情况2： 第一次有随访时，start_date 和  end_date   结束


        --------- 步骤2.更新情况2： 上次有随访时，start_date 和  end_date   开始
        declare @更新情况2sql varchar(1000)='update now
set now.start_date=DATEADD(DD, 90 - 14, case
                                            when last.visit_date is not null then last.visit_date
                                            when last.irregular_visit_date is not null
                                                then last.irregular_visit_date end),
    now.end_date=DATEADD(DD, 90 + 14, case
                                          when last.visit_date is not null then last.visit_date
                                          when last.irregular_visit_date is not null then last.irregular_visit_date end)
from temp_高血压随访次数统计 last,
     temp_高血压随访次数统计 now
where last.archive_num = now.archive_num
  and last.index_time =' + cast(@当前随访次数 - 1 as varchar) + '
  and now.index_time =' + cast(@当前随访次数 as varchar) + '
  and (last.visit_date is not null or last.irregular_visit_date is not null)'
        PRINT (@更新情况2sql)
        EXEC ( @更新情况2sql)
        --------- 步骤2.更新情况2： 第一次有随访时，start_date 和  end_date   结束


        --------- 步骤3.更新 本次有效随访的随访时间  开始
        declare @更新有效随访时间sql varchar(1000)='update temp_高血压随访次数统计
set visit_date= a.visitDate
from (select a.ArchiveNum     ArchiveNum,
             max(a.visitDate) visitDate

      from ##高血压随访信息 a,
           temp_高血压随访次数统计 b
      where b.archive_num = a.ArchiveNum
        and a.visitDate >= b.start_date
        and a.visitDate <= b.end_date
        and b.index_time =' + cast(@当前随访次数 as varchar) + '
      group by a.ArchiveNum
     ) a,
     temp_高血压随访次数统计 b
where b.archive_num = a.ArchiveNum
  and b.index_time =' + cast(@当前随访次数 as varchar)
        PRINT (@更新有效随访时间sql)
        EXEC ( @更新有效随访时间sql)
        --------- 步骤3.更新 本次有效随访的随访时间  结束


        --------- 步骤4.更新 本次无效随访的随访时间  开始
        declare @更新无效随访时间sql varchar(1000)='update temp_高血压随访次数统计
set irregular_visit_date= a.visitDate
from (select a.ArchiveNum     ArchiveNum,
             max(a.visitDate) visitDate

      from ##高血压随访信息 a,
           temp_高血压随访次数统计 last,
           temp_高血压随访次数统计 now
      where last.archive_num = a.ArchiveNum
        and last.archive_num = now.archive_num
        and last.index_time = ' + cast(@当前随访次数 - 1 as varchar) + '
        and now.index_time = ' + cast(@当前随访次数 as varchar) + '
        and a.visitDate >= last.end_date
        and a.visitDate <= now.start_date
      group by a.ArchiveNum
     ) a,
     temp_高血压随访次数统计 b
where b.archive_num = a.ArchiveNum
  and b.index_time = ' + cast(@当前随访次数 as varchar)
        PRINT (@更新无效随访时间sql)
        EXEC ( @更新无效随访时间sql)
        --------- 步骤4.更新 本次无效随访的随访时间  结束


        -- 循环执行语句结束
        set @当前随访次数 = @当前随访次数 + 1
    END


--  清除 1 2 3 次随访多余数据，因为部分人随访次数小于3次

delete
from temp_高血压随访次数统计
where index_time > target_time


-- 更新report_qyyh 表



-- B611	高血压随访表实际有效张数
update report_qyyh
set B611=(select count(*)
          from temp_高血压随访次数统计 a
          where a.archive_num = sfzh
            and a.index_time > 0
            and a.visit_date is not null)

-- B612	高血压随访表实际无效张数
update report_qyyh
set B612=(select count(*)
          from temp_高血压随访次数统计 a
          where a.archive_num = sfzh
            and a.index_time > 0
            and a.visit_date is  null)

-- B613	高血压随访表计算用总张数= 实际张数B6+实际无效张数B612
update report_qyyh
set B613=B6+B612


END
go

