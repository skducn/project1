CREATE PROCEDURE [dbo].[createReportQyyhCursor]
as
BEGIN

  if exists(select *
          from sysobjects
          where name = 'temp_高血压随访次数统计'
            and type = 'U')
    drop table temp_高血压随访次数统计;

if exists(select *
          from sysobjects
          where name = 'temp_糖尿病随访次数统计'
            and type = 'U')
    drop table temp_糖尿病随访次数统计;


CREATE TABLE [dbo].[temp_高血压随访次数统计]
(
    [id]                   bigint IDENTITY (1000,1)               NOT NULL,
    [archive_num]          nvarchar(50) COLLATE Chinese_PRC_CI_AS NULL,
    [target_time]          int                                    NULL,
    [visit_date]           datetime                               NULL,
    [irregular_visit_date] datetime                               NULL,
    [start_date]           datetime                               NULL,
    [end_date]             datetime                               NULL,
    [index_time]           int                                    NULL,
    CONSTRAINT [PK_temp_高血压随访] PRIMARY KEY CLUSTERED ([id])
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
        ON [PRIMARY]
)
    ON [PRIMARY]


ALTER TABLE [dbo].[temp_高血压随访次数统计]
    SET (LOCK_ESCALATION = TABLE)


CREATE NONCLUSTERED INDEX [htn_archive_num_index_time]
    ON [dbo].[temp_高血压随访次数统计] (
                               [archive_num] ASC,
                               [index_time] ASC
        )


EXEC sp_addextendedproperty
     'MS_Description', N'档案编号',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_高血压随访次数统计',
     'COLUMN', N'archive_num'


EXEC sp_addextendedproperty
     'MS_Description', N'理论随访次数',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_高血压随访次数统计',
     'COLUMN', N'target_time'


EXEC sp_addextendedproperty
     'MS_Description', N'正确的随访时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_高血压随访次数统计',
     'COLUMN', N'visit_date'


EXEC sp_addextendedproperty
     'MS_Description', N'不规范的最新随访时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_高血压随访次数统计',
     'COLUMN', N'irregular_visit_date'


EXEC sp_addextendedproperty
     'MS_Description', N'随访范围开始时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_高血压随访次数统计',
     'COLUMN', N'start_date'


EXEC sp_addextendedproperty
     'MS_Description', N'随访范围结束时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_高血压随访次数统计',
     'COLUMN', N'end_date'


EXEC sp_addextendedproperty
     'MS_Description', N'本次随访次数',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_高血压随访次数统计',
     'COLUMN', N'index_time'

CREATE TABLE [dbo].[temp_糖尿病随访次数统计] (
                                        [id] bigint  IDENTITY(1000,1) NOT NULL,
                                        [archive_num] nvarchar(50) COLLATE Chinese_PRC_CI_AS  NULL,
                                        [target_time] int  NULL,
                                        [visit_date] datetime  NULL,
                                        [irregular_visit_date] datetime  NULL,
                                        [start_date] datetime  NULL,
                                        [end_date] datetime  NULL,
                                        [index_time] int  NULL,
                                        CONSTRAINT [PK_temp_高血压随访_copy2] PRIMARY KEY CLUSTERED ([id])
                                            WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
                                            ON [PRIMARY]
)
    ON [PRIMARY]


ALTER TABLE [dbo].[temp_糖尿病随访次数统计] SET (LOCK_ESCALATION = TABLE)


CREATE NONCLUSTERED INDEX [dm_archive_num_index_time]
    ON [dbo].[temp_糖尿病随访次数统计] (
                               [archive_num] ASC,
                               [index_time] ASC
        )


EXEC sp_addextendedproperty
     'MS_Description', N'档案编号',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_糖尿病随访次数统计',
     'COLUMN', N'archive_num'


EXEC sp_addextendedproperty
     'MS_Description', N'理论随访次数',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_糖尿病随访次数统计',
     'COLUMN', N'target_time'


EXEC sp_addextendedproperty
     'MS_Description', N'正确的随访时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_糖尿病随访次数统计',
     'COLUMN', N'visit_date'


EXEC sp_addextendedproperty
     'MS_Description', N'不规范的最新随访时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_糖尿病随访次数统计',
     'COLUMN', N'irregular_visit_date'


EXEC sp_addextendedproperty
     'MS_Description', N'随访范围开始时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_糖尿病随访次数统计',
     'COLUMN', N'start_date'


EXEC sp_addextendedproperty
     'MS_Description', N'随访范围结束时间',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_糖尿病随访次数统计',
     'COLUMN', N'end_date'


EXEC sp_addextendedproperty
     'MS_Description', N'本次随访次数',
     'SCHEMA', N'dbo',
     'TABLE', N'temp_糖尿病随访次数统计',
     'COLUMN', N'index_time'

END
go

