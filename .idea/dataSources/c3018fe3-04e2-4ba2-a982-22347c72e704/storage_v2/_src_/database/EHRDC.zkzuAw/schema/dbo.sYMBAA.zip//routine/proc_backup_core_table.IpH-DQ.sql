CREATE PROCEDURE [dbo].[proc_backup_core_table](
    @StartDate varchar(20)
)
as

-- 删除重名的备份表
DECLARE
    @execSql varchar(max) = REPLACE(
            '
             IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_HrCover_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_HrCover_@StartDate]

             IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_HrPersonBasicInfo_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_HrPersonBasicInfo_@StartDate]

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_HrAssociationInfo_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_HrAssociationInfo_@StartDate]

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_tb_dc_chronic_info_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_tb_dc_chronic_info_@StartDate]

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_tb_dc_chronic_main_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_tb_dc_chronic_main_@StartDate]

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_tb_dc_htn_visit_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_tb_dc_htn_visit_@StartDate]

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_tb_dc_dm_visit_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_tb_dc_dm_visit_@StartDate]

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_tb_dc_examination_info_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_tb_dc_examination_info_@StartDate]

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[BAK_ZY_report_qyyh_@StartDate]'') AND type IN (''U''))
                DROP TABLE [dbo].[BAK_ZY_report_qyyh_@StartDate]

            ', '@StartDate', @StartDate
        )


-- 封面 和 基本信息  和多选项
DECLARE @hrcover VARCHAR(1000)= 'select * into BAK_ZY_HrCover_' + @StartDate + ' from   HrCover'
DECLARE @HrPersonBasicInfo VARCHAR(1000) = 'select * into BAK_ZY_HrPersonBasicInfo_' + @StartDate + ' from   HrPersonBasicInfo'
DECLARE @HrAssociationInfo VARCHAR(1000)= 'select * into BAK_ZY_HrAssociationInfo_' + @StartDate + ' from   HrAssociationInfo'
-- 慢病
DECLARE
    @tb_dc_chronic_info VARCHAR(1000)= 'select * into BAK_ZY_tb_dc_chronic_info_' + @StartDate + ' from   tb_dc_chronic_info'
DECLARE
    @tb_dc_chronic_main VARCHAR(1000)= 'select * into BAK_ZY_tb_dc_chronic_main_' + @StartDate + ' from   tb_dc_chronic_main'
DECLARE @tb_dc_htn_visit VARCHAR(1000)= 'select * into BAK_ZY_tb_dc_htn_visit_' + @StartDate + ' from   tb_dc_htn_visit'
DECLARE @tb_dc_dm_visit VARCHAR(1000) = 'select * into BAK_ZY_tb_dc_dm_visit_' + @StartDate + ' from   tb_dc_dm_visit'
-- 体检
DECLARE
    @tb_dc_examination_info VARCHAR(1000) = 'select * into BAK_ZY_tb_dc_examination_info_' + @StartDate +
                                            ' from   tb_dc_examination_info'
-- 质控报告结果汇总
DECLARE @report_qyyh VARCHAR(1000)= 'select * into BAK_ZY_report_qyyh_' + @StartDate + ' from  report_qyyh'


-- 创建索引
DECLARE
    @idx#hrcover#archivenum VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#hrcover#archivenum] on BAK_ZY_HrCover_'
        + @StartDate + '([ArchiveNum] ASC)'


DECLARE
    @idx#HrPersonBasicInfo#archivenum VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#HrPersonBasicInfo#archivenum] on BAK_ZY_HrPersonBasicInfo_'
        + @StartDate + '([ArchiveNum] ASC)'

DECLARE
    @idx#HrPersonBasicInfo#IdCard#archivenum VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#HrPersonBasicInfo#IdCard#archivenum] on BAK_ZY_HrPersonBasicInfo_'
        + @StartDate + '([IdCard], [archivenum] ASC)'


DECLARE
    @idx#HrAssociationInfo#Pid#TableSource VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#HrAssociationInfo#Pid#TableSource] on BAK_ZY_HrAssociationInfo_'
        + @StartDate + '([Pid], [TableSource] ASC)';

DECLARE
    @idx#tb_dc_chronic_info#orgCode#manageNum VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#tb_dc_chronic_info#orgCode#manageNum] on BAK_ZY_tb_dc_chronic_info_'
        + @StartDate + '([orgCode], [manageNum] ASC)';

DECLARE
    @idx#tb_dc_chronic_info#empiGuid VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#tb_dc_chronic_info#empiGuid] on BAK_ZY_tb_dc_chronic_info_'
        + @StartDate + '([empiGuid]ASC)';

DECLARE
    @idx#tb_dc_chronic_main#orgCode#visitNum VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#tb_dc_chronic_main#orgCode#visitNum] on BAK_ZY_tb_dc_chronic_main_'
        + @StartDate + '([orgCode], [visitNum] ASC)';

DECLARE
    @idx#tb_dc_chronic_main#orgCode#manageNum VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#tb_dc_chronic_main#orgCode#manageNum] on BAK_ZY_tb_dc_chronic_main_'
        + @StartDate + '([orgCode], [manageNum] ASC)';


DECLARE
    @idx#tb_dc_htn_visit#visitOrgCode#cardId VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#tb_dc_htn_visit#visitOrgCode#cardId] on BAK_ZY_tb_dc_htn_visit_'
        + @StartDate + '([visitOrgCode], [cardId] ASC)';

DECLARE
    @idx#tb_dc_dm_visit#visitOrgCode#cardId VARCHAR(1000)='CREATE NONCLUSTERED index  [idx#tb_dc_dm_visit#visitOrgCode#cardId] on BAK_ZY_tb_dc_dm_visit_'
        + @StartDate + '([visitOrgCode], [cardId] ASC)';



    --   删除同名备份表
    EXEC (@execSql)


    -- 备份表插入数据
    EXEC (@HrCover)
    EXEC (@HrPersonBasicInfo)
    EXEC (@HrAssociationInfo)
    EXEC (@tb_dc_chronic_info)
    EXEC (@tb_dc_chronic_main)
    EXEC (@tb_dc_htn_visit)
    EXEC (@tb_dc_dm_visit)
    EXEC (@tb_dc_examination_info)
    EXEC (@report_qyyh)

--  备份表创建索引
    EXEC (@idx#hrcover#archivenum)
    EXEC (@idx#HrPersonBasicInfo#archivenum)
    EXEC (@idx#HrPersonBasicInfo#IdCard#archivenum)
    EXEC (@idx#HrAssociationInfo#Pid#TableSource)
    EXEC (@idx#tb_dc_chronic_info#orgCode#manageNum)
    EXEC (@idx#tb_dc_chronic_info#empiGuid)
    EXEC (@idx#tb_dc_chronic_main#orgCode#visitNum)
    EXEC (@idx#tb_dc_chronic_main#orgCode#manageNum)
    EXEC (@idx#tb_dc_htn_visit#visitOrgCode#cardId)
    EXEC (@idx#tb_dc_dm_visit#visitOrgCode#cardId)
go

