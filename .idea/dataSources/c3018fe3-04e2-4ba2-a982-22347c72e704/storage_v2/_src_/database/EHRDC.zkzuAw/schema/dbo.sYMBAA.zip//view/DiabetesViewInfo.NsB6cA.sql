CREATE VIEW [dbo].[DiabetesViewInfo] AS SELECT 
tb_dc_dm_visit.guid  as "Diabetes.guid",
tb_dc_dm_visit.acr					"tb_dc_dm_visit.acr",
tb_dc_dm_visit.bmi					"tb_dc_dm_visit.bmi",
tb_dc_dm_visit.cardId					"tb_dc_dm_visit.cardId",
tb_dc_dm_visit.cholesterol					"tb_dc_dm_visit.cholesterol",
case when tb_dc_dm_visit.clinicalSymptomsCode	='1' then '多饮'
     when tb_dc_dm_visit.clinicalSymptomsCode	='2' then '多尿'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='3' then '多食/常有饥饿感'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='4' then '乏力'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='5' then '体重下降'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='6' then '视力下降'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='7' then '肢体麻木'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='8' then '下肢浮肿'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='9' then '肢端溃疡'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='10' then '皮肤及外阴瘙痒'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='11' then '感染'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='12' then '其它'
		 when tb_dc_dm_visit.clinicalSymptomsCode	='13' then '以上都无'
		 else tb_dc_dm_visit.clinicalSymptomsCode end		"tb_dc_dm_visit.clinicalSymptomsCode",
case when tb_dc_dm_visit.complianceStatusCode	='1' then '良好'
     when tb_dc_dm_visit.complianceStatusCode	='2' then '一般'
		 when tb_dc_dm_visit.complianceStatusCode	='3' then '差'
		 else tb_dc_dm_visit.complianceStatusCode	end "tb_dc_dm_visit.complianceStatusCode",
tb_dc_dm_visit.deathReason					"tb_dc_dm_visit.deathReason",
case when tb_dc_dm_visit.dietCode	='1' then '完全按医生要求执行'
     when tb_dc_dm_visit.dietCode	='2' then '不控制'
		 when tb_dc_dm_visit.dietCode	='3' then '不规律'
		 else tb_dc_dm_visit.dietCode		end		"tb_dc_dm_visit.dietCode",
case when tb_dc_dm_visit.dorsalArteryOfFootLeftCode	='1' then '未触及'
     when tb_dc_dm_visit.dorsalArteryOfFootLeftCode	='2' then '触及双侧对称'
		 when tb_dc_dm_visit.dorsalArteryOfFootLeftCode	='3' then '触及左侧弱或消失'
		 when tb_dc_dm_visit.dorsalArteryOfFootLeftCode	='4' then '触及右侧弱或消失'
		 when tb_dc_dm_visit.dorsalArteryOfFootLeftCode	='5' then '未检测'
		 else tb_dc_dm_visit.dorsalArteryOfFootLeftCode	 end	"tb_dc_dm_visit.dorsalArteryOfFootLeftCode",
case when tb_dc_dm_visit.drinkingFrequencyCode	='1' then '从不'
     when tb_dc_dm_visit.drinkingFrequencyCode	='2' then '偶尔'
		 when tb_dc_dm_visit.drinkingFrequencyCode	='3' then '经常'
		 when tb_dc_dm_visit.drinkingFrequencyCode	='4' then '每天'
		 else tb_dc_dm_visit.drinkingFrequencyCode	end			"tb_dc_dm_visit.drinkingFrequencyCode",
tb_dc_dm_visit.drinkingVolume					"tb_dc_dm_visit.drinkingVolume",
case when tb_dc_dm_visit.drugComplianceCode	='1' then '规律'
     when tb_dc_dm_visit.drugComplianceCode	='2' then '间断'
		 when tb_dc_dm_visit.drugComplianceCode	='3' then '不服药'
		 else tb_dc_dm_visit.drugComplianceCode end		"tb_dc_dm_visit.drugComplianceCode",
case when tb_dc_dm_visit.familyHistory	='1' then '有'
     when tb_dc_dm_visit.familyHistory	='2' then '无'
		 when tb_dc_dm_visit.familyHistory	='3' then '不详'
		 else tb_dc_dm_visit.familyHistory end		"tb_dc_dm_visit.familyHistory",
tb_dc_dm_visit.fastingBloodSugarCode					"tb_dc_dm_visit.fastingBloodSugarCode",
case when tb_dc_dm_visit.fastingBloodSugarGatherCode	='1' then '手动输入'
     when tb_dc_dm_visit.fastingBloodSugarGatherCode	='2' then '仪器采集'
		 else tb_dc_dm_visit.fastingBloodSugarGatherCode end		"tb_dc_dm_visit.fastingBloodSugarGatherCode",
tb_dc_dm_visit.fastingBloodSugarOGTTCode					"tb_dc_dm_visit.fastingBloodSugarOGTTCode",
tb_dc_dm_visit.ghGaterWayCode					"tb_dc_dm_visit.ghGaterWayCode",
case when tb_dc_dm_visit.hasPaperCard	='1' then '是'
     when tb_dc_dm_visit.hasPaperCard	='2' then '否'
		 else tb_dc_dm_visit.hasPaperCard end				"tb_dc_dm_visit.hasPaperCard",
tb_dc_dm_visit.hasUseDrugSideEffects					"tb_dc_dm_visit.hasUseDrugSideEffects",
case when tb_dc_dm_visit.healthEduType	='1' then '电话'
     when tb_dc_dm_visit.healthEduType	='2' then '讲座'
		 when tb_dc_dm_visit.healthEduType	='3' then '资料发放'
		 when tb_dc_dm_visit.healthEduType	='4' then '现场活动'
		 when tb_dc_dm_visit.healthEduType	='5' then '面对面咨询'
		 when tb_dc_dm_visit.healthEduType	='6' then '观看视频'
		 when tb_dc_dm_visit.healthEduType	='7' then '网络'
		 when tb_dc_dm_visit.healthEduType	='8' then '其他'
		 else tb_dc_dm_visit.healthEduType end			"tb_dc_dm_visit.healthEduType",
tb_dc_dm_visit.height					"tb_dc_dm_visit.height",
tb_dc_dm_visit.highCholesterol					"tb_dc_dm_visit.highCholesterol",
case when tb_dc_dm_visit.hypoglycemia	='1' then '无'
     when tb_dc_dm_visit.hypoglycemia	='2' then '偶尔'
		 when tb_dc_dm_visit.hypoglycemia	='3' then '频繁'
		 else tb_dc_dm_visit.hypoglycemia end	"tb_dc_dm_visit.hypoglycemia",
case when tb_dc_dm_visit.isAcceptHealthEdu	='1' then '是'
     when tb_dc_dm_visit.isAcceptHealthEdu	='2' then '否'
		 else tb_dc_dm_visit.isAcceptHealthEdu end		"tb_dc_dm_visit.isAcceptHealthEdu",
case when tb_dc_dm_visit.isLawSport	='1' then '有'
     when tb_dc_dm_visit.isLawSport	='2' then '无'
		 else tb_dc_dm_visit.isLawSport end		"tb_dc_dm_visit.isLawSport",
case when tb_dc_dm_visit.lostVisitCode	='1' then '死亡'
     when tb_dc_dm_visit.lostVisitCode	='2' then '搬迁'
		 when tb_dc_dm_visit.lostVisitCode	='3' then '拒访'
     when tb_dc_dm_visit.lostVisitCode	='4' then '其他'
		 else tb_dc_dm_visit.lostVisitCode end			"tb_dc_dm_visit.lostVisitCode",
tb_dc_dm_visit.lowCholesterol					"tb_dc_dm_visit.lowCholesterol",
tb_dc_dm_visit.nextVisiDate					"tb_dc_dm_visit.nextVisiDate",
tb_dc_dm_visit.proposal					"tb_dc_dm_visit.proposal",
case when tb_dc_dm_visit.psychologyStatusCode	='1' then '良好'
     when tb_dc_dm_visit.psychologyStatusCode	='2' then '一般'
		 when tb_dc_dm_visit.psychologyStatusCode	='3' then '差'
		 else tb_dc_dm_visit.psychologyStatusCode end		"tb_dc_dm_visit.psychologyStatusCode",
tb_dc_dm_visit.randomBloodSugarCode					"tb_dc_dm_visit.randomBloodSugarCode",
tb_dc_dm_visit.referralOrgDept					"tb_dc_dm_visit.referralOrgDept",
tb_dc_dm_visit.referralReason					"tb_dc_dm_visit.referralReason",
tb_dc_dm_visit.sbp					"tb_dc_dm_visit.sbp",
case when tb_dc_dm_visit.smokingStatusCode	='1' then '现在每天吸'
     when tb_dc_dm_visit.smokingStatusCode	='2' then '现在吸，但不是每天吸'
		 when tb_dc_dm_visit.smokingStatusCode	='3' then '过去吸，现在不吸'
		 when tb_dc_dm_visit.smokingStatusCode	='4' then '从不吸'
		 else tb_dc_dm_visit.smokingStatusCode end		"tb_dc_dm_visit.smokingStatusCode",
tb_dc_dm_visit.smokingVolume					"tb_dc_dm_visit.smokingVolume",
tb_dc_dm_visit.sportFrequence					"tb_dc_dm_visit.sportFrequence",
tb_dc_dm_visit.sportTimes					"tb_dc_dm_visit.sportTimes",
case when tb_dc_dm_visit.sportTypeCode	='1' then '轻度运动'
     when tb_dc_dm_visit.sportTypeCode	='2' then '中度运动'
		 when tb_dc_dm_visit.sportTypeCode	='3' then '重度运动'
		 when tb_dc_dm_visit.sportTypeCode	='4' then '极重度运动'
		 else tb_dc_dm_visit.sportTypeCode end			"tb_dc_dm_visit.sportTypeCode",
tb_dc_dm_visit.stapleFood					"tb_dc_dm_visit.stapleFood",
case when tb_dc_dm_visit.symptomStatus	='1' then '酮症酸中毒'
     when tb_dc_dm_visit.symptomStatus	='2' then '高渗性高血糖状态'
		 when tb_dc_dm_visit.symptomStatus	='3' then '糖尿病乳酸性酸中毒'
		 when tb_dc_dm_visit.symptomStatus	='4' then '糖尿病肾脏病变'
		 when tb_dc_dm_visit.symptomStatus	='5' then '视网膜病变和失明'
		 when tb_dc_dm_visit.symptomStatus	='6' then '糖尿病神经病变'
		 when tb_dc_dm_visit.symptomStatus	='7' then '糖尿病心脑血管病'
		 when tb_dc_dm_visit.symptomStatus	='8' then '下肢血管病变'
		 when tb_dc_dm_visit.symptomStatus	='9' then '糖尿病足'
		 else tb_dc_dm_visit.symptomStatus end			"tb_dc_dm_visit.symptomStatus",
tb_dc_dm_visit.targetBmi					"tb_dc_dm_visit.targetBmi",
tb_dc_dm_visit.targetDistrictCode					"tb_dc_dm_visit.targetDistrictCode",
tb_dc_dm_visit.targetDrink					"tb_dc_dm_visit.targetDrink",
tb_dc_dm_visit.targetOrgCode					"tb_dc_dm_visit.targetOrgCode",
tb_dc_dm_visit.targetSmoke					"tb_dc_dm_visit.targetSmoke",
tb_dc_dm_visit.targetSportFrequencyCode					"tb_dc_dm_visit.targetSportFrequencyCode",
tb_dc_dm_visit.targetSportTimes					"tb_dc_dm_visit.targetSportTimes",
tb_dc_dm_visit.targetStapleFood					"tb_dc_dm_visit.targetStapleFood",
tb_dc_dm_visit.targetWeight					"tb_dc_dm_visit.targetWeight",
tb_dc_dm_visit.triglycerides					"tb_dc_dm_visit.triglycerides",
tb_dc_dm_visit.twoHBloodSugarOGTTCode					"tb_dc_dm_visit.twoHBloodSugarOGTTCode",
tb_dc_dm_visit.urineProtein					"tb_dc_dm_visit.urineProtein",
tb_dc_dm_visit.visitDate					"tb_dc_dm_visit.visitDate",
tb_dc_dm_visit.visitDocName					"tb_dc_dm_visit.visitDocName",
tb_dc_dm_visit.visitOrgCode					"tb_dc_dm_visit.visitOrgCode",
case when tb_dc_dm_visit.visitType	='1' then '控制满意'
     when tb_dc_dm_visit.visitType	='2' then '控制不满意'
		 when tb_dc_dm_visit.visitType	='3' then '不良反应'
		 when tb_dc_dm_visit.visitType	='4' then '并发症'
     else tb_dc_dm_visit.visitType end		 "tb_dc_dm_visit.visitType",
tb_dc_dm_visit.visitWayCode					"tb_dc_dm_visit.visitWayCode",
case when tb_dc_dm_visit.vistStatusCode	='1' then '继续随访'
     when tb_dc_dm_visit.vistStatusCode	='2' then '暂时性失访'
		 when tb_dc_dm_visit.vistStatusCode	='3' then '失访'
     else tb_dc_dm_visit.vistStatusCode end "tb_dc_dm_visit.vistStatusCode",
tb_dc_dm_visit.weight					"tb_dc_dm_visit.weight",
tb_dc_dm_visit.name					"tb_empi_index_root.name",
tb_empi_index_root.idCardNo  "tb_empi_index_root.idCardNo",
tb_dc_dm_visit.ehrNum "tb_dc_dm_visit.ehrNum",
tb_dc_dm_visit.fastingBloodSugarOGTTValue "tb_dc_dm_visit.fastingBloodSugarOGTTValue",
tb_dc_dm_visit.fastingBloodSugarValue "tb_dc_dm_visit.fastingBloodSugarValue",
tb_dc_dm_visit.randomBloodSugarValue "tb_dc_dm_visit.randomBloodSugarValue"

from tb_dc_dm_visit 
left join tb_dc_chronic_main main on  tb_dc_dm_visit .cardId = main.visitNum and tb_dc_dm_visit .visitOrgCode =main.OrgCode
left join tb_dc_chronic_info on tb_dc_chronic_info.manageNum = main.manageNum and tb_dc_chronic_info.orgCode = main.orgcode
left join tb_empi_index_root on tb_empi_index_root.guid = tb_dc_chronic_info.empiGuid
go

