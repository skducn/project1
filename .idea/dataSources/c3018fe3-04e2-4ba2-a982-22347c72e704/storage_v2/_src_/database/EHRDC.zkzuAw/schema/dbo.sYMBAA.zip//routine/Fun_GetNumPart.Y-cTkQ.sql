CREATE FUNCTION [dbo].[Fun_GetNumPart]
( @Str NVARCHAR(MAX) )
    RETURNS NVARCHAR(MAX)
AS
BEGIN
    DECLARE @Start INT;
    DECLARE @End INT;
    DECLARE @Part NVARCHAR(MAX)
    SET @Start = PATINDEX('%[0-9]%', @Str);
    SET @End = PATINDEX('%[0-9]%',SUBSTRING(@Str, @Start+1,LEN(@Str) - @Start));
    SET @Part = SUBSTRING(@Str,@Start,1)
    WHILE  @End >0
        BEGIN
            SET @Start = @start+@End
            SET @Part = @Part+SUBSTRING(@Str,@Start,1)
            SET @End = PATINDEX('%[0-9]%',SUBSTRING(@Str, @Start+1,LEN(@Str) - @Start));
        END

    RETURN  @Part;
END;
go

