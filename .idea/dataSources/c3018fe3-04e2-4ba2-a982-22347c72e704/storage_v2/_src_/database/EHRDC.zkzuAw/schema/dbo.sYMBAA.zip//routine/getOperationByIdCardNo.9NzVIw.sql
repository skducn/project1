CREATE PROCEDURE [dbo].[getOperationByIdCardNo] @idCardNo VARCHAR ( 100 ) AS BEGIN-- 创建临时表 获取所有的流水号和机构编码
IF OBJECT_ID( N'tempdb..#T', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T
    end
CREATE TABLE #T (
                    orgCode VARCHAR ( 100 ),
                    visitStrNo VARCHAR ( 100 ),
                    visitDate DATE
)
-- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index ON #T ( orgCode, visitStrNo )
-- 创建临时变量 身份证的guid
DECLARE	@empiguid VARCHAR ( 100 )
-- 给临时变量赋值
SET @empiguid = ( SELECT guid FROM tb_empi_index_root WHERE idCardNo =@idCardNo ) -- 将数据存储到临时表内
-- 给临时表赋值 获取所有的流水编号和机构Id
INSERT INTO #T SELECT * FROM
    (SELECT orgCode,ipVisitStrNo,dischargeDate FROM tb_his_ip_medical_record WHERE	empiGuid =@empiguid
     UNION
     SELECT orgCode,opVisitStrNo,visitTime FROM tb_his_op_medical_record  WHERE empiGuid =@empiguid ) a

-- 获取最终输出结果
SELECT
    operCode,operName,operEndDate from
     #T t
    INNER JOIN tb_his_operation d ON t.orgcode = d.orgCode
     AND t.VisitStrNo = d.visitStrNo
END
go

