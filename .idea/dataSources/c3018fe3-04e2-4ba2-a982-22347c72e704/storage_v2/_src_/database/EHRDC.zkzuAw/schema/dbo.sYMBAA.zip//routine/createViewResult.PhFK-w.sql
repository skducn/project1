CREATE PROCEDURE [dbo].[createViewResult]
@batchNum VARCHAR(50)
AS
BEGIN
    -- 根据批次号进行相关结果数据的生成

--如果没有该表 需要先创建视图
--CREATE VIEW SpecialCrowd AS  (
--SELECT * FROM healthrecord.dbo.SpecialCrowd )

--     DECLARE @control_basic_fullTableName VARCHAR(100)
--     DECLARE @control_result_fullTableName VARCHAR(100)
--     DECLARE @problemArchiveView_fullTableName varchar(100)
    DECLARE @execSql varchar(max)
--     SET @control_basic_fullTableName='control_basic'
--     SET @control_result_fullTableName='control_result'
--     SET @problemArchiveView_fullTableName='problemArchiveView'


    --需要先行删除视图  @problemArchiveView_fullTableName
--删除表  @control_basic_fullTableName  @control_result_fullTableName
--删除数据  ZKTypeTrend zkbm 为 @batchNum
    select @execSql =
            '
--             IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[problemArchiveView]'') AND type IN (''V''))
--                 DROP view [dbo].[problemArchiveView]
-- 

            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[control_basic]'') AND type IN (''U''))
                DROP TABLE [dbo].[control_basic]


            IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[control_result]'') AND type IN (''U''))
                DROP TABLE [dbo].[control_result]

            delete from ZKTypeTrend where zkbm =''@batchNum'';
            delete from ControlError where controlId =''@batchNum'';

            '
    EXEC(@execSql)


    print '--------------------------------清除设置批次的表----------------------------------------------'


    --人员基本信息表(相对质控结果表,多了质控通过的人员)

--质控结果信息
    select @execSql =
            '
            CREATE TABLE control_basic(
            rownumber INT,
            idCard VARCHAR(50),
            archiveNum VARCHAR(70),
            name VARCHAR(50),
            archiveUnit varchar(100),
            archiveUnitCode varchar(32),
            age int default 0, --年龄
            jb_gxy int default 0, --高血压
            jb_tnb int default 0, --糖尿病
            jb_ncz int default 0, --脑卒中
            jb_zl int default 0, --肿瘤
            jb_fjh int default 0, --肺结核
            jb_jsb int default 0, --精神病
            jb_other int default 0,--其他
            ts_yunfu int default 0,--特殊人群-孕妇
            ts_jihua_jiating int default 0, --计划生育特殊家庭
            ts_pinkun int default 0, --贫困家庭
            ts_canji int default 0, --是否是残疾
            ts_other INT DEFAULT 0, --是否是其他特殊人群
            jtys_td_name varchar(100),--家庭医生团队名称
            sign_doctor_name varchar(100),--签约医生姓名
            sign_doctor_no varchar(100),--签约医生工号
            years varchar(10), --年份
            isSigned varchar(2), --是否签约
            isError int, --档案是否通过 1为有错

            isCoverBaisc int, --属于封面基本 1为属于
            isCheckup int, --健康体检表分值  1为属于
            isHypertension int, --属于高血压随访表 1为属于
            isDiabetes int, --属于糖尿病随访表 1为属于

            coverBaiscScore int, --封面基本信息表分值
            checkupScore int, --健康体检表分值
            hypertensionScore int, --高血压随访表分值
            diabetesScore int, --糖尿病随访表分值

             isErrorCoverBasic INT, --封面表
             isErrorCheckup INT--, --体检表
             --isErrorHypertension INT,--高血压随访表
             --isErrorDiabetes INT --糖尿病随访表

            )
            '

    exec(@execSql)

    print '------------------------------------创建质控结果记录表-------------------------------------'

    --基本信息居民档案分数表

--基本信息表插入数据

    SELECT @execSql =  '
                                      INSERT INTO control_basic(rownumber,idCard,archiveNum,name,ArchiveUnit,ArchiveUnitCode,isError)
                                      SELECT  ROW_NUMBER() OVER( ORDER BY(b.idCard)) rowNumber,b.IdCard,b.ArchiveNum,b.Name,a.ArchiveUnit,a.ArchiveUnitCode,
                                      isNull(c.flag,0) as isError
                                      FROM HrCover a
                                      INNER JOIN dbo.HrPersonBasicInfo b
                                      ON a.ArchiveNum = b.ArchiveNum
                                      left JOIN (SELECT ArchiveNum,1 as flag FROM HrArchivesResult WHERE IsPass=0 GROUP BY ArchiveNum ) c
                                      ON a.ArchiveNum = c.ArchiveNum
                                      '

    exec(@execSql)

    print '-----------------------------------------插入基本信息表--------------------------------------------------'

--质控结果表

    SELECT @execSql =
            '
            CREATE TABLE control_result(
            id int identity(1,1) primary key,
            archiveNum varchar(70),
            tableName varchar(100),
            fieldName VARCHAR(100),
            ruleType VARCHAR(100),
            comment VARCHAR(200),
            strengthName varchar(10)
            )
            '
    EXEC(@execSql)

    print '-----------------------------------------创建质控结果表------------------------------------------------------------------'
    --质控结果数据插入
--SELECT @execSql = REPLACE(REPLACE(
--'
--INSERT INTO @control_result_fullTableName(ArchiveNum,tableName,fieldName,ruleType,comment,strengthName)
--SELECT  a.ArchiveNum,c.formName,c.fieldName,b.Categories AS ruleType,b.Comment,c.strengthName  FROM HrRuleRecord_@batchNum a
--INNER JOIN dbo.HrRule b
--ON a.RuleId = b.RuleId
--LEFT JOIN dbo.DimForm c
--ON b.TargetTable = c.formType AND b.TargetField = c.fieldType
--
--','@control_result_fullTableName',@control_result_fullTableName),'@batchNum',@batchNum)

    SELECT @execSql =
                                      '
                                      INSERT INTO control_result(ArchiveNum,tableName,fieldName,ruleType,comment,strengthName)

                                      SELECT   a.ArchiveNum,

                                       CASE b.TargetTable
                                       WHEN ''HrHealthCheckup'' THEN ''健康体检表''
                                       WHEN ''HypertensionVisit'' THEN ''高血压随访表''
                                       WHEN ''HrCover'' THEN ''封面表''
                                        WHEN ''DiabetesVisit'' THEN ''糖尿病随访表''
                                         WHEN ''HrPersonBasicInfo'' THEN ''基本信息表''
                                         END AS tableName,
                                      b.targetFieldCn as fieldName,
                                      b.Categories AS ruleType,b.Comment,
                                      CASE  b.indexLevel
                                      WHEN 1 THEN ''核心''
                                      WHEN 2 THEN ''重要''
                                      WHEN 3 THEN ''中等''
                                      WHEN 4 THEN ''普通'' END AS strengthName
                                      FROM HrRuleRecord a
                                      INNER JOIN dbo.HrRule b
                                      ON a.RuleId = b.RuleId

                                      '

    exec(@execSql)

    print '---------------------------------插入质控结果----------------------------------------------'

---质控基本信息创建索引


    SELECT @execSql = 
            '
            CREATE NONCLUSTERED INDEX control_basic_idCard ON control_basic (idCard);  --身份证号
            CREATE NONCLUSTERED INDEX control_basic_archiveNum ON control_basic (archiveNum);  --档案编号
            CREATE NONCLUSTERED INDEX control_basic_isSigned_age_archiveNum ON control_basic (isSigned,age,archiveNum); --年龄
            CREATE NONCLUSTERED INDEX control_basic_SignDoctorName_archiveNum ON control_basic (sign_doctor_name,archiveNum); --签约医生
            '
    EXEC(@execSql)


    print '--------------------------------------质控基本信息创建索引-----------------------------------------------------------'
---质控结果创建索引

    SELECT @execSql = 
            '
            CREATE NONCLUSTERED INDEX control_result_archiveNum ON control_result (archiveNum);  --档案编号
            CREATE NONCLUSTERED INDEX control_result_ruleType_tableName_fieldName_archiveNum ON control_result (ruleType,tableName,fieldName,archiveNum);  --规则类型
            CREATE NONCLUSTERED INDEX control_result_strengthName_tableName_fieldName_archiveNum ON control_result (strengthName,tableName,fieldName,archiveNum);  --指标强度
            '
    exec(@execSql)

    print '--------------------------------------------质控结果创建索引------------------------------------------------------------------------'
---创建视图
-- 
--     select @execSql = 
--                                       '
--                                       create view problemArchiveView as (
--                                       SELECT
--                                       a.rownumber,
--                                       a.idCard,
--                                       a.archiveNum,
--                                       a.name,
--                                       a.archiveUnit,
--                                       a.archiveUnitCode,
--                                       a.age,
--                                       a.jb_gxy,
--                                       a.jb_tnb,
--                                       a.jb_ncz,
--                                       a.jb_zl,
--                                       a.jb_fjh,
--                                       a.jb_jsb,
--                                       a.jb_other,
--                                       a.ts_yunfu,
--                                       a.ts_jihua_jiating,
--                                       a.ts_pinkun,
--                                       a.ts_canji,
--                                       a.ts_other,
--                                       a.jtys_td_name,
--                                       a.sign_doctor_name,
--                                       a.sign_doctor_no,
--                                       a.years,
--                                       a.isSigned,
--                                       a.isError,
--                                       b.tableName,
--                                       b.fieldName,
--                                       b.ruleType,
--                                       b.comment,
--                                       '''' as ruleLevel,
--                                       b.strengthName
--                                       FROM control_basic a
--                                           INNER JOIN control_result b
--                                           ON a.archiveNum = b.archiveNum
--                                           where isError=1
--                                       )
--                                       '
-- 
--     exec(@execSql)

    print '--------------------------------------创建视图-------------------------------------------------'

    -------------------------------------------更新脚本



--年龄更新
--select @execSql = REPLACE(
--'
--UPDATE a SET age=DATENAME(year,GetDate())- CAST(substring(idcard,7,4) AS int) FROM control_basic_@batchNum a
--WHERE ISNUMERIC(substring(idcard,7,4))=1;
--','@batchNum',@batchNum
--)
    select @execSql = 
            '
            UPDATE a SET age =
            (
            CASE  LEN(a.idCard)
            WHEN 18 THEN DATENAME(year,GetDate())- CAST(substring(idcard,7,4) AS int)
            WHEN 15 THEN DATENAME(year,GetDate())- CAST(''19''+SUBSTRING(idcard,7,2) AS INT)
            ELSE -1 END )
            FROM control_basic a
            WHERE ISNUMERIC(substring(idcard,7,4))=1;
            UPDATE  control_basic SET age =-1 WHERE dbo.IsvalidIDCard(idCard) =0;
            '
    exec(@execSql)

    print '----------------------------更新年龄--------------------------------------------------'
    ----------------------------------------------------
--高血压
    select @execSql = 
            '
            UPDATE a SET jb_gxy=ISNULL(gxy,0) FROM control_basic a
             LEFT JOIN (
            select idCard,1 AS gxy FROM HrAssociationInfo t1
                    LEFT JOIN  HrPersonBasicInfo t2 on t1.pid = t2.id
                    where AssociationType = ''history_of_disease''
                    and code = ''I10.x00'')b
                    ON a.idCard = b.idCard;
            '
    exec(@execSql)

    print '---------------------------------更新高血压------------------------------------------------'
    ----------------------------------------------------
--糖尿病
    select @execSql = 
            '
                UPDATE a SET jb_tnb=ISNULL(tnb,0) FROM control_basic a
             LEFT JOIN (
            select idCard,1 AS tnb FROM HrAssociationInfo t1
                    LEFT JOIN  HrPersonBasicInfo t2 on t1.pid = t2.id
                    where AssociationType = ''history_of_disease''
                    and code = ''E14.900'')b
                    ON a.idCard = b.idCard;
            '
    exec(@execSql)

    print '------------------------------------更新糖尿病--------------------------------------------------------'
    ------------------------------------------------------
---脑卒中 I64.x00
    select @execSql = 
            '
                    UPDATE a SET jb_ncz=ISNULL(ncz,0) FROM control_basic a
             LEFT JOIN (
            select idCard,1 AS ncz FROM HrAssociationInfo t1
                    LEFT JOIN  HrPersonBasicInfo t2 on t1.pid = t2.id
                    where AssociationType = ''history_of_disease''
                    and code = ''I64.x00'')b
                    ON a.idCard = b.idCard;
            '
    exec(@execSql)

    print '--------------------------------------脑卒中------------------------------------------------------------'
    -----------------------------------------------------
---肿瘤  10
    select @execSql = 
            '
            UPDATE a SET jb_zl=ISNULL(zl,0) FROM control_basic a
             LEFT JOIN (
            select idCard,1 AS zl FROM HrAssociationInfo t1
                    LEFT JOIN  HrPersonBasicInfo t2 on t1.pid = t2.id
                    where AssociationType = ''history_of_disease''
                    and code = ''10'')b
                    ON a.idCard = b.idCard;
            '
    exec(@execSql)

    print '------------------------------------------肿瘤----------------------------------------------------------'
    -----------------------------------------------------


--肺结核 1004
    select @execSql = 
            '
                UPDATE a SET jb_fjh=ISNULL(fjh,0) FROM control_basic a
             LEFT JOIN (
            select idCard,1 AS fjh FROM HrAssociationInfo t1
                    LEFT JOIN  HrPersonBasicInfo t2 on t1.pid = t2.id
                    where AssociationType = ''history_of_disease''
                    and code = ''1004'')b
                    ON a.idCard = b.idCard;
            '
    exec(@execSql)

    print '---------------------------------------------肺结核--------------------------------------------------------------'
    -----------------------------------------------------
--精神病 1003
    select @execSql =
            '
            UPDATE a SET jb_jsb=ISNULL(jsb,0) FROM control_basic a
             LEFT JOIN (
            select idCard,1 AS jsb FROM HrAssociationInfo t1
                    LEFT JOIN  HrPersonBasicInfo t2 on t1.pid = t2.id
                    where AssociationType = ''history_of_disease''
                    and code = ''1003'')b
                    ON a.idCard = b.idCard;
            '
    exec(@execSql)

    print '---------------------------------------------精神病-----------------------------------------------------------------'
    -----------------------------------------------------
----其他  not in ('I10.x00','E14.900','I64.x00','10','1004','1003','0000') and t1.msg !='无'
    select @execSql = 
            '
            UPDATE a SET jb_other=ISNULL(other,0) FROM control_basic a
             LEFT JOIN (
            select idCard,1 AS other FROM HrAssociationInfo t1
                    LEFT JOIN  HrPersonBasicInfo t2 on t1.pid = t2.id
                    where AssociationType = ''history_of_disease''
                    and code not in (''I10.x00'',''E14.900'',''I64.x00'',''10'',''1004'',''1003'',''0000'') and t1.msg !=''无'')b
                    ON a.idCard = b.idCard;
            '
    exec(@execSql)
    print '---------------------------------------------其他--------------------------------------------------------'
    -------------------------------------------------
--孕妇等更新
    select @execSql = 
            '
            UPDATE a SET ts_yunfu =ISNULL(b.IsYun,0),ts_jihua_jiating = ISNULL(b.IsJiHua,0),
            ts_pinkun = ISNULL(b.IsPin,0),ts_canji =ISNULL(b.IsCan,0),
            ts_other=ISNULL(b.Other,0)
             FROM control_basic a
            LEFT JOIN SpecialCrowd b
            ON a.idCard = b.Idcard;
            '
    exec(@execSql)

    print '--------------------------------------孕妇等更新--------------------------------------------------'
    -------------------------------------------------
----------家庭医生团队
    select @execSql = 
            '
                UPDATE a SET a.jtys_td_name= d.TeamName FROM control_basic a
                LEFT JOIN dbo.HrPersonBasicInfo b
                ON a.idCard = b.idCard
                LEFT JOIN HrCover c
                ON a.archiveNum =c.ArchiveNum
                LEFT JOIN dbo.Team d
                ON c.VillageCode = d.VillageCode
                WHERE ISNULL(c.VillageCode,'''') !='''';
            '
    exec(@execSql)

    print '----------------------------------------家庭医生团队------------------------------------------------------------------'
    -------------------------------------------------
--	责任医生姓名,责任医生编码
    select @execSql = 
            '
            UPDATE a SET a.sign_doctor_name=b.CZRYXM,a.sign_doctor_no=b.CZRYBM FROM control_basic a
                LEFT JOIN QYYH b
                ON a.idCard = b.SFZH;
            '
    exec(@execSql)

    print '-------------------------------------------责任医生姓名,责任医生编码--------------------------------------------------------'
    -------------------------------------------------
--年更新
    select @execSql = 
            '
            UPDATE a SET a.years =CONVERT(VARCHAR(4),ISNULL(b.UpdateTime,b.CreateTime),23) FROM
             control_basic a
            LEFT JOIN HrCover b
            ON a.archiveNum = b.ArchiveNum;
            '
    exec(@execSql)

    print '--------------------------------------------------更新------------------------------------------------------------'
    -------------------------------------------------
--是否签约更新
    select @execSql = 
            '
            UPDATE a SET a.isSigned =ISNULL(b.isSigned,0)
             FROM
             control_basic a
            LEFT JOIN (SELECT *,1 AS isSigned FROM QYYH) b
            ON a.idCard = b.SFZH;
            '
    exec(@execSql)

    print '---------------------------------------------------是否签约更新------------------------------------------------------'

--封面基本信息表
    select @execSql = 
            '
            update a set a.isCoverBaisc=1
            from control_basic a
            '
    exec(@execSql)

    print '--------------------------------------封面基本信息表---------------------------------------------'

    --isCheckup
--体检表
    select @execSql = 
            '
            update a set a.isCheckup=(case when b.idCardNo is not null then ''1'' else ''0'' end)
            from control_basic a
            left join (select DISTINCT(t.idCardNo) from tb_empi_pat_info t inner join tb_dc_examination_info t1 on t.guid=t1.empiGuid where systemCode=''jktj_main'') b
            on a.idCard=b.idCardNo
            '
    exec(@execSql)

    print '---------------------------------------------体检表---------------------------------------------------------'

    --isHypertension
--高血压随访表
    select @execSql = 
            '
            update a set a.isHypertension=(case when b.idCardNo is not null then ''1'' else ''0'' end)
            from control_basic a
            left join (select DISTINCT(idCardNo) from tb_empi_pat_info t
            inner join tb_dc_chronic_info t1 on t.guid=t1.empiGuid
            inner join tb_dc_chronic_main t2 on t1.manageNum=t2.manageNum and t1.orgCode=t2.orgCode
            inner join tb_dc_htn_visit t3 on t2.visitNum=t3.cardId where systemCode=''mxb_main'') b
            on a.idCard=b.idCardNo
            '
    exec(@execSql)

    print '------------------------------------------高血压随访表--------------------------------------------------------------------'
    --isDiabetes
--糖尿病随访表
    select @execSql = 
            '
            update a set a.isDiabetes=(case when b.idCardNo is not null then ''1'' else ''0'' end)
            from control_basic a
            left join (select DISTINCT(idCardNo) from tb_empi_pat_info t
            inner join tb_dc_chronic_info t1 on t.guid=t1.empiGuid
            inner join tb_dc_chronic_main t2 on t1.manageNum=t2.manageNum and t1.orgCode=t2.orgCode
            inner join tb_dc_dm_visit t3 on t2.visitNum=t3.cardId where systemCode=''mxb_main'') b
            on a.idCard=b.idCardNo
            '
    exec(@execSql)

    print '-----------------------------------------------糖尿病随访表---------------------------------------------------------------'

--isCoverBaisc int, --属于封面基本 1为属于
    select @execSql = 
            '
            update control_basic set isCoverBaisc=1
            '
    exec(@execSql)


    print '--------------------------------------------------属于封面基本 1为属于------------------------------------------------------------------'
    --isCheckup int, --健康体检表分值  1为属于
--isHypertension int, --属于高血压随访表 1为属于
--isDiabetes int, --属于糖尿病随访表 1为属于
--

--checkupScore int, --健康体检表分值
--hypertensionScore int, --高血压随访表分值
--diabetesScore int --糖尿病随访表分值

--coverBaiscScore int, --封面基本信息表分值
--封面基本信息表分值 --非核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum,(107-SUM(b.score))*100/107 AS score
            FROM dbo.control_basic a
            INNER JOIN (
            SELECT archiveNum,
            CASE strengthName
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS score
             FROM control_result WHERE strengthName !=''核心'' and tableName IN (''封面表'',''基本信息表'')
            ) b
            ON a.archiveNum = b.archiveNum
            WHERE a.isCoverBaisc =1
            GROUP BY a.archiveNum)

            UPDATE a SET a.coverBaiscScore = t.score
            FROM dbo.control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)

    print '---------------------------------------封面基本信息表分值 --非核心--------------------------------------------------------------'

    --checkupScore  isCheckup
--健康体检表分值 --非核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum,(337-SUM(b.score))*100/337 AS score
            FROM dbo.control_basic a
            INNER JOIN (
            SELECT archiveNum,tableName,
            CASE strengthName
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS score
             FROM control_result WHERE strengthName !=''核心'' and tableName IN (''健康体检表'')
            ) b
            ON a.archiveNum = b.archiveNum
            WHERE a.isCheckup =1
            GROUP BY a.archiveNum)

            UPDATE a SET a.checkupScore = t.score
            FROM dbo.control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)

    print '-------------------------------------------健康体检表分值 --非核心--------------------------------------------------------------'
    --isDiabetes diabetesScore
--糖尿病随访表 --非核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum,(141-SUM(b.score))*100/141 AS score
            FROM dbo.control_basic a
            INNER JOIN (
            SELECT archiveNum,
            CASE strengthName
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS score
             FROM control_result WHERE strengthName !=''核心'' and tableName IN (''糖尿病随访表'')
            ) b
            ON a.archiveNum = b.archiveNum
            WHERE a.isDiabetes =1
            GROUP BY a.archiveNum)

            UPDATE a SET a.diabetesScore = t.score
            FROM dbo.control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)
    print '--------------------------------------------------糖尿病随访表 --非核心--------------------------------------------------------------------------------------'
    --isHypertension hypertensionScore
--高血压随访表 --非核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum,(140-SUM(b.score))*100/140 AS score
            FROM dbo.control_basic a
            INNER JOIN (
            SELECT archiveNum,
            CASE strengthName
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS score
             FROM control_result WHERE strengthName !=''核心''  AND tableName IN (''高血压随访表'')
            ) b
            ON a.archiveNum = b.archiveNum
            WHERE a.isHypertension =1
            GROUP BY a.archiveNum)

            UPDATE a SET a.hypertensionScore = t.score
            FROM dbo.control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)

    print '----------------------------------------------高血压随访表 --非核心-----------------------------------------------------'
    --isCoverBaisc
--封面基本信息表分值 --核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum FROM control_basic a
            INNER JOIN control_result b
            ON a.archiveNum = b.archiveNum
            WHERE a.isCoverBaisc =1 AND b.tableName IN (''封面表'',''基本信息表'') AND b.strengthName =''核心''
            GROUP BY a.archiveNum
            )
            UPDATE a SET a.coverBaiscScore=0
             FROM control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)

    print '---------------------------------------------封面基本信息表分值 --核心----------------------------------------------------------------------------'
    --isCheckup
--健康体检表表分值 --核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum FROM control_basic a
            INNER JOIN control_result b
            ON a.archiveNum = b.archiveNum
            WHERE a.isCheckup =1 AND b.tableName IN (''健康体检表'') AND b.strengthName =''核心''
            GROUP BY a.archiveNum
            )
            UPDATE a SET a.checkupScore=0
             FROM control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)

    print '----------------------------------------------------健康体检表表分值 --核心------------------------------------------------------------------------------'
    --isDiabetes
--糖尿病随访表分值 --核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum FROM control_basic a
            INNER JOIN control_result b
            ON a.archiveNum = b.archiveNum
            WHERE a.isDiabetes =1 AND b.tableName IN (''糖尿病随访表'') AND b.strengthName =''核心''
            GROUP BY a.archiveNum
            )
            UPDATE a SET a.diabetesScore=0
             FROM control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)

    print '----------------------------------------------糖尿病随访表分值 --核心------------------------------------------------------------------------'
    --isHypertension
--高血压随访表分值 --核心
    select @execSql = 
            '
            WITH t AS (
            SELECT a.archiveNum FROM control_basic a
            INNER JOIN control_result b
            ON a.archiveNum = b.archiveNum
            WHERE a.isHypertension =1 AND b.tableName IN (''高血压随访表'') AND b.strengthName =''核心''
            GROUP BY a.archiveNum
            )
            UPDATE a SET a.hypertensionScore=0
             FROM control_basic a
            INNER JOIN t
            ON a.archiveNum = t.archiveNum
            '
    exec(@execSql)

    print '---------------------------------------------高血压随访表分值 --核心----------------------------------------------------------------------------'

    --添加 规则类型索引  签约医生



----------------------ZKTypeTrend 表数据维护------------------------

-----------ZKTypeTrend  标志位（ 0-字段质控，1-错误总数量，2-签约数量标志，3-年份标志）


------ 0-字段质控
---    select @execSql = REPLACE(
---            '
---            INSERT INTO ZKTypeTrend(ControlTime,ControlFields,WrongNum,CreateTime,Symbol,zkbm)
---            SELECT ---(SUBSTRING(''@batchNum'',1,4)+''-''+SUBSTRING(''@batchNum'',5,2)+''-''+SUBSTRING(''@batchNum'',7,2)) AS ---ControlTime,
---            ruleType AS ControlFields,
---            COUNT(ruleType) AS WrongNum,GETDATE() AS CreateTime,0 AS Symbol,
--            ''@batchNum'' AS zkbm
--            FROM (
 ---           SELECT archiveNum,ruleType FROM dbo.control_result_@batchNum GROUP BY archiveNum,ruleType)a
---           GROUP BY ruleType
--            ','@batchNum',@batchNum
--        )
--print @execSql
  --  exec(@execSql)

   -- print '-------------------------------------------- 0-字段质控----------------------------------------------------'

----   1-错误总数量
--     SELECT @execSql = REPLACE(
--             '
--             INSERT INTO ZKTypeTrend(ControlTime,WrongNum,CreateTime,Symbol,zkbm)
--             VALUES (SUBSTRING(''@batchNum'',1,4)+''-''+SUBSTRING(''@batchNum'',5,2)+''-''+SUBSTRING(''@batchNum'',7,2),(SELECT COUNT(*) FROM dbo.control_basic_@batchNum WHERE isError=1),GETDATE(),1,''@batchNum'');
--             ','@batchNum',@batchNum
--         )
-- --print @execSql
--     EXEC(@execSql)
-- 
--     print '--------------------------------------------   1-错误总数量----------------------------------------------------------------'
-- 
-- ----- 2 签约数量标志
--     SELECT @execSql = REPLACE(
--             '
--             INSERT INTO  dbo.ZKTypeTrend
--             (ControlTime, WrongNum,CreateTime,Symbol,zkbm)
--             VALUES(SUBSTRING(''@batchNum'',1,4)+''-''+SUBSTRING(''@batchNum'',5,2)+''-''+SUBSTRING(''@batchNum'',7,2),(SELECT COUNT(*) FROM dbo.control_basic_@batchNum WHERE isSigned=1 and isError=1),GETDATE(),2,''@batchNum'')
--             ','@batchNum',@batchNum
--         )
-- --print @execSql
--     EXEC(@execSql)
-- 
--     print '------------------------------------------------2 签约数量标志-------------------------------------------------------------------------------'
-- ----- 3-年份标志
--     SELECT @execSql = REPLACE(
--             '
--             INSERT INTO  dbo.ZKTypeTrend
--             (ControlTime, WrongNum,CreateTime,Symbol,zkbm,year)
--             SELECT (SUBSTRING(''@batchNum'',1,4)+''-''+SUBSTRING(''@batchNum'',5,2)+''-''+SUBSTRING(''@batchNum'',7,2)) AS ControlTime,
--             COUNT(years) AS WrongNum,GETDATE() AS CreateTime,3 AS Symbol,
--             ''@batchNum'' AS zkbm,
--             years AS year FROM control_basic_@batchNum WHERE isError =1 GROUP BY years
--             ','@batchNum',@batchNum
--         )
-- --print @execSql
--     EXEC(@execSql)
-- 
--     print '---------------------------------------------------3-年份标志---------------------------------------------------------------------------------------'
----------------ControlError 表更新
--     SELECT @execSql = REPLACE(
--             '
--             INSERT INTO dbo.ControlError(controlId,years,yearsNum)
--             SELECT ''@batchNum'' AS controlId,years,COUNT(years) AS yearsNum   FROM dbo.control_basic_@batchNum WHERE ISNULL(years,'''') !='''' GROUP BY years
--             ','@batchNum',@batchNum
--         )
--     EXEC(@execSql)
-- 
--     print '--------------------------------------------------ControlError 表更新------------------------------------------------------------------------------------'
-- 
-- -----------------------ZKJLB 签约人群更新
--     SELECT @execSql = REPLACE(
--             '
--             UPDATE ZKJLB SET qyNum =(SELECT COUNT(*) FROM dbo.control_basic_@batchNum  WHERE isSigned=1) WHERE zkbm =''@batchNum''
--             ','@batchNum',@batchNum
--         )
--     EXEC(@execSql)
-- 
--     print '-------------------------------------------------------ZKJLB 签约人群更新--------------------------------------------------------------------------------------------'

----------如果质控没有错 给100分
    select @execSql = 
            '
            update 	control_basic set coverBaiscScore=100 where isCoverBaisc=1 and coverBaiscScore is null;
            update 	control_basic set checkupScore=100 where isCheckup =1 and checkupScore is null;
            update 	control_basic set hypertensionScore=100 where isHypertension =1 and hypertensionScore is null;
            update 	control_basic set diabetesScore=100 where isDiabetes=1 and diabetesScore is null;
            '
    EXEC(@execSql)

    print '----------------------------------------------------------如果质控没有错 给100分------------------------------------------------------------------------------------'

--封面基本信息表是否错误
    select @execSql = 
            '
            UPDATE a SET a.isErrorCoverBasic = ISNULL(b.flag,0)
            FROM dbo.control_basic a
            left JOIN (
            SELECT archiveNum,1 AS flag
            FROM dbo.control_result
            WHERE tableName IN (''封面表'',''基本信息表'')
            GROUP BY ArchiveNum
            )b ON a.archiveNum = b.archiveNum
            WHERE a.isCoverBaisc =1
            '
    EXEC(@execSql)

    print '-----------------------------------------------------------封面基本信息表是否错误---------------------------------------------------------------------------'

--体检表是否错误
    select @execSql = 
            '
            UPDATE a SET a.isErrorCheckup = ISNULL(b.flag,0)
            FROM dbo.control_basic a
            left JOIN (
            SELECT archiveNum,1 AS flag
            FROM dbo.control_result
            WHERE tableName IN (''健康体检表'')
            GROUP BY ArchiveNum
            )b ON a.archiveNum = b.archiveNum
            WHERE a.isCheckup =1
            '
    EXEC(@execSql)

    print '--------------------------------------------体检表是否错误-------------------------------------------------------------------------------------'

--高血压随访表是否错误
--     select @execSql = 
--             '
--             UPDATE a SET a.isErrorHypertension = ISNULL(b.flag,0)
--             FROM dbo.control_basic a
--             left JOIN (
--             SELECT archiveNum,1 AS flag
--             FROM dbo.control_result
--             WHERE tableName IN (''高血压随访表'')
--             GROUP BY ArchiveNum
--             )b ON a.archiveNum = b.archiveNum
--             WHERE a.isHypertension =1
--             '
--EXEC(@execSql)

-- 
--     print '---------------------------------------------------高血压随访表是否错误--------------------------------------------------------------------------'
--糖尿病随访表是否错误
--     select @execSql = 
--             '
--             UPDATE a SET a.isErrorDiabetes = ISNULL(b.flag,0)
--             FROM dbo.control_basic a
--             left JOIN (
--             SELECT archiveNum,1 AS flag
--             FROM dbo.control_result
--             WHERE tableName IN (''糖尿病随访表'')
--             GROUP BY ArchiveNum
--             )b ON a.archiveNum = b.archiveNum
--             WHERE a.isDiabetes =1
--             '
--EXEC(@execSql)
-- 
--     print '---------------------------------------------------------糖尿病随访表是否错误-----------------------------------------------------------------------------------------------'

END
go

