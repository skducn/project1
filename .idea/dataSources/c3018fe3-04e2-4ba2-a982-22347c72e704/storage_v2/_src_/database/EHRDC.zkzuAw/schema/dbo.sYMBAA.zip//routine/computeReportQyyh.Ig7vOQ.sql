CREATE PROCEDURE [dbo].[computeReportQyyh]
  @startDate VARCHAR(20), 
  @endDate VARCHAR(20)
AS
BEGIN

set nocount ON
    -- 创建临时表
    exec createReportQyyhCursor
    -- 计算基础数据    
		exec computeBasicData @startDate,@endDate
		-- 计算高血压
		exec computeHtnVisit2 @startDate,@endDate
		-- 计算糖尿病
		exec computeDmVisit2 @startDate,@endDate
		-- 计算其他数值
		exec computeOtherInfo @startDate,@endDate
		-- 计算临时设置
		exec computeTemporaryInfo @startDate,@endDate

END
go

