CREATE PROCEDURE [dbo].[getgetCheckResultByIdCardNo] @idCardNo VARCHAR ( 100 ) 
AS 
BEGIN 

    declare @empiGuid varchar(100)
    
  set @empiGuid = (select guid from tb_empi_index_root where idCardNo = @idCardNo)

  print @empiGuid
  
 IF OBJECT_ID( N'tempdb..#T', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T
    end 
   CREATE table #T (
    guid varchar(100),
    reportNo VARCHAR(100),
   HospitalLevel varchar(100),
   reportDate datetime  
  )
    -- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index ON #T ( reportNo)

 INSERT INTO #T SELECT guid,reportNo,a.HospitalLevel,reportDate FROM tb_lis_report total 
 outer apply (select HospitalLevel from t_dic_hospital_info where Hospital_id = total.orgCode ) a
 where  empiGuid =@empiGuid

select  resultUnit AS unit, HospitalLevel AS orgLevel, orgCode AS orgCode,
   orgName AS orgName, reportDate AS examDate
 , t.guid AS idOfTargetTable, itemName, resultValue from  tb_lis_report_indicator detail 
inner join #T t on t.reportNo = detail.reportNo 

END
go

