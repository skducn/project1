CREATE PROCEDURE [dbo].[usp_getIndicatorByIdCardNoAndReportDate]
	@idCardNo VARCHAR(20),
	@reportDateBegin VARCHAR(50) = '1970-01-01 10:10:10.000',
	@reportDateEnd VARCHAR(50) = '2099-12-30 10:17:16.000'
AS
BEGIN
	-- 1. root.guid = total.empiguid  根据 @idCardNo 查 tb_empi_index_root root.guid 
	DECLARE @rootGuid VARCHAR(100)
	SET @rootGuid = (SELECT TOP 1 guid FROM tb_empi_index_root WHERE idCardNo = @idCardNo)
	
	-- 2.tb_lis_report total 用子查询替代
	SELECT
		detail.itemName,
		detail.resultValue,
		detail.resultUnit
	FROM
		tb_lis_report_indicator detail
		INNER JOIN (
				SELECT visitStrNo, orgCode
				FROM tb_lis_report
				WHERE empiguid = @rootGuid
				AND reportDate BETWEEN DATEADD(month, -3, @reportDateBegin) AND @reportDateEnd
		) total ON total.visitStrNo = detail.visitStrNo AND total.orgCode = detail.orgCode
END
go

