CREATE FUNCTION [dbo].[computeDate] (
  @startDate AS varchar(20), 
  @endDate AS  varchar(20) 
)
RETURNS varchar(20)
AS
BEGIN
 
  set @startDate = convert(varchar(10),convert(date,@startDate,120))
  set @endDate = convert(varchar(10),convert(date,@endDate,120))

  declare @returnDate varchar(20)=''
  
	-- 如果登记时间大于质控开始时间 返回 登记时间
  if DATEDIFF(day,@startDate,@endDate)<=0 
  begin
  set @returnDate =@startDate
  end
  else
  begin 
  declare @mmCount int =0
	-- 计算需要增加多少月份 
  declare @mmInfo int =  abs(datediff(MONTH,convert(date,@startDate),CONVERT(date,@endDate))%3)
	 
	 --如果 月份一致且 日小于质控开始日就加一个季度
	if @mmInfo =0 and convert(int,RIGHT(@startDate, 2)) < convert(int,RIGHT(@endDate, 2))
     BEGIN
	       set @mmCount +=3	
	 end
  --如果日期相同且 日大于质控开始时间的日 就为 0 
  if  @mmInfo =0 and (convert(int,RIGHT(@startDate, 2)) >= convert(int,RIGHT(@endDate, 2)) )
      begin
		   set @mmCount +=@mmInfo
	  end
	--如果 日期小于质控开始时间 加取余少的时间	
  if @mmInfo>0
		begin
		   set @mmCount +=3-@mmInfo
	
	    end
	
	declare @month int  = Month(dateadd(mm,@mmCount,CONVERT(date,@endDate)))

  set @returnDate = convert(varchar(8), dateadd(mm,@mmCount,CONVERT(date,@endDate)))
		
	declare @y int = YEAR(dateadd(mm,@mmCount,CONVERT(date,@endDate)))
	
	if(@month=2 and  convert(int,right(@startDate,2))>28)
	BEGIN
	     IF ( (  @y % 4 = 0 AND  @y % 100  <> 0 ) OR ( @y % 400 = 0 ))
			   BEGIN
			     set @returnDate +='29';
			   END
		  ELSE 
			   BEGIN
				 	 set @returnDate +='28';
			   END

	END
	else if ( convert(int,right(@startDate,2))>30  and ( (@month%2=0 and @month!=8 and @month !=10 and @month !=12 ) or @month =9 or @month =11) )
	BEGIN
	  set @returnDate +='30'
	END
	ELSE 
	BEGIN
	  set @returnDate +=right(@startDate,2)
	end 
 end

  RETURN  @returnDate;

END
go

