CREATE PROCEDURE [dbo].[getHypertensionInfoByIdCardNo] @idCardNo VARCHAR ( 100 ) AS BEGIN
	DECLARE
		@empiGuid VARCHAR ( 100 ) 
		SET @empiGuid = ( SELECT guid FROM tb_empi_index_root WHERE idCardNo = @idCardNo ) 
		
		IF OBJECT_ID( N'tempdb..#T1', N'U' ) IS NOT NULL BEGIN
			DROP TABLE #T1 
		END 
	create Table #T1(
	  orgCode  varchar(100),
      livePlaceDetailAddress varchar(200),
      phone varchar(50),
      sex varchar(50),
      visitNum  varchar(50)			
		)
	CREATE NONCLUSTERED INDEX NonClu_Index ON #T1 (orgCode,visitNum) 		
		
		
	insert into #t1 select orgCode,livePlaceDetailAddress,phone, sexCode, visitNum	from  tb_dc_chronic_main where empiGuid = @empiGuid	and visitTypeCode like '%31%'
		
		
	IF OBJECT_ID( N'tempdb..#T2', N'U' ) IS NOT NULL BEGIN
			DROP TABLE #T2
		END 
	-- 获取随访表信息
	CREATE TABLE #T2 (
			name VARCHAR ( 255 ),
			idOfTargetTable VARCHAR ( 255 ),
			number VARCHAR ( 255 ),
			ehrNum VARCHAR ( 255 ),
			visitCode VARCHAR ( 255 ),
			otherVisit VARCHAR ( 255 ),
			lostVisit VARCHAR ( 255 ),
			lostVisitCode VARCHAR ( 255 ),
			lostVisitOther VARCHAR ( 255 ),
			lostVisitDate datetime,
			visitDate datetime,
			hasPaperCard VARCHAR ( 255 ),
			symptomCode VARCHAR ( 255 ),
			symptomOther VARCHAR ( 255 ),
			bpWayCode VARCHAR ( 255 ),
			sbp VARCHAR ( 255 ),
			dbp VARCHAR ( 255 ),
			height VARCHAR ( 255 ),
			weight VARCHAR ( 255 ),
			targetWeight VARCHAR ( 255 ),
			bmi VARCHAR ( 255 ),
			targetBmi VARCHAR ( 255 ),
			heartRate VARCHAR ( 255 ),
			smokeStatus VARCHAR ( 255 ),
			smokingStatusName VARCHAR ( 255 ),
			smokingVolume VARCHAR ( 255 ),
			targetSmoke VARCHAR ( 255 ),
			drinkFrequency VARCHAR ( 255 ),
			drinkingFrequencyName VARCHAR ( 255 ),
			drinkingVolume VARCHAR ( 255 ),
			targetDrink VARCHAR ( 255 ),
			exeWeek VARCHAR ( 255 ),
			targetExeWeek VARCHAR ( 255 ),
			sportTime VARCHAR ( 255 ),
			targetSportTime VARCHAR ( 255 ),
			saltUptakeStatus VARCHAR ( 255 ),
			targetSaltUptakeStatus VARCHAR ( 255 ),
			psychologyStatus VARCHAR ( 255 ),
			complianceStatus VARCHAR ( 255 ),
			manageGroup VARCHAR ( 255 ),
			clinicalInfo VARCHAR ( 255 ),
			cholesterol VARCHAR ( 255 ),
			highCholesterol VARCHAR ( 255 ),
			lowCholesterol VARCHAR ( 255 ),
			triglycerides VARCHAR ( 255 ),
			dangerousLevel VARCHAR ( 255 ),
			isUseDrug VARCHAR ( 255 ),
			noUseDrugReasonCode VARCHAR ( 255 ),
			noUseDrugSideEffects VARCHAR ( 255 ),
			noUseDrugLaw VARCHAR ( 255 ),
			drugCompliance VARCHAR ( 255 ),
			lawSideEffectsCode VARCHAR ( 255 ),
			lawSideEffects VARCHAR ( 255 ),
			visitType VARCHAR ( 255 ),
			treatmentMeasures VARCHAR ( 255 ),
			proposal VARCHAR ( 255 ),
			acceptability VARCHAR ( 255 ),
			isAcceptHealthEdu VARCHAR ( 255 ),
			healthEduType VARCHAR ( 255 ),
			referralReason VARCHAR ( 255 ),
			referralOrgDept VARCHAR ( 255 ),
			nextVisiDate datetime,
			visitDocNo VARCHAR ( 255 ),
			visitOrgCode VARCHAR ( 255 ),
			visitOrgName VARCHAR ( 255 ),
			serumPotassium VARCHAR ( 255 ),
			sodium VARCHAR ( 255 ),
			fastingBloodGlucose VARCHAR ( 255 ),
			bloodLipid VARCHAR ( 255 ),
			uricAcid VARCHAR ( 255 ),
			creatinine VARCHAR ( 255 ),
			hemoglobin VARCHAR ( 255 ),
			leukocyte VARCHAR ( 255 ),
			platelet VARCHAR ( 255 ),
			urineProtein VARCHAR ( 255 ),
			urineGlucose VARCHAR ( 255 ),
			glycosylatedHemoglobin VARCHAR ( 255 ),
			highSensitivityCReactiveProtein VARCHAR ( 255 ),
			urineProteinQuantity VARCHAR ( 255 ),
			homocysteine VARCHAR ( 255 ),
			carotidArteryUltrasound VARCHAR ( 255 ),
			pulseWaveVelocity VARCHAR ( 255 ),
			ecg VARCHAR ( 255 ),
			ultrasonicCardiogram VARCHAR ( 255 ),
			waistline VARCHAR ( 255 ),
			chestXRay VARCHAR ( 255 ),
		    cardId varchar(255),
		    orgCode  varchar(255)
		) 
		
		
	CREATE NONCLUSTERED INDEX NonClu_Index ON #T2( cardId, orgCode ) 
		
  insert into #T2 SELECT
        
        -- 姓名
        htn.name AS name,
        -- 当前记录唯一标识
        htn.guid AS idOfTargetTable,
        -- 随访表编号
        htn.cardId AS number,
        -- 编号
        htn.ehrNum AS ehrNum,
        -- 随访方式
        htn.visitWayCode AS visitCode,
        -- 其他随访方式(非code)
        htn.otherVisit AS otherVisit,
        -- 是否失访
        htn.vistStatusCode AS lostVisit,
        -- 失访理由
        htn.lostVisitCode AS lostVisitCode,
        -- 其它失访理由
        htn.otherLostVIsitName AS lostVisitOther,
        -- 失访日期
        htn.lostVisitDate AS lostVisitDate,
        -- 随访日期
        htn.visitDate AS visitDate,
        -- 是否有纸质卡
        htn.hasPaperCard AS hasPaperCard,
        -- 目前症状
        htn.symptomCode AS symptomCode,
        -- 其他症状
        htn.symptomOther AS symptomOther,
        -- 血压数据采集方式
        htn.bpWayCode AS bpWayCode,
        -- 血压(收缩)
        htn.sbp AS sbp,
        -- 血压(舒张)
        htn.dbp AS dbp,
        -- 身高
        htn.height AS height,
        -- 体重
        htn.weight AS weight,
        -- 目标体重
        htn.targetWeight AS targetWeight,
        -- 体质指数
        htn.bmi AS bmi,
        -- 目标体质指数
        htn.targetBmi AS targetBmi,
        -- 心率
        htn.heartRate AS heartRate,
        -- 吸烟状况
        htn.smokingStatusCode AS smokeStatus,
        -- 吸烟状况名称
        htn.smokingStatusName AS smokingStatusName,
        -- 日吸烟量
        htn.smokingVolume AS smokingVolume,
        -- 目标吸烟
        htn.targetSmoke AS targetSmoke,
        -- 饮酒频率
        htn.drinkingFrequencyCode AS drinkFrequency,
        -- 饮酒频率名称
        htn.drinkingFrequencyName AS drinkingFrequencyName,
        -- 日饮酒量
        htn.drinkingVolume AS drinkingVolume,
        -- 目标饮酒量
        htn.targetDrink AS targetDrink,
        -- 每周运动次数
        htn.sportFrequence AS exeWeek,
        -- 目标每周运动次数
        htn.targetSportFrequencyCode AS targetExeWeek,
        -- 每次运动时间
        htn.sportTime AS sportTime,
        -- 目标每次运动时间（分钟）
        htn.targetSportTimes AS targetSportTime,
        -- 摄盐情况
        htn.saltUptakeStatus AS saltUptakeStatus,
        -- 目标摄盐情况
        htn.targetSaltUptakeStatus AS targetSaltUptakeStatus,
        -- 心理调整
        htn.psychologyStatus AS psychologyStatus,
        -- 遵医行为
        htn.complianceStatus AS complianceStatus,
        -- 管理组别
        htn.manageGroup AS manageGroup,
        -- 高血压并存临床情况
        htn.clinicalInfo AS clinicalInfo,
        -- 其他辅助检查—总胆固醇
        htn.cholesterol AS cholesterol,
        -- 其他辅助检查—血清高密度脂蛋白胆固醇
        htn.highCholesterol AS highCholesterol,
        -- 其他辅助检查—血清低密度脂蛋白胆固醇
        htn.lowCholesterol AS lowCholesterol,
        -- 甘油三酯
        htn.triglycerides AS triglycerides,
        -- 危险分层
        htn.dangerousLevelCode AS dangerousLevel,
        -- 是否服药
        htn.isUseDrug AS isUseDrug,
        -- 不服药原因
        htn.noUseDrugReasonCode AS noUseDrugReasonCode,
        -- 不服药不良反应描述
        htn.noUseDrugSideEffects AS noUseDrugSideEffects,
        -- 是否规律服药
        htn.noUseDrugLaw AS noUseDrugLaw,
        -- 服药依从性
        htn.drugComplianceCode AS drugCompliance,
        -- 药物不良反应
        htn.lawSideEffectsFlag AS lawSideEffectsCode,
        -- 药物不良反应描述
        htn.lawSideEffects AS lawSideEffects,
        -- 此次随访分类
        htn.visitType AS visitType,
        -- 非药物治疗措施
        htn.treatmentMeasures AS treatmentMeasures,
        -- 健康处方
        htn.proposal AS proposal,
        -- 患者接受管理程度
        htn.acceptability AS acceptability,
        -- 是否接受过健康教育
        htn.isAcceptHealthEdu AS isAcceptHealthEdu,
        -- 接受过何种形式的健康教育
        htn.healthEduType AS healthEduType,
        -- 转诊原因
        htn.referralReason AS referralReason,
        -- 转诊机构及科别
        htn.referralOrgDept AS referralOrgDept,
        -- 下次随访日期
        htn.nextVisiDate AS nextVisiDate,
        -- 随访医生签名
        htn.visitDocName AS visitDocNo,
        -- 随访机构
        htn.visitOrgCode AS visitOrgCode,
        htn.visitOrgName AS visitOrgName,
        -- 辅助检查—血钾
        htn.bloodPotassium AS serumPotassium,
        -- 辅助检查—钠
        htn.bloodSodium AS sodium,
        -- 辅助检查—空腹血糖
        htn.fastingBloodSugarValue AS fastingBloodGlucose,
        -- 辅助检查—血脂
        htn.bloodLipids AS bloodLipid,
        -- 辅助检查—尿酸
        htn.uricAcid AS uricAcid,
        -- 辅助检查—肌酐
        htn.creatinine AS creatinine,
        -- 辅助检查—血红蛋白
        htn.hemoglobin AS hemoglobin,
        -- 辅助检查—白细胞
        htn.hemameba AS leukocyte,
        -- 辅助检查—血小板
        htn.platelet AS platelet,
        -- 辅助检查—尿蛋白
        htn.urineProtein AS urineProtein,
        -- 辅助检查—尿糖
        htn.urineSugar AS urineGlucose,
        -- 辅助检查—糖化血红蛋白
        htn.glycosylatedHemoglobin AS glycosylatedHemoglobin,
        -- 辅助检查—血高敏 C 反应蛋白
        htn.serumCProtein AS highSensitivityCReactiveProtein,
        -- 辅助检查—尿蛋白定量
        htn.urineProteinQuantity AS urineProteinQuantity,
        -- 辅助检查—同型半胱氨酸
        htn.homocysteineDetection AS homocysteine,
        -- 其他辅助检查—颈动脉超声
        htn.carotidUltrasound AS carotidArteryUltrasound,
        -- 其他辅助检查—脉搏波传导速度
        htn.pulseWave AS pulseWaveVelocity,
        -- 其他辅助检查—心电图
        htn.ECG AS ecg,
        -- 其他辅助检查—超声心动图
        htn.echocardiogram AS ultrasonicCardiogram,
        -- 腰围
        htn.waistline AS waistline,
        -- 其他辅助检查—胸部 X 线摄片
        htn.chestXray AS chestXRay,
        -- 高血压随访表“管理机构代码”字段对应的中文名称
        htn.cardId,
		htn.orgCode
				
        FROM tb_dc_htn_visit AS htn	  where empiGuid = @empiGuid
				
		select @idCardNo AS idCard , t2.*,t1.livePlaceDetailAddress,t1.phone,t1.sex,t3.Hospital_name as orgName, 
IIF((select count(1) from tb_dc_htn_usedrug where visitId = t1.visitNum  and orgcode = t1.orgCode ) >0,1,0)drugIsTrue 	
	from  #T2 t2 inner join  #T1 t1 on t2.cardId = t1.visitNum and t2.orgCode = t1.orgCode 
		left join t_dic_hospital_info t3 on t2.orgCode=t3.Hospital_id
		order by visitDate desc

	END
go

