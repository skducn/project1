CREATE FUNCTION [dbo].[IsvalidIDCard] ( @IDCardNo VARCHAR(50) )
    RETURNS BIT
AS
BEGIN


    DECLARE @Length INT ,
        @Loop INT ,
        @Sum INT
    DECLARE @SingleChar CHAR


    SET @Sum = 0
    IF @IDCardNo IS NULL
        OR @IDCardNo = NULL
        OR LTRIM(RTRIM(@IDCardNo)) = ''
        BEGIN
            RETURN 0
        END


    SET @Length = LEN(@IDCardNo)
    --判断位数
    IF @Length < > 18
        AND @Length < > 15
        BEGIN
            RETURN 0
        END
    IF @Length = 18
        BEGIN
            IF ISNUMERIC(LEFT(@IDCardNo, 17)) = 0
                BEGIN
                    RETURN 0
                END
            IF ISDATE(SUBSTRING(@IDCardNo, 7, 4) + ' - '
                + SUBSTRING(@IDCardNo, 11, 2) + ' - '
                + SUBSTRING(@IDCardNo, 13, 2)) = 0
                BEGIN
                    RETURN 0
                END
            SET @Loop = 17
            WHILE ( @Loop >= 1 )
                BEGIN
                    SET @Sum = @Sum
                        + CONVERT(INT, REPLACE(SUBSTRING(@IDCardNo, @Loop,
                                                         1), '.', ''))
                                   * ( POWER(2, ( 18 - @Loop )) % 11 )
                    SET @Loop = @Loop - 1
                END
            SET @Loop = @Sum % 11
            IF @Loop = 0
                BEGIN
                    SET @SingleChar = '1'
                END
            ELSE
                IF @Loop = 1
                    BEGIN
                        SET @SingleChar = '0'
                    END
                ELSE
                    IF @Loop = 2
                        BEGIN
                            SET @SingleChar = 'X'
                        END
                    ELSE
                        BEGIN
                            SET @SingleChar = CONVERT(VARCHAR(2), ( 12
                                - @Loop ))
                        END
            IF LOWER(RIGHT(@IDCardNo, 1)) < > LOWER(@SingleChar)
                BEGIN
                    RETURN 0
                END
        END
    ELSE
        IF @Length = 15
            BEGIN
                IF ISNUMERIC(@IDCardNo) = 0
                    BEGIN
                        RETURN 0
                    END
                IF ISDATE('19' + SUBSTRING(@IDCardNo, 7, 2) + ' - '
                    + SUBSTRING(@IDCardNo, 9, 2) + ' - '
                    + SUBSTRING(@IDCardNo, 11, 2)) = 0
                    BEGIN
                        RETURN 0
                    END
                IF LEFT(@IDCardNo, 1)=0
                    BEGIN
                        RETURN 0
                    END
            END

    RETURN 1

END
go

