CREATE PROCEDURE [dbo].[computeOtherInfo]
  @质控数据开始时间 AS varchar(20), 
  @质控数据截止时间 AS varchar(20)
AS
BEGIN

-- 档案封面字段总数
declare @A float=11
-- 个人基本信息表
declare @B float=38
-- 健康体检表
declare @C float=143
-- 高血压随访表
declare @D float=57
-- 糖尿病随访表
declare @E float=58

-- 记录 sql执行开始时间 和 耗时
declare @SQL开始执行时间 datetime
declare @耗时 int


-- 签约居民中≥65岁老年人，且无高血压和糖尿病登记，字段总数（N1)
-- A+B+C
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N1=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
where R1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N1' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(N1)', GETDATE())

-- 签约居民中≥65岁老年人，且同时有高血压和糖尿病登记,字段总数（N2)
-- A+B+C+D*B613+E*B813
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N2=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
    + @D * B613
    + @E * B813
where R2 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(N2)', GETDATE())

-- 签约居民中≥65岁老年人，有高血压，无糖尿病登记,字段总数（N3)
-- A+B+C+D*B613
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N3=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
    + @D * B613
where R3 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N3' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 签约居民中≥65岁老年人，无高血压，有糖尿病登记,字段总数（N4)
-- A+B+C+E*B813
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N4=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
    + @E * B813
where R4 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(N4)', GETDATE())

-- 签约居民中＜65岁，且无高血压和糖尿病登记,字段总数（N5)
-- A+B
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N5=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
where R5 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N5' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(N5)', GETDATE())

-- 签约居民中＜65岁，且同时有高血压和糖尿病登记,字段总数（N6)
-- A+B+C+D*B613+E*B813
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N6=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
    + @D * B613
    + @E * B813
where R6 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N6' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 签约居民中＜65岁，有高血压，无糖尿病登记,字段总数（N7)
-- A+B+C+D*B613
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N7=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
    + @D * B613
where R7 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N7' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 签约居民中＜65岁，无高血压，有糖尿病登记,字段总数（N8)
-- A+B+C+E*B813
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set N8=@A + @B + @C * (case when B3 > B4 then B3 else B4 end)
    + @E * B813
where R8 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'N8' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(N8)', GETDATE())

-- L1	签约居民中≥65岁老年人，且无健康体检表
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set L1=1
where A5 = 1
  and B4 = 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'L1' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(L1)', GETDATE())

-- L2	签约居民中＜65岁人，有高血压登记或有糖尿病登记，且无体检表
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set L2=1
where A5 = 0
  and B4 = 0
  and (A6 = 1 or A7 = 1)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'L2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(L2)', GETDATE())

-- L3	签约居民中，有高血压登记，但是缺高血压随访表的张数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set L3=B612
where A6 = 1

set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'L3' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- L4	签约居民中，有糖尿病登记，但是缺糖尿病随访表的张数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set L4=B812
where A7 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'L4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- L5	签约居民中，需要有健康体检表，但是缺健康体检表的张数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set L5=B3 - B4
where
  -- R5是签约居民中＜65岁，且无高血压和糖尿病登记的，
  -- 这部分人群只需要有档案封面、个人基本信息表。不需要体检表
    R5 = 0
  -- 实际张数比理论张数多的，不计算
  and B4 < B3
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'L5' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(L5)', GETDATE())

-- C111	封面表质控错误字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C111= (select count(distinct a.archiveNum + TargetField)
           from HrCover a
                INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
                INNER JOIN HrRuleRecord t1 ON a.archiveNum = t1.archiveNum
                INNER JOIN HrRule t2 ON t1.RuleId = t2.RuleId
           where A4 = 1
             and a.archiveNum = report_qyyh.sfzh
             -- and a.ArchiveUnitCode = report_qyyh.org_code
             and a.DateOfCreateArchive >= '1900-01-01'
             and a.DateOfCreateArchive <= @质控数据截止时间
             and t2.TargetTable = 'HrCover'
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C111' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- C112	个人基本信息表质控错误字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C112= (select count(distinct a.archiveNum + TargetField)
           from HrCover a
                INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
                INNER JOIN HrRuleRecord t1 ON a.archiveNum = t1.archiveNum
                INNER JOIN HrRule t2 ON t1.RuleId = t2.RuleId
           where A4 = 1
             and a.archiveNum = report_qyyh.sfzh
             -- and a.ArchiveUnitCode = report_qyyh.org_code
             and a.DateOfCreateArchive >= '1900-01-01'
             and a.DateOfCreateArchive <= @质控数据截止时间
             and t2.TargetTable = 'HrPersonBasicInfo'
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C112' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- C1	封面和个人基本信息表质控错误字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C1= C111 + C112
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C1' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(C1)', GETDATE())

-- C113	个人信息质控规则问题导致的错误数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C113= (select count(*) from HrRuleRecord a 
          where a.ArchiveNum = report_qyyh.SFZH  and a.RuleId in (
					select RuleId from HrRule where Categories ='完整性'  and TargetFieldCn like '既往史—%'  
          union all
          select RuleId from  HrRule where Categories ='完整性'  and TargetFieldCn like '家族史—%'
					union all
		      select RuleId from  HrRule where Categories ='完整性'  and TargetFieldCn like '药物过敏史%'))
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C113' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(C113)', GETDATE())

-- C2	健康体检表质控错误字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C2=(select count(distinct idOfTargetTable + TargetField) num
        from HrCover a
             INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
             INNER JOIN tb_dc_examination_info c ON b.guid = c.empiGuid
             INNER JOIN HrRuleRecord t1 ON a.archiveNum = t1.archiveNum
             INNER JOIN HrRule t2 ON t1.RuleId = t2.RuleId
        where a.archiveNum = report_qyyh.sfzh
          -- and a.ArchiveUnitCode = report_qyyh.org_code
          and a.DateOfCreateArchive >= '1900-01-01'
          and a.DateOfCreateArchive <= @质控数据截止时间
          and A4 = 1
          and c.orgcode = report_qyyh.org_code
          and c.examinationDate >= @质控数据开始时间
          and c.examinationDate <= @质控数据截止时间
          and T2.targetTable = 'HrHealthCheckup'
)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(C2)', GETDATE())


-- C3	高血压随访表质控错误字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C3 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where T2.targetTable = 'HypertensionVisit'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_htn_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
							and e.visitDate <= @质控数据截止时间
							and d.visitTypeCode like '%31%'
							and r.A4 = 1
							and a.DateOfCreateArchive >= '1900-01-01'
							and a.DateOfCreateArchive <= @质控数据截止时间
							--and a.ArchiveUnitCode = r.org_code
							and c.orgCode = r.org_code
							and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C3' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C3)', GETDATE())


-- C4	糖尿病随访表质控错误字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C4 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'DiabetesVisit'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_dm_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
							and e.visitDate <= @质控数据截止时间
							and d.visitTypeCode like '%33%'
							and r.A4 = 1
							and a.DateOfCreateArchive >= '1900-01-01'
							and a.DateOfCreateArchive <= @质控数据截止时间
							--and a.ArchiveUnitCode = r.org_code
							and c.orgCode = r.org_code
							and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C4)', GETDATE())

-- C511	缺档案封面表字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C511=@A
where A4 = 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C511' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- C512	缺个人基本信息表字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C512=@B
where A4 = 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C512' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- C5	缺档案封面和个人基本信息表字段总数
-- 签约居民中未建档人数  (A+B)
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C5=@A + @B
where A4 = 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C5' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- C6	缺体检表的字段总数
-- (L1) @C
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C6=@C
where L1 = 1 
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C6' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(C6)', GETDATE())

-- C7	缺高血压随访表人数的字段总数
-- @D*L3
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C7=@D * L3
where L3 > 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C7' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- C8	缺糖尿病随访表人数的字段总数
-- @E*L4
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C8=@E * L4
where L4 > 0
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C8' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(C8)', GETDATE())

-- C9	分母总字段数
-- N1+N2+N3+N4+N5+N6+N7+N8
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C9=N1 + N2 + N3 + N4 + N5 + N6 + N7 + N8
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C9' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- C10	全部质控错误字段总数
-- C1+C2+C3+C4+C5+C6+C7+C8
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C10=C1 + C2 + C3 + C4 + C5 + C6 + C7 + C8
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C10' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- C11  封面基本信息表质控完整性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C11 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.TargetTable in ('HrCover', 'HrPersonBasicInfo')
						  and t2.Categories = '完整性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
									INNER JOIN report_qyyh r on b.ArchiveNum = r.sfzh
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C11' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C11)', GETDATE())

-- C12  封面基本信息表质控规范性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C12 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.TargetTable in ('HrCover', 'HrPersonBasicInfo')
						  and t2.Categories = '规范性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
									INNER JOIN report_qyyh r on b.ArchiveNum = r.sfzh
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C12' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C12)', GETDATE())

-- C13  封面基本信息表质控一致性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C13 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.TargetTable in ('HrCover', 'HrPersonBasicInfo')
						  and t2.Categories = '一致性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
									INNER JOIN report_qyyh r on b.ArchiveNum = r.sfzh
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C13' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C13)', GETDATE())

-- C14  封面基本信息表质控有效性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C14 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.TargetTable in ('HrCover', 'HrPersonBasicInfo')
						  and t2.Categories = '有效性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
									INNER JOIN report_qyyh r on b.ArchiveNum = r.sfzh
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C14' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- C15  封面基本信息表质控追溯性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C15 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.TargetTable in ('HrCover', 'HrPersonBasicInfo')
						  and t2.Categories = '追溯性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
									INNER JOIN report_qyyh r on b.ArchiveNum = r.sfzh
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C15' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C15)', GETDATE())

-- C16  体检表质控完整性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C16 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HrHealthCheckup'
							and t2.Categories = '完整性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
									INNER JOIN tb_dc_examination_info c ON b.guid = c.empiGuid
									INNER JOIN report_qyyh r on b.idcardNo = r.sfzh and c.orgcode = r.org_code
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
										and c.examinationDate >= @质控数据开始时间
										and c.examinationDate <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C16' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C16)', GETDATE())


-- C17  体检表质控规范性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C17 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HrHealthCheckup'
							and t2.Categories = '规范性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
									INNER JOIN tb_dc_examination_info c ON b.guid = c.empiGuid
									INNER JOIN report_qyyh r on b.idcardNo = r.sfzh and c.orgcode = r.org_code
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
										and c.examinationDate >= @质控数据开始时间
										and c.examinationDate <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C17' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- C18  体检表质控一致性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C18 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HrHealthCheckup'
							and t2.Categories = '一致性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
									INNER JOIN tb_dc_examination_info c ON b.guid = c.empiGuid
									INNER JOIN report_qyyh r on b.idcardNo = r.sfzh and c.orgcode = r.org_code
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
										and c.examinationDate >= @质控数据开始时间
										and c.examinationDate <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C18' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C18)', GETDATE())

-- C19  体检表质控有效性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C19 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HrHealthCheckup'
							and t2.Categories = '有效性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
									INNER JOIN tb_dc_examination_info c ON b.guid = c.empiGuid
									INNER JOIN report_qyyh r on b.idcardNo = r.sfzh and c.orgcode = r.org_code
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
										and c.examinationDate >= @质控数据开始时间
										and c.examinationDate <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C19' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- C20  体检表质控追溯性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C20 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HrHealthCheckup'
							and t2.Categories = '追溯性'
							and t1.archiveNum in
								(
									select a.archiveNum
									from HrCover a
									INNER JOIN tb_empi_index_root b ON a.archiveNum = b.idcardNo
									INNER JOIN tb_dc_examination_info c ON b.guid = c.empiGuid
									INNER JOIN report_qyyh r on b.idcardNo = r.sfzh and c.orgcode = r.org_code
									WHERE r.A4 = 1
										--and a.ArchiveUnitCode = r.org_code 
										and a.DateOfCreateArchive >= '1900-01-01'
										and a.DateOfCreateArchive <= @质控数据截止时间
										and c.examinationDate >= @质控数据开始时间
										and c.examinationDate <= @质控数据截止时间
									group by a.archiveNum
								)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C20' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C20)', GETDATE())


-- C21  高血压质控完整性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C21 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where T2.targetTable = 'HypertensionVisit'
						and t2.Categories = '完整性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_htn_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%31%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C21' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C21)', GETDATE())

-- C22  高血压质控规范性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C22 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where T2.targetTable = 'HypertensionVisit'
						and t2.Categories = '规范性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_htn_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%31%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C22' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C22)', GETDATE())

-- C23  高血压质控一致性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C23 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HypertensionVisit'
						and t2.Categories = '一致性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_htn_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%31%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C23' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C23)', GETDATE())

-- C24  高血压质控有效性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C24 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HypertensionVisit'
						and t2.Categories = '有效性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_htn_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%31%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C24' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C24)', GETDATE())


-- C25  高血压质控追溯性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C25 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'HypertensionVisit'
						and t2.Categories = '追溯性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_htn_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%31%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C25' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C25)', GETDATE())


-- C26  糖尿病质控完整性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C26 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'DiabetesVisit'
						and t2.Categories = '完整性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_dm_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%33%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C26' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C26)', GETDATE())

-- C27  糖尿病质控规范性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C27 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'DiabetesVisit'
						and t2.Categories = '规范性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_dm_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%33%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C27' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C27)', GETDATE())

-- C28  糖尿病质控一致性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C28 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'DiabetesVisit'
						and t2.Categories = '一致性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_dm_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%33%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C28' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C28)', GETDATE())

-- C29  糖尿病质控有效性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C29 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'DiabetesVisit'
						and t2.Categories = '有效性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_dm_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%33%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C29' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C29)', GETDATE())

-- C30  糖尿病质控追溯性错误字段数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set C30 = b.num
from report_qyyh a
INNER JOIN (
				select archiveNum AS sfzh,count(*) as num
				from (
						select t1.archiveNum,t1.idOfTargetTable,t2.TargetField
						from HrRuleRecord t1
						INNER JOIN HrRule t2 on t1.RuleId = t2.RuleId
						where t2.targetTable = 'DiabetesVisit'
						and t2.Categories = '追溯性'
						and t1.archiveNum in
						(
							select a.archiveNum
							from tb_dc_dm_visit e
							INNER JOIN tb_dc_chronic_main d on d.visitNum = e.cardId and d.orgCode = e.orgCode
							INNER JOIN tb_dc_chronic_info c on c.manageNum = d.manageNum and c.orgCode = d.orgCode
							INNER JOIN tb_empi_index_root b on b.guid = c.empiGuid
							INNER JOIN HrCover a on a.archiveNum = b.idcardNo
							INNER JOIN report_qyyh r on b.idcardNo = r.sfzh
							where e.visitDate >= @质控数据开始时间
								and e.visitDate <= @质控数据截止时间
								and d.visitTypeCode like '%33%'
								and r.A4 = 1
								and a.DateOfCreateArchive >= '1900-01-01'
								and a.DateOfCreateArchive <= @质控数据截止时间
								--and a.ArchiveUnitCode = r.org_code
								and c.orgCode = r.org_code
								and d.orgCode = r.org_code
							group by a.archiveNum
						)
						group by t1.archiveNum,t1.idOfTargetTable,t2.TargetField
				) as a
				group by archiveNum
) b ON a.sfzh = b.sfzh
where 1 = 1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'C30' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables VALUES (NEWID(), 'report_qyyh(C30)', GETDATE())

------------------------------
-- A9 是否存在档案更新
-- 需要分两种情况，重点人群 和非重点人群，具体判断标准参考需求文档

-- 1.重点人群 存在档案更新
/*set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A9=1
where (R1 = 1 and B4 >= 1 and A4 = 1)
   or (R2 = 1 and( B4 >= 1 or B612=0 or B812=0 )and A4 = 1)
   or (R3 = 1 and(B4 >= 1 or B612=0 )and A4 = 1)
   or (R4 = 1 and( B4 >= 1 or B812=0) and A4 = 1)
   or (R6 = 1 and(B4 >= 1 or B612=0 or B812=0 )and A4 = 1)
   or (R7 = 1 and ( B4 >= 1 or B612=0) and A4 = 1)
   or (R8 = 1 and( B4 >= 1 or B812=0) and A4 = 1)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A9重点人群' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(A9)', GETDATE())*/
-- 1.重点人群 存在档案更新
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A9=1
where (R1 = 1 and B4 >= 1 and A4 = 1)
   or (R2 = 1 and( B4 >= 1 or B6 >= 1 or B8 >= 1 )and A4 = 1)
   or (R3 = 1 and(B4 >= 1 or B6 >= 1 )and A4 = 1)
   or (R4 = 1 and( B4 >= 1 or B8 >= 1 ) and A4 = 1)
   or (R6 = 1 and(B4 >= 1 or B6 >= 1 or B8 >= 1 )and A4 = 1)
   or (R7 = 1 and ( B4 >= 1 or B6 >= 1) and A4 = 1)
   or (R8 = 1 and( B4 >= 1 or B8 >= 1) and A4 = 1)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A9重点人群' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(A9)', GETDATE())


-- 1.2.重点人群 存在档案更新 健康档案更新时间在范围内
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A9=1
where R5 = 0
  and A4 = 1
  and (
        -- 档案封面表更新时间 在质控时间段内
        sfzh in (select a.archivenum
                    from HrCover a
                    where a.archiveNum = report_qyyh.sfzh
                      -- and a.ArchiveUnitCode = report_qyyh.org_code
                      and a.DateOfCreateArchive >= '1900-01-01'
                      and a.DateOfCreateArchive <= @质控数据截止时间
                      and a.UpdateTime is not null
                      and a.UpdateTime >= @质控数据开始时间
                      and a.UpdateTime <= @质控数据截止时间)
        -- 或者 个人基本信息表更新时间 在质控时间段内
        or sfzh in (select b.archivenum
                    from HrCover a
                         INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
                    where a.archiveNum = report_qyyh.sfzh
                      -- and a.ArchiveUnitCode = report_qyyh.org_code
                      and a.DateOfCreateArchive >= '1900-01-01'
                      and a.DateOfCreateArchive <= @质控数据截止时间
                      and b.UpdateTime is not null
                      and b.UpdateTime >= @质控数据开始时间
                      and b.UpdateTime <= @质控数据截止时间)
    )
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A9重点人群1.2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'


-- 2.非重点人群 存在档案更新
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set A9=1
where R5 = 1
  and A4 = 1
  and (
        --档案封面表更新时间 在质控时间段内
        sfzh in (select a.archivenum
                    from HrCover a
                    where a.archiveNum = report_qyyh.sfzh
                      -- and a.ArchiveUnitCode = report_qyyh.org_code
                      and a.DateOfCreateArchive >= '1900-01-01'
                      and a.DateOfCreateArchive <= @质控数据截止时间
                      and a.UpdateTime is not null
                      and a.UpdateTime >= @质控数据开始时间
                      and a.UpdateTime <= @质控数据截止时间
                      and dbo.Fn_GetAge(a.archivenum, @质控数据截止时间) < 65)
        -- 或者 个人基本信息表更新时间 在质控时间段内
        or sfzh in (select b.archivenum
                    from HrCover a
                         INNER JOIN HrPersonBasicInfo b ON a.archiveNum = b.ArchiveNum
                    where a.archiveNum = report_qyyh.sfzh
                      -- and a.ArchiveUnitCode = report_qyyh.org_code
                      and a.DateOfCreateArchive >= '1900-01-01'
                      and a.DateOfCreateArchive <= @质控数据截止时间
                      and b.UpdateTime is not null
                      and b.UpdateTime >= @质控数据开始时间
                      and b.UpdateTime <= @质控数据截止时间
                      and dbo.Fn_GetAge(b.archivenum, @质控数据截止时间) < 65)
    )
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'A9非重点人群' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'

-- E1	高血压随访 核心字段有错误（核心字段为姓名和血压）
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set E1 = 1 
from (select RuleId from HrRule where TargetTable='HypertensionVisit' and (TargetField = 'tb_dc_htn_visit.name' or TargetField = 'tb_dc_htn_visit.dbp' or TargetField = 'tb_dc_htn_visit.sbp')) r 
       inner join HrRuleRecord rd 
       on r.RuleId = rd.RuleId 
       where rd.ArchiveNum = report_qyyh.sfzh
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'E1' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(E1)', GETDATE())

-- E2	高血压随访 无缺表且核心字段无错误（核心字段为姓名和血压）
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set E2 = 1 
where B612 = 0 
      and report_qyyh.sfzh not in (
      select ArchiveNum from (select RuleId from HrRule where TargetTable='HypertensionVisit' and (TargetField = 'tb_dc_htn_visit.name' or TargetField = 'tb_dc_htn_visit.dbp' or TargetField = 'tb_dc_htn_visit.sbp')) r 
      inner join HrRuleRecord rd 
      on r.RuleId = rd.RuleId
			)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'E2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(E2)', GETDATE())

-- E3	糖尿病随访 核心字段有错误（核心字段为姓名和空腹血糖和随机血糖）
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set E3 = 1 
from (select RuleId from HrRule where TargetTable='DiabetesVisit' and (TargetField = 'tb_dc_dm_visit.name' or TargetField = 'tb_dc_dm_visit.fastingBloodSugarValue' or TargetField = 'tb_dc_dm_visit.randomBloodSugarValue')) r 
       inner join HrRuleRecord rd 
       on r.RuleId = rd.RuleId 
       where rd.ArchiveNum = report_qyyh.sfzh
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'E3' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(E3)', GETDATE())

-- E4	糖尿病随访 无缺表且核心字段无错误（核心字段为姓名和空腹血糖和随机血糖）
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set E4 = 1 
where B812 = 0 
      and report_qyyh.sfzh not in (
      select ArchiveNum from (select RuleId from HrRule where TargetTable='DiabetesVisit' and (TargetField = 'tb_dc_dm_visit.name' or TargetField = 'tb_dc_dm_visit.fastingBloodSugarValue' or TargetField = 'tb_dc_dm_visit.randomBloodSugarValue')) r 
      inner join HrRuleRecord rd 
      on r.RuleId = rd.RuleId
			)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'E4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(E4)', GETDATE())


-- F1	根据权重判断核心档案是否不规范
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set F1 = 1 
where A4 = 0

update report_qyyh 
set F1 = 1 
from 
(select ArchiveNum,weight,count(1) as weightNum from 
(select RuleId,weight from HrRule where TargetTable='HrCover' or TargetTable='HrPersonBasicInfo') a 
inner join HrRuleRecord b 
on a.RuleId = b.RuleId 
group by ArchiveNum,weight) t 
where t.ArchiveNum = report_qyyh.SFZH and ((weight = '1' and weightNum > 0) or (weight = '2' and weightNum >= 3) or (weight = '3' and weightNum >= 4))
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'F1' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(F1)', GETDATE())


-- F2	根据权重判断高血压随访表是否不规范
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set F2 = 1 
from 
(select ArchiveNum,weight,count(1) as weightNum from 
(select RuleId,weight from HrRule where TargetTable='HypertensionVisit') a 
inner join HrRuleRecord b 
on a.RuleId = b.RuleId 
group by ArchiveNum,weight) t 
where A6 = 1 and ((t.ArchiveNum = report_qyyh.SFZH and ((weight = '1' and weightNum > 0) or (weight = '2' and weightNum >= 3))) or B5 > B6)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'F2' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(F2)', GETDATE())


-- F3	根据权重判断糖尿病随访表是否不规范
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set F3 = 1 
from 
(select ArchiveNum,weight,count(1) as weightNum from 
(select RuleId,weight from HrRule where TargetTable='DiabetesVisit') a 
inner join HrRuleRecord b 
on a.RuleId = b.RuleId 
group by ArchiveNum,weight) t 
where A7 = 1 and ((t.ArchiveNum = report_qyyh.SFZH and ((weight = '1' and weightNum > 0) or (weight = '2' and weightNum >= 3))) or B7 > B8)
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'F3' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(F3)', GETDATE())


-- F4	根据权重判断体检表是否不规范
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set F4 = 1 
from 
(select ArchiveNum,weight,count(1) as weightNum from 
(select RuleId,weight from HrRule where TargetTable='HrHealthCheckup') a 
inner join HrRuleRecord b 
on a.RuleId = b.RuleId 
group by ArchiveNum,weight) t 
where A5 = 1 and (t.ArchiveNum = report_qyyh.SFZH and ((weight = '1' and weightNum > 0) or (weight = '2' and weightNum >= 3)))
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'F4' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(F4)', GETDATE())

-- F4 判断无体检的老年人是否不规范
--老年人总数
DECLARE @snrTotal INT;
--70%老年人总数
DECLARE @snrTotal70 INT;
--30%老年人总数
DECLARE @snrTotal30 INT;
--有体检表老年人数
DECLARE @snrHave INT;
--无体检表其他档案全规范人数
DECLARE @snrNorm INT;
set @snrTotal = (select count(*) from report_qyyh where A5 = 1)
set @snrTotal70 = (@snrTotal * 0.7)
set @snrTotal30 = (@snrTotal * 0.3)
set @snrHave = (select count(*) from report_qyyh where A5 = 1 and B4 > 0)
if @snrHave < @snrTotal70
begin
		set @snrNorm = (select count(*) from report_qyyh where A5 = 1 and B4 = 0 and F1 = 0 and F2 = 0 and F3 = 0)
		
		if @snrNorm >= @snrTotal30 
		begin
				update report_qyyh 
				set F4 = 1 
				where sfzh in (
					select top (@snrTotal30) (SFZH) from report_qyyh where A5 = 1 and B4 = 0 and F1 = 0 and F2 = 0 and F3 = 0 order by SFZH desc
				)				
		end
		else 
		begin 
				update report_qyyh 
				set F4 = 1
				where A5 = 1 and B4 = 0 and F1 = 0 and F2 = 0 and F3 = 0
		end
		
end


-- F5	根据权重判断儿童(0~3)是否不规范
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set F5 = 1 
from 
(select ArchiveNum,weight,count(1) as weightNum from 
(select RuleId,weight from HrRule where TargetTable='ChildExamRecord') a 
inner join HrRuleRecord b 
on a.RuleId = b.RuleId 
group by ArchiveNum,weight) t 
where A16 = 1 and (A18 = 0 or (t.ArchiveNum = report_qyyh.SFZH and (weight = '1' and weightNum > 0)) or (A18 = 1 and A19 = 0))
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'F5' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(F5)', GETDATE())


-- F6	根据权重判断孕妇是否不规范
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set F6 = 1 
from 
(select ArchiveNum,weight,count(1) as weightNum from 
(select RuleId,weight from HrRule where TargetTable='FirstPrenatal' or TargetTable='ManyPrenatal' or TargetTable='PostpartumRecord') a 
inner join HrRuleRecord b 
on a.RuleId = b.RuleId 
group by ArchiveNum,weight) t 
where A20 = 1 and (t.ArchiveNum = report_qyyh.SFZH and (weight = '1' and weightNum > 0))
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'F6' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(F6)', GETDATE())

-- update q set F6 = 1 
-- FROM
-- report_qyyh q inner join (select root.idCardNo from tb_dc_pregnant_main_info main 
-- INNER JOIN tb_empi_index_root root on main.empiguid = root.guid
-- LEFT JOIN 
-- tb_dc_postpartum_visit_info info on main.pregnantId = info.pregnantId and main.orgCode = info.orgCode
-- where info.pregnantId is null ) a on q.sfzh = a.idCardNo


-- F0	根据权重判断整个档案是否不规范
set @SQL开始执行时间 = GETDATE()
update report_qyyh 
set F0 = 1 
where F1 = 1 or F2 = 1 or F3 = 1 or F4 = 1 or F5 = 1 or F6 =1
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'F0' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(F0)', GETDATE())


-- D1	档案封面字段总数
-- D2	个人基本信息表字段总数
-- D3	健康体检表字段总数
-- D4	高血压随访表字段总数
-- D5	糖尿病随访表字段总数
set @SQL开始执行时间 = GETDATE()
update report_qyyh
set D1=11,
    D2=38,
    D3=143,
    D4=57,
    D5=58
set @耗时 = datediff(second, @SQL开始执行时间, GETDATE())
print 'D12345' + ' 耗时：' + CONVERT(varchar(100), @耗时) + 'S'
INSERT into temp_tables
VALUES (NEWID(), 'report_qyyh(D1,D2,D3,D4,D5)', GETDATE())


/*先默认设置没有建档的都是 无档案的*/
update report_qyyh
set no_record_reason=
        case
            when A4 = 0 then '无档案封面和个人基本信息表或儿童未找到新生儿访视服务记录表;'
            when A4 = 1 then '-'
            end
						
update report_qyyh 
set no_record_reason = '核心档案有否决项错误;' 
where A4 = 1 and A412 = 0


update report_qyyh
set no_record_reason='' +
                     case
                         when b.ArchiveUnitCode is null or b.ArchiveUnitCode = '' then '已建档但管理机构为空值;'
                         when b.ArchiveUnitCode != a.org_code1 then '已建档但签约机构和管理机构不一致;'
                         else ''
                         end
    +
                     case
                         when b.DateOfCreateArchive is null then '建档日期为空值'
                         when b.DateOfCreateArchive > @质控数据截止时间 then '已建档但建档日期在质控时间以后'
                         else ''
                         end
from report_qyyh a,
     HrCover b
where a.SFZH = b.archiveNum
  and A4 = 0

--  将HrCover表的手机号 更新到report_qyyh表
update report_qyyh
set phone=b.phone
from report_qyyh a,
     HrCover b
where a.SFZH = b.archiveNum


END
go

