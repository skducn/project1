CREATE PROCEDURE [dbo].[proc_infotable]
(
    @StartDate varchar(20)
)
as
DECLARE @HrRuleRecord VARCHAR(100)
DECLARE @HrRuleRecord_index VARCHAR(100)

DECLARE @report_qyyh VARCHAR(100)
DECLARE @report_home VARCHAR(100)
DECLARE @execSql varchar(max)
DECLARE @HrArchivesResult VARCHAR(100)

select @execSql =REPLACE(
        '
        IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[HrRuleRecord_@StartDate]'') AND type IN (''U''))
            DROP TABLE [dbo].[HrRuleRecord_@StartDate]
		
        IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[HrArchivesResult_@StartDate]'') AND type IN (''U''))
            DROP TABLE [dbo].[HrArchivesResult_@StartDate]
						
				IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[report_qyyh_@StartDate]'') AND type IN (''U''))
            DROP TABLE [dbo].[report_qyyh_@StartDate]		
						
        IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N''[dbo].[report_home_@StartDate]'') AND type IN (''U''))
            DROP TABLE [dbo].[report_home_@StartDate]
        ','@StartDate',@StartDate)
				
    EXEC(@execSql)

    SET @HrArchivesResult =  'select * into HrArchivesResult_'+@StartDate + ' from   HrArchivesResult'
		
    SET @HrRuleRecord= 'select * into HrRuleRecord_'+@StartDate + ' from   HrRuleRecord'
    
    SET @HrRuleRecord_index = 'CREATE NONCLUSTERED index   archve_index on HrRuleRecord_' + @StartDate +'(archivenum,RuleId)'

    SET @report_qyyh= 'select * into report_qyyh_'+@StartDate + ' from  report_qyyh'

		SET @report_home= 'select * into report_home_'+@StartDate + ' from   report_home'
 
    EXEC(@HrArchivesResult)
    EXEC(@HrRuleRecord)
    EXEC(@HrRuleRecord_index)
    EXEC(@report_qyyh)	
	EXEC(@report_home)
go

