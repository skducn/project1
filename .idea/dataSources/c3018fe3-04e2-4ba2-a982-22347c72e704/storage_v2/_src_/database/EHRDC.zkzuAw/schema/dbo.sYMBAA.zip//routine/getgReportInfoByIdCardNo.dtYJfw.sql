CREATE PROCEDURE [dbo].[getgReportInfoByIdCardNo] @idCardNo VARCHAR ( 100 ),@visitDate Date
AS 
BEGIN 

   declare @empiGuid varchar(100)
    
  set @empiGuid = (select guid from tb_empi_index_root where idCardNo = @idCardNo)

  
 IF OBJECT_ID( N'tempdb..#T', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T
    end 
  CREATE table #T (
   visitStrNo VARCHAR(100),
   orgCode varchar(100)
  )
    -- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index ON #T ( visitStrNo,orgCode)


INSERT INTO #T select visitStrNo,orgCode from tb_lis_report where empiGuid = @empiGuid
and reportDate BETWEEN DATEADD(month, -3, @visitDate)  and @visitDate



select itemName,resultValue,resultUnit FROM tb_lis_report a  where  EXISTS (select 1 from #T  where orgCode =a.orgCode and  visitStrNo = a.visitStrNo  )

END
go

