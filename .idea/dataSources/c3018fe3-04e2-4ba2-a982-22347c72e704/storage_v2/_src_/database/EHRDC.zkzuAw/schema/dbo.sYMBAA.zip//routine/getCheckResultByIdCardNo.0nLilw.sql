CREATE PROCEDURE [dbo].[getCheckResultByIdCardNo] @idCardNo VARCHAR ( 100 ) 
AS 
BEGIN 

    declare @empiGuid varchar(100)
    
		set @empiGuid = (select guid from tb_empi_index_root where idCardNo = @idCardNo)
 
   declare @count int 

  set @count =(select count(1) from tb_lis_report_indicator WHERE  empiGuid = @empiGuid  ) 

 IF(@count>0) 
 begin 
		
	IF OBJECT_ID( N'tempdb..#T', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T
    end	
	  CREATE table #T (
		  guid varchar(100),
		  reportNo VARCHAR(100),
			HospitalLevel varchar(100),
			reportDate datetime,
			specimenTypeName varchar(100)
		)
    -- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index ON #T ( reportNo)

 INSERT INTO #T SELECT guid,reportNo,a.HospitalLevel,reportDate,specimenTypeName FROM tb_lis_report total 
 outer apply (select HospitalLevel from t_dic_hospital_info where Hospital_id = total.orgCode ) a
 where  empiGuid =@empiGuid

 IF OBJECT_ID( N'tempdb..#T1', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T1
    end 
  CREATE table #T1 (
   guid varchar(100),
   itemName varchar(50),
   resultValue varchar(50), 
   resultUnit varchar(50),
   reportNo VARCHAR(100),
   orgCode varchar(100),
   orgName varchar(100)
  )
    -- 添加非聚集索引
 CREATE NONCLUSTERED INDEX NonClu_Index ON #T1 ( reportNo)

INSERT INTO #T1 select  guid,itemName, resultValue, resultUnit,reportNo,orgCode,orgName from tb_lis_report_indicator where empiGuid = @empiGuid


select  resultUnit AS unit, HospitalLevel AS orgLevel, orgCode AS orgCode,
   orgName AS orgName, reportDate AS examDate
 , t.guid AS idOfTargetTable, itemName, resultValue,specimenTypeName from  #T1 detail 
inner join #T t on t.reportNo = detail.reportNo  ORDER BY reportDate desc,detail.guid
end
else 
begin
 select  itemName,  resultValue,  resultUnit from tb_lis_report_indicator where 1<>1
end

END
go

