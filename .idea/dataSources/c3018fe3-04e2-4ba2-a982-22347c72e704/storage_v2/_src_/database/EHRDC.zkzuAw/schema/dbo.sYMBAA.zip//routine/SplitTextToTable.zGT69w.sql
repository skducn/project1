CREATE FUNCTION [dbo].[SplitTextToTable]
(
  @SplitString varchar(8000),
  @Separator varchar(10) = ','
)
RETURNS @SplitStringsTable TABLE
(
  [VALUE] varchar(900) primary key
)
AS
BEGIN
     DECLARE @CurrentIndex int;
     DECLARE @NextIndex int;
     DECLARE @ReturnText varchar(8000);
     SELECT @CurrentIndex=1;

     WHILE @CurrentIndex<=len(@SplitString)
     BEGIN
        SET @NextIndex=charindex(@Separator,@SplitString,@CurrentIndex);
        IF @NextIndex=0 OR @NextIndex IS NULL
             SET @NextIndex=len(@SplitString)+1;
         
        SET @ReturnText=substring(@SplitString,@CurrentIndex,@NextIndex-@CurrentIndex);

		if not exists(select * from @SplitStringsTable where value = @ReturnText)
		begin
         INSERT INTO @SplitStringsTable([VALUE]) VALUES(@ReturnText);
		end

        SET @CurrentIndex=@NextIndex+1;
     END

     RETURN;
END
go

