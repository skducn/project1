CREATE VIEW [dbo].[HrPersonBasicInfoViewInfo] AS select HrPersonBasicInfo.ContactsPhone              "HrPersonBasicInfo.ContactsPhone",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.history_of_trauma.msg",
       STUFF((SELECT distinct ',' + HrAssociationInfo.msg
              FROM dbo.HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = 'history_of_trauma'
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_trauma.msg",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.history_of_disease.msg",
			 STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'history_of_disease' and b.TargetField='history_of_disease') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_disease.msg",
       --  HrAssociationInfo.msg                        "HrAssociationInfo.family_history_of_siblings",
				STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'family_history_of_siblings' and b.TargetField='history_of_disease') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.family_history_of_siblings",
       --  HrAssociationInfo.msg                        "HrAssociationInfo.history_of_operation",
       STUFF((SELECT distinct ',' + HrAssociationInfo.msg
              FROM dbo.HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = 'history_of_operation'
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_operation",
       HrPersonBasicInfo.DateOfBirth                "HrPersonBasicInfo.DateOfBirth",
       HrPersonBasicInfo.IdCard                     "HrPersonBasicInfo.IdCard",
       -- HrPersonBasicInfo.ArchiveNum                     "HrPersonBasicInfo.ehrNum",
       (select top 1 ehrNum  from HrCover where HrCover.ArchiveNum=HrPersonBasicInfo.ArchiveNum) "HrPersonBasicInfo.ehrNum",
       HrPersonBasicInfo.Name                       "HrPersonBasicInfo.Name",
       HrPersonBasicInfo.Name                       "tb_empi_index_root",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.history_of_exposure",
				STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'history_of_exposure' and b.TargetField='history_of_exposure') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_exposure",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.history_of_blood.msg",
       STUFF((SELECT distinct ',' + HrAssociationInfo.msg
              FROM dbo.HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = 'history_of_blood'
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_blood.msg",
       HrPersonBasicInfo.WorkUnit                   "HrPersonBasicInfo.WorkUnit",
       HrPersonBasicInfo.BloodType                  "HrPersonBasicInfo.BloodType",
       HrPersonBasicInfo.RhBloodType                "HrPersonBasicInfo.RhBloodType",
       HrPersonBasicInfo.ContactsName               "HrPersonBasicInfo.ContactsName",
       HrPersonBasicInfo.ResidenceType              "HrPersonBasicInfo.ResidenceType",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.pay_method",
			 STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'pay_method' and b.TargetField='pay_method') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.pay_method",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.history_of_drug_allergy",
				STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'history_of_drug_allergy' and b.TargetField='history_of_drug_allergy') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_drug_allergy",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.family_history_of_mother",
				STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'family_history_of_mother' and b.TargetField='history_of_disease') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.family_history_of_mother",
       HrPersonBasicInfo.NationCode                 "HrPersonBasicInfo.NationCode",
       HrPersonBasicInfo.EnvironmentCorral          "HrPersonBasicInfo.EnvironmentCorral",
       HrPersonBasicInfo.Occupation                 "HrPersonBasicInfo.Occupation",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.disablity_type",
				STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'disablity_type' and b.TargetField='disablity_type') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.disablity_type",
       HrPersonBasicInfo.EnvironmentFuelType        "HrPersonBasicInfo.EnvironmentFuelType",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.heredity_history",
       STUFF((SELECT distinct ',' + HrAssociationInfo.msg
              FROM dbo.HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = 'heredity_history'
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.heredity_history",
       -- HrAssociationInfo.occurDate                  "HrAssociationInfo.history_of_blood.occurDate",
       STUFF((SELECT ',' + CONVERT(varchar(10), HrAssociationInfo.occurDate, 120)
              FROM dbo.HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = 'history_of_blood'
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_blood.occurDate",
       HrPersonBasicInfo.Sex                        "HrPersonBasicInfo.Sex",
       HrPersonBasicInfo.EnvironmentToilet          "HrPersonBasicInfo.EnvironmentToilet",
       HrPersonBasicInfo.MaritalStatus              "HrPersonBasicInfo.MaritalStatus",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.family_history_of_father",
				STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'family_history_of_father' and b.TargetField='history_of_disease') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.family_history_of_father",
       HrPersonBasicInfo.Degree                     "HrPersonBasicInfo.Degree",
       HrPersonBasicInfo.Phone                      "HrPersonBasicInfo.Phone",
       -- HrAssociationInfo.occurDate                  "HrAssociationInfo.history_of_disease.occurDate",
       STUFF((SELECT ',' + CONVERT(varchar(7), HrAssociationInfo.occurDate, 120)
              FROM dbo.HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = 'history_of_disease'
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_disease.occurDate",
       -- HrAssociationInfo.msg                        "HrAssociationInfo.family_history_of_children",
				STUFF((SELECT distinct ',' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo a inner join tb_code b 
							on a.code=b.code where a.AssociationType = 'family_history_of_children' and b.TargetField='history_of_disease') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.family_history_of_children",
       HrPersonBasicInfo.EnvironmentWater           "HrPersonBasicInfo.EnvironmentWater",
       -- HrAssociationInfo.occurDate                  "HrAssociationInfo.history_of_trauma.occurDate",
       STUFF((SELECT ',' + CONVERT(varchar(10), HrAssociationInfo.occurDate, 120)
              FROM dbo.HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = 'history_of_trauma'
              FOR XML PATH('')), 1, 1, '')          "HrAssociationInfo.history_of_trauma.occurDate",
       HrPersonBasicInfo.EnvironmentKitchenAeration "HrPersonBasicInfo.EnvironmentKitchenAeration",
       HrPersonBasicInfo.ArchiveNum                 "HrPersonBasicInfo.ArchiveNum"


from HrPersonBasicInfo
go

