CREATE PROCEDURE [dbo].[proc_HrArchivesResult]
as
with a1 as (select archiveNum,TargetTable,GETDATE() as createtime from HrRuleRecord a left join HrRule b
                                                                                                on a.RuleId=b.RuleId
            group by archiveNum,TargetTable)
insert into dbo.HrArchivesResult(archiveNum,TargetTable,createtime,ispass)
select t1.archiveNum,t2.TargetTable,t2.createtime,case when t2.ArchiveNum is null then 1 else 0 end as 'ispass' from HrCover t1 left join a1 t2
                                                                                                                                          on t1.ArchiveNum=t2.ArchiveNum
go

