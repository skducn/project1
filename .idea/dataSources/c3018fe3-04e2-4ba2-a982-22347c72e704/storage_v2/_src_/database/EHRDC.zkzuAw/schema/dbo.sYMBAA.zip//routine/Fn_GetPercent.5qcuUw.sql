CREATE FUNCTION [dbo].[Fn_GetPercent](
    @分子 INT,@分母 INT
)
    returns VARCHAR(10)
as

begin

    declare @return numeric(8,2)

    if (@分母 is null or @分母 = 0)
        begin
            set @return=0.0
        end
    else
        begin
            set @return=cast(cast(round(@分子/CONVERT(float,@分母), 4) * 100   as   numeric(8,2)) as VARCHAR)
        end

    return @return
end
go

