CREATE PROCEDURE [dbo].[governance_create_visitinfo]
AS 
BEGIN

IF OBJECT_ID( N'tempdb..#T', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T;
    end 
		-- 记录有旧随访数据的随访表编号 -- 
  CREATE table #T (
  manageNum varchar(100),
  visitNum varchar(100)
  );
    -- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index1 ON #T ( manageNum );
CREATE NONCLUSTERED INDEX NonClu_Index2 ON #T ( visitNum );

----------------- 高血压 -------------------

insert into #T
select t1.manageNum, t1.visitNum from (select a.manageNum,max(a.visitNum) visitNum from tb_dc_chronic_main a inner join 
tb_dc_htn_visit b on a.visitNum = b.cardid and a.orgCode = b.orgCode  where a.isGovernance <> 1 or a.isGovernance is null group by a.manageNum) t1 
inner join (select manageNum from tb_dc_chronic_main where isGovernance = 1 group by manageNum) t2 
on t1.manageNum = t2.manageNum;

update a set 
 a.name = c.name
,a.ehrNum = c.ehrNum
,a.visitWayCode = c.visitWayCode
,a.visitWayValue = c.visitWayValue
,a.otherVisit = c.otherVisit
,a.visitDocNo = c.visitDocNo
,a.visitDocName = c.visitDocName
,a.visitOrgCode = c.visitOrgCode
,a.visitOrgName = c.visitOrgName
,a.vistStatusCode = c.vistStatusCode
,a.visitStatusValue = c.visitStatusValue
,a.nextVisiDate = c.nextVisiDate
,a.manageGroup = c.manageGroup
,a.lostVisitCode = c.lostVisitCode
,a.lostVisitName = c.lostVisitName
,a.otherLostVIsitName = c.otherLostVIsitName
,a.lostVisitDate = c.lostVisitDate
,a.moveProvinceCode = c.moveProvinceCode
,a.moveProvinceValue = c.moveProvinceValue
,a.moveCityCode = c.moveCityCode
,a.moveCityValue = c.moveCityValue
,a.moveDistrictCode = c.moveDistrictCode
,a.moveDistrictValue = c.moveDistrictValue
,a.moveStreetCode = c.moveStreetCode
,a.moveStreetValue = c.moveStreetValue
,a.moveNeighborhoodCode = c.moveNeighborhoodCode
,a.moveNeighborhoodValue = c.moveNeighborhoodValue
,a.moveVillageValue = c.moveVillageValue
,a.moveHouseNumber = c.moveHouseNumber
,a.moveOrgCode = c.moveOrgCode
,a.moveOrgName = c.moveOrgName
,a.dangerousLevelCode = c.dangerousLevelCode
,a.dangerousLevelName = c.dangerousLevelName
,a.deathReason = c.deathReason
,a.sbp = c.sbp
,a.dbp = c.dbp
,a.isManualInput = c.isManualInput
,a.height = c.height
,a.weight = c.weight
,a.targetWeight = c.targetWeight
,a.BMI = c.BMI
,a.waistline = c.waistline
,a.targetBMI = c.targetBMI
,a.fastingBloodSugarValue = c.fastingBloodSugarValue
,a.fastingBloodSugarCode = c.fastingBloodSugarCode
,a.fastingBloodSugarName = c.fastingBloodSugarName
,a.fastingBloodSugarSign = c.fastingBloodSugarSign
,a.cholesterol = c.cholesterol
,a.highCholesterol = c.highCholesterol
,a.lowCholesterol = c.lowCholesterol
,a.triglycerides = c.triglycerides
,a.uacr = c.uacr
,a.bctv = c.bctv
,a.buatv = c.buatv
,a.homocysteineDetection = c.homocysteineDetection
,a.bloodPotassium = c.bloodPotassium
,a.bloodSodium = c.bloodSodium
,a.bloodLipids = c.bloodLipids
,a.uricAcid = c.uricAcid
,a.creatinine = c.creatinine
,a.hemoglobin = c.hemoglobin
,a.hemameba = c.hemameba
,a.platelet = c.platelet
,a.urineProtein = c.urineProtein
,a.urineSugar = c.urineSugar
,a.glycosylatedHemoglobin = c.glycosylatedHemoglobin
,a.serumCProtein = c.serumCProtein
,a.urineProteinQuantity = c.urineProteinQuantity
,a.ECG = c.ECG
,a.echocardiogram = c.echocardiogram
,a.carotidUltrasound = c.carotidUltrasound
,a.chestXray = c.chestXray
,a.pulseWave = c.pulseWave
,a.regularActivitySign = c.regularActivitySign
,a.regularActivitiesTypes = c.regularActivitiesTypes
,a.hasPaperCard = c.hasPaperCard
,a.drugComplianceCode = c.drugComplianceCode
,a.drugComplianceName = c.drugComplianceName
,a.bpWayCode = c.bpWayCode
,a.bpWayName = c.bpWayName
,a.heartRate = c.heartRate
,a.smokingVolume = c.smokingVolume
,a.drinkingVolume = c.drinkingVolume
,a.positiveSigns = c.positiveSigns
,a.smokingStatusCode = c.smokingStatusCode
,a.smokingStatusName = c.smokingStatusName
,a.targetSmoke = c.targetSmoke
,a.quitSmoking = c.quitSmoking
,a.drinkingFrequencyCode = c.drinkingFrequencyCode
,a.drinkingFrequencyName = c.drinkingFrequencyName
,a.targetDrink = c.targetDrink
,a.targetSaltUptakeStatus = c.targetSaltUptakeStatus
,a.reasonableDietEvaluation = c.reasonableDietEvaluation
,a.psychologyEvaluation = c.psychologyEvaluation
,a.complianceEvaluation = c.complianceEvaluation
,a.saltUptakeStatus = c.saltUptakeStatus
,a.saltUptakeStatusName = c.saltUptakeStatusName
,a.psychologyStatus = c.psychologyStatus
,a.psychologyStatusName = c.psychologyStatusName
,a.complianceStatus = c.complianceStatus
,a.complianceStatusName = c.complianceStatusName
,a.sportFrequence = c.sportFrequence
,a.sportTime = c.sportTime
,a.exerciseDescription = c.exerciseDescription
,a.exerciseFrequencyCode = c.exerciseFrequencyCode
,a.exerciseFrequencyName = c.exerciseFrequencyName
,a.targetSportFrequencyCode = c.targetSportFrequencyCode
,a.targetSportFrequencyName = c.targetSportFrequencyName
,a.targetSportTimes = c.targetSportTimes
,a.targetStapleFood = c.targetStapleFood
,a.symptomCode = c.symptomCode
,a.symptomValue = c.symptomValue
,a.symptomOther = c.symptomOther
,a.isUseDrug = c.isUseDrug
,a.noUseDrugReasonCode = c.noUseDrugReasonCode
,a.noUseDrugReasonValue = c.noUseDrugReasonValue
,a.noUseDrugSideEffects = c.noUseDrugSideEffects
,a.otherNoUseDrugReason = c.otherNoUseDrugReason
,a.noUseDrugLaw = c.noUseDrugLaw
,a.noUseDrugLawReason = c.noUseDrugLawReason
,a.lawSideEffects = c.lawSideEffects
,a.otherLawReason = c.otherLawReason
,a.treatmentMeasures = c.treatmentMeasures
,a.clinicalInfo = c.clinicalInfo
,a.auxiliaryCheck = c.auxiliaryCheck
,a.interveneNum = c.interveneNum
,a.beforeInterveneDate = c.beforeInterveneDate
,a.isIntervene = c.isIntervene
,a.syndrome = c.syndrome
,a.interveneMeasures = c.interveneMeasures
,a.measuresContent = c.measuresContent
,a.otherInterveneMeasures = c.otherInterveneMeasures
,a.otherMeasuresContent = c.otherMeasuresContent
,a.proposal = c.proposal
,a.acceptability = c.acceptability
,a.isAcceptHealthEdu = c.isAcceptHealthEdu
,a.healthEduType = c.healthEduType
,a.visitType = c.visitType
,a.referralReason = c.referralReason
,a.referralOrgDept = c.referralOrgDept
,a.synStatus = c.synStatus
,a.lawSideEffectsFlag = c.lawSideEffectsFlag
,a.age = c.age
,a.empiGuid = c.empiGuid
from tb_dc_htn_visit a 
inner join tb_dc_chronic_main b 
on a.cardid = b.visitNum and a.orgCode = b.orgCode 
inner join (select t.manageNum, tt.* from #T t inner join tb_dc_htn_visit tt on t.visitNum = tt.cardId) c 
on b.manageNum = c.manageNum
where a.isGovernance = 1;

-- 没有上一次随访数据，自造数据 -- 
with
exerciseTimeList as (
SELECT  * FROM (VALUES ('30'), ('40'), ('50'), ('60'))  AS X(name)
)

update a set 
a.name = c.name
,a.ehrNum = CASE WHEN len ( c.idCardNo ) = 18 THEN
	substring( c.idCardNo, 2, 17 ) ELSE c.idCardNo 
	END
,a.visitWayCode = '1'
,a.visitWayValue = '门诊'
,a.vistStatusCode = '1'
,a.visitStatusValue = '继续随访'
,a.hasPaperCard = '1'
,a.symptomCode = '13'
,a.bpWayCode = '1'
,a.sbp =  ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 120+ 1-90 ) + 90 )
,a.dbp = ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 90+ 1-60 ) + 60 )
,a.height = cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 180+ 1-160 ) + 160 ) AS VARCHAR ( 10 ) ) + '.0'
,a.weight = cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 60+ 1-45 ) + 45 ) AS VARCHAR ( 10 ) ) + '.' + cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 9+ 1-1 ) + 1 ) AS VARCHAR ( 10 ) )
,a.heartRate = ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 100+ 1-80 ) + 80 )
,a.smokingStatusCode = '4'
,a.smokingStatusName = '从不吸'
,a.smokingVolume = 0
,a.drinkingFrequencyCode = '1'
,a.drinkingFrequencyName = '从不'
,a.drinkingVolume = 0
,a.exerciseFrequencyCode = '3'
,a.exerciseFrequencyName = '偶尔'
,a.sportTime = ( SELECT top 1 * FROM exerciseTimeList ORDER BY newid ( ) )
,a.saltUptakeStatus = '1'
,a.saltUptakeStatusName = '轻'
,a.psychologyStatus = '1'
,a.psychologyStatusName = '良好'
,a.complianceStatus = '1'
,a.complianceStatusName = '良好'
,a.manageGroup = '1'
,a.clinicalInfo = '16'
,a.dangerousLevelCode = '1'
,a.dangerousLevelName = '低危层'
,a.isUseDrug = '2'
,a.noUseDrugReasonCode = '99'
,a.noUseDrugReasonValue = '其他'
,a.noUseDrugSideEffects = '无'
,a.noUseDrugLaw = '2'
,a.drugComplianceCode = '3'
,a.drugComplianceName = '不服药'
,a.lawSideEffectsFlag = '2'
,a.visitType = '1'
,a.treatmentMeasures = '4'
,a.proposal = '8-1'
,a.acceptability = '1'
,a.isAcceptHealthEdu = '1'
,a.healthEduType = ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 5+ 1-1 ) + 1 )
,a.age = dbo.Fn_GetAge(c.idCardNo,a.visitDate)
,a.nextVisiDate = dateadd(m,3,a.visitDate)
,a.empiGuid = d.empiGuid 
from tb_dc_htn_visit a 
inner join tb_dc_chronic_main b 
on a.cardid = b.visitNum and a.orgCode = b.orgCode 
inner join tb_dc_chronic_info d 
on b.manageNum = d.manageNum and b.orgCode = d.orgCode 
inner join tb_empi_index_root c 
on d.empiGuid = c.guid 
where b.manageNum not in (select manageNum from #T) and a.isGovernance = 1;


------------------------ 糖尿病 -----------------------------

truncate table #T;

insert into #T
select t1.manageNum, t1.visitNum from (select a.manageNum,max(a.visitNum) visitNum from tb_dc_chronic_main a inner join 
tb_dc_dm_visit b on a.visitNum = b.cardid and a.orgCode = b.orgCode  where a.isGovernance <> 1 or a.isGovernance is null group by a.manageNum) t1 
inner join (select manageNum from tb_dc_chronic_main where isGovernance = 1 group by manageNum) t2 
on t1.manageNum = t2.manageNum;

update a set 
 a.name = c.name
,a.ehrNum = c.ehrNum
,a.orgCode = c.orgCode
,a.visitWayCode = c.visitWayCode
,a.visitWayValue = c.visitWayValue
,a.otherVisit = c.otherVisit
,a.visitDocNo = c.visitDocNo
,a.visitDocName = c.visitDocName
,a.visitOrgCode = c.visitOrgCode
,a.visitOrgName = c.visitOrgName
,a.vistStatusCode = c.vistStatusCode
,a.visitStatusValue = c.visitStatusValue
,a.nextVisiDate = c.nextVisiDate
,a.lostVisitCode = c.lostVisitCode
,a.lostVisitName = c.lostVisitName
,a.lostVisitDate = c.lostVisitDate
,a.otherLostVIsitName = c.otherLostVIsitName
,a.deathReason = c.deathReason
,a.targetDistrictCode = c.targetDistrictCode
,a.targetDistrictName = c.targetDistrictName
,a.targetOrgCode = c.targetOrgCode
,a.targetOrgName = c.targetOrgName
,a.moveProvinceCode = c.moveProvinceCode
,a.moveProvinceValue = c.moveProvinceValue
,a.moveCityCode = c.moveCityCode
,a.moveCityValue = c.moveCityValue
,a.moveDistrictCode = c.moveDistrictCode
,a.moveDistrictValue = c.moveDistrictValue
,a.moveStreetCode = c.moveStreetCode
,a.moveStreetValue = c.moveStreetValue
,a.moveNeighborhoodCode = c.moveNeighborhoodCode
,a.moveNeighborhoodValue = c.moveNeighborhoodValue
,a.moveVillageValue = c.moveVillageValue
,a.moveHouseNumber = c.moveHouseNumber
,a.moveOrgCode = c.moveOrgCode
,a.moveOrgName = c.moveOrgName
,a.hasPaperCard = c.hasPaperCard
,a.isAcceptHealthEdu = c.isAcceptHealthEdu
,a.healthEduType = c.healthEduType
,a.clinicalSymptomsCode = c.clinicalSymptomsCode
,a.clinicalSymptomsValue = c.clinicalSymptomsValue
,a.otherClinicalSymptoms = c.otherClinicalSymptoms
,a.symptomStatus = c.symptomStatus
,a.clinicalInfo = c.clinicalInfo
,a.sbp = c.sbp
,a.dbp = c.dbp
,a.height = c.height
,a.weight = c.weight
,a.waistline = c.waistline
,a.hipline = c.hipline
,a.targetWeight = c.targetWeight
,a.BMI = c.BMI
,a.targetBMI = c.targetBMI
,a.dorsalArteryOfFootLeftCode = c.dorsalArteryOfFootLeftCode
,a.dorsalArteryOfFootLeftName = c.dorsalArteryOfFootLeftName
,a.dorsalArteryOfFootRightCode = c.dorsalArteryOfFootRightCode
,a.dorsalArteryOfFootRightName = c.dorsalArteryOfFootRightName
,a.hypoglycemia = c.hypoglycemia
,a.familyHistory = c.familyHistory
,a.isLawSport = c.isLawSport
,a.sportTypeCode = c.sportTypeCode
,a.sportTypeName = c.sportTypeName
,a.sportFrequence = c.sportFrequence
,a.sportTimes = c.sportTimes
,a.dietCode = c.dietCode
,a.dietName = c.dietName
,a.stapleFood = c.stapleFood
,a.targetStapleFood = c.targetStapleFood
,a.smokingVolume = c.smokingVolume
,a.drinkingVolume = c.drinkingVolume
,a.targetSportFrequencyCode = c.targetSportFrequencyCode
,a.targetSportFrequencyName = c.targetSportFrequencyName
,a.targetSportTimes = c.targetSportTimes
,a.smokingStatusCode = c.smokingStatusCode
,a.smokingStatusName = c.smokingStatusName
,a.targetSmoke = c.targetSmoke
,a.quitSmoking = c.quitSmoking
,a.drinkingFrequencyCode = c.drinkingFrequencyCode
,a.drinkingFrequencyName = c.drinkingFrequencyName
,a.targetDrink = c.targetDrink
,a.psychologyStatusCode = c.psychologyStatusCode
,a.psychologyStatusName = c.psychologyStatusName
,a.complianceStatusCode = c.complianceStatusCode
,a.complianceStatusName = c.complianceStatusName
,a.referralReason = c.referralReason
,a.referralOrgDept = c.referralOrgDept
,a.visitType = c.visitType
,a.fastingBloodSugarCode = c.fastingBloodSugarCode
,a.fastingBloodSugarName = c.fastingBloodSugarName
,a.fastingBloodSugarValue = c.fastingBloodSugarValue
,a.fastingBloodSugarGatherCode = c.fastingBloodSugarGatherCode
,a.fastingBloodSugarGatherName = c.fastingBloodSugarGatherName
,a.randomBloodSugarCode = c.randomBloodSugarCode
,a.randomBloodSugarName = c.randomBloodSugarName
,a.randomBloodSugarValue = c.randomBloodSugarValue
,a.randomBloodSugarGatherCode = c.randomBloodSugarGatherCode
,a.randomBloodSugarGatherName = c.randomBloodSugarGatherName
,a.fastingBloodSugarOGTTCode = c.fastingBloodSugarOGTTCode
,a.fastingBloodSugarOGTTName = c.fastingBloodSugarOGTTName
,a.fastingBloodSugarOGTTValue = c.fastingBloodSugarOGTTValue
,a.fastingBloodSugarOGTTGatherCode = c.fastingBloodSugarOGTTGatherCode
,a.fastingBloodSugarOGTTGatherName = c.fastingBloodSugarOGTTGatherName
,a.twoHBloodSugarOGTTCode = c.twoHBloodSugarOGTTCode
,a.twoHBloodSugarOGTTName = c.twoHBloodSugarOGTTName
,a.twoHBloodSugarOGTTValue = c.twoHBloodSugarOGTTValue
,a.twoHBloodSugarOGTTGatherCode = c.twoHBloodSugarOGTTGatherCode
,a.twoHBloodSugarOGTTGatherName = c.twoHBloodSugarOGTTGatherName
,a.hbAlc = c.hbAlc
,a.hbAlcDate = c.hbAlcDate
,a.cholesterol = c.cholesterol
,a.triglycerides = c.triglycerides
,a.highCholesterol = c.highCholesterol
,a.lowCholesterol = c.lowCholesterol
,a.acr = c.acr
,a.urineProtein = c.urineProtein
,a.ghGaterWayCode = c.ghGaterWayCode
,a.ghGaterWayName = c.ghGaterWayName
,a.drugComplianceCode = c.drugComplianceCode
,a.drugComplianceName = c.drugComplianceName
,a.useDrug = c.useDrug
,a.hasUseDrugSideEffects = c.hasUseDrugSideEffects
,a.UseDrugSideEffects = c.UseDrugSideEffects
,a.interveneCount = c.interveneCount
,a.beforeInterveneDate = c.beforeInterveneDate
,a.isIntervene = c.isIntervene
,a.syndrome = c.syndrome
,a.interveneMeasures = c.interveneMeasures
,a.measuresContent = c.measuresContent
,a.otherInterveneMeasures = c.otherInterveneMeasures
,a.otherMeasuresContent = c.otherMeasuresContent
,a.proposal = c.proposal
,a.otherProposal = c.otherProposal
,a.synStatus = c.synStatus
,a.age = c.age
,a.empiGuid = c.empiGuid 
from tb_dc_dm_visit a 
inner join tb_dc_chronic_main b 
on a.cardid = b.visitNum and a.orgCode = b.orgCode 
inner join (select t.manageNum, tt.* from #T t inner join tb_dc_dm_visit tt on t.visitNum = tt.cardId) c 
on b.manageNum = c.manageNum
where a.isGovernance = 1;

-- 没有上一次随访数据，自造数据 -- 
with
exerciseTimeList as (
SELECT  * FROM (VALUES ('30'), ('40'), ('50'), ('60'))  AS X(name)
),
foodList as (
SELECT  * FROM (VALUES ('250'), ('300'))  AS X(name)
) 

update a set 
a.name = c.name
,a.ehrNum = CASE WHEN len ( c.idCardNo ) = 18 THEN
	substring( c.idCardNo, 2, 17 ) ELSE c.idCardNo 
	END
,a.vistStatusCode = '1'
,a.visitStatusValue = '继续随访'
,a.hasPaperCard = '1'
,a.clinicalSymptomsCode = '13'
,a.clinicalSymptomsValue = '以上都无'
,a.symptomStatus = '2'
,a.hypoglycemia = '1'
,a.familyHistory = '2'
,a.isLawSport = '1'
,a.sportTypeCode = '1'
,a.sportTypeName = '轻度运动'
,a.sbp = ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 120+ 1-90 ) + 90 )
,a.dbp = ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 90+ 1-60 ) + 60 )
,a.height = cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 180+ 1-160 ) + 160 ) AS VARCHAR ( 10 ) ) + '.0'
,a.weight = cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 60+ 1-45 ) + 45 ) AS VARCHAR ( 10 ) ) + '.' + cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 9+ 1-1 ) + 1 ) AS VARCHAR ( 10 ) )
,a.waistline = cast( ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 85+ 1-60 ) + 60 ) AS VARCHAR ( 10 ) ) + '.0'
,a.dorsalArteryOfFootLeftCode = '1'
,a.dorsalArteryOfFootLeftName = '未触及'
,a.dorsalArteryOfFootRightCode = '1'
,a.dorsalArteryOfFootRightName = '未触及'
,a.smokingStatusCode = '4'
,a.smokingStatusName = '从不吸'
,a.smokingVolume = 0
,a.drinkingVolume = 0
,a.drinkingFrequencyCode = '1'
,a.drinkingFrequencyName = '从不'
,a.sportTimes = ( SELECT top 1 * FROM exerciseTimeList ORDER BY newid ( ) )
,a.dietCode = '1'
,a.dietName = '完全按医生要求执行'
,a.stapleFood = ( SELECT top 1 * FROM foodList ORDER BY newid ( ) )
,a.psychologyStatusCode = '1'
,a.psychologyStatusName = '良好'
,a.complianceStatusCode = '1'
,a.complianceStatusName = '良好'
,a.fastingBloodSugarValue = '6.8'
,a.drugComplianceCode = '1'
,a.drugComplianceName = '规律'
,a.hasUseDrugSideEffects = '2'
,a.visitType = '1'
,a.isAcceptHealthEdu = '1'
,a.healthEduType = ( abs( CHECKSUM ( NEWID ( ) ) ) % ( 5+ 1-1 ) + 1 )
,a.visitWayCode = '1'
,a.visitWayValue = '门诊'
,a.nextVisiDate = dateadd(m,3,a.visitDate)
,a.empiGuid = d.empiGuid 
from tb_dc_dm_visit a 
inner join tb_dc_chronic_main b 
on a.cardid = b.visitNum and a.orgCode = b.orgCode 
inner join tb_dc_chronic_info d 
on b.manageNum = d.manageNum and b.orgCode = d.orgCode 
inner join tb_empi_index_root c 
on d.empiGuid = c.guid 
where b.manageNum not in (select manageNum from #T) and a.isGovernance = 1;

DROP TABLE #T;
end
go

