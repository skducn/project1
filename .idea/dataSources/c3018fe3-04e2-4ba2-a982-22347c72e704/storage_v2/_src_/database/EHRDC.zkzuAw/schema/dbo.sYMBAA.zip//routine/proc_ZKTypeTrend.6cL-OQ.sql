CREATE PROCEDURE [dbo].[proc_ZKTypeTrend]
as
WITH a as (
    select top 1  substring (zksj , 1,4)+'-'+substring (zksj ,5,2)+'-'+substring (zksj ,7,2) as ControlTime,zkbm  from ZKJLB
    ORDER BY id DESC
),b as (
    select '' as ControlFields, COUNT(DISTINCT ArchiveNum) as WrongNum, GETDATE() as 'CreateTime',1 as 'Symbol'
    from HrArchivesResult where IsPass = 0
)
insert into ZKTypeTrend(ControlTime,ControlFields,WrongNum,createtime,Symbol,zkbm)
select a.ControlTime,b.*,a.zkbm from a,b
go

