CREATE VIEW [dbo].[view_tb_his_op_medical_record] AS select * from tb_his_op_medical_record
go

