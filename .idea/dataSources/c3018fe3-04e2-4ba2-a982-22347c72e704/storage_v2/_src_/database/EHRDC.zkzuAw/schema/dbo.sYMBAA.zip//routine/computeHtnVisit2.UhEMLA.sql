CREATE PROCEDURE [dbo].[computeHtnVisit2]
  @startDate AS varchar(20),
  @endDate AS varchar(20) 
AS
BEGIN
truncate table temp_高血压随访次数统计


declare @startDate2 varchar(20)='',@startDate1 varchar(20)=''
set @startDate1 =@startDate

while(@startDate<@endDate)
begin    

set @startDate2 = convert(varchar(10),DATEADD(MONTH,3,@startDate),120)

INSERT into temp_高血压随访次数统计(archive_num,start_date,end_date)
select sfzh,
dbo.computeDate(convert(varchar(10),info.registTime,120),@startDate) startDate,
DATEADD(Day,-1, dbo.computeDate(convert(varchar(10),info.registTime,120),@startDate2)) endDate 
from report_qyyh q
inner join tb_empi_index_root r on q.SFZH  =r.idCardNo
inner join 
(select empiguid,min(registTime) registTime from  tb_dc_chronic_main 
where visitTypeCode like '%31%' and registTime>'2010-01-01' group by empiGuid) 
info on r.guid =info.empiGuid
where A6 = 1 and info.registTime is not null
set @startDate =@startDate2
end

delete from temp_高血压随访次数统计 where end_date>@endDate
delete from temp_高血压随访次数统计 where end_date<start_date


update a set a.visit_date = v.visitdate 
from temp_高血压随访次数统计 a
inner join tb_empi_index_root r on a.archive_num =r.idCardNo
left join tb_dc_htn_visit v on r.guid =v.empiGuid
where visitdate>start_date and visitdate<end_date


update report_qyyh
set B611=(select count(*)
          from temp_高血压随访次数统计 a
          where a.archive_num = sfzh
            and a.visit_date is not null)

update report_qyyh
set B612=(select count(*)
          from temp_高血压随访次数统计 a
          where a.archive_num = sfzh
            and a.visit_date is  null)


update  q set B612 = DATEDIFF(Month,@startDate1,@endDate)/3 
from report_qyyh q
inner join tb_empi_index_root r on q.SFZH  =r.idCardNo
inner join (select empiguid,min(registTime) registTime from  tb_dc_chronic_main 
where visitTypeCode like '%31%'  group by empiGuid) 
info  on r.guid =info.empiGuid
where info.registTime is null



update report_qyyh
set B613=B6+B612

update report_qyyh 
set B5=B613


END
go

