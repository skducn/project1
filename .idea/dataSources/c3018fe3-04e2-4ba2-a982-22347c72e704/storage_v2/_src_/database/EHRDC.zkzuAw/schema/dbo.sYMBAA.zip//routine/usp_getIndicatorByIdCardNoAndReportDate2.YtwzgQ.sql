CREATE PROCEDURE [dbo].[usp_getIndicatorByIdCardNoAndReportDate2]
	@idCardNo VARCHAR(20),
	@reportDateBegin VARCHAR(50) = '',
	@reportDateEnd VARCHAR(50) = ''
AS
BEGIN
	-- 1. root.guid = total.empiguid  根据 @idCardNo 查 tb_empi_index_root root.guid 
	DECLARE @rootGuid VARCHAR(100);
	SET @rootGuid = (SELECT TOP 1 guid FROM tb_empi_index_root WHERE idCardNo = @idCardNo);
	
	IF (@reportDateBegin = '' OR @reportDateEnd = '')
		BEGIN
			-- 2.查询最终结果 ,过滤参数没有时间条件
			SELECT
				detail.itemName,
				detail.resultValue,
				detail.resultUnit
			FROM
				tb_lis_report_indicator detail
				WHERE detail.visitStrNo IN (
					SELECT DISTINCT visitStrNo FROM  (
						SELECT visitStrNo
						FROM tb_lis_report
						WHERE empiguid = @rootGuid
					) total
				)
		END
	ELSE
		BEGIN
			-- 3.查询最终结果 ,过滤参数有时间条件
			SELECT
				detail.itemName,
				detail.resultValue,
				detail.resultUnit
			FROM
				tb_lis_report_indicator detail
				WHERE detail.visitStrNo IN (
					SELECT DISTINCT visitStrNo FROM  (
						SELECT visitStrNo
						FROM tb_lis_report
						WHERE empiguid = @rootGuid
						AND reportDate BETWEEN DATEADD(month, -3, @reportDateBegin) AND @reportDateEnd
					) total
				)
		END
	

END
go

