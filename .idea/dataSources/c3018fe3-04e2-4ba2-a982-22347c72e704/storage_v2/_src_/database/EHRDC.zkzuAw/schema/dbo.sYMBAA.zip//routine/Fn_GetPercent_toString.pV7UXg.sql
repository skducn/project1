CREATE FUNCTION [dbo].[Fn_GetPercent_toString](
    @分子 INT,@分母 INT
)
    returns varchar(max)
as

begin

    declare @return varchar(max)

    if (@分母 is null or @分母 = 0)
        begin
            set @return='0.0'
        end
    else
        begin
            set @return=cast(cast(round(@分子/CONVERT(float,@分母), 4) * 100   as   numeric(8,1)) as varchar)
        end

    return @return
end
go

