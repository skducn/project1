CREATE PROCEDURE [dbo].[getHrCoverViewInfo]
  @targetFiled  varchar(250),@archiveNum varchar(250)
AS
BEGIN

 DECLARE @maxId varchar(50);
set @maxId= (select max(id) id  from backup_history);
 DECLARE @SqlStr nvarchar(max) ='';
 
set @SqlStr='select ['+@targetFiled+'] from ( select HrCover.ArchiverId "HrCover.ArchiverId",
HrCover.ArchiveUnitCode				"HrCover.ArchiveUnitCode",
convert(varchar(10),HrCover.DateOfCreateArchive,120)				"HrCover.DateOfCreateArchive",
HrCover.ehrNum				"HrCover.ehrNum",
HrCover.Name				"HrCover.Name",
HrCover.Neighborhood				"HrCover.Neighborhood",
HrCover.PermanentAddress				"HrCover.PermanentAddress",
HrCover.Phone				"HrCover.Phone",
HrCover.PresentAddress				"HrCover.PresentAddress",
HrCover.ResponsibleDoctor				"HrCover.ResponsibleDoctor",
HrCover.VillageName				"HrCover.VillageName",
Hrcover.ArchiveNum "Hrcover.ArchiveNum",
HrCover.ResponsibleDoctorId				"HrCover.ResponsibleDoctorId",
HrCover.VillageCode				"HrCover.VillageCode",
HrCover.ProvinceCode      "HrCover.ProvinceCode",
HrCover.NeighborhoodCode   "HrCover.NeighborhoodCode"

from dbo.Hrcover_third_'+@maxId+' HrCover  where ArchiveNum='''+@archiveNum +''' ) a ';
 
 exec (@sqlStr)


END
go

