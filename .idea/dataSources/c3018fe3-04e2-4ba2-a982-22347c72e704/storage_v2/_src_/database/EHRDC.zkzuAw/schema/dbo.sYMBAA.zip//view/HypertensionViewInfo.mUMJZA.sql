CREATE VIEW [dbo].[HypertensionViewInfo] AS SELECT
  tb_dc_htn_visit.guid  as "Hypertension.guid",
	tb_dc_chronic_info.livePlaceDetailAddress "tb_dc_chronic_info.livePlaceDetailAddress",
	tb_dc_chronic_info.sexName "tb_dc_chronic_info.sexName",
	case when tb_dc_htn_visit.acceptability = '1' then '完全接受'
	     when tb_dc_htn_visit.acceptability = '2' then '勉强接受'
			 when tb_dc_htn_visit.acceptability = '3' then '不接受'
			 else tb_dc_htn_visit.acceptability end "tb_dc_htn_visit.acceptability",
	tb_dc_htn_visit.bloodLipids "tb_dc_htn_visit.bloodLipids",
	tb_dc_htn_visit.bloodPotassium "tb_dc_htn_visit.bloodPotassium",
	tb_dc_htn_visit.bloodSodium "tb_dc_htn_visit.bloodSodium",
	tb_dc_htn_visit.bmi "tb_dc_htn_visit.bmi",
	case when tb_dc_htn_visit.bpWayCode = '1' then '手动输入'
	     when tb_dc_htn_visit.bpWayCode = '2' then '仪器采集'
			 else tb_dc_htn_visit.bpWayCode end "tb_dc_htn_visit.bpWayCode",
	tb_dc_htn_visit.cardId "tb_dc_htn_visit.cardId",
	tb_dc_htn_visit.carotidUltrasound "tb_dc_htn_visit.carotidUltrasound",
	tb_dc_htn_visit.chestXray "tb_dc_htn_visit.chestXray",
	tb_dc_htn_visit.cholesterol "tb_dc_htn_visit.cholesterol",
	case when tb_dc_htn_visit.clinicalInfo = '1' then '缺血性卒中'
       when tb_dc_htn_visit.clinicalInfo = '2' then '脑出血'
       when tb_dc_htn_visit.clinicalInfo = '3' then '短暂性脑缺血发作（TIA）'
       when tb_dc_htn_visit.clinicalInfo = '4' then '心肌梗死'
       when tb_dc_htn_visit.clinicalInfo = '5' then '心绞痛'
       when tb_dc_htn_visit.clinicalInfo = '6' then '冠状动脉血运重建史'
       when tb_dc_htn_visit.clinicalInfo = '7' then '慢性心力衰竭'
       when tb_dc_htn_visit.clinicalInfo = '8' then '充血性心力衰竭'
       when tb_dc_htn_visit.clinicalInfo = '9' then '糖尿病肾病'
       when tb_dc_htn_visit.clinicalInfo = '10' then '肾功能衰竭（血肌酐：男性≥1.5mg/dl，女性≥1.4mg/dl，蛋白质≥300mg/24h）'
       when tb_dc_htn_visit.clinicalInfo = '11' then '外周血管疾病'
       when tb_dc_htn_visit.clinicalInfo = '12' then '视网膜病变（出血或渗出，视乳头水肿）'
       when tb_dc_htn_visit.clinicalInfo = '13' then '糖尿病'
       when tb_dc_htn_visit.clinicalInfo = '14' then '夹层动脉瘤'
       when tb_dc_htn_visit.clinicalInfo = '15' then '症状性动脉疾病'
       when tb_dc_htn_visit.clinicalInfo = '16' then '以上情况均无' 
			 else tb_dc_htn_visit.clinicalInfo end  "tb_dc_htn_visit.clinicalInfo",
	case when tb_dc_htn_visit.complianceStatus = '1' then '良好'
			 when tb_dc_htn_visit.complianceStatus = '2' then '一般'
			 when tb_dc_htn_visit.complianceStatus = '3' then '差'
			 else tb_dc_htn_visit.complianceStatus end "tb_dc_htn_visit.complianceStatus",
	tb_dc_htn_visit.creatinine "tb_dc_htn_visit.creatinine",
	case when tb_dc_htn_visit.dangerousLevelCode = '1' then '低危层'
       when tb_dc_htn_visit.dangerousLevelCode = '2' then '中危层'
       when tb_dc_htn_visit.dangerousLevelCode = '3' then '高危层'
       when tb_dc_htn_visit.dangerousLevelCode = '4' then '很高危层'
			 else tb_dc_htn_visit.dangerousLevelCode end "tb_dc_htn_visit.dangerousLevelCode",
	tb_dc_htn_visit.dbp "tb_dc_htn_visit.dbp",
	case when tb_dc_htn_visit.drinkingFrequencyCode = '1' then '从不'
	     when tb_dc_htn_visit.drinkingFrequencyCode = '2' then '偶尔'
			 when tb_dc_htn_visit.drinkingFrequencyCode = '3' then '经常'
			 when tb_dc_htn_visit.drinkingFrequencyCode = '4' then '每天'
			 else tb_dc_htn_visit.drinkingFrequencyCode end "tb_dc_htn_visit.drinkingFrequencyCode",
	tb_dc_htn_visit.drinkingVolume "tb_dc_htn_visit.drinkingVolume",
	case when tb_dc_htn_visit.drugComplianceCode = '1' then '规律'
	     when tb_dc_htn_visit.drugComplianceCode = '2' then '间断'
			 when tb_dc_htn_visit.drugComplianceCode = '3' then '不服药'
			 else tb_dc_htn_visit.drugComplianceCode end "tb_dc_htn_visit.drugComplianceCode",
	tb_dc_htn_visit.ECG "tb_dc_htn_visit.ECG",
	tb_dc_htn_visit.echocardiogram "tb_dc_htn_visit.echocardiogram",
	tb_dc_htn_visit.fastingBloodSugarValue "tb_dc_htn_visit.fastingBloodSugarValue",
	tb_dc_htn_visit.glycosylatedHemoglobin "tb_dc_htn_visit.glycosylatedHemoglobin",
	case when tb_dc_htn_visit.hasPaperCard = '1' then '是'
	     when tb_dc_htn_visit.hasPaperCard = '2' then '否'
			 else tb_dc_htn_visit.hasPaperCard end "tb_dc_htn_visit.hasPaperCard",
	case when tb_dc_htn_visit.healthEduType = '1' then '电话'
       when tb_dc_htn_visit.healthEduType = '2' then '讲座'
       when tb_dc_htn_visit.healthEduType = '3' then '资料发放'
       when tb_dc_htn_visit.healthEduType = '4' then '现场活动'
       when tb_dc_htn_visit.healthEduType = '5' then '面对面咨询'
       when tb_dc_htn_visit.healthEduType = '6' then '观看视频'
       when tb_dc_htn_visit.healthEduType = '7' then '网络'
       when tb_dc_htn_visit.healthEduType = '8' then '其他' 
			 else tb_dc_htn_visit.healthEduType end "tb_dc_htn_visit.healthEduType",
	tb_dc_htn_visit.heartRate "tb_dc_htn_visit.heartRate",
	tb_dc_htn_visit.height "tb_dc_htn_visit.height",
	tb_dc_htn_visit.hemameba "tb_dc_htn_visit.hemameba",
	tb_dc_htn_visit.hemoglobin "tb_dc_htn_visit.hemoglobin",
	tb_dc_htn_visit.highCholesterol "tb_dc_htn_visit.highCholesterol",
	tb_dc_htn_visit.homocysteineDetection "tb_dc_htn_visit.homocysteineDetection",
	case when tb_dc_htn_visit.isAcceptHealthEdu = '1' then '是'
	     when tb_dc_htn_visit.isAcceptHealthEdu = '2' then '否'
			 else tb_dc_htn_visit.isAcceptHealthEdu end "tb_dc_htn_visit.isAcceptHealthEdu",
  case when tb_dc_htn_visit.isUseDrug = '1' then '是'
	     when tb_dc_htn_visit.isUseDrug = '2' then '否'
			 else tb_dc_htn_visit.isUseDrug  end "tb_dc_htn_visit.isUseDrug",
	tb_dc_htn_visit.lawSideEffects "tb_dc_htn_visit.lawSideEffects",
	case when tb_dc_htn_visit.lostVisitCode = '1' then '死亡'
       when tb_dc_htn_visit.lostVisitCode = '2' then '搬迁'
       when tb_dc_htn_visit.lostVisitCode = '3' then '拒访'
       when tb_dc_htn_visit.lostVisitCode = '4' then '其他' 
			 else tb_dc_htn_visit.lostVisitCode end "tb_dc_htn_visit.lostVisitCode",
	tb_dc_htn_visit.lostVisitDate "tb_dc_htn_visit.lostVisitDate",
	tb_dc_htn_visit.lowCholesterol "tb_dc_htn_visit.lowCholesterol",
	case when tb_dc_htn_visit.manageGroup = '1' then '一组重点组'
	     when tb_dc_htn_visit.manageGroup = '2' then '二组好转组'
			 when tb_dc_htn_visit.manageGroup = '3' then '三组稳定组'
			 when tb_dc_htn_visit.manageGroup = '4' then '一般管理对象'
			 else tb_dc_htn_visit.manageGroup end "tb_dc_htn_visit.manageGroup",
	tb_dc_htn_visit.nextVisiDate "tb_dc_htn_visit.nextVisiDate",
	case when tb_dc_htn_visit.noUseDrugLaw = '1' then '是'
			when tb_dc_htn_visit.noUseDrugLaw = '2' then '否'
			else tb_dc_htn_visit.noUseDrugLaw end "tb_dc_htn_visit.noUseDrugLaw",
	case when tb_dc_htn_visit.noUseDrugReasonCode = '1' then '经济原因'
       when tb_dc_htn_visit.noUseDrugReasonCode = '2' then '忘记'
       when tb_dc_htn_visit.noUseDrugReasonCode = '3' then '不良反应'
       when tb_dc_htn_visit.noUseDrugReasonCode = '4' then '配药不方便'
       when tb_dc_htn_visit.noUseDrugReasonCode = '5' then '不需药物治疗'
			 when tb_dc_htn_visit.noUseDrugReasonCode = '99' then '其他'
			 else tb_dc_htn_visit.noUseDrugReasonCode end "tb_dc_htn_visit.noUseDrugReasonCode",
	tb_dc_htn_visit.noUseDrugSideEffects "tb_dc_htn_visit.noUseDrugSideEffects",
	tb_dc_htn_visit.otherLostVIsitName "tb_dc_htn_visit.otherLostVIsitName",
	tb_dc_htn_visit.platelet "tb_dc_htn_visit.platelet",
	-- 字典见”健康处方字典“sheet
	tb_dc_htn_visit.proposal "tb_dc_htn_visit.proposal",
	case when tb_dc_htn_visit.psychologyStatus = '1' then '良好'
			 when tb_dc_htn_visit.psychologyStatus = '2' then '一般'
			 when tb_dc_htn_visit.psychologyStatus = '3' then '差'
			 else tb_dc_htn_visit.psychologyStatus end "tb_dc_htn_visit.psychologyStatus",
	tb_dc_htn_visit.pulseWave "tb_dc_htn_visit.pulseWave",
	tb_dc_htn_visit.referralOrgDept "tb_dc_htn_visit.referralOrgDept",
	tb_dc_htn_visit.referralReason "tb_dc_htn_visit.referralReason",
	case when tb_dc_htn_visit.saltUptakeStatus = '1' then '轻' 
	     when tb_dc_htn_visit.saltUptakeStatus = '2' then '中' 
		   when tb_dc_htn_visit.saltUptakeStatus = '3' then '重' 
			 else tb_dc_htn_visit.saltUptakeStatus end  "tb_dc_htn_visit.saltUptakeStatus",
	tb_dc_htn_visit.sbp "tb_dc_htn_visit.sbp",
	tb_dc_htn_visit.serumCProtein "tb_dc_htn_visit.serumCProtein",
	case when tb_dc_htn_visit.smokingStatusCode = '1' then '现在每天吸'
	     when tb_dc_htn_visit.smokingStatusCode = '2' then '现在吸，但不是每天吸'
			 when tb_dc_htn_visit.smokingStatusCode = '3' then '过去吸，现在不吸'
			 when tb_dc_htn_visit.smokingStatusCode = '4' then '从不吸'
			 else tb_dc_htn_visit.smokingStatusCode end "tb_dc_htn_visit.smokingStatusCode",
	tb_dc_htn_visit.smokingVolume "tb_dc_htn_visit.smokingVolume",
	tb_dc_htn_visit.sportFrequence "tb_dc_htn_visit.sportFrequence",
	tb_dc_htn_visit.sportTime "tb_dc_htn_visit.sportTime",
	case when tb_dc_htn_visit.symptomCode = '1' then '头晕'
       when tb_dc_htn_visit.symptomCode = '2' then '头痛'
       when tb_dc_htn_visit.symptomCode = '3' then '烦躁'
       when tb_dc_htn_visit.symptomCode = '4' then '面色苍白或潮红'
       when tb_dc_htn_visit.symptomCode = '5' then '视力模糊'
       when tb_dc_htn_visit.symptomCode = '6' then '恶心呕吐'
       when tb_dc_htn_visit.symptomCode = '7' then '眼花耳鸣'
       when tb_dc_htn_visit.symptomCode = '8' then '呼吸困难'
       when tb_dc_htn_visit.symptomCode = '9' then '心悸胸闷'
       when tb_dc_htn_visit.symptomCode = '10' then '鼻衄出血不止'
       when tb_dc_htn_visit.symptomCode = '11' then '四肢发麻'
       when tb_dc_htn_visit.symptomCode = '12' then '下肢水肿'
       when tb_dc_htn_visit.symptomCode = '13' then '其他'
       when tb_dc_htn_visit.symptomCode = '14' then '以上情况全无'
			 else tb_dc_htn_visit.symptomCode end "tb_dc_htn_visit.symptomCode",
	tb_dc_htn_visit.targetBmi "tb_dc_htn_visit.targetBmi",
	tb_dc_htn_visit.targetDrink "tb_dc_htn_visit.targetDrink",
	case when tb_dc_htn_visit.targetSaltUptakeStatus = '1' then '轻'
	     when tb_dc_htn_visit.targetSaltUptakeStatus = '2' then '中'
			 when tb_dc_htn_visit.targetSaltUptakeStatus = '3' then '重'
			 else tb_dc_htn_visit.targetSaltUptakeStatus end "tb_dc_htn_visit.targetSaltUptakeStatus",
	tb_dc_htn_visit.targetSmoke "tb_dc_htn_visit.targetSmoke",
	tb_dc_htn_visit.targetSportFrequencyCode "tb_dc_htn_visit.targetSportFrequencyCode",
	tb_dc_htn_visit.targetSportTimes "tb_dc_htn_visit.targetSportTimes",
	tb_dc_htn_visit.targetWeight "tb_dc_htn_visit.targetWeight",
	case when tb_dc_htn_visit.treatmentMeasures = '1' then '限盐'
       when tb_dc_htn_visit.treatmentMeasures = '2' then '减少吸烟量或戒烟'
       when tb_dc_htn_visit.treatmentMeasures = '3' then '减少饮酒量或戒酒'
       when tb_dc_htn_visit.treatmentMeasures = '4' then '减少膳食脂肪'
       when tb_dc_htn_visit.treatmentMeasures = '5' then '减轻体重'
       when tb_dc_htn_visit.treatmentMeasures = '6' then '有规律体育运动'
       when tb_dc_htn_visit.treatmentMeasures = '7' then '放松情绪'
       when tb_dc_htn_visit.treatmentMeasures = '8' then '起居调摄'
       when tb_dc_htn_visit.treatmentMeasures = '9' then '穴位保健'
       when tb_dc_htn_visit.treatmentMeasures = '10' then '其他'
       when tb_dc_htn_visit.treatmentMeasures = '11' then '以上情况全无'
			 else tb_dc_htn_visit.treatmentMeasures end "tb_dc_htn_visit.treatmentMeasures",
	tb_dc_htn_visit.triglycerides "tb_dc_htn_visit.triglycerides",
	tb_dc_htn_visit.uricAcid "tb_dc_htn_visit.uricAcid",
	tb_dc_htn_visit.urineProtein "tb_dc_htn_visit.urineProtein",
	tb_dc_htn_visit.urineProteinQuantity "tb_dc_htn_visit.urineProteinQuantity",
	tb_dc_htn_visit.urineSugar "tb_dc_htn_visit.urineSugar",
	tb_dc_htn_visit.visitDate "tb_dc_htn_visit.visitDate",
	tb_dc_htn_visit.visitDocName "tb_dc_htn_visit.visitDocName",
	tb_dc_htn_visit.visitOrgCode "tb_dc_htn_visit.visitOrgCode",
	case when tb_dc_htn_visit.visitType = '1' then '控制满意'
	     when tb_dc_htn_visit.visitType = '2' then '控制不满意'
			 when tb_dc_htn_visit.visitType = '3' then '不良反应'
			 when tb_dc_htn_visit.visitType = '4' then '并发症' 
		   else tb_dc_htn_visit.visitType end "tb_dc_htn_visit.visitType",
  case when tb_dc_htn_visit.visitWayCode = '1' then '门诊'
       when tb_dc_htn_visit.visitWayCode = '2' then '家庭'
       when tb_dc_htn_visit.visitWayCode = '3' then '电话'
       when tb_dc_htn_visit.visitWayCode = '4' then '短信'
       when tb_dc_htn_visit.visitWayCode = '5' then '网络'
			 when tb_dc_htn_visit.visitWayCode = '9' then '社区'
			 when tb_dc_htn_visit.visitWayCode = '99' then '其他'
			 else tb_dc_htn_visit.visitWayCode end "tb_dc_htn_visit.visitWayCode",
	case when tb_dc_htn_visit.vistStatusCode = '1' then '是'
	     when tb_dc_htn_visit.vistStatusCode = '2' then '否'
			 else tb_dc_htn_visit.vistStatusCode  end "tb_dc_htn_visit.vistStatusCode",
	tb_dc_htn_visit.weight "tb_dc_htn_visit.weight",
	tb_dc_htn_visit.name "tb_empi_index_root.name",
	tb_empi_index_root.phoneNum "tb_empi_index_root.phoneNum",
	tb_empi_index_root.idCardNo "tb_empi_index_root.idCardNo" ,
	tb_dc_htn_visit.ehrNum "tb_dc_htn_visit.ehrNum",
	tb_dc_htn_visit.lawSideEffectsFlag "tb_dc_htn_visit.lawSideEffectsFlag",
	tb_dc_htn_visit.otherVisit "tb_dc_htn_visit.otherVisit",
	tb_dc_htn_visit.symptomOther "tb_dc_htn_visit.symptomOther"
	
FROM
	tb_dc_htn_visit
	LEFT JOIN tb_dc_chronic_main main ON tb_dc_htn_visit.cardId = main.visitNum 
	AND tb_dc_htn_visit.OrgCode = main.OrgCode
	LEFT JOIN tb_dc_chronic_info ON tb_dc_chronic_info.manageNum = main.manageNum 
	AND tb_dc_chronic_info.orgCode = main.orgcode
	LEFT JOIN tb_empi_index_root ON tb_empi_index_root.guid = tb_dc_chronic_info.empiGuid
go

