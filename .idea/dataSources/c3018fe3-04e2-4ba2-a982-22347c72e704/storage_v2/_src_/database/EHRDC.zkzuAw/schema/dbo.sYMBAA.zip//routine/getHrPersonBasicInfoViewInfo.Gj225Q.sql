CREATE PROCEDURE [dbo].[getHrPersonBasicInfoViewInfo] 
	@targetFiled varchar(250),
	@archiveNum varchar(250)
AS
BEGIN
	
 DECLARE @maxId varchar(50);
 set @maxId= (select max(id) id  from backup_history);
 DECLARE @SqlStr nvarchar(max) ='';

	set @SqlStr = 'select ['+@targetFiled+'] from ( select HrPersonBasicInfo.ContactsPhone              "HrPersonBasicInfo.ContactsPhone",
       STUFF((SELECT distinct '''+','' + HrAssociationInfo.msg FROM dbo.HrAssociationInfo_third_'+@maxId+' HrAssociationInfo 
	   WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid and AssociationType = '''+ 'history_of_trauma'' FOR XML PATH('''')), 1, 1, '''')    "HrAssociationInfo.history_of_trauma.msg", 
	   STUFF((SELECT distinct '''+','' + t.msg  FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a 
	   inner join tb_code b on a.code=b.code where a.AssociationType = '''+'history_of_disease'' and b.TargetField ='''+'history_of_disease'') t 
	   WHERE HrPersonBasicInfo.id = t.Pid   FOR XML PATH('''')), 1, 1, '''')   "HrAssociationInfo.history_of_disease.msg",
	   STUFF((SELECT distinct '''+','' + t.msg   FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a 
	   inner join tb_code b	on a.code=b.code where a.AssociationType = '''+'history_of_disease'' and b.TargetField='''+'family_history_of_siblings'') t
              WHERE HrPersonBasicInfo.id = t.Pid FOR XML PATH('''')), 1, 1, '''')          "HrAssociationInfo.family_history_of_siblings",
       STUFF((SELECT distinct '''+','' + HrAssociationInfo.msg  FROM dbo.HrAssociationInfo_third_'+@maxId+' HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid and AssociationType = '''+'history_of_operation''  FOR XML PATH('''')), 1, 1, '''') 
			       "HrAssociationInfo.history_of_operation",
       HrPersonBasicInfo.DateOfBirth      "HrPersonBasicInfo.DateOfBirth",
       HrPersonBasicInfo.IdCard         "HrPersonBasicInfo.IdCard",
       (select top 1 ehrNum  from HrCover_third_'+@maxId+' HrCover  where HrCover.ArchiveNum=HrPersonBasicInfo.ArchiveNum) "HrPersonBasicInfo.ehrNum",
       HrPersonBasicInfo.Name    "HrPersonBasicInfo.Name",
       HrPersonBasicInfo.Name   "tb_empi_index_root",
	    STUFF((SELECT distinct '''+','' + t.msg FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a inner join tb_code b on a.code=b.code where a.AssociationType = '''+'history_of_exposure'' and b.TargetField='''+'history_of_exposure'') t
              WHERE HrPersonBasicInfo.id = t.Pid FOR XML PATH('''')), 1, 1, '''')      "HrAssociationInfo.history_of_exposure",
       STUFF((SELECT distinct '''+','' + HrAssociationInfo.msg
              FROM dbo.HrAssociationInfo_third_'+@maxId+' HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = '''+'history_of_blood''
              FOR XML PATH('''')), 1, 1, '''')          "HrAssociationInfo.history_of_blood.msg",
       HrPersonBasicInfo.WorkUnit       "HrPersonBasicInfo.WorkUnit",
       HrPersonBasicInfo.BloodType      "HrPersonBasicInfo.BloodType",
       HrPersonBasicInfo.RhBloodType     "HrPersonBasicInfo.RhBloodType",
       HrPersonBasicInfo.ContactsName    "HrPersonBasicInfo.ContactsName",
       HrPersonBasicInfo.ResidenceType   "HrPersonBasicInfo.ResidenceType",
			 STUFF((SELECT distinct '''+','' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a inner join tb_code b 
							on a.code=b.code where a.AssociationType = '''+'pay_method'' and b.TargetField='''+'pay_method'') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('''')), 1, 1, '''')   "HrAssociationInfo.pay_method",
				STUFF((SELECT distinct '''+','' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a inner join tb_code b 
							on a.code=b.code where a.AssociationType = '''+'history_of_drug_allergy'' and b.TargetField='''+'history_of_drug_allergy'') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('''')), 1, 1, '''')    "HrAssociationInfo.history_of_drug_allergy",
				STUFF((SELECT distinct '''+','' +  t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a inner join tb_code b 
							on a.code=b.code where a.AssociationType = '''+'history_of_disease'' and b.TargetField='''+'family_history_of_mother'') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('''')), 1, 1, '''')  "HrAssociationInfo.family_history_of_mother",
       HrPersonBasicInfo.NationCode     "HrPersonBasicInfo.NationCode",
       HrPersonBasicInfo.EnvironmentCorral      "HrPersonBasicInfo.EnvironmentCorral",
       HrPersonBasicInfo.Occupation           "HrPersonBasicInfo.Occupation",
				STUFF((SELECT distinct '''+',''  + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a inner join tb_code b 
							on a.code=b.code where a.AssociationType = '''+'disablity_type'' and b.TargetField='''+'disablity_type'') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('''')), 1, 1, '''')    "HrAssociationInfo.disablity_type",
       HrPersonBasicInfo.EnvironmentFuelType   "HrPersonBasicInfo.EnvironmentFuelType",
       STUFF((SELECT distinct '''+','' + HrAssociationInfo.msg
              FROM dbo.HrAssociationInfo_third_'+@maxId+' HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = '''+'heredity_history''
              FOR XML PATH('''')), 1, 1, '''')    "HrAssociationInfo.heredity_history",
       STUFF((SELECT '''+','' + CONVERT(varchar(10), HrAssociationInfo.occurDate, 120)
              FROM dbo.HrAssociationInfo_third_'+@maxId+' HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = '''+'history_of_blood'' 
              FOR XML PATH('''')), 1, 1, '''')      "HrAssociationInfo.history_of_blood.occurDate",
       HrPersonBasicInfo.Sex                "HrPersonBasicInfo.Sex",
       HrPersonBasicInfo.EnvironmentToilet  "HrPersonBasicInfo.EnvironmentToilet",
       HrPersonBasicInfo.MaritalStatus      "HrPersonBasicInfo.MaritalStatus",
				STUFF((SELECT distinct '''+',''+ t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a inner join tb_code b 
							on a.code=b.code where a.AssociationType = '''+'history_of_disease'' and b.TargetField='''+'family_history_of_father'') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('''')), 1, 1, '''')   "HrAssociationInfo.family_history_of_father",
       HrPersonBasicInfo.Degree    "HrPersonBasicInfo.Degree",
       HrPersonBasicInfo.Phone  "HrPersonBasicInfo.Phone",
       STUFF((SELECT '''+','' + CONVERT(varchar(7), HrAssociationInfo.occurDate, 120)
              FROM dbo.HrAssociationInfo_third_'+@maxId+' HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = '''+'history_of_disease''
              FOR XML PATH('''')), 1, 1, '''')          "HrAssociationInfo.history_of_disease.occurDate",
				STUFF((SELECT distinct '''+','' + t.msg
              FROM (select pid,b.value as msg from HrAssociationInfo_third_'+@maxId+' a inner join tb_code b 
							on a.code=b.code where a.AssociationType = '''+'history_of_disease'' and b.TargetField='''+'family_history_of_children'') t
              WHERE HrPersonBasicInfo.id = t.Pid
              FOR XML PATH('''')), 1, 1, '''')    "HrAssociationInfo.family_history_of_children",
       HrPersonBasicInfo.EnvironmentWater      "HrPersonBasicInfo.EnvironmentWater",
       STUFF((SELECT '''+','' + CONVERT(varchar(10), HrAssociationInfo.occurDate, 120)
              FROM dbo.HrAssociationInfo_third_'+@maxId+' HrAssociationInfo
              WHERE HrPersonBasicInfo.id = HrAssociationInfo.Pid
                and AssociationType = '''+'history_of_trauma''
              FOR XML PATH('''')), 1, 1, '''')    "HrAssociationInfo.history_of_trauma.occurDate",
       HrPersonBasicInfo.EnvironmentKitchenAeration "HrPersonBasicInfo.EnvironmentKitchenAeration",
       HrPersonBasicInfo.ArchiveNum    "HrPersonBasicInfo.ArchiveNum"
   from HrPersonBasicInfo_third_'+@maxId+' HrPersonBasicInfo where archiveNum ='''+@archiveNum+''' )a'
   
	--select @SqlStr
 exec  (@SqlStr)
END
go

