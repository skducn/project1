CREATE PROCEDURE [dbo].[getDmInfoByIdCardNo] @idCardNo VARCHAR ( 100 ) AS BEGIN
	DECLARE
		@empiGuid VARCHAR ( 100 ) 
		SET @empiGuid = ( SELECT guid FROM tb_empi_index_root WHERE idCardNo = @idCardNo ) 
		
	IF OBJECT_ID( N'tempdb..#T1', N'U' ) IS NOT NULL BEGIN
			DROP TABLE #T1 
		END 
	create Table #T1(
	    orgCode  varchar(100),
      dtName varchar(50),
      registerName varchar(50),
	    visitNum varchar(100)
		)
	CREATE NONCLUSTERED INDEX NonClu_Index ON #T1 (orgCode,visitNum) 		
		
	insert into #t1 select orgCode,name,name,visitNum from  tb_dc_chronic_main where empiGuid = @empiGuid	and visitTypeCode like '%33%'
		
		
	IF OBJECT_ID( N'tempdb..#T2', N'U' ) IS NOT NULL BEGIN
			DROP TABLE #T2
		END 
	-- 获取随访表信息
	CREATE TABLE #T2 (
            name varchar(255),
            idOfTargetTable varchar(255),
            number varchar(255),
            cardId varchar(255),
            orgCode varchar(255),
            vistStatusCode varchar(255),
            lostVisitCode varchar(255),
            lostVisitMsg varchar(255),
            deathReason varchar(255),
            visitDate datetime,
            hasPaperCard varchar(255),
            clinicalSymptomsList varchar(255),
            clinicalSymptomsOther varchar(255),
            dorsalArteryOfFootLeftCode varchar(255),
            symptomStatus varchar(255),
            hypoglycemia varchar(255),
            familyHistory varchar(255),
            isLawSport varchar(255),
            sportTypeCode varchar(255),
            fastingBloodSugarGatherCode varchar(255),
            bloodPressureHigh varchar(255),
            bloodPressureLow varchar(255),
            height varchar(255),
            weight varchar(255),
            targetWeight varchar(255),
            bmi varchar(255),
            targetBmi varchar(255),
            smokingState varchar(255),
            smokingStatusName varchar(255),
            smokingVolume varchar(255),
            targetSmoke varchar(255),
            dringFrequency varchar(255),
            drinkingFrequencyName varchar(255),
            drinkingVolume varchar(255),
            targetDrink varchar(255),
            exeWeek varchar(255),
            targetExeWeek varchar(255),
            sportTimes varchar(255),
            targetSportTimes varchar(255),
            dietCode varchar(255),
            stapleFood varchar(255),
            targetStapleFood varchar(255),
            psychologyStatusCode varchar(255),
            complianceStatusCode varchar(255),
            fastingBloodSugarCode varchar(255),
            randomBloodSugarCode varchar(255),
            fastingBloodSugarOGTTCode varchar(255),
            twoHBloodSugarOGTTCode varchar(255),
            ghGaterWayCode varchar(255),
            cholesterol varchar(255),
            highCholesterol varchar(255),
            lowCholesterol varchar(255),
            triglycerides varchar(255),
            drugCompliance varchar(255),
            hasUseDrugSideEffects varchar(255),
            useDragSpecific varchar(255),
            visitType varchar(255),
            isAcceptHealthEdu varchar(255),
            healthEduType varchar(255),
            referralReason varchar(255),
            referralOrgDept varchar(255),
            nextVisiDate datetime,
            visitDocName varchar(255),
            visitOrgCode varchar(255),
            visitWay varchar(255),
            otherVisitWay varchar(255),
            targetArea varchar(255),
            targetOrg varchar(255),
            fastingBloodSugarValue varchar(255),
            randomBloodSugarValue varchar(255),
            fastingBloodSugarOGTTValue varchar(255),
            twoHBloodSugarOGTTValue varchar(255),
            visitAdvice varchar(255),
            urineAlbuminCreatinineRatio varchar(255),
            urineProtein24H varchar(255),
            useDrug varchar(255),
            waistline varchar(255),
            otherLostVisitName varchar(255)
		) 
		
		
	CREATE NONCLUSTERED INDEX NonClu_Index ON #T2( cardId, orgCode ) 
		
  insert into #T2 SELECT
         -- 姓名
            dm.name AS name,
            -- 当前记录唯一标识
            dm.guid AS idOfTargetTable,
            -- 编号
            dm.ehrNum AS number,
            -- 随访编号
            dm.cardId AS cardId,
            -- 管理机构
            dm.orgCode AS orgCode,
            -- 本次随访管理状态
            dm.vistStatusCode AS vistStatusCode,
            -- 失访理由
            dm.lostVisitCode AS lostVisitCode,
            -- 失访理由其他
            dm.lostVisitName AS lostVisitMsg,
            -- 死亡原因
            dm.deathReason AS deathReason,
            -- 随访日期
            dm.visitDate AS visitDate,
            -- 是否有纸质卡
            dm.hasPaperCard AS hasPaperCard,
            -- 糖尿病临床症状
            dm.clinicalSymptomsCode AS clinicalSymptomsList,
            -- 糖尿病临床症状其他内容
            dm.otherClinicalSymptoms AS clinicalSymptomsOther,
            -- 足背动脉搏动
            dm.dorsalArteryOfFootLeftCode AS dorsalArteryOfFootLeftCode,
            -- 糖尿病新诊断并发症
            dm.symptomStatus AS symptomStatus,
            -- 低糖反应
            dm.hypoglycemia AS hypoglycemia,
            -- 糖尿病家族史
            dm.familyHistory AS familyHistory,
            -- 规律活动
            dm.isLawSport AS isLawSport,
            -- 活动种类
            dm.sportTypeCode AS sportTypeCode,
            -- 血压数据采集方式
            dm.fastingBloodSugarGatherCode AS fastingBloodSugarGatherCode,
            -- 血压（收缩压）
            dm.sbp AS bloodPressureHigh,
            -- 血压（舒张压）
            dm.dbp AS bloodPressureLow,
            -- 身高
            dm.height AS height,
            -- 体重
            dm.weight AS weight,
            -- 目标体重
            dm.targetWeight AS targetWeight,
            -- 体质指数
            dm.bmi AS bmi,
            -- 目标体质指
            dm.targetBmi AS targetBmi,
            -- 吸烟状况
            dm.smokingStatusCode AS smokingState,
            -- 吸烟状况名称
            dm.smokingStatusName AS smokingStatusName,
            -- 日吸烟量
            dm.smokingVolume AS smokingVolume,
            -- 目标吸烟量
            dm.targetSmoke AS targetSmoke,
            -- 饮酒频率
            dm.drinkingFrequencyCode AS dringFrequency,
            -- 饮酒频率名称
            dm.drinkingFrequencyName AS drinkingFrequencyName,
            -- 日饮酒量
            dm.drinkingVolume AS drinkingVolume,
            -- 目标日饮酒量
            dm.targetDrink AS targetDrink,
            -- 每周运动次数
            dm.sportFrequence AS exeWeek,
            -- 目标每周运动次数
            dm.targetSportFrequencyCode AS targetExeWeek,
            -- 每次运动时间（分钟）
            dm.sportTimes AS sportTimes,
            -- 目标每次运动时间
            dm.targetSportTimes AS targetSportTimes,
            -- 饮食情况
            dm.dietCode AS dietCode,
            -- 主食
            dm.stapleFood AS stapleFood,
            -- 目标主食
            dm.targetStapleFood AS targetStapleFood,
            -- 心理调整
            dm.psychologyStatusCode AS psychologyStatusCode,
            -- 遵医行为
            dm.complianceStatusCode AS complianceStatusCode,
            -- 空腹血糖
            dm.fastingBloodSugarCode AS fastingBloodSugarCode,
            -- 随机血糖
            dm.randomBloodSugarCode AS randomBloodSugarCode,
            -- 空腹血糖（OGTT）
            dm.fastingBloodSugarOGTTCode AS fastingBloodSugarOGTTCode,
            -- 餐后两小时血糖（OGTT）
            dm.twoHBloodSugarOGTTCode AS twoHBloodSugarOGTTCode,
            -- 糖化血红蛋白（%）
            dm.hbAlc AS ghGaterWayCode,
            -- 其他辅助检查—总胆固醇（mmol/L）
            dm.cholesterol AS cholesterol,
            -- 其他辅助检查—血清高密度脂蛋白胆固醇
            dm.highCholesterol AS highCholesterol,
            -- 其他辅助检查—血清低密度脂蛋白胆固醇
            dm.lowCholesterol AS lowCholesterol,
            -- 其他辅助检查—甘油三酯
            dm.triglycerides AS triglycerides,
            -- 服药依从性
            dm.drugComplianceCode AS drugCompliance,
            -- 药物不良反应
            dm.hasUseDrugSideEffects AS hasUseDrugSideEffects,
            -- 具体药物不良反应
            dm.UseDrugSideEffects AS useDragSpecific,
            -- 此次随访分类
            dm.visitType AS visitType,
            -- 是否接受过健康教育
            dm.isAcceptHealthEdu AS isAcceptHealthEdu,
            -- 接受过何种形式的健康教育
            dm.healthEduType AS healthEduType,
            -- 转诊原因
            dm.referralReason AS referralReason,
            -- 转诊机构及科别
            dm.referralOrgDept AS referralOrgDept,
            -- 下次随访日期
            dm.nextVisiDate AS nextVisiDate,
            -- 随访医生签名
            dm.visitDocName AS visitDocName,
            -- 随访机构
            dm.visitOrgCode AS visitOrgCode,
            -- 随访方式
            dm.visitWayCode as visitWay,
            -- 其他随访方式
            dm.otherVisit as otherVisitWay,
            -- 目标区县
            dm.targetDistrictCode as targetArea,
            -- 目标机构
            dm.targetOrgCode as targetOrg,
            -- 空腹血糖值
            dm.fastingBloodSugarValue as fastingBloodSugarValue,
            -- 随机血糖值
            dm.randomBloodSugarValue as randomBloodSugarValue,
            -- 空腹血糖OGTT
            dm.fastingBloodSugarOGTTValue as fastingBloodSugarOGTTValue,
            -- 餐后2小时血糖
            dm.twoHBloodSugarOGTTValue as twoHBloodSugarOGTTValue,
            -- 随访建议
            dm.proposal as visitAdvice,
            -- 其他辅助检查—尿微量白蛋白肌酐比值
            dm.acr AS urineAlbuminCreatinineRatio,
            -- 其他辅助检查—24小时尿蛋白定量
            dm.urineProtein AS urineProtein24H,
            -- 服药情况
            dm.useDrug as useDrug,
            -- 腰围
            dm.waistline as waistline,
            -- 其他失访理由
            dm.otherLostVisitName as otherLostVisitName
        FROM tb_dc_dm_visit AS dm	  where empiGuid = @empiGuid
				
		select @idCardNo AS idCard , t2.*,t1.dtName,t1.registerName,
	  IIF((select count(1) from tb_dc_dm_usedrug where visitId = t1.visitNum  and orgcode = t1.orgCode ) >0,1,0)drugIsTrue
		from  #T2 t2 
		inner join  #T1 t1 
		on t2.cardId = t1.visitNum 
		and t2.orgCode = t1.orgCode 
		order by visitDate desc
		
		
	END
go

