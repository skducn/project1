CREATE VIEW [dbo].[HrCoverViewInfo] AS select 
HrCover.ArchiverId				"HrCover.ArchiverId",
HrCover.ArchiveUnitCode				"HrCover.ArchiveUnitCode",
convert(varchar(10),HrCover.DateOfCreateArchive,120)				"HrCover.DateOfCreateArchive",
HrCover.ehrNum				"HrCover.ehrNum",
HrCover.Name				"HrCover.Name",
HrCover.Neighborhood				"HrCover.Neighborhood",
HrCover.PermanentAddress				"HrCover.PermanentAddress",
HrCover.Phone				"HrCover.Phone",
HrCover.PresentAddress				"HrCover.PresentAddress",
HrCover.ResponsibleDoctor				"HrCover.ResponsibleDoctor",
HrCover.VillageName				"HrCover.VillageName",
Hrcover.ArchiveNum "Hrcover.ArchiveNum",
HrCover.ResponsibleDoctorId				"HrCover.ResponsibleDoctorId",
HrCover.VillageCode				"HrCover.VillageCode",
HrCover.ProvinceCode      "HrCover.ProvinceCode",
HrCover.NeighborhoodCode   "HrCover.NeighborhoodCode"
from dbo.Hrcover
go

