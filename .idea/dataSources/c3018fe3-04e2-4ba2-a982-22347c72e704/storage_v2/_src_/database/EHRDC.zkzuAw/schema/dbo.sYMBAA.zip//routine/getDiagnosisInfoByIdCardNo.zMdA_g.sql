CREATE PROCEDURE [dbo].[getDiagnosisInfoByIdCardNo] @idCardNo VARCHAR ( 100 ) AS BEGIN-- 创建临时表 获取所有的流水号和机构编码
IF OBJECT_ID( N'tempdb..#T', N'U' ) IS NOT NULL
    begin
        DROP TABLE #T
    end
CREATE TABLE #T (
                    orgCode VARCHAR ( 100 ),
                    visitStrNo VARCHAR ( 100 ),
                    visitDate DATE
)
-- 添加非聚集索引
CREATE NONCLUSTERED INDEX NonClu_Index ON #T ( orgCode, visitStrNo )
-- 创建临时变量 身份证的guid
DECLARE	@empiguid VARCHAR ( 100 )
-- 给临时变量赋值
SET @empiguid = ( SELECT guid FROM tb_empi_index_root WHERE idCardNo = @idCardNo ) -- 将数据存储到临时表内
-- 给临时表赋值 获取所有的流水编号和机构Id
INSERT INTO #T SELECT * FROM
    (SELECT orgCode,ipVisitStrNo,dischargeDate FROM tb_his_ip_medical_record WHERE	empiGuid =@empiguid
     UNION
     SELECT orgCode,opVisitStrNo,visitTime FROM tb_his_op_medical_record  WHERE empiGuid =@empiguid ) a

-- 获取最终输出结果
SELECT
    diagnOsisCode AS diagnosisCode,
    diagnOsisName AS diagnosisName,
    diagnosisDate,
    HospitalLevel,
    hospital_name AS orgName,
    -- 三级医院住院
    CASE WHEN HospitalLevel = 3 	AND visitType = 2 THEN 6
        -- 二级医院住院
         WHEN HospitalLevel = 2   AND visitType = 2 THEN 5
        -- 三级医院门诊
         WHEN HospitalLevel = 3   AND visitType = 1 THEN 4
        -- 二级医院门诊
         WHEN HospitalLevel = 2 	AND visitType = 1 THEN 3
        -- 一级医院住院
         WHEN HospitalLevel = 1   AND visitType = 2 THEN 2
        -- 一级医院门诊
         WHEN HospitalLevel = 1   AND visitType = 1 THEN 1
        END type,
    CASE WHEN diagnosisStatus = 1 THEN '出院小结'
         WHEN visitType = 2 AND ( diagnosisStatus != 1 OR diagnosisStatus IS NULL ) THEN '住院就诊记录'
         WHEN visitType = 1 THEN '门诊就诊记录'
         ELSE '' END tableInfo,
    t.visitDate
FROM
    tb_his_diagnosis d
        INNER JOIN t_dic_hospital_info i ON d.orgCode = i.Hospital_id
        INNER JOIN #T t ON t.orgcode = d.orgCode
        AND t.VisitStrNo = d.visitStrNo
ORDER BY
    type DESC,
    diagnosisDate DESC

END
go

