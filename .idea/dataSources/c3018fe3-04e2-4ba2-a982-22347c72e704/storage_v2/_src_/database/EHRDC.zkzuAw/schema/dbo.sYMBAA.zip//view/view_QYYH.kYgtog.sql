CREATE VIEW [dbo].[view_QYYH] AS select * from QYYH where ArchiveUnitCode='42483515900'
go

