create FUNCTION [dbo].[SplitStr2]
(
@strInfo NVARCHAR(MAX), --被分割的字符串，如“a,b,c”
@sign NVARCHAR(10), --指定的分割字符，如“,”
 @code_field_name varchar(40) 
)
RETURNS @array TABLE(Item NVARCHAR(MAX))
AS
BEGIN

DECLARE @index INT, @item NVARCHAR(MAX),@valuses VARCHAR(20) 
if(@strInfo is null or  @strInfo='')
BEGIN
RETURN 
END
else 
BEGIN
SET @index=CHARINDEX(@sign, @strInfo)
WHILE(@index<>0)
BEGIN
SET @item = SUBSTRING(@strInfo,1,@index-1)
SET @valuses=(SELECT max([VALUE])  from TB_CODE where targetTable = @code_field_name AND code =@item  )
INSERT INTO @array(Item) VALUES(@valuses)
SET @strInfo = SUBSTRING(@strInfo, @index+1,LEN(@strInfo)-@index)
SET @index=CHARINDEX(@sign, @strInfo)
END
SET @item = @strInfo
SET @valuses=(SELECT max([VALUE])  from TB_CODE where targetTable = @code_field_name AND code =@item   )
IF (LEN(@item)>0)
INSERT INTO @array(Item) VALUES(@valuses)
END
RETURN 
END
go

