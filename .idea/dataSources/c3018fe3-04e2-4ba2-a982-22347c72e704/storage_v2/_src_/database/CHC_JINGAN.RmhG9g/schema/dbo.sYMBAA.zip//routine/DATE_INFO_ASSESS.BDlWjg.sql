CREATE PROCEDURE [dbo].[DATE_INFO_ASSESS] (@IDCARD NVARCHAR(18),@ID int)
as 
BEGIN

--检测@IDCARD是否有sql注入
declare @inputcheck Nvarchar(20)=''
declare @guid Nvarchar(80)=''
declare @LastUpdateDate datetime=''
declare @DISEASE nvarchar(max)=''

SET @guid=  (SELECT  guid FROM  TB_EMPI_INDEX_ROOT WHERE IDCARDNO=@IDCARD )
set @inputcheck=@IDCARD
  
 if @inputcheck like '%select %' 
 or @inputcheck like '%update %'
 or @inputcheck like '%insert %'
 or @inputcheck like '%delete %'
 or @inputcheck like '%truncate %'
 or @inputcheck like '%drop %'
 or @inputcheck like '%union %'
 or @inputcheck like '%exec  %'
 or @inputcheck like '%xp_ %'
        begin
		  raiserror('输入变量值中包含sql注入！',16,1)
		  return
		end

create table #diagn (
  DIAGNOSISCODE varchar(200) PRIMARY KEY
)

insert into #diagn(DIAGNOSISCODE) select  ISNULL(DIAGNOSISCODE, '') from (
select  d.DIAGNOSISCODE   from  TB_HIS_OP_MEDICAL_RECORD op
inner join TB_HIS_DIAGNOSIS d on d.VISITSTRNO = op.OPVISITSTRNO and d.ORGCODE = op.ORGCODE
inner join TB_EMPI_INDEX_ROOT r  on op.EMPIGUID = r.GUID
where IDCARDNO = @IDCARD   and DIAGNOSISTYPE =1 and DIAGNOSISDATE BETWEEN DATEADD(YEAR,-1, GETDATE()) and GETDATE()
union 
select d.DIAGNOSISCODE from  TB_HIS_IP_MEDICAL_RECORD  ip
inner join TB_HIS_DIAGNOSIS d on d.VISITSTRNO = ip.IPVISITSTRNO and d.ORGCODE = ip.ORGCODE
inner join TB_EMPI_INDEX_ROOT r  on ip.EMPIGUID = r.GUID
where IDCARDNO = @IDCARD   and DIAGNOSISTYPE =1  and DIAGNOSISDATE BETWEEN DATEADD(YEAR,-1, GETDATE()) and GETDATE() 
)  a ;

set @DISEASE =(select STUFF((select  ','+msg  from (
select msg from  HrAssociationInfo  a inner join HrPersonBasicInfo b on a.PID = b.id where  AssociationType = 'history_of_disease' and ARCHIVENUM = @IDCARD
union 
select '高血压' from  #diagn where DIAGNOSISCODE like 'I10%' 
union 
select '糖尿病' from #diagn where DIAGNOSISCODE like 'E11%'  
union 
select '慢性肾脏病' from #diagn where DIAGNOSISCODE like 'N03%'  
union 
select '慢性阻塞性肺疾病' from #diagn where DIAGNOSISCODE like 'J44.9%'  
union
select '肺癌' from #diagn where DIAGNOSISCODE like 'C34%'  
union
select '脑卒中' from #diagn where (DIAGNOSISCODE like 'I60%' or DIAGNOSISCODE like 'I61%' or DIAGNOSISCODE like 'I62%' or DIAGNOSISCODE like 'I63%' or DIAGNOSISCODE like 'I64%' ) 
union
select '结直肠癌' from #diagn where (DIAGNOSISCODE like 'C18%' or DIAGNOSISCODE like 'C19%' or DIAGNOSISCODE like 'C20%' or DIAGNOSISCODE like 'C21%' )  
union
select '乳腺癌' from #diagn where DIAGNOSISCODE like 'C50%'  
union
select '肝癌' from #diagn where DIAGNOSISCODE like 'C22%'  
union
select '胃癌' from #diagn where DIAGNOSISCODE like 'C16%'  
union
select '宫颈癌' from #diagn where DIAGNOSISCODE like 'C53%'  
union
select '冠心病' from #diagn where DIAGNOSISCODE like 'I25.1%'  
union
select '结核病' from #diagn where (DIAGNOSISCODE like 'A15%' or DIAGNOSISCODE like 'A16%' ) 
union
select '肝炎' from #diagn where DIAGNOSISCODE like 'B18%'  
) a  FOR XML PATH ( '' ) ), 1, 1, ',' ))

  
	set @LastUpdateDate=(SELECT
	s1.LastUpdateDate
FROM
	(
	SELECT
		t1.IDCARDNO,
		
		(SELECT MAX(UpdateDate) AS LastUpdateDate FROM ( SELECT t2.examinationDate AS UpdateDate UNION

SELECT  t8.visitdate  UNION

SELECT t9.visitdate 

) ud
) LastUpdateDate
FROM

	(SELECT *  from	TB_EMPI_INDEX_ROOT WHERE IDCARDNO=@IDCARD ) t1
		LEFT JOIN (
	 SELECT TOP 1 * FROM tb_dc_examination_info 
		WHERE EMPIGUID =@guid
			ORDER BY EXAMINATIONDATE DESC
		) t2 ON t1.guid= t2.empiGuid
		LEFT JOIN (
		 SELECT top 1 * FROM TB_DC_HTN_VISIT
		WHERE EMPIGUID =@guid
			ORDER BY VISITDATE DESC
		) t8 ON t8.EMPIGUID= t1.guid
		LEFT JOIN (
	 SELECT top 1 * FROM TB_DC_DM_VISIT
		WHERE EMPIGUID =@guid
			ORDER BY VISITDATE DESC
		) t9 ON t9.EMPIGUID= t1.guid 
	WHERE
	t1.IDCARDNO=@IDCARD  
	) s1)
;

WITH m1 as 
(

SELECT 

  ISNULL(t14.ARCHIVEUNITCODE, '') as orgcode ,
 ISNULL( t3.Name, '' ) AS NAME,
CASE
		t3.Sex 
		WHEN '2' THEN
		'女' 
		WHEN '1' THEN
		'男' ELSE '未知' 
	END AS Sex,
	isnull(CONVERT ( VARCHAR ( 10 ), t3.DateOfBirth, 111 ), '' ) AS BIRTH,
	isnull(@IDCARD, '' )  AS ID_CARD,
	isnull( t2.Province, '' ) AS PROVINCE,
	isnull( t2.City, '' ) AS CITY,
	isnull( t2.District, '' ) AS DISTRICT,
	isnull( t2.Neighborhood, '' ) AS TOWN,
	isnull( t2.VillageName, '' ) AS VILLAGE,
	isnull( t2.PresentAddress, '' ) AS ADDRESS,
	isnull( t2.PermanentAddress, '' ) AS PERMANENT_ADDRESS,
	case when 
t3.Telephone is not null 
then t3.Telephone 
when t3.phone  is not null 
then t3.PHONE 
else '' end AS PHONE,
	
	
-- 				isnull(
-- 	CASE
-- 			WHEN t6.examinationDate=@LastUpdateDate
-- 				then t6.height 
-- 				WHEN t8.visitDate=@LastUpdateDate 
-- 				then 	t8.height 
-- 					WHEN t9.visitDate=@LastUpdateDate
-- 			  then 			t9.height ELSE '' 
-- 					END
-- 				,'')  AS HEIGHT,
-- 							isnull(
-- 	CASE
-- 			WHEN t6.examinationDate=@LastUpdateDate
-- 				then t6.weight 
-- 				WHEN t8.visitDate=@LastUpdateDate 
-- 				then 	t8.weight 
-- 					WHEN t9.visitDate=@LastUpdateDate
-- 			  then 			t9.weight ELSE '' 
-- 					END
-- 				,'')  AS WEIGHT,
										isnull(
	CASE
			WHEN t6.examinationDate=@LastUpdateDate
				then t6.bmi
				WHEN t8.visitDate=@LastUpdateDate 
				then 	t8.bmi 
					WHEN t9.visitDate=@LastUpdateDate
			  then 			t9.bmi ELSE '' 
					END
				,'') AS BMI,
--										isnull(
-- 	CASE
-- 			WHEN t6.examinationDate=@LastUpdateDate
-- 				then t6.WAISTLINE
-- 				WHEN t8.visitDate=@LastUpdateDate 
-- 				then 	t8.WAISTLINE
-- 					WHEN t9.visitDate=@LastUpdateDate
-- 			  then 			t9.WAISTLINE ELSE '' 
-- 					END
-- 				,'')  AS WAISTLINE,
-- 							isnull(						CASE
-- 			WHEN t6.examinationDate=@LastUpdateDate
-- 				then t6.hips
-- 				WHEN t8.visitDate=@LastUpdateDate 
-- 				then t9.HIPLINE
-- 					WHEN t9.visitDate=@LastUpdateDate
-- 			  then 		t9.HIPLINE ELSE '' 
-- 					END
-- 				,'') AS HIPLINE,
																isnull(
																CASE
																		
																		WHEN t6.examinationDate=@LastUpdateDate
																		
																	 THEN
																			t6.LEFTDBP
																			WHEN t8.visitDate=@LastUpdateDate
																		
																			
																 THEN
																				t8.dbp 
																				WHEN t9.visitDate=@LastUpdateDate
																			
																				 THEN
																					t9.dbp ELSE '' 
																				END,
																				'' 
																			) AS DBP,
																			isnull(
																			CASE
																					
																					WHEN t6.examinationDate=@LastUpdateDate
																					 
																				THEN
																						NULLIF ( t6.leftSBP, t6.rightSBP ) 
																						WHEN t8.visitDate=@LastUpdateDate
																					
																						 THEN
																							t8.sbp 
																						
																							WHEN t9.visitDate=@LastUpdateDate
																							
																						 THEN
																								t9.sbp ELSE '' 
																							END,
																							'' 
																						) AS SBP,
																						case when 
t3.Telephone is not null 
then t3.Telephone  
when t3.phone  is not null 
then t3.PHONE 
else '' end AS MOBILE_PHONE,
																					CASE 
		WHEN ( SELECT top 1 id FROM HRASSOCIATIONINFO WHERE AssociationType = 'history_of_disease' AND Code = '02' AND pid = t3.id ) IS NOT NULL 
		OR (
		SELECT
		  top 1
			x1.EMPIGUID
		FROM
			TB_DC_CHRONIC_INFO x1
			INNER JOIN TB_DC_CHRONIC_MAIN  x2 ON x2.MANAGENUM= x1.MANAGENUM 
			AND x1.orgcode= x2.orgcode 
		WHERE
			x2.visitTypeCode  like  '%31%' 
			AND x1.EMPIGUID= t1.guid
		GROUP BY 	x1.EMPIGUID
			) IS NOT NULL THEN
		'有' ELSE '无' 
END as   IS_HYPERTENSION,
																						CASE
																								
																								WHEN ( SELECT top 1 id FROM HRASSOCIATIONINFO WHERE AssociationType = 'history_of_disease' AND Code = '03' AND pid = t3.id ) IS NOT NULL 
																								OR (
		SELECT 
		top 1
			x1.EMPIGUID
		FROM
			TB_DC_CHRONIC_INFO x1
			INNER JOIN TB_DC_CHRONIC_MAIN  x2 ON x2.MANAGENUM= x1.MANAGENUM 
			AND x1.orgcode= x2.orgcode 
		WHERE
			x2.visitTypeCode  like  '%33%' 
			AND x1.EMPIGUID= t1.guid 
			GROUP BY 	x1.EMPIGUID
			) IS NOT NULL THEN
		'有' ELSE '无' 
END AS IS_DIABETES,
																								'' AS HYPERURICEMIA,
																								'' AS NEPHROPATHY_FAMILY_HISTORY,
																								'' AS CHRONIC_NEPHRITIS_HISTORY,
																							CASE
																									
																									WHEN DATEDIFF( YEAR, t3.DateOfBirth, GETDATE( ) ) > 65 THEN
																									'有' ELSE '无' 
																								END AS 'IS_OVER_65',
																								'' AS 'URINE_ERYTHROCYTE',
																								'' AS EGFR,
																								isnull(
																									(
																									SELECT
																									top 1
																										q1.resultValue 
																									FROM
																										(
																										SELECT
																											s1.EMPIGUID,
																											s1.resultValue 
																										FROM
																											(
																											SELECT
																												t1.EMPIGUID,
																												t2.resultValue,
																												ROW_NUMBER ( ) OVER ( partition BY t1.EMPIGUID ORDER BY t1.REPORTDATE DESC ) AS b1 
																											FROM
																												TB_LIS_REPORT t1
																												INNER JOIN TB_LIS_REPORT_INDICATOR t2 ON t1.REPORTNO= t2.REPORTNO 
																											WHERE
																												t2.itemName= '尿蛋白' 
																											) s1 
																										WHERE
																											s1.b1= 1 
																										) q1 
																									WHERE
																										q1.EMPIGUID= t1.guid 
																									),
																									'' 
																								) AS UROPROTEIN,
																								isnull(
																									(
																									SELECT
																									top 1
																										q1.resultValue 
																									FROM
																										(
																										SELECT
																											s1.EMPIGUID,
																											s1.resultValue 
																										FROM
																											(
																											SELECT
																												t1.EMPIGUID,
																												t2.resultValue,
																												ROW_NUMBER ( ) OVER ( partition BY t1.EMPIGUID ORDER BY t1.REPORTDATE DESC ) AS b1 
																											FROM
																												TB_LIS_REPORT t1
																												INNER JOIN TB_LIS_REPORT_INDICATOR t2 ON t1.REPORTNO= t2.REPORTNO 
																											WHERE
																												t2.itemName= '尿白蛋白/肌酐' 
																											) s1 
																										WHERE
																											s1.b1= 1 
																										) q1 
																									WHERE
																										q1.EMPIGUID= t1.guid 
																									),
																									'' 
																								)AS CREATININE,
																								'' AS GLOMERULAR_FILTRATION_RATE,
																								isnull(
																								CASE
			WHEN t6.examinationDate=@LastUpdateDate
				then t6.examinationDate
				WHEN t8.visitDate=@LastUpdateDate 
				then 	t8.visitDate
					WHEN t9.visitDate=@LastUpdateDate
			  then 			t9.visitDate ELSE '' 
					END
				,'')AS 'INPUT_DATE',
																											isnull( (SELECT  max(visitTypeValue) from TB_DC_CHRONIC_MAIN WHERE MANAGENUM=t5.MANAGENUM AND orgcode=t5.orgcode)  , '' ) AS MANAGE_TYPE,
																											ISNULL( t6.eatingHabitsName, '' ) AS EATING_HABIT,
																											'' AS PSYCHOTROPIC_DRUG,
																											isnull(
																											CASE
																													
																													WHEN t6.examinationDate=@LastUpdateDate
																												 THEN
																														t6.exerciseFrequencyName 
																														WHEN t8.visitDate=@LastUpdateDate
																														 THEN
																															t8.sportFrequence 
																															WHEN t9.visitDate= @LastUpdateDate
																															THEN
																																t9.sportFrequence ELSE '' 
																															END,
																															'' 
																														) AS SEDENTARY_LIFESTYLE,
																													
																													
																													
																													

			
			
ISNULL(				
(SELECT 
case 
WHEN sum(s1.num)>0 
THEN '是'
when sum(s1.num)=0
THEN '否'
ELSE '  '
end 
FROM 
(SELECT
 t100.EMPIGUID,
CASE  
	WHEN t200.RESULTFLAGCODE IS NOT NULL AND t200.RESULTFLAGCODE!= '1' THEN 1
  WHEN t200.RESULTFLAGCODE = '1'  THEN 0
	ELSE -1000
END  as   num 

			FROM
				TB_EMPI_INDEX_ROOT
				INNER JOIN TB_LIS_REPORT t100 ON TB_EMPI_INDEX_ROOT.GUID= t100.EMPIGUID
				INNER JOIN TB_LIS_REPORT_INDICATOR  t200 ON t100.REPORTNO= t200.REPORTNO 
			WHERE
				t100.EMPIGUID= TB_EMPI_INDEX_ROOT.GUID 
				AND t100.REPORTDATE>= DATEADD( YEAR, - 1, GETDATE( ) ) 
				AND t100.REPORTDATE<= GETDATE( ) 
				AND (t200.ITEMNAME= '甘油三酯'
				OR t200.ITEMNAME= '高密度脂蛋白胆固醇'
			 OR t200.ITEMNAME= '低密度脂蛋白胆固醇')) s1
			  WHERE s1.EMPIGUID=t1.guid 
			 GROUP BY s1.EMPIGUID ),'')
		 AS BLOOD_FAT_ABNORMAL,
																															'' AS GIANT_CHILD_PRODUCTION,
																															'' AS ASCVD,
																															'' AS TRANSIENT_STEROID_DIABETES,
																															'' AS PCOS,
																																	isnull(
																																(
																																SELECT
																																STUFF( ',' + b1.Msg, 1, 1, ',' ) 
																																FROM
																																(
																																SELECT  DISTINCT pid, Msg
																																from 
																												
																																	HrAssociationInfo 
																																WHERE
																																	Pid = t3.id 
																																	AND AssociationType = 'family_history_of_children' 
																																	OR AssociationType = 'family_history_of_daughter' 
																																	OR AssociationType = 'family_history_of_father' 
																																	OR AssociationType = 'family_history_of_mother' 
																																	OR AssociationType = 'family_history_of_grandpas' 
																																	OR AssociationType = 'family_history_of_siblings' 
																																GROUP BY
																																	Pid,
																																	Msg)
																															
																												
																																b1   
																														WHERE b1.Pid=t3.id	
																														GROUP BY  
																														Pid,
																																	Msg
																															FOR XML PATH ( '' ) 
																																),
																																'' 
																															)AS FAMILY_HISTORY,
																													isnull(case 
																														t3.BLOODTYPE
																															when '1' then 'O型'
																															when '2' then 'A型'
																															when '3' then 'B型'
																															when '4' then 'AB型'
																															when '5' then '不详'
																															ELSE '' END  
																															
																															
																													, '' ) AS BLOOD_TYPE,
																															'' AS DISABILITY,
																															isnull(
																																STUFF((
																																SELECT
																																 ',' + Msg
																																FROM
																																	HrAssociationInfo 
																																WHERE
																																	Pid = t3.id 
																																	AND AssociationType = 'history_of_disease' 
																																GROUP BY
																																	Pid,
																																	Msg FOR XML PATH ( '' ) 
																																), 1, 1, ''),
																																'' 
																															) AS DISEASE_HISTORY,
																															isnull(
																																(
																																SELECT
																																	STUFF( ' ' + Msg, 1, 1, '' ) 
																																FROM
																																	HrAssociationInfo 
																																WHERE
																																	Pid = t3.id 
																																	AND AssociationType = 'history_of_operation' 
																																GROUP BY
																																	Pid,
																																	Msg FOR XML PATH ( '' ) 
																																),
																																'' 
																															) AS OPERATION_HISTORY,
																															isnull(
																																(
																																SELECT
																																	STUFF( ',' + Msg, 1, 1, '' ) 
																																FROM
																																	HrAssociationInfo 
																																WHERE
																																	Pid = t3.id 
																																	AND AssociationType = 'history_of_trauma' 
																																GROUP BY
																																	Pid,
																																	Msg FOR XML PATH ( '' ) 
																																),
																																'' 
																															) AS TRAUMA_HISTORY,
																															isnull(
																																(
																																SELECT
																																	STUFF( ' ' + Msg, 1, 1, '' ) 
																																FROM
																																	HrAssociationInfo 
																																WHERE
																																	Pid = t3.id 
																																	AND AssociationType = 'history_of_blood' 
																																GROUP BY
																																	Pid,
																																	Msg FOR XML PATH ( '' ) 
																																),
																																'' 
																															) AS TRANSFUSION_HISTORY,
																														
																															isnull(
																																(
																																SELECT
																																	STUFF( ' ' +b1.Msg, 1, 1, '' ) 
																																	from 
																																	(
																																	SELECT 
																																	Pid,
																																	CASE  AssociationType
	WHEN 'family_history_of_children'THEN '儿子'
	WHEN 'family_history_of_daughter'THEN '女儿'
	WHEN 'family_history_of_father'THEN '父亲'
	WHEN 'family_history_of_mother'THEN '母亲'
	WHEN 'family_history_of_grandpas'THEN '祖父'
	WHEN 'family_history_of_siblings' THEN '兄弟' 
	ELSE '' END as  Msg
																															
																																FROM
																																	HrAssociationInfo 
																																WHERE
																																	Pid = t3.id 
																																	AND 
																																AssociationType like '%family_history_of%'	
																																	) b1 
																														
																																GROUP BY
																																	b1.Pid,
																																	b1.Msg FOR XML PATH ( '' ) 
																																),
																																'' 
																															)	 AS FAMILY_RELATION,
																															'' AS H_TYPE_HYPERTENSION,
																															'' AS ATRIAL_FIBRILLATION,
																															'' AS CORONARY_HEART,
																															'' AS PERIPHERAL_VASCULAR,
																															'' AS CARDIOVASCULAR_CEREBROVASCULAR,
																															'' AS CEREBRAL_INFARCTION_TYPE,
																															'' AS OTHER_CEREBRAL_INFARCTION_TYPE,
																															isnull( t6.examinationDate, '' ) AS DIAGNOSIS_DATE,
																															isnull( t6.ehrNum , '' ) AS ID_NUM,
																															'' AS DECISION_RESULT,
																															isnull( t3.MaritalStatus, '' ) AS MARITAL,
																															isnull( t3.Degree, '' ) AS EDUCATION,
																															isnull( t3.Occupation , '' ) AS OCCUPATION,
																															'' AS MEDICAL_INSURANCE_MODE,
																															'' AS OTHER_MEDICAL_INSURANCE_MODE,
																															'' AS CHRONIC_DIARRHEA,
																															'' AS CHRONIC_DIARRHEA_MONTH,
																															'' AS CHRONIC_DIARRHEA_DAY,
																															'' AS CHRONIC_CONSTIPATION,
																															'' AS CHRONIC_CONSTIPATION_MONTH,
																															'' AS CHRONIC_CONSTIPATION_DAY,
																															'' AS BLOODY_STOOL,
																															'' AS BLOODY_STOOL_YEAR,
																															'' AS APPENDIX,
																															'' AS APPENDIX_YEAR,
																															'' AS GALLBLADDER,
																															'' AS GALLBLADDER_YEAR,
																															'' AS GALLBLADDER_HOSPITAL,
																															'' AS MENTAL_TRAUMA,
																															'' AS CANCER_HISTORY,
																															'' AS CANCER1,
																															'' AS CANCER_MORBIDITY_AGE1,
																															'' AS CANCER_HOSPITAL1,
																															'' AS CANCER2,
																															'' AS CANCER_MORBIDITY_AGE2,
																															'' AS CANCER_HOSPITAL2,
																															'' AS CANCER3,
																															'' AS CANCER_MORBIDITY_AGE3,
																															'' AS CANCER_HOSPITAL3,
																															'' AS INTESTINAL_POLYP,
																															'' AS INTESTINAL_POLYP_CLEAR,
																															'' AS INTESTINAL_POLYP_YEAR,
																															'' AS RELATIVES_BOWEL_CANCER,
																															'' AS BOWEL_CANCER_PERSON1,
																															'' AS BOWEL_CANCER_MORBIDITY_AGE1,
																															'' AS BOWEL_CANCER_ALIVE1,
																															'' AS BOWEL_CANCER_PERSON2,
																															'' AS BOWEL_CANCER_MORBIDITY_AGE2,
																															'' AS BOWEL_CANCER_ALIVE2,
																															'' AS BOWEL_CANCER_PERSON3,
																															'' AS BOWEL_CANCER_MORBIDITY_AGE3,
																															'' AS BOWEL_CANCER_ALIVE3,
																															'' AS SCHISTOSOMIASIS,
																															'' AS SCHISTOSOMIASIS_YEAR,
																															'' AS USE_ASPIRIN,
																															'' AS ASPIRIN_START_DATE,
																															'' AS ASPIRIN_DAILY_DOSE,
																															'' AS USE_ANTIBIOTIC,
																															'' AS DIABETES_BY_HOSPITAL,
																															'' AS DIABETES_YEAR,
																															'' AS DIABETES_HOSPITAL,
																															'' AS ENTEROSCOPE,
																															'' AS ENTEROSCOPE_DATE,
																															'' AS RISK_ASSESS_RESULT,
																															'' AS ASSESSOR_SIGN,
																															'' AS FECAL_OCCULT_BLOOD1,
																															'' AS FECAL_OCCULT_BLOOD2,
																															'' AS FECAL_OCCULT_BLOOD_RESULT,
																															'' AS FECAL_GENE,
																															'' AS FIT_VALUE,
																															'' AS FIT_RESULT,
																															'' AS INSPECTOR_SIGN,
																															'' AS CHECK_DATE,
																															'' AS CREATE_SOURCE,
																															'' AS FIRST_CHECK_SAVE_TIME,
																															'' AS CLOSED_STATUS,
																															'' AS BIOPSY_RESULT,
																															'' AS MALIGNANT_TUMOR_TYPE,
																															'' AS SMOKING_AROUND,
																															'' AS TUMOR_DIAGNOSIS,
																															'' AS PATHOLOGICAL_TYPE,
																															'' AS PASSIVE_SMOKING_PLACE,
																															'' AS CURRENT_SITUATION,
																															'' AS PAST_TREATMENT,
																															'' AS GUIDANCE_CONTENT,
																															'' AS CARTESIAN_SCORE,
																															'' AS VISIT_DATE,
																															isnull( t6.pulseRate, '' ) AS PULSE_RATE,
																															isnull( t6.cerebrovascularCode, '' ) AS CEREBROVASCULAR_DISEASE_CODE,
																															isnull( t6.cerebrovascularName, '' ) AS CEREBROVASCULAR_DISEASE_NAME,
																															isnull( t6.kidneyCode, '' ) AS KIDNEY_DISEASE_CODE,
																															isnull( t6.kidneyName, '' ) AS KIDNEY_DISEASE_NAME,
																															isnull( t6.bloodVesselsCode, '' ) AS VASCULAR_DISEASE_CODE,
																															isnull( t6.bloodVesselsName, '' ) AS VASCULAR_DISEASE_NAME,
																															isnull( t6.exerciseFrequencyCode, '' ) AS EXERCISE_FREQUENCY_CODE,
																															isnull( t6.exerciseFrequencyName, '' ) AS EXERCISE_FREQUENCY_NAME,
																															isnull( t6.eatingHabitsCode, '' ) AS EATING_HABITS_CODE,
																															isnull( t6.eatingHabitsName, '' ) AS EATING_HABITS_NAME,
																															isnull( t6.smokingCode, '' ) AS SMOKING_STATUS_CODE,
																															isnull( t6.smokingName, '' ) AS SMOKING_STATUS_NAME,
																															isnull( t6.dailySmoking, '' ) AS SMOKING_QUANTITY,
																															isnull( t6.startSmokingAge, '' ) AS SMOKING_START_AGE,
																															isnull( t6.quitSmokingAge, '' ) AS QUIT_SMOKING_AGE,
																															isnull( t6.drinkingFrequencyCode, '' ) AS DRINKING_FREQUENCY_CODE,
																															isnull( t6.drinkingFrequencyName, '' ) AS DRINKING_FREQUENCY_NAME,
																															isnull( t6.dailyDrinking, '' ) AS DAILY_DRINKING,
																															isnull( t6.isQuitDrinking, '' ) AS QUIT_DRINKING,
																															isnull( t6.quitDrinkingAge, '' ) AS QUIT_DRINKING_AGE,
																															isnull( t6.startDrinkingAge, '' ) AS START_DRINKING_AGE,
																															isnull( t6.isDrunkYear, '' ) AS DRUNK,
																															isnull( t6.drinkingTypeCodeSystem, '' ) AS DRINKING_TYPE_CODE,
																															isnull( t6.drinkingTypeName, '' ) AS DRINKING_TYPE_NAME,
																															'' AS OCCUPATIONAL_DISEASES,
																														
																															isnull( '', '' ) AS DRUG_FREQUENCY,
																															isnull( '', '' ) AS DRUG_DATE,
																															isnull( '', '' ) AS DRUG_COMPLIANCE,
																															isnull( t6.examinationId, '' ) AS EXAM_NUM,
																															'' AS UNDONE_PROJECT,
																															'' AS URINE,
																															'' AS BLOOD,
																															'' AS DUNG1,
																															'' AS DUNG2,
																															'' AS ECG,
																															'' AS B_ULTRASOUND,
																															'' AS CHEST_RADIOGRAPH,
																														 isnull( t14.CATEGORY_CODE, '' ) AS CATEGORY_CODE,
																														isnull( t14.CATEGORY_NAME, '' ) AS CATEGORY_NAME,
																															'' AS SOCIAL_SECURITY_CARD,
																															'' AS REGISTRANT,
																														isnull( t14.CZRYBM , '' ) AS SIGN_DOC_NAME,
																															isnull( t14.ARCHIVEUNITNAME, '' ) AS SIGN_ORG,
																															'' AS INSPECTION_DOC_NAME,
																															'' AS EXAM_TYPE,
																															'' AS INTEGRITY_RATIO,
																															'' AS EXAM_STATUS,
																															'' AS PRINT_MARK,
																															isnull(t6.examinationDate,'') AS EXAM_DATE,
																															'' AS INSPECTION_DATE,
																															'' AS REGISTER_DATE,
																															'' AS SERVICE_STATION,
																															'0' AS ASSESS_STATUS,
																															'' AS CREATE_DATE,
																															'' AS ASSESS_DATE,
																															'0' AS IS_DELETE 
																														FROM
																												(	SELECT * FROM		tb_empi_index_root
																												WHERE IDCARDNO=@IDCARD 
																												) t1
																															LEFT JOIN 
																															
																															(SELECT * FROM HrCover WHERE ArchiveNum=@IDCARD) t2 ON t1.idCardNo= t2.ArchiveNum
																															LEFT JOIN 
																															
																															(SELECT * FROM HrPersonBasicInfo WHERE ArchiveNum=@IDCARD) t3 ON t2.ArchiveNum= t3.ArchiveNum
																															LEFT JOIN (
																														 SELECT  top 1 * FROM TB_DC_CHRONIC_INFO WHERE empiGuid=@guid ORDER BY REGISTTIME DESC  ) t5 
																															
																														 ON t1.guid= t5.empiGuid
																															LEFT JOIN (
																															 SELECT TOP 1 * FROM tb_dc_examination_info WHERE EMPIGUID=@guid  ORDER BY EXAMINATIONDATE DESC		 
																															) t6 ON t1.guid= t6.empiGuid
																														
																															LEFT JOIN (
																														
																																SELECT  TOP 1 * FROM tb_dc_htn_visit 
																																WHERE EMPIGUID=@guid 
																																ORDER BY visitDate DESC
																														
																															) t8 ON t8.EMPIGUID= t1.guid
																															
																															LEFT JOIN (
																															SELECT  TOP 1 * FROM TB_DC_DM_VISIT
																																WHERE EMPIGUID=@guid 
																																ORDER BY visitDate DESC
																														
																															) t9 ON t9.EMPIGUID=t1.guid
																														
																															
																												
																															
																															INNER  JOIN QYYH t14 ON t1.IDCARDNO= t14.SFZH
																													WHERE
	t1.IDCARDNO=@IDCARD)
	,
	 m2 as (
	 SELECT
		VISITDATE,
		SMOKINGSTATUSCODE,
		DRINKINGFREQUENCYCODE,
		NULL AS EATINGHABITSCODE,
		null AS EXERCISEFREQUENCYCODE
	FROM
		TB_DC_DM_VISIT 
	WHERE
		EMPIGUID = @guid
		AND VISITDATE BETWEEN DATEADD(year, -1, GETDATE())
		AND GETDATE() UNION ALL
	SELECT
		VISITDATE,
		SMOKINGSTATUSCODE,
		DRINKINGFREQUENCYCODE,
		NULL AS EATINGHABITSCODE,
		NULL AS EXERCISEFREQUENCYCODE

	FROM
		TB_DC_HTN_VISIT 
	WHERE
		EMPIGUID = @guid
			AND VISITDATE BETWEEN DATEADD(year, -1, GETDATE())
		AND GETDATE() UNION ALL
	SELECT
		EXAMINATIONDATE,
		SMOKINGCODE,
		DRINKINGFREQUENCYCODE,
		EATINGHABITSCODE,
		EXERCISEFREQUENCYCODE
	FROM
		TB_DC_EXAMINATION_INFO 
	WHERE
		EMPIGUID = @guid
		AND EXAMINATIONDATE  BETWEEN DATEADD(year, -1, GETDATE())
		AND GETDATE()
	 ),
-- 身体指标
 m3 as(
SELECT    
 CONVERT(VARCHAR(50), HEIGHT) AS HEIGHT,
 CONVERT(VARCHAR(50), WEIGHT) AS WEIGHT,
 CONVERT(VARCHAR(50), WAISTLINE) AS WAISTLINE,
 CONVERT(VARCHAR(50), HIPLINE) AS HIPLINE,
 CREATE_DATE AS reportdate
FROM TB_INFORMATION_EXCELINFO WHERE SFZH = @IDCARD
UNION ALL
SELECT 
 CONVERT(VARCHAR(50), HEIGHT) AS HEIGHT,
 CONVERT(VARCHAR(50), WEIGHT) AS WEIGHT,
 CONVERT(VARCHAR(50), WAISTLINE) AS WAISTLINE,
 CONVERT(VARCHAR(50), HIPLINE) AS HIPLINE,
 MEASURE_DATE AS reportdate
FROM TB_VISIT_MEASURE WHERE ID_CARD = @IDCARD
UNION ALL
SELECT
 CONVERT(VARCHAR(50), HEIGHT) AS HEIGHT,
 CONVERT(VARCHAR(50), WEIGHT) AS WEIGHT,
 CONVERT(VARCHAR(50), WAISTLINE) AS WAISTLINE,
 CONVERT(VARCHAR(50), HIPLINE) AS HIPLINE,
  RECORD_TIME AS reportdate
FROM TB_SELF_ASSESSMENT WHERE ID_CARD = @IDCARD
UNION ALL
SELECT HEIGHT AS HEIGHT,
WEIGHT AS WEIGHT,
WAISTLINE AS WAISTLINE,
HIPS AS HIPLINE,
EXAMINATIONDATE AS reportdate
 FROM  TB_DC_EXAMINATION_INFO  
WHERE EMPIGUID = @guid
UNION ALL
SELECT
HEIGHT AS HEIGHT,
WEIGHT AS WEIGHT,
WAISTLINE AS WAISTLINE,
HIPLINE AS HIPLINE,
VISITDATE AS reportdate
FROM
TB_DC_DM_VISIT 
WHERE EMPIGUID = @guid
UNION ALL
SELECT
HEIGHT AS HEIGHT,
WEIGHT AS WEIGHT,
WAISTLINE AS WAISTLINE,
'' AS HIPLINE,
VISITDATE AS reportdate
FROM
TB_DC_HTN_VISIT
WHERE EMPIGUID = @guid
	 ),
-- 生活习惯	 
 m4 as(
 SELECT
	EATING_HABITS_CODE AS EATING_HABITS_CODE,
	EXERCISE_FREQUENCY_CODE AS EXERCISE_FREQUENCY_CODE,
	SMOKING_STATUS_CODE AS SMOKING_STATUS_CODE,
	DRINKING_FREQUENCY_CODE AS DRINKING_FREQUENCY_CODE ,
		RECORD_TIME AS REPORT_DATE
	FROM TB_SELF_ASSESSMENT 
WHERE
	ID_CARD = @IDCARD
	
	 UNION ALL
SELECT
	EATINGHABITSCODE,
	EXERCISEFREQUENCYCODE,
	SMOKINGCODE,
	DRINKINGFREQUENCYCODE ,
	EXAMINATIONDATE
FROM
	TB_DC_EXAMINATION_INFO 
WHERE
	EMPIGUID = @guid
UNION ALL
SELECT
	DIETCODE,
	TARGETSPORTFREQUENCYCODE,
	SMOKINGSTATUSCODE,
	DRINKINGFREQUENCYCODE ,
	VISITDATE
FROM
	TB_DC_DM_VISIT 
WHERE
	EMPIGUID = @guid
	 UNION ALL
SELECT
	'' AS t,
	EXERCISEFREQUENCYCODE,
	SMOKINGSTATUSCODE,
	DRINKINGFREQUENCYCODE,
	VISITDATE
	FROM TB_DC_HTN_VISIT
	WHERE EMPIGUID = @guid 
	UNION ALL
SELECT 
	EATINGHABITSCODE,
	SPORTFREQUENCECODE,
	SMOKINGCODE,
	DRINKINGFREQUENCYCODE,
	REGISTTIME
	FROM TB_DC_CHRONIC_INFO 
	WHERE EMPIGUID = @guid 
)

UPDATE  dbo.T_HEALTH_ASSESS

SET
 [NAME]=m1.[NAME] ,
 [Sex]=m1.[Sex] ,
 [BIRTH]=m1.[BIRTH] ,
 [ID_CARD]=m1.[ID_CARD] ,
 [PROVINCE]=m1.[PROVINCE] ,
 [CITY]=m1.[CITY] ,
 [DISTRICT]=m1.[DISTRICT] ,
 [TOWN]=m1.[TOWN] ,
 [VILLAGE]=m1.[VILLAGE] ,
 [ADDRESS]=m1.[ADDRESS] ,
 [PERMANENT_ADDRESS]=m1.[PERMANENT_ADDRESS] ,
 [PHONE]=m1.[PHONE] ,
 [HEIGHT]= ISNULL((SELECT top 1 HEIGHT FROM m3 WHERE HEIGHT is not null and HEIGHT !='' ORDER BY reportdate desc),''),
 [WEIGHT]= ISNULL((SELECT top 1 WEIGHT FROM m3 WHERE WEIGHT is not null and WEIGHT !='' ORDER BY reportdate desc),''),
 [BMI]=m1.[BMI] ,
 [WAISTLINE]=ISNULL((SELECT top 1 WAISTLINE FROM m3 WHERE WAISTLINE is not null and WAISTLINE !='' ORDER BY reportdate desc),'') ,
 [HIPLINE]= ISNULL((SELECT top 1 HIPLINE FROM m3 WHERE HIPLINE is not null and HIPLINE !='' ORDER BY reportdate desc),'') ,
 [DBP]=m1.[DBP] ,
 [SBP]=m1.[SBP] ,
 [MOBILE_PHONE]=m1.[MOBILE_PHONE] ,
 [IS_HYPERTENSION]=m1.[IS_HYPERTENSION] ,
 [IS_DIABETES]=m1.[IS_DIABETES] ,
 [HYPERURICEMIA]=m1.[HYPERURICEMIA] ,
 [NEPHROPATHY_FAMILY_HISTORY]=m1.[NEPHROPATHY_FAMILY_HISTORY] ,
 [CHRONIC_NEPHRITIS_HISTORY]=m1.[CHRONIC_NEPHRITIS_HISTORY] ,
 [IS_OVER_65]=m1.[IS_OVER_65] ,
 [URINE_ERYTHROCYTE]=m1.[URINE_ERYTHROCYTE] ,
 [EGFR]=m1.[EGFR] ,
 [UROPROTEIN]=m1.[UROPROTEIN] ,
 [CREATININE]=m1.[CREATININE] ,
 [GLOMERULAR_FILTRATION_RATE]=m1.[GLOMERULAR_FILTRATION_RATE] ,
 [INPUT_DATE]=m1.[INPUT_DATE] ,
 [MANAGE_TYPE]=m1.[MANAGE_TYPE] ,
 [EATING_HABIT]=m1.[EATING_HABIT] ,
 [PSYCHOTROPIC_DRUG]=m1.[PSYCHOTROPIC_DRUG] ,
 [SEDENTARY_LIFESTYLE]=m1.[SEDENTARY_LIFESTYLE] ,
 [BLOOD_FAT_ABNORMAL]=m1.[BLOOD_FAT_ABNORMAL] ,
 [GIANT_CHILD_PRODUCTION]=m1.[GIANT_CHILD_PRODUCTION] ,
 [ASCVD]=m1.[ASCVD] ,
 [TRANSIENT_STEROID_DIABETES]=m1.[TRANSIENT_STEROID_DIABETES] ,
 [PCOS]=m1.[PCOS] ,
 [FAMILY_HISTORY]=m1.[FAMILY_HISTORY] ,
 [BLOOD_TYPE]=m1.[BLOOD_TYPE] ,
 [DISABILITY]=m1.[DISABILITY] ,
 [DISEASE_HISTORY]=ISNULL(@DISEASE,''),
 [OPERATION_HISTORY]=m1.[OPERATION_HISTORY] ,
 [TRAUMA_HISTORY]=m1.[TRAUMA_HISTORY] ,
 [TRANSFUSION_HISTORY]=m1.[TRANSFUSION_HISTORY] ,
 HEREDITARY_HISTORY=m1.[TRAUMA_HISTORY],
 [FAMILY_RELATION]=m1.[FAMILY_RELATION] ,
 [H_TYPE_HYPERTENSION]=m1.[H_TYPE_HYPERTENSION] ,
 [ATRIAL_FIBRILLATION]=m1.[ATRIAL_FIBRILLATION] ,
 [CORONARY_HEART]=m1.[CORONARY_HEART] ,
 [PERIPHERAL_VASCULAR]=m1.[PERIPHERAL_VASCULAR] ,
 [CARDIOVASCULAR_CEREBROVASCULAR]=m1.[CARDIOVASCULAR_CEREBROVASCULAR] ,
 [CEREBRAL_INFARCTION_TYPE]=m1.[CEREBRAL_INFARCTION_TYPE] ,
CEREBROVASCULAR_DISEASE_CODE=m1.CEREBROVASCULAR_DISEASE_CODE,
CEREBROVASCULAR_DISEASE_NAME=m1.CEREBROVASCULAR_DISEASE_NAME,


 [OTHER_CEREBRAL_INFARCTION_TYPE]=m1.[OTHER_CEREBRAL_INFARCTION_TYPE] ,
 [DIAGNOSIS_DATE]=m1.[DIAGNOSIS_DATE] ,
 [ID_NUM]=m1.[ID_NUM] ,
 [DECISION_RESULT]=m1.[DECISION_RESULT] ,
 [MARITAL]=m1.[MARITAL] ,
 [EDUCATION]=m1.[EDUCATION] ,
 [OCCUPATION]=m1.[OCCUPATION] ,
 [MEDICAL_INSURANCE_MODE]=m1.[MEDICAL_INSURANCE_MODE] ,
 [OTHER_MEDICAL_INSURANCE_MODE]=m1.[OTHER_MEDICAL_INSURANCE_MODE] ,
 [CHRONIC_DIARRHEA]=m1.[CHRONIC_DIARRHEA] ,
 [CHRONIC_DIARRHEA_MONTH]=m1.[CHRONIC_DIARRHEA_MONTH] ,
 [CHRONIC_DIARRHEA_DAY]=m1.[CHRONIC_DIARRHEA_DAY] ,
 [CHRONIC_CONSTIPATION]=m1.[CHRONIC_CONSTIPATION] ,
 [CHRONIC_CONSTIPATION_MONTH]=m1.[CHRONIC_CONSTIPATION_MONTH] ,
 [CHRONIC_CONSTIPATION_DAY]=m1.[CHRONIC_CONSTIPATION_DAY] ,
 [BLOODY_STOOL]=m1.[BLOODY_STOOL] ,
 [BLOODY_STOOL_YEAR]=m1.[BLOODY_STOOL_YEAR] ,
 [APPENDIX]=m1.[APPENDIX] ,
 [APPENDIX_YEAR]=m1.[APPENDIX_YEAR] ,
 [GALLBLADDER]=m1.[GALLBLADDER] ,
 [GALLBLADDER_YEAR]=m1.[GALLBLADDER_YEAR] ,
 [GALLBLADDER_HOSPITAL]=m1.[GALLBLADDER_HOSPITAL] ,
 [MENTAL_TRAUMA]=m1.[MENTAL_TRAUMA] ,
 [CANCER_HISTORY]=m1.[CANCER_HISTORY] ,
 [CANCER1]=m1.[CANCER1] ,
 [CANCER_MORBIDITY_AGE1]=m1.[CANCER_MORBIDITY_AGE1] ,
 [CANCER_HOSPITAL1]=m1.[CANCER_HOSPITAL1] ,
 [CANCER2]=m1.[CANCER2] ,
 [CANCER_MORBIDITY_AGE2]=m1.[CANCER_MORBIDITY_AGE2] ,
 [CANCER_HOSPITAL2]=m1.[CANCER_HOSPITAL2] ,
 [CANCER3]=m1.[CANCER3] ,
 [CANCER_MORBIDITY_AGE3]=m1.[CANCER_MORBIDITY_AGE3] ,
 [CANCER_HOSPITAL3]=m1.[CANCER_HOSPITAL3] ,
 [INTESTINAL_POLYP]=m1.[INTESTINAL_POLYP] ,
 [INTESTINAL_POLYP_CLEAR]=m1.[INTESTINAL_POLYP_CLEAR] ,
 [INTESTINAL_POLYP_YEAR]=m1.[INTESTINAL_POLYP_YEAR] ,
 [RELATIVES_BOWEL_CANCER]=m1.[RELATIVES_BOWEL_CANCER] ,
 [BOWEL_CANCER_PERSON1]=m1.[BOWEL_CANCER_PERSON1] ,
 [BOWEL_CANCER_MORBIDITY_AGE1]=m1.[BOWEL_CANCER_MORBIDITY_AGE1] ,
 [BOWEL_CANCER_ALIVE1]=m1.[BOWEL_CANCER_ALIVE1] ,
 [BOWEL_CANCER_PERSON2]=m1.[BOWEL_CANCER_PERSON2] ,
 [BOWEL_CANCER_MORBIDITY_AGE2]=m1.[BOWEL_CANCER_MORBIDITY_AGE2] ,
 [BOWEL_CANCER_ALIVE2]=m1.[BOWEL_CANCER_ALIVE2] ,
 [BOWEL_CANCER_PERSON3]=m1.[BOWEL_CANCER_PERSON3] ,
 [BOWEL_CANCER_MORBIDITY_AGE3]=m1.[BOWEL_CANCER_MORBIDITY_AGE3] ,
 [BOWEL_CANCER_ALIVE3]=m1.[BOWEL_CANCER_ALIVE3] ,
 [SCHISTOSOMIASIS]=m1.[SCHISTOSOMIASIS] ,
 [SCHISTOSOMIASIS_YEAR]=m1.[SCHISTOSOMIASIS_YEAR] ,
 [USE_ASPIRIN]=m1.[USE_ASPIRIN] ,
 [ASPIRIN_START_DATE]=m1.[ASPIRIN_START_DATE] ,
 [ASPIRIN_DAILY_DOSE]=m1.[ASPIRIN_DAILY_DOSE] ,
 [USE_ANTIBIOTIC]=m1.[USE_ANTIBIOTIC] ,
 [DIABETES_BY_HOSPITAL]=m1.[DIABETES_BY_HOSPITAL] ,
 [DIABETES_YEAR]=m1.[DIABETES_YEAR],
  [ORG_CODE]=m1.orgcode,
			CATEGORY_CODE=m1.CATEGORY_CODE,
				CATEGORY_NAME=m1.CATEGORY_NAME,
										SIGN_DOC_NAME=m1.SIGN_DOC_NAME,
										SIGN_ORG=m1.SIGN_ORG,
										PULSE_RATE=m1.PULSE_RATE,
										KIDNEY_DISEASE_CODE=m1.KIDNEY_DISEASE_CODE,
										KIDNEY_DISEASE_NAME=m1.KIDNEY_DISEASE_NAME,
										VASCULAR_DISEASE_CODE=m1.VASCULAR_DISEASE_CODE,
										VASCULAR_DISEASE_NAME=m1.VASCULAR_DISEASE_NAME,
										EXERCISE_FREQUENCY_CODE=ISNULL((SELECT top 1 EXERCISE_FREQUENCY_CODE FROM m4 WHERE EXERCISE_FREQUENCY_CODE IS NOT NULL AND EXERCISE_FREQUENCY_CODE != '' ORDER BY REPORT_DATE DESC),'') ,
										EXERCISE_FREQUENCY_NAME=m1.EXERCISE_FREQUENCY_NAME,
										EATING_HABITS_CODE= ISNULL((SELECT top 1 EATING_HABITS_CODE FROM m4 WHERE EATING_HABITS_CODE IS NOT NULL AND EATING_HABITS_CODE != '' ORDER BY REPORT_DATE DESC),'') ,
									--	EATING_HABITS_NAME=m1.EATING_HABITS_NAME,
										SMOKING_STATUS_NAME=m1.SMOKING_STATUS_NAME,
										SMOKING_QUANTITY=m1.SMOKING_QUANTITY,
										SMOKING_START_AGE=m1.SMOKING_START_AGE,
										QUIT_SMOKING_AGE=m1.QUIT_SMOKING_AGE,
										DRINKING_FREQUENCY_CODE=ISNULL((SELECT top 1 DRINKING_FREQUENCY_CODE FROM m4 WHERE DRINKING_FREQUENCY_CODE IS NOT NULL AND DRINKING_FREQUENCY_CODE != '' ORDER BY REPORT_DATE DESC),''),
										DAILY_DRINKING=m1.DAILY_DRINKING,
										QUIT_DRINKING_AGE=m1.QUIT_DRINKING_AGE,
										DRUNK=m1.DRUNK,
										DRINKING_TYPE_CODE=m1.DRINKING_TYPE_CODE,
										DRINKING_TYPE_NAME=m1.DRINKING_TYPE_NAME,
										EXAM_DATE=m1.EXAM_DATE,
										SMOKING_STATUS_CODE=ISNULL((SELECT top 1 SMOKING_STATUS_CODE FROM m4 WHERE SMOKING_STATUS_CODE IS NOT NULL AND SMOKING_STATUS_CODE != '' ORDER BY REPORT_DATE DESC),'') ,
										DRINKING_FREQUENCY_NAME=m1.DRINKING_FREQUENCY_NAME
										
										
										
							
from m1	
WHERE id=@ID
;

INSERT ASSESS_DIAGNOSIS (
ASSESS_ID,
DIAGNOSIS_CODE,
DIAGNOSIS_NAME,
DIAGNOSIS_DATE
)

SELECT 
@ID,
t2.diagnosisCode,
t2.DIAGNOSISDESC,
diagnosisDate
from 
(SELECT * FROM TB_HIS_OP_MEDICAL_RECORD WHERE EMPIGUID=@guid) t1 LEFT JOIN 

TB_HIS_DIAGNOSIS t2
ON t1.OPVISITSTRNO=t2.VISITSTRNO 
AND t1.ORGCODE=t2.ORGCODE
WHERE t2.diagnosisCode is not null and t2.DIAGNOSISDESC is not null 



;




INSERT ASSESS_MEDICATION (DRUG_NAME,MEDICATION_DATA,ASSESS_ID)
		SELECT 
	q2.DRUG_NAME,
	RXDATE,
	@ID
	FROM(
		SELECT
		t2.*,
		ROW_NUMBER ( ) OVER ( partition BY t1.EMPIGUID , t2.ITEMNAME ORDER BY RXDATE DESC ) s1 
	FROM
		( SELECT * FROM TB_HIS_OP_MEDICAL_RECORD WHERE EMPIGUID = @guid ) t1
		LEFT JOIN TB_HIS_OP_PERSCRIPTION t2 ON t1.OPVISITSTRNO= t2.OPVISITSTRNO 
		AND t1.ORGCODE= t2.ORGCODE ) q1 INNER JOIN T_DRUG q2 ON q1.ITEMCODE = q2.DRUG_CODE
		WHERE q1.s1 = 1
		AND q1.ITEMCODE IS NOT NULL
		AND q1.RXDATE >=DATEADD(YEAR,-1,GETDATE())
	  AND q1.RXDATE <=GETDATE()
		
		UNION ALL
		
		SELECT 
	q2.DRUG_NAME,
	ORDERDATE,
	@ID
	FROM(
		SELECT
		t2.*,
		ROW_NUMBER ( ) OVER ( partition BY t1.EMPIGUID , t2.ITEMNAME ORDER BY ORDERDATE DESC ) s1 
	FROM
		( SELECT * FROM TB_HIS_IP_MEDICAL_RECORD WHERE EMPIGUID = @guid ) t1
		LEFT JOIN TB_HIS_IP_ORDER t2 ON t1.IPVISITSTRNO= t2.IPVISITSTRNO 
		AND t1.ORGCODE= t2.ORGCODE ) q1 INNER JOIN T_DRUG q2 ON q1.ITEMCODE = q2.DRUG_CODE
		WHERE q1.s1 = 1
		AND q1.ITEMCODE IS NOT NULL
		AND q1.ORDERDATE >=DATEADD(YEAR,-1,GETDATE())
	  AND q1.ORDERDATE <=GETDATE()
		
		UNION ALL
		

				SELECT 
	q1.DRUGNAME,
	q1.EXAMINATIONDATE,
	@ID
	FROM(
		SELECT
		t2.DRUGNAME,t1.EXAMINATIONDATE,
		ROW_NUMBER ( ) OVER ( partition BY t1.EMPIGUID , t2.DRUGNAME ORDER BY EXAMINATIONDATE DESC ) s1 
	FROM
		( SELECT * FROM TB_DC_EXAMINATION_INFO WHERE EMPIGUID = @guid ) t1
		LEFT JOIN TB_DC_EXAMINATION_MEDICATE t2 ON t1.EXAMINATIONID= t2.EXAMINATIONID 
		AND t1.ORGCODE= t2.ORGCODE ) q1 
		WHERE q1.s1 = 1
		AND q1.DRUGNAME IS NOT NULL
		AND q1.EXAMINATIONDATE >=DATEADD(YEAR,-1,GETDATE())
	  AND q1.EXAMINATIONDATE <=GETDATE()

	;


 UPDATE  dbo.T_HEALTH_ASSESS

SET DRUG_NAME = (

SELECT 
    STUFF((
        SELECT ', ' + DRUG_NAME
        FROM ASSESS_MEDICATION 
        WHERE ASSESS_ID = @id
        GROUP BY DRUG_NAME
        FOR XML PATH('')
    ), 1, 2, '') AS ConcatenatedDrugs
),
PHYSICAL_TYPE=ISNULL((
SELECT  TOP 1  MEDICINE_NAME from 
 TB_DC_MEDICIANE 
WHERE   IDCARD= @IDCARD	
 ORDER BY FROM_DATE DESC
), ' ')
WHERE ID =@id;



	
	
UPDATE  dbo.T_HEALTH_ASSESS

		SET
		 DRINKING_FREQUENCY_NAME=( SELECT 
			CASE  DRINKING_FREQUENCY_CODE 
	WHEN '1'  THEN  '从不' 
	WHEN '2'  THEN  '偶尔' 
	WHEN '3'  THEN  '经常'
	WHEN '4'  THEN  '每天'
	
	ELSE ''
END
),
SMOKING_STATUS_NAME=(

SELECT 
			CASE  SMOKING_STATUS_CODE
	WHEN '1'  THEN  '现在每天吸' 
	WHEN '2'  THEN  '现在吸，但不是每天吸'
	WHEN '3'  THEN  '过去吸，现在不吸'
	WHEN '4'  THEN '从不吸'
	
	ELSE ''
END
)


,
EATING_HABITS_NAME=(

SELECT 
			CASE  EATING_HABITS_CODE
	WHEN '1'  THEN  '荤素均衡 '
	WHEN '2'  THEN  '荤食为主'
	WHEN '3'  THEN  '素食为主' 
		WHEN '4'  THEN  '嗜盐' 
			WHEN '5'  THEN  '嗜油' 
				WHEN '6'  THEN  '嗜糖' 
	ELSE ''
END
)

,
EXERCISE_FREQUENCY_NAME=(

SELECT 
			CASE  EXERCISE_FREQUENCY_CODE
	WHEN '1'  THEN  '每天 ' 
	WHEN '2'  THEN  '每周一次以上'
	WHEN '3'  THEN  '偶尔' 
		WHEN '4'  THEN  '不运动'
		
	ELSE ''
END
)

		WHERE ID=@ID
	
	;
	
	UPDATE  dbo.T_HEALTH_ASSESS
	  set HEIGHT= iif(b1.HEIGHT is null or b1.HEIGHT =-1,T_HEALTH_ASSESS.HEIGHT, CONVERT(VARCHAR(10), b1.HEIGHT)),
		WEIGHT =iif(b1.WEIGHT is null or b1.WEIGHT =-1,T_HEALTH_ASSESS.WEIGHT, CONVERT(VARCHAR(10), b1.WEIGHT)),
		WAISTLINE=iif(b1.WAISTLINE is null or b1.WAISTLINE =-1,T_HEALTH_ASSESS.WAISTLINE, CONVERT(VARCHAR(10), b1.WAISTLINE)),
		HIPLINE=iif(b1.HIPLINE is null or b1.HIPLINE =-1,T_HEALTH_ASSESS.HIPLINE, CONVERT(VARCHAR(10), b1.HIPLINE)),
		PHYSICAL_TYPE=iif(b1.PHYSICAL_TYPE is null or b1.PHYSICAL_TYPE ='',T_HEALTH_ASSESS.PHYSICAL_TYPE,b1.PHYSICAL_TYPE)
		
		FROM 
		TB_INFORMATION_EXCELINFO b1
		WHERE T_HEALTH_ASSESS.ID_CARD= b1.SFZH

		and  T_HEALTH_ASSESS.ID=@ID;
		-- 如果身高体重或腰围臀围为空，获取上一次评估完成的数据
		UPDATE dbo.T_HEALTH_ASSESS 
		SET HEIGHT = ISNULL(CASE WHEN T_HEALTH_ASSESS.HEIGHT = '' AND T_HEALTH_ASSESS.WEIGHT = '' THEN (SELECT TOP 1 HEIGHT FROM T_HEALTH_ASSESS WHERE REPORT_STATUS = 1 AND ID_CARD=@IDCARD ORDER BY ASSESS_DATE DESC) ELSE T_HEALTH_ASSESS.HEIGHT END,''),
		WEIGHT = ISNULL(CASE WHEN T_HEALTH_ASSESS.HEIGHT = '' AND T_HEALTH_ASSESS.WEIGHT = '' THEN (SELECT TOP 1 WEIGHT FROM T_HEALTH_ASSESS WHERE REPORT_STATUS = 1  AND ID_CARD=@IDCARD ORDER BY ASSESS_DATE DESC) ELSE T_HEALTH_ASSESS.WEIGHT END,''),
		WAISTLINE = ISNULL(CASE WHEN T_HEALTH_ASSESS.WAISTLINE = '' AND T_HEALTH_ASSESS.HIPLINE = '' THEN (SELECT TOP 1 WAISTLINE FROM T_HEALTH_ASSESS WHERE REPORT_STATUS = 1  AND ID_CARD=@IDCARD ORDER BY ASSESS_DATE DESC) ELSE T_HEALTH_ASSESS.WAISTLINE END,''),
		HIPLINE = ISNULL(CASE WHEN T_HEALTH_ASSESS.WAISTLINE = '' AND T_HEALTH_ASSESS.HIPLINE = '' THEN (SELECT TOP 1 HIPLINE FROM T_HEALTH_ASSESS WHERE REPORT_STATUS = 1  AND ID_CARD=@IDCARD ORDER BY ASSESS_DATE DESC) ELSE T_HEALTH_ASSESS.HIPLINE END,'')
		WHERE T_HEALTH_ASSESS.ID=@ID;
		
UPDATE dbo.T_HEALTH_ASSESS
SET BMI = 
    (SELECT 
        CASE
            WHEN HEIGHT IS NULL OR WEIGHT IS NULL OR 
                 HEIGHT = '' OR WEIGHT = '' OR
                 ISNUMERIC(HEIGHT) = 0 OR ISNUMERIC(WEIGHT) = 0 OR
                 CAST(HEIGHT AS DECIMAL(10,2)) = 0
            THEN 0
            ELSE 
                CAST(CAST(WEIGHT AS DECIMAL(10,2)) / 
                     (CAST(HEIGHT AS DECIMAL(10,2)) * CAST(HEIGHT AS DECIMAL(10,2))) * 10000 AS DECIMAL(10,2))
        END
    )
WHERE ID = @ID
	;
	UPDATE  dbo.T_HEALTH_ASSESS
set  ASSESS_STATUS='0' ,


VACCINATION_NAME=ISNULL((
SELECT 
    STUFF((
        SELECT ',' + VACCINE_NAME
        FROM TB_DC_IMMUNICATION
        WHERE IDCARD = @IDCARD
            AND VACCIATION_DATE BETWEEN DATEADD(YEAR, -1, GETDATE()) AND GETDATE()
        GROUP BY VACCINE_NAME
        FOR XML PATH('')), 1, 1, '') AS ConcatenatedVaccines
), ' ')

		WHERE ID=@ID
		



END
go

