CREATE FUNCTION [dbo].[Split_String]
(
    @String NVARCHAR(MAX),
    @Delimiter NVARCHAR(255)
)
RETURNS @Result TABLE (Value NVARCHAR(MAX))
AS
BEGIN
    DECLARE @StartPosition INT, @EndPosition INT

    SET @StartPosition = 1
    SET @EndPosition = CHARINDEX(@Delimiter, @String)

    WHILE @EndPosition > 0
    BEGIN
        INSERT INTO @Result (Value)
        VALUES (SUBSTRING(@String, @StartPosition, @EndPosition - @StartPosition))

        SET @StartPosition = @EndPosition + 1
        SET @EndPosition = CHARINDEX(@Delimiter, @String, @StartPosition)
    END

    INSERT INTO @Result (Value)
    VALUES (SUBSTRING(@String, @StartPosition, LEN(@String) - @StartPosition + 1))

    RETURN
END;
go

