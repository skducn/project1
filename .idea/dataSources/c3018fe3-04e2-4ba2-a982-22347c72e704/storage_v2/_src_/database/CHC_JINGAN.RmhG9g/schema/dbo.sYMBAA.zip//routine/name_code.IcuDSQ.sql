CREATE FUNCTION [dbo].[name_code]
( @name varchar(32) ,
  @code_field_name varchar(40) 
	
)
RETURNS varchar(2)
AS
BEGIN 
DECLARE @codes varchar(2),@type varchar(2)

   SET @type  = ( SELECT max(code)  from PHS_PPROD.dbo.t_snr_dictionary where field_name = @code_field_name AND [value] = @name)
	 
	  if(@type  is null ) BEGIN 
		set @codes=''
		END 
		else
		BEGIN
		set @codes=@type
end 
	RETURN (@codes);
	
END
go

