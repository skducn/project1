CREATE FUNCTION [dbo].[FN_GETAGE](@IDCARD NVARCHAR(18),@LIMITDDATE DATETIME)
    RETURNS INT AS
BEGIN
    DECLARE @BIRTHYEAR VARCHAR(4)
    DECLARE @BIRTHMONTH VARCHAR(2)
    DECLARE @BIRTHDAY VARCHAR(2)
    DECLARE @BIRTHDATE DATETIME
    DECLARE @BIRTHDATESTR NVARCHAR(10)
    DECLARE @AGE INT
    DECLARE @LENGTH INT
    SET @AGE = -1
    BEGIN
        SET @BIRTHDATESTR = ''
        SET @BIRTHDATE = NULL
        SET @LENGTH = LEN(@IDCARD)
        IF(@LENGTH = 15)
            BEGIN
                SET @BIRTHYEAR = ('19' + SUBSTRING(@IDCARD,7,2))
                SET @BIRTHMONTH = SUBSTRING(@IDCARD,9,2)
                SET @BIRTHDAY = SUBSTRING(@IDCARD,11,2)
            END
        ELSE IF(@LENGTH = 18)
            BEGIN
                SET @BIRTHYEAR = SUBSTRING(@IDCARD,7,4)
                SET @BIRTHMONTH = SUBSTRING(@IDCARD,11,2)
                SET @BIRTHDAY = SUBSTRING(@IDCARD,13,2)
            END
        IF(@BIRTHYEAR > 1800)
            BEGIN
                --2 ·ݵ ʱ  
                IF((@BIRTHYEAR % 4 = 0 OR @BIRTHYEAR % 100 != 0) OR (@BIRTHYEAR % 400 = 0)) --    
                    BEGIN
                        IF(@BIRTHMONTH = 2)
                            BEGIN
                                IF(@BIRTHDAY > 0 AND @BIRTHDAY <= 29)
                                    BEGIN
                                        SET @BIRTHDATESTR = @BIRTHYEAR + '-' + @BIRTHMONTH + '-'+ @BIRTHDAY
                                    END
                            END
                    END
                ELSE
                    BEGIN
                        IF(@BIRTHMONTH = 2)
                            BEGIN
                                IF(@BIRTHDAY > 0 AND @BIRTHDAY <= 28)
                                    BEGIN
                                        SET @BIRTHDATESTR = @BIRTHYEAR + '-' + @BIRTHMONTH + '-'+ @BIRTHDAY
                                    END
                            END
                    END
                --1 3 5 7 8 10 12 ·ݵĴ   
                IF(@BIRTHMONTH = 1 OR @BIRTHMONTH = 3 OR @BIRTHMONTH = 5 OR @BIRTHMONTH = 7 OR @BIRTHMONTH = 8 OR @BIRTHMONTH = 10 OR @BIRTHMONTH = 12)
                    BEGIN
                        IF(@BIRTHDAY > 0 AND @BIRTHDAY <= 31)
                            BEGIN
                                SET @BIRTHDATESTR = @BIRTHYEAR + '-' + @BIRTHMONTH + '-'+ @BIRTHDAY
                            END
                    END
                ELSE IF(@BIRTHMONTH = 4 OR @BIRTHMONTH = 6 OR @BIRTHMONTH = 9 OR @BIRTHMONTH = 11) --4 6 9 11 ·ݵĴ   
                    BEGIN
                        IF(@BIRTHDAY > 0 AND @BIRTHDAY <= 30)
                            BEGIN
                                SET @BIRTHDATESTR = @BIRTHYEAR + '-' + @BIRTHMONTH + '-'+ @BIRTHDAY
                            END
                    END
                IF(@BIRTHDATESTR != '')
                    BEGIN
                        SET @BIRTHDATE = CONVERT(DATETIME,@BIRTHDATESTR)
                        SET @AGE = DATEDIFF(YEAR,@BIRTHDATE,@LIMITDDATE)
                        IF(DATEPART(MONTH,@BIRTHDATE) > DATEPART(MONTH,@LIMITDDATE))
                            BEGIN
                                SET @AGE = @AGE - 1
                            END
                        ELSE IF(DATEPART(MONTH,@BIRTHDATE) = DATEPART(MONTH,@LIMITDDATE))
                            BEGIN
                                IF(DATEPART(DAY,@BIRTHDATE) > DATEPART(DAY,@LIMITDDATE))
                                    BEGIN
                                        SET @AGE = @AGE - 1
                                    END
                            END
                    END
            END
    END
    RETURN @AGE
END
go

