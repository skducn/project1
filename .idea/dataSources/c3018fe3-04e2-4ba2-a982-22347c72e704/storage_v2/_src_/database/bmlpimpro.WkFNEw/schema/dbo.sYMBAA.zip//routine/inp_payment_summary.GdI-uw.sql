CREATE PROCEDURE [dbo].[inp_payment_summary](
@condition nvarchar(50))
as
begin
DECLARE
@startTime nvarchar(20),
@endTime nvarchar(20)
IF (@condition IS NOT NULL AND @condition != '')

    BEGIN
    SET @startTime = SUBSTRING(@condition,0,20)
    SET @endTime = SUBSTRING(@condition,21,20)
		END

select 
userNo as '编号',userName as '收款员',
CONVERT(VARCHAR(20),SUM(prepayamount))  as'预交次数',
CONVERT(VARCHAR(20),sum(prepayfee))  as'预交金额',
CONVERT(VARCHAR(20),SUM(invoiceamount))  as'结算次数',
CONVERT(VARCHAR(20),SUM(invoicefee))  as'结算金额',
CONVERT(VARCHAR(20),SUM(backFee))  as'结算退款',
CONVERT(VARCHAR(20),SUM(checkoutFee))  as'结算补款',
CONVERT(VARCHAR(20),sum(prepayfee+checkoutFee-backFee)) 总计
from 
(select 
operationUserNo userNo,
operationUserName userName,
1 as prepayamount,
paymentFee as prepayfee,
0 as invoiceamount,
0 invoicefee,
0 checkoutFee,
0 backFee
from bmlinppro.dbo.t_inpatient_prepay
where operationDate >=  @startTime and operationDate <=  @endTime and status=2
UNION all
select 
settleUserNo userno,
settleUserName username,
0 as prepayamount,
0 as prepayfee,
case  invoiceStatus when 1  then 1 when 2 then 1 else 0 end  as invoiceamount,
MAX(totalFee) invoicefee,
SUM(case  receiptPayType when 2  then pp.payFee else 0 end ) checkoutFee,
SUM(case  receiptPayType when 3  then pp.payFee else 0 end ) backFee
from 
bmlinppro.dbo.t_inpatient_invoice_info ii
left join bmlinppro.dbo.t_inpatient_invoice_pay pp on ii.settleId=pp.settleId
where settleDate >=  @startTime  and settleDate <= @endTime
group by ii.settleId,ii.settleUserNo,ii.settleUserName,invoiceStatus
) a
group by a.userno,a.username

union all
--合计开始
select 
'合计',null,
CONVERT(VARCHAR(20),SUM(prepayamount)) prepayamount,
CONVERT(VARCHAR(20),sum(prepayfee)) prepayfee,
CONVERT(VARCHAR(20),SUM(invoiceamount)) invoiceamount,
CONVERT(VARCHAR(20),SUM(invoicefee)) invoicefee,
CONVERT(VARCHAR(20),SUM(checkoutFee)) checkoutFee,
CONVERT(VARCHAR(20),SUM(backFee)) backFee,
CONVERT(VARCHAR(20),sum(prepayfee+checkoutFee-backFee)) 总计
from 
(select 
operationUserNo userNo,
operationUserName userName,
1 as prepayamount,
paymentFee as prepayfee,
0 as invoiceamount,
0 invoicefee,
0 checkoutFee,
0 backFee
from bmlinppro.dbo.t_inpatient_prepay
where operationDate >=  @startTime  and operationDate <= @endTime and status=2
UNION all
select 
settleUserNo userno,
settleUserName username,
0 as prepayamount,
0 as prepayfee,
case invoiceStatus when 1  then 1 when 2 then 1 else 0 end  as invoiceamount,
MAX(totalFee) invoicefee,
SUM(case  receiptPayType when 2  then pp.payFee else 0 end ) checkoutFee,
SUM(case  receiptPayType when 3  then pp.payFee else 0 end ) backFee
from 
bmlinppro.dbo.t_inpatient_invoice_info ii
left join bmlinppro.dbo.t_inpatient_invoice_pay pp on ii.settleId=pp.settleId
where settleDate >=  @startTime  and settleDate <= @endTime 
group by ii.settleId,ii.settleUserNo,ii.settleUserName,invoiceStatus
) a

--合计结束
union all

select '收款情况','',null,null,null,null,null,null,null
union ALL

select 
'编号','收款员','现金','微信','支付宝','统筹支付','医保卡','银联卡','总计'
union ALL
select 
userNo,userName,
CONVERT(VARCHAR(20),现金) 现金,
CONVERT(VARCHAR(20),微信) 微信,
CONVERT(VARCHAR(20),支付宝) 支付宝,
CONVERT(VARCHAR(20),统筹支付) 统筹支付,
CONVERT(VARCHAR(20),医保卡) 医保卡,
CONVERT(VARCHAR(20),银联卡) 银联卡,
CONVERT(VARCHAR(20),isNull(现金,0)+isNull(微信,0)+isNull(支付宝,0)+isNull(统筹支付,0)+isNull(医保卡,0)+isNull(银联卡,0)) 总计
from 
(
select 
userNo,userName,
SUM(现金) 现金,
SUM(微信) 微信,
SUM(支付宝) 支付宝,
SUM(统筹支付) 统筹支付,
SUM(医保卡) 医保卡,
SUM(银联卡) 银联卡,
0 总计
from
(select 
operationUserNo userno,
operationUserName userName,
case payway when 1 then paymentFee else 0 end 现金,
case payway when 3 then paymentFee else 0 end 微信,
case payway when 4 then paymentFee else 0 end 支付宝,
0 as  统筹支付,
0 as  医保卡,
case payway when 6 then paymentFee else 0 end as  银联卡
from bmlinppro.dbo.t_inpatient_prepay
where operationDate >=  @startTime  and operationDate <=  @endTime and status=2
UNION all
select 
settleUserNo userno,
settleUserName username,
SUM(case   when pp.receiptPayType =2 and payway=1  then pp.payFee else 0 end )-SUM(case when receiptPayType = 3 and payway=1 then pp.payFee else 0 end ) 现金,
SUM(case   when receiptPayType =2 and payway=3  then pp.payFee else 0 end ) 微信,
SUM(case   when receiptPayType =2 and payway=4  then pp.payFee else 0 end ) 支付宝,
MAX(ii.refundFee) 统筹支付,
MAX(ii.sdGrzhzfs) 医保卡,
SUM(case   when receiptPayType =2 and payway=6  then pp.payFee else 0 end ) 银行卡
from 
bmlinppro.dbo.t_inpatient_invoice_info ii	
left join bmlinppro.dbo.t_inpatient_invoice_pay pp on ii.settleId=pp.settleId
where settleDate >=  @startTime  and settleDate <= @endTime
group by ii.settleId,ii.settleUserNo,ii.settleUserName,invoiceStatus
) a 
group by a.userno,a.username
)a

UNION ALL
--合计开始
select 
'合计' as 合计 ,
null as f1,
CONVERT(VARCHAR(20),现金) 现金,
CONVERT(VARCHAR(20),微信) 微信,
CONVERT(VARCHAR(20),支付宝) 支付宝,
CONVERT(VARCHAR(20),统筹支付) 统筹支付,
CONVERT(VARCHAR(20),医保卡) 医保卡,
CONVERT(VARCHAR(20),银联卡) 银联卡,
CONVERT(VARCHAR(20),isNull(现金,0)+isNull(微信,0)+isNull(支付宝,0)+isNull(统筹支付,0)+isNull(医保卡,0)+isNull(银联卡,0)) 总计
from 
(
select 
'合计' as 合计 ,
null as f1,
SUM(现金) 现金,
SUM(微信) 微信,
SUM(支付宝) 支付宝,
SUM(统筹支付) 统筹支付,
SUM(医保卡) 医保卡,
SUM(银联卡) 银联卡,
0 总计
from
(select 
operationUserNo userno,
operationUserName userName,
case payway when 1 then paymentFee else 0 end 现金,
case payway when 3 then paymentFee else 0 end 微信,
case payway when 4 then paymentFee else 0 end 支付宝,
0 as  统筹支付,
0 as  医保卡,
case payway when 6 then paymentFee else 0 end as  银联卡
from bmlinppro.dbo.t_inpatient_prepay
where operationDate >=  @startTime  and operationDate <=  @endTime and status=2
UNION all
select 
settleUserNo userno,
settleUserName username,
SUM(case   when pp.receiptPayType =2 and payway=1  then pp.payFee else 0 end )-SUM(case when receiptPayType = 3 and payway=1 then pp.payFee else 0 end ) 现金,
SUM(case   when receiptPayType =2 and payway=3  then pp.payFee else 0 end ) 微信,
SUM(case   when receiptPayType =2 and payway=4  then pp.payFee else 0 end ) 支付宝,
MAX(ii.refundFee) 统筹支付,
MAX(ii.sdGrzhzfs) 医保卡,
SUM(case   when receiptPayType =2 and payway=6  then pp.payFee else 0 end ) 银行卡
from 
bmlinppro.dbo.t_inpatient_invoice_info ii	
left join bmlinppro.dbo.t_inpatient_invoice_pay pp on ii.settleId=pp.settleId
where settleDate >=  @startTime  and settleDate <= @endTime
group by ii.settleId,ii.settleUserNo,ii.settleUserName,invoiceStatus
) a 
)a


end
go

