CREATE PROCEDURE [dbo].[mz_dept_income]
@condition nvarchar(50)
AS
BEGIN
DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
IF (@condition IS NOT NULL AND @condition != '')

    BEGIN
    SET @startTime = SUBSTRING(@condition,0,20)
    SET @endTime = SUBSTRING(@condition,21,20)
  END

SELECT 
	isnull([项目\科室],'合计') '项目\科室',
	isnull(sum([查体科]),0) '查体科',
	isnull(sum([儿保科]),0) '儿保科',
	isnull(sum([儿科]),0) '儿科',
	isnull(sum([妇保科]),0) '妇保科',
	isnull(sum([妇产科]),0) '妇产科',
	isnull(sum([护士站]),0) '护士站',
	isnull(sum([收费室]),0) '收费室',
	isnull(sum([手术室]),0) '手术室',
	isnull(sum([新生儿筛查]),0) '新生儿筛查',
	isnull(sum([合计]),0) '合计'
FROM (
	SELECT  
	codeTab.name [项目\科室],[查体科],[儿保科],[儿科],[妇保科],[妇产科],[护士站],[收费室],[手术室],[新生儿筛查],[合计]
FROM (
	SELECT
		businessType,
		SUM ( CASE WHEN deptCode = '23' THEN amount ELSE 0 END ) AS '查体科',
		SUM ( CASE WHEN deptCode = '22' THEN amount ELSE 0 END ) AS '儿保科',
		SUM ( CASE WHEN deptCode = '12' THEN amount ELSE 0 END ) AS '儿科',
		SUM ( CASE WHEN deptCode = '21' THEN amount ELSE 0 END ) AS '妇保科',
		SUM ( CASE WHEN deptCode = '11' THEN amount ELSE 0 END ) AS '妇产科',
		SUM ( CASE WHEN deptCode = '74' THEN amount ELSE 0 END ) AS '护士站',
		SUM ( CASE WHEN deptCode = '61' THEN amount ELSE 0 END ) AS '收费室',
		SUM ( CASE WHEN deptCode = '33' THEN amount ELSE 0 END ) AS '手术室',
		SUM ( CASE WHEN deptCode = '24' THEN amount ELSE 0 END ) AS '新生儿筛查',
		SUM ( CASE WHEN deptCode IN ( '23', '22', '12', '21', '11', '74', '61', '33', '24' ) THEN amount ELSE 0 END ) AS '合计' 
	FROM
		t_outpatient_cashier_detail t1
		LEFT JOIN t_outpatient_registration_info t2 ON t1.visitId = t2.visitId 
		LEFT JOIN t_code_fee_item t3 on t1.itemId = t3.id
		WHERE t1.itemId is not null and t3.businessType is not null and t1.itemType not in('03','06','09','99')
		and t1.detailTime BETWEEN @startTime and @endTime
	GROUP BY
		t3.businessType
) tabDs
LEFT JOIN (SELECT code,name FROM t_code_standard_code WHERE sysName = '基础业务支撑平台' and codeType = '业务类别' and isValid=1) codeTab on tabDs.businessType = codeTab.code

UNION ALL 
-- 药品费用
SELECT
		case when itemType = '03' then '西药' when itemType = '06' then '中成药' when itemType = '09' then '中草药' when itemType='99' then '卫生材料' else '' end as '项目\科室',
		SUM ( CASE WHEN deptCode = '23' THEN amount ELSE 0 END ) AS '查体科',
		SUM ( CASE WHEN deptCode = '22' THEN amount ELSE 0 END ) AS '儿保科',
		SUM ( CASE WHEN deptCode = '12' THEN amount ELSE 0 END ) AS '儿科',
		SUM ( CASE WHEN deptCode = '21' THEN amount ELSE 0 END ) AS '妇保科',
		SUM ( CASE WHEN deptCode = '11' THEN amount ELSE 0 END ) AS '妇产科',
		SUM ( CASE WHEN deptCode = '74' THEN amount ELSE 0 END ) AS '护士站',
		SUM ( CASE WHEN deptCode = '61' THEN amount ELSE 0 END ) AS '收费室',
		SUM ( CASE WHEN deptCode = '33' THEN amount ELSE 0 END ) AS '手术室',
		SUM ( CASE WHEN deptCode = '24' THEN amount ELSE 0 END ) AS '新生儿筛查',
		SUM ( CASE WHEN deptCode IN ( '23', '22', '12', '21', '11', '74', '61', '33', '24' ) THEN amount ELSE 0 END ) AS '合计' 
	FROM
		t_outpatient_cashier_detail t1
		LEFT JOIN t_outpatient_registration_info t2 ON t1.visitId = t2.visitId 
		WHERE t1.itemId is not null and t1.itemType in('03','06','09','99')
		and t1.detailTime BETWEEN @startTime and @endTime
	GROUP BY
		t1.itemType
) tab
GROUP BY cube([项目\科室])



END
go

