CREATE VIEW [dbo].[View_OutPatient] AS SELECT      tori.id, tori.deptCode AS DeptId, tcdi.deptName, tori.regNo AS RegNum, tori.regDate AS RegTime, 
                   CASE tori.visitStatus WHEN '1' THEN '0' WHEN '2' THEN '0' WHEN '3' THEN '0' WHEN '4' THEN '3' WHEN '5' THEN '3' WHEN '6' THEN '2' ELSE '0' END
                    AS Status, tcdi.id AS DoctId, tori.clinicDocName AS DoctNmae, tori.pSign AS PatiId, tori.pName AS PatiName, tori.bookTime AS AppmTime, 
                   tori.bookFlag AS IsAppm, NULL AS Flag
FROM         dbo.t_outpatient_registration_info AS tori LEFT OUTER JOIN
                   dbo.t_code_department_information AS tcdi ON tori.deptCode = tcdi.deptCode
WHERE      (tori.regDate > CONVERT(varchar(100), GETDATE(), 23))
go

