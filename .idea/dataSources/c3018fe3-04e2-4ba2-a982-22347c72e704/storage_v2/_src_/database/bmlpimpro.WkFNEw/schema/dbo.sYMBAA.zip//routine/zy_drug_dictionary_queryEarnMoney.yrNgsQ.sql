CREATE PROCEDURE [dbo].[zy_drug_dictionary_queryEarnMoney]
AS

select SUM(detail.costAmount) AS costOf,
                sum(detail.priceAmount) AS retail,
                sum(detail.WholesaleAmount) AS wholesale
        from t_dsh_outin_info AS outin
        inner join t_dsh_outin_detail AS detail ON outin.Id = detail.outinId
        inner join t_drug_dictionary AS dici ON dici.id = detail.drugId
        WHERE outin.relativeDeptId IS NULL AND outin.state = 3
go

exec sp_addextendedproperty 'MS_Description', '查询出库(赚取的) 成本总金额 零售总金额 批发总金额', 'SCHEMA', 'dbo', 'PROCEDURE',
     'zy_drug_dictionary_queryEarnMoney'
go

