CREATE PROCEDURE [dbo].[reported_drug_antibiotics_analyse]
  @timeString AS VARCHAR(50) 
AS
BEGIN
DECLARE
@startTime nvarchar(100),
@endTime nvarchar(100)

IF (@timeString IS NOT NULL AND @timeString != '')
    BEGIN
    SET @startTime = SUBSTRING(@timeString,0,20)
    SET @endTime = SUBSTRING(@timeString,21,20)
		END

SELECT 
dept.deptCode AS 科室编码,
dept.deptName AS 科室名称,
total.total AS 门诊处方数,
mzkj.total AS 门诊抗菌药物处方数,
Convert(VARCHAR, CAST((Convert(decimal(18,2), mzkj.total) / NULLIF(Convert(decimal(18,2),total.total), 0)) * 100 as decimal(10,2))) +'%' AS 门诊抗菌药物处方百分比,
kj.drug AS 抗菌药物品种数,
CAST(CAST(kj.money AS DECIMAL(10,2)) AS VARCHAR(20)) AS 抗菌药物使用金额,
kj.number AS 抗菌药物使用数量,
cy.number AS 出院人数,
cykj.number AS 住院使用抗菌药物人数,
Convert(VARCHAR, CAST((Convert(decimal(18,2), cykj.number) / NULLIF(Convert(decimal(18,2),cy.number), 0)) * 100 as decimal(10,2))) +'%' AS 住院抗菌使用药物比例
FROM t_code_department_information AS dept 
LEFT JOIN
--门诊处方数
(SELECT
	recipeDeptId,
	COUNT ( DISTINCT recipeId) AS total
FROM
	t_ph_outpatient_dispensing_information
	WHERE dispensingTime BETWEEN  @startTime AND @endTime
GROUP BY recipeDeptId) AS total ON total.recipeDeptId = dept.id
LEFT JOIN 
--门诊抗菌药物处方数
(
SELECT
	info.recipeDeptId,
	COUNT (  DISTINCT info.recipeId ) AS total
FROM
	t_ph_outpatient_dispensing_detail AS detail
	LEFT JOIN t_ph_outpatient_dispensing_information AS info ON detail.dispenseId = info.dispenseId
	LEFT JOIN t_drug_dictionary AS dic ON dic.id=detail.drugId
		WHERE 
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31' AND
	   info.dispensingTime BETWEEN  @startTime AND @endTime AND info.dispenseId >0
GROUP BY info.recipeDeptId
) AS mzkj ON mzkj.recipeDeptId = dept.id
LEFT JOIN
--抗菌药物门诊+住院品种数/金额/数量
(
SELECT
	res.recipeDeptId,
	COUNT(DISTINCT res.drugId) AS drug,
	SUM ( res.money ) AS money,
	SUM ( res.number ) AS number 
FROM
	(
	SELECT
		info.recipeDeptId,
		detail.drugId,
		detail.price * (detail.realNumber-detail.returnNumber) AS money,
		(detail.realNumber-detail.returnNumber) AS number 
	FROM
		t_ph_outpatient_dispensing_detail AS detail
		LEFT JOIN t_ph_outpatient_dispensing_information AS info ON detail.dispenseId = info.dispenseId
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= detail.drugId 
	WHERE
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31'
		AND info.dispensingTime BETWEEN @startTime
		AND @endTime 
		AND info.dispenseId > 0 
	UNION ALL
	SELECT
		arrange.belongDept AS recipeDeptId,
		arrange.drugId,
		arrange.price * arrange.realNumber AS money,
		arrange.realNumber AS number 
	FROM
		t_drug_arrange_info AS arrange
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= arrange.drugId 
	WHERE
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31'
		AND arrange.agoPreparingUserTime BETWEEN @startTime
		AND @endTime 
	) AS res 
GROUP BY
	res.recipeDeptId
) AS kj ON kj.recipeDeptId = dept.id
LEFT JOIN
--出院人数
(
SELECT belongDept, COUNT(DISTINCT outPNo) AS number FROM bmlinppro.dbo.t_inpatient_register WHERE leaveDate BETWEEN  @startTime AND @endTime GROUP BY belongDept
) AS cy ON cy.belongDept=dept.id
LEFT JOIN
--住院使用抗菌药物人数
(SELECT
		inp.belongDept AS recipeDeptId,
			COUNT(DISTINCT inp.outPNo) AS number
	FROM
		t_drug_arrange_info AS arrange
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= arrange.drugId 
		LEFT JOIN bmlinppro.dbo.t_inpatient_register AS inp ON arrange.inPId=inp.id
	WHERE
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31'
		AND inp.leaveDate BETWEEN @startTime
		AND @endTime 
		GROUP BY inp.belongDept
) AS cykj ON cykj.recipeDeptId = dept.id WHERE dept.deptState=1 AND dept.deptProperty IN ('1110000000', '12A0000000')
UNION ALL
--总计
SELECT 
'总计' AS 科室编码,
'' AS 科室名称,
totals.total AS 门诊处方数,
mzkjs.total AS 门诊抗菌药物处方数,
Convert(VARCHAR, CAST((Convert(decimal(18,2), mzkjs.total) / NULLIF(Convert(decimal(18,2),totals.total), 0)) * 100 as decimal(10,2))) +'%' AS 门诊抗菌药物处方百分比,
kjs.drug AS 抗菌药物品种数,
CAST(CAST(kjs.money AS DECIMAL(10,2)) AS VARCHAR(20)) AS 抗菌药物使用金额,
kjs.number AS 抗菌药物使用数量,
cys.number AS 出院人数,
cykjs.number AS 住院使用抗菌药物人数,
Convert(VARCHAR, CAST((Convert(decimal(18,2), cykjs.number) / NULLIF(Convert(decimal(18,2),cys.number), 0)) * 100 as decimal(10,2))) +'%' AS 住院抗菌使用药物比例
FROM 
--门诊处方数
(
SELECT
	COUNT ( DISTINCT info.recipeId) AS total
FROM
	t_ph_outpatient_dispensing_information AS info
	LEFT JOIN t_code_department_information AS dept ON dept.id = info.recipeDeptId
	WHERE info.dispensingTime BETWEEN  @startTime AND @endTime
	AND dept.deptState=1 AND dept.deptProperty IN ('1110000000', '12A0000000')
) AS totals,
	
--门诊抗菌药物处方数
(
SELECT

	COUNT (  DISTINCT info.recipeId ) AS total
FROM
	t_ph_outpatient_dispensing_detail AS detail
	LEFT JOIN t_ph_outpatient_dispensing_information AS info ON detail.dispenseId = info.dispenseId
	LEFT JOIN t_drug_dictionary AS dic ON dic.id=detail.drugId
	LEFT JOIN t_code_department_information AS dept ON dept.id = info.recipeDeptId
		WHERE 
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31' AND
	   info.dispensingTime BETWEEN  @startTime AND @endTime AND info.dispenseId >0
		 AND dept.deptState=1 AND dept.deptProperty IN ('1110000000', '12A0000000')
) AS mzkjs,
--抗菌药物门诊+住院品种数/金额/数量
(
SELECT
	COUNT(DISTINCT res.drugId) AS drug,
	SUM ( res.money ) AS money,
	SUM ( res.number ) AS number 
FROM
	(
	SELECT
		info.recipeDeptId,
		detail.drugId,
		detail.price * (detail.realNumber-detail.returnNumber) AS money,
		(detail.realNumber-detail.returnNumber) AS number 
	FROM
		t_ph_outpatient_dispensing_detail AS detail
		LEFT JOIN t_ph_outpatient_dispensing_information AS info ON detail.dispenseId = info.dispenseId
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= detail.drugId 
		LEFT JOIN t_code_department_information AS dept ON dept.id = info.recipeDeptId
	WHERE
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31'
		AND info.dispensingTime BETWEEN @startTime AND @endTime
		AND info.dispenseId > 0 
		AND dept.deptState=1 AND dept.deptProperty IN ('1110000000', '12A0000000')
	UNION ALL
	SELECT
		arrange.belongDept AS recipeDeptId,
		arrange.drugId,
		arrange.price * arrange.retreatNumber AS money,
		arrange.retreatNumber AS number 
	FROM
		t_drug_arrange_info AS arrange
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= arrange.drugId 
		LEFT JOIN t_code_department_information AS dept ON dept.id = arrange.belongDept
		
	WHERE
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31'
		AND arrange.agoPreparingUserTime BETWEEN @startTime AND @endTime
		AND dept.deptState=1 AND dept.deptProperty IN ('1110000000', '12A0000000')
	) AS res
) AS kjs,

--出院人数
(
SELECT COUNT(DISTINCT outPNo) AS number FROM bmlinppro.dbo.t_inpatient_register WHERE leaveDate BETWEEN  @startTime AND @endTime
) AS cys,
--住院使用抗菌药物人数
(SELECT
			COUNT(DISTINCT inp.outPNo) AS number
	FROM
		t_drug_arrange_info AS arrange
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= arrange.drugId 
		LEFT JOIN bmlinppro.dbo.t_inpatient_register AS inp ON arrange.inPId=inp.id
		LEFT JOIN t_code_department_information AS dept ON dept.id = arrange.belongDept
	WHERE
		SUBSTRING(dic.unifyPropertyBidInviting, 22, 2) = '31'
		AND inp.leaveDate BETWEEN @startTime
		AND @endTime 
		AND arrange.retreatNumber > 0
		AND dept.deptState=1 AND dept.deptProperty IN ('1110000000', '12A0000000')
) AS cykjs

END
go

