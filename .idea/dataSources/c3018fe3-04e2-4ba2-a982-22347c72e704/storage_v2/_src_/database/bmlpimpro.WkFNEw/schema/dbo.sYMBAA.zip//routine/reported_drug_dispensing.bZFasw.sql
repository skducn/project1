CREATE PROCEDURE [dbo].[reported_drug_dispensing]
@startTime VARCHAR(10),
@endTime VARCHAR(10)
as 
begin 
SELECT us.userNo as 操作人工号,us.username as 姓名,
count(DISTINCT case deta.itemType when '03' then info.dispenseId end) as 西药处方数,	
sum(case deta.itemType when '03' then deta.price*deta.number else 0 end )as  西药金额,
count(DISTINCT case deta.itemType when '06' then info.dispenseId end) as 成药处方数,
			sum(case deta.itemType when '06' then deta.price*deta.number else 0 end )as  成药金额,
count(DISTINCT case deta.itemType when '09' then info.dispenseId end) as 草药处方数,
			sum(case deta.itemType when '09' then deta.price*deta.number else 0 end )as  草药金额,
count(DISTINCT case deta.itemType when '03' then info.dispenseId end)+
count(DISTINCT case deta.itemType when '06' then info.dispenseId end)+
count(DISTINCT case deta.itemType when '09' then info.dispenseId end) as 处方数,
	sum(case deta.itemType when '03' then deta.price*deta.number else 0 end )+
sum(case deta.itemType when '06' then deta.price*deta.number else 0 end )+
sum(case deta.itemType when '09' then deta.price*deta.number else 0 end ) as 总金额
from t_ph_outpatient_dispensing_detail AS deta 
join (
select DISTINCT dispenseId,dispenserUserCode  from t_ph_outpatient_dispensing_information as info
where state =3 and preparingTime>=@startTime and preparingTime<=@endTime  ) as info on deta.dispenseId = info.dispenseId
left join bmlusertest.dbo.sys_user as us on dispenserUserCode = us.userNo
GROUP BY us.userNo,us.username
end
go

