CREATE proc zy_ph_dispensing_statistics
@condition nvarchar(50)
as
begin
DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
IF (@condition IS NOT NULL AND @condition != '')

    BEGIN
    SET @startTime = SUBSTRING(@condition,0,20)
    SET @endTime = SUBSTRING(@condition,21,20)
		END


-- new 药房当日发药统计
select 
'门诊' AS 类别, 
recipeIdCount AS 处方数, 
total AS 应收金额, 
total AS 实收金额, 
total AS 对账金额 
from (

SELECT
ISNULL(count(DISTINCT recipeid),0) AS recipeIdCount,
ISNULL(sum(drugAmount) ,0) AS total
FROM t_ph_outpatient_dispensing_information b 
where state in (3,9) and dispenseId in(select min(dispenseId) from t_ph_outpatient_dispensing_information
where dispensingTime > @startTime AND dispensingTime < @endTime
GROUP BY invoiceid)

) t

UNION ALL

select 
'住院' AS 类别, 
0 AS 处方数, 
total AS 应收金额, 
total AS 实收金额, 
total AS 对账金额 
from (
select 
ISNULL(sum(price*pleaseNumber),0) total
from t_drug_arrange_info
where checkUserTime > @startTime AND checkUserTime < @endTime
and state = 2
) t

UNION ALL

select
'合计' AS 类别, 
recipeIdCount AS 处方数, 
total AS 应收金额, 
total AS 实收金额, 
total AS 对账金额 
from (

select  
ISNULL((select sum(price*pleaseNumber) AS total from t_drug_arrange_info where checkUserTime > @startTime AND checkUserTime < @endTime and state = 2 ),0)
+ 
(SELECT 
ISNULL(sum(drugAmount) ,0) AS total
FROM t_ph_outpatient_dispensing_information b 
where state in (3,9) and dispenseId in(select min(dispenseId) from t_ph_outpatient_dispensing_information
where dispensingTime > @startTime AND dispensingTime < @endTime
GROUP BY invoiceid)) AS total,


ISNULL(count(DISTINCT recipeid),0) AS recipeIdCount
FROM t_ph_outpatient_dispensing_information b 
where state in (3,9) and dispenseId in(select min(dispenseId) from t_ph_outpatient_dispensing_information
where dispensingTime > @startTime AND dispensingTime < @endTime
GROUP BY invoiceid)
) t


end
go

