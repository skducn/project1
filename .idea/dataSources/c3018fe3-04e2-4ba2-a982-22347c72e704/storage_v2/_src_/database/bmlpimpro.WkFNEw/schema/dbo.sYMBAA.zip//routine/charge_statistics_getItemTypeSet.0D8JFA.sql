CREATE PROCEDURE [dbo].[charge_statistics_getItemTypeSet]
@itemTypeSet nvarchar(200) OUTPUT
AS
BEGIN
	SET @itemTypeSet = '16-挂号费;19-诊疗费;10-治疗费;08-材料费;05-化验费;07-检查费;06-中成药费;22-摄片费;21-输血费;03-西药费;24-输氧费;23-体检费'
	SELECT @itemTypeSet
END
go

exec sp_addextendedproperty 'MS_Description', '门诊收费统计-获取项目类别代码', 'SCHEMA', 'dbo', 'PROCEDURE',
     'charge_statistics_getItemTypeSet'
go

