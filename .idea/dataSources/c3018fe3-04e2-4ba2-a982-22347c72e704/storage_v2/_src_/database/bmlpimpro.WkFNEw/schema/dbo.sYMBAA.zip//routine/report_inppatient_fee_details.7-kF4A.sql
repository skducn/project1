CREATE PROCEDURE [dbo].[report_inppatient_fee_details]
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-4-30 23:59:59'
as
begin
declare @enterTime nvarchar(50),
@leaveTime nvarchar(50),
@allTime nvarchar(100)
set @allTime = @timeString
set @enterTime = substring(@allTime,0,20)
set @leaveTime = substring(@allTime,21,20)
SELECT
   CASE WHEN GROUPING(tr.inPNo)=1 THEN '合计' ELSE MAX(tr.name) END AS 姓名,
   CASE WHEN GROUPING(tr.inPNo)=1 THEN null ELSE tr.inPNo END as 住院号,
   CASE WHEN GROUPING(tr.inPNo)=1 THEN null ELSE MAX(tr.inPDatetime) END as 入院时间,
   CASE WHEN GROUPING(tr.inPNo)=1 THEN null ELSE MAX(tr.leaveDate) END as 出院时间,
	 --MAX(tr.inPDatetime) as 入院时间,
   --MAX(tr.leaveDate) as 出院时间,
   SUM(bedFee) as 住院费,
   SUM(diagnosisTreatmentFee) as 诊疗费,
   SUM(treatmentFee) as 治疗费,
   SUM(nursingFee) as 护理费,
   SUM(materialFee) as 材料费,
   SUM(inspectionFee) as 检查费,
   SUM(assayFee) as 化验费,
   SUM(filmFee) as 摄片费,
   SUM(oxygenCharge) as 输氧费,
	 SUM(westernMedicineFee) as 西药费,
	 SUM(chinesePatentMedicineFee) as 中成药费,
	 SUM(allFee)- SUM(bedFee)- SUM(diagnosisTreatmentFee)- SUM(treatmentFee)-SUM(nursingFee)-SUM

(materialFee)-SUM(inspectionFee)-SUM(assayFee)-SUM(filmFee)-SUM(oxygenCharge)-SUM(westernMedicineFee)-SUM

(chinesePatentMedicineFee) as 其它,
	 SUM(allFee) as 总费用
   FROM
    bmlinppro.dbo.t_inpatient_register tr
      LEFT JOIN bmlinppro.dbo.t_inpatient_invoice_info ti ON tr.inPId = ti.inPId and ti.invoiceStatus = 2
      LEFT JOIN (
        SELECT settleId,
				SUM(fee) as allFee,
    SUM(CASE itemType WHEN '18' THEN fee ELSE 0 END) as bedFee, --住院费
    SUM(CASE itemType WHEN '19' THEN fee ELSE 0 END) as diagnosisTreatmentFee, --诊疗费
    SUM(CASE itemType WHEN '10' THEN fee ELSE 0 END) as treatmentFee, --治疗费
    SUM(CASE itemType WHEN '13' THEN fee ELSE 0 END) as nursingFee, --护理费
    SUM(CASE itemType WHEN '08' THEN fee ELSE 0 END) as materialFee, --材料费
    SUM(CASE itemType WHEN '07' THEN fee ELSE 0 END) as inspectionFee, --检查费
    SUM(CASE itemType WHEN '05' THEN fee ELSE 0 END) as assayFee, --化验费
    SUM(CASE itemType WHEN '22' THEN fee ELSE 0 END) as filmFee, --摄片费
    SUM(CASE itemType WHEN '24' THEN fee ELSE 0 END) as oxygenCharge, --输氧费
		SUM(CASE itemType WHEN '03' THEN fee ELSE 0 END) as westernMedicineFee, --西药费
		SUM(CASE itemType WHEN '06' THEN fee ELSE 0 END) as chinesePatentMedicineFee, --中成药费
		SUM(CASE itemType WHEN '99' THEN fee ELSE 0 END) as otherFee
    FROM bmlinppro.dbo.t_inpatient_invoice_detail
        WHERE feeDate BETWEEN @enterTime AND @leaveTime GROUP BY settleId)
      feeA ON ti.settleId = feeA.settleId
   WHERE tr.leaveDate BETWEEN @enterTime AND @leaveTime
      GROUP BY tr.inPNo WITH ROLLUP
end ;
go

