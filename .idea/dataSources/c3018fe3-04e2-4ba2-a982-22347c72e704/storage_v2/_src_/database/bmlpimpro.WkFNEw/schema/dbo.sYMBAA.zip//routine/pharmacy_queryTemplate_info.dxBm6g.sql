CREATE PROCEDURE [dbo].[pharmacy_queryTemplate_info]
AS
DECLARE @status INT
SET @status = 0
BEGIN
	SELECT a.*,@status AS status FROM t_ph_outpatient_drug_info AS a
	LEFT JOIN  t_dc_check_template AS b on a.drugId = b.drugId
	WHERE b.templateId = 2
	AND 
	EXISTS(SELECT id FROM t_ph_outpatient_drug_info WHERE a.drugId IN (SELECT drugId FROM t_dc_check_template))
		SET @status = 1

END
go

