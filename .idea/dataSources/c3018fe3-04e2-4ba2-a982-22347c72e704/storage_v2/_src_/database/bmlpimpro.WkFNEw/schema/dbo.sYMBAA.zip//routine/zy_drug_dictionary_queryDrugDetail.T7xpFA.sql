CREATE PROCEDURE [dbo].[zy_drug_dictionary_queryDrugDetail]
AS

SELECT dici.id AS drugId,
                dici.drugName AS drugName,
                dici.origin AS origin,
                dici.drugCategory AS drugCategory,
                dici.remark AS remark,
				mation.price AS price,
				mation.wholesale AS wholesale,
				(select SUM(t.costAmount)
					from t_dsh_outin_info AS o
					inner join t_dsh_outin_detail AS t
					inner join t_drug_dictionary AS d
					ON d.id = t.drugId
					ON o.Id = t.outinId
					WHERE t.drugId = dici.id) AS totalCost,

				(select SUM(t.priceAmount)
					from t_dsh_outin_info AS o
					inner join t_dsh_outin_detail AS t
					inner join t_drug_dictionary AS d
					on d.id = t.drugId
					ON o.Id = t.outinId
					WHERE t.drugId = dici.id) AS retailCost,

				(select SUM(t.WholesaleAmount)
					from t_dsh_outin_info AS o
					inner join t_dsh_outin_detail AS t
					inner join t_drug_dictionary AS d
					ON d.id = t.drugId
					ON o.Id = t.outinId
					WHERE t.drugId = dici.id) AS wholesaleCost,

        (select SUM(t.realNumber)
					from t_dsh_outin_info AS o
					inner join t_dsh_outin_detail AS t
					inner join t_drug_dictionary AS d
					ON d.id = t.drugId
					ON o.Id = t.outinId
					WHERE t.drugId = dici.id AND o.receiptType BETWEEN 11 AND 20) AS expendNumber,
        (select SUM(t.realNumber)
					from t_dsh_outin_info AS o
					inner join t_dsh_outin_detail AS t
					inner join t_drug_dictionary AS d
					ON d.id = t.drugId
					ON o.Id = t.outinId
					WHERE t.drugId = 49 AND o.receiptType BETWEEN 1 AND 10) AS incomeNumber
        FROM t_drug_dictionary AS dici
				INNER JOIN t_dsh_outin_detail AS detail ON dici.id = detail.drugId
        INNER JOIN t_dsh_outin_info AS out ON detail.outinId = out.Id
				INNER JOIN t_dsh_drug_info AS mation ON mation.drugId = dici.id
				GROUP BY dici.id,dici.drugName,dici.drugName,dici.origin,dici.drugCategory,dici.remark,mation.price,mation.wholesale
go

exec sp_addextendedproperty 'MS_Description', '结存明细表查询', 'SCHEMA', 'dbo', 'PROCEDURE',
     'zy_drug_dictionary_queryDrugDetail'
go

