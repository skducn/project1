CREATE PROCEDURE [dbo].[reported_drug_bml_consume]
  @type AS varchar , 
  @timeString VARCHAR(100)
AS
BEGIN

DECLARE
@startTime VARCHAR(100),
@endTime VARCHAR(100)

IF (@timeString IS NOT NULL AND @timeString != '')

    BEGIN
    SET @startTime = SUBSTRING(@timeString,0,20)
    SET @endTime = SUBSTRING(@timeString,21,20)
		END
-- 门诊时排名
IF (@type = 1)
    BEGIN

		
SELECT
			 *
		FROM
			(
				SELECT
 					TOP 100
					tdd.drugCode AS 药品编号,
					odd.drugName AS 药品名称,
					odd.spec AS 药品规格,
					origin.name AS 厂家,
					odd.price AS 单价,
					SUM (odd.realNumber - odd.returnNumber) AS 数量,
					odd.packUnit AS 单位,
					SUM ((odd.realNumber - odd.returnNumber)*odd.price) AS 金额
				FROM
					t_ph_outpatient_dispensing_information AS odi
				LEFT JOIN	t_ph_outpatient_dispensing_detail AS odd ON odi.dispenseId = odd.dispenseId
				LEFT JOIN T_DRUG_DICTIONARY AS tdd ON odd.drugId = tdd.id
				LEFT JOIN (
					SELECT
						name,
						code
					FROM
						t_code_standard_code
					WHERE
						sysName = '药库管理系统'
					AND codeType = '产地厂家'
				) AS origin ON tdd.origin = origin.code
  				WHERE odi.dispensingTime BETWEEN @startTime AND @endTime
				GROUP BY
					tdd.drugCode,
					odd.drugName,
					odd.spec,
					odd.price,
					odd.packUnit,
					origin.name
				ORDER BY 数量 DESC
			) AS tab

UNION ALL 

SELECT '合计','','','','',SUM(number),'',SUM(amount) FROM 
(
		SELECT
			 *
		FROM
			(
				SELECT
 					TOP 100
					tdd.drugCode AS drugCode,
					odd.drugName AS drugName,
					odd.spec AS spec,
					origin.name AS originName,
					odd.price AS price,
					SUM (odd.realNumber - odd.returnNumber) AS number,
					odd.packUnit AS packUnit,
					SUM ((odd.realNumber - odd.returnNumber)*odd.price) AS amount
				FROM
					t_ph_outpatient_dispensing_information AS odi
				LEFT JOIN	t_ph_outpatient_dispensing_detail AS odd ON odi.dispenseId = odd.dispenseId
				LEFT JOIN T_DRUG_DICTIONARY AS tdd ON odd.drugId = tdd.id
				LEFT JOIN (
					SELECT
						name,
						code
					FROM
						t_code_standard_code
					WHERE
						sysName = '药库管理系统'
					AND codeType = '产地厂家'
				) AS origin ON tdd.origin = origin.code
  			WHERE odi.dispensingTime BETWEEN @startTime AND @endTime
				GROUP BY
					tdd.drugCode,
					odd.drugName,
					odd.spec,
					odd.price,
					odd.packUnit,
					origin.name
				ORDER BY number DESC
			) AS tab
) as tb;
		END
--类型为住院时
IF (@type = 2)
    BEGIN

SELECT  * FROM(		
SELECT
TOP 100
			tdd.drugCode AS  药品编号,
			tda.drugName AS  药品名称,
			tda.spec AS  药品规格,
			origin.name AS  厂家,
			tda.price AS  单价,
			SUM (tda.retreatNumber)  数量,
			tda.packUnit AS  单位,
			SUM (tda.retreatNumber*tda.price) 金额
		FROM
			t_drug_arrange_info AS tda
		LEFT JOIN T_DRUG_DICTIONARY AS tdd ON tda.drugId = tdd.id
		LEFT JOIN (
			SELECT
				name,
				code
			FROM
				t_code_standard_code
			WHERE
				sysName = '药库管理系统'
			AND codeType = '产地厂家'
		) AS origin ON tdd.origin = origin.code
 		WHERE tda.agoPreparingUserTime BETWEEN @startTime AND @endTime
		GROUP BY
			tdd.drugCode,
			tda.drugName,
			tda.spec,
			tda.price,
			tda.packUnit,
			origin.name
 ORDER BY 数量 DESC
) as tb

	UNION ALL
SELECT '合计','','','','',SUM(number),'',SUM(money) FROM 
(
		SELECT
			tdd.drugCode AS  drugCode,
			tda.drugName AS  drugName,
			tda.spec AS  spec,
			origin.name AS  name,
			tda.price AS  price,
			SUM (tda.retreatNumber)  number,
			tda.packUnit AS  pname,
			SUM (tda.retreatNumber*tda.price) money
		FROM
			t_drug_arrange_info AS tda
		LEFT JOIN T_DRUG_DICTIONARY AS tdd ON tda.drugId = tdd.id
		LEFT JOIN (
			SELECT
				name,
				code
			FROM
				t_code_standard_code
			WHERE
				sysName = '药库管理系统'
			AND codeType = '产地厂家'
		) AS origin ON tdd.origin = origin.code
 		WHERE tda.agoPreparingUserTime BETWEEN @startTime AND @endTime
		GROUP BY
			tdd.drugCode,
			tda.drugName,
			tda.spec,
			tda.price,
			tda.packUnit,
			origin.name
) as tab


		END

--类型为全部时
IF (@type = 3)
    BEGIN
	

SELECT * FROM (
							SELECT 
							TOP 100
							tdd.drugCode AS 药品编号,
							tab.drugName AS 药品名称,
							tab.spec AS 药品规格,
							origin.name AS 厂家,
							tab.price AS 单价,
							SUM (tab.number) AS 数量,
							tab.packUnit AS 单位,
							SUM (tab.amount) AS 金额
							FROM(
									SELECT
										odd.drugId drugId,
										odd.drugName drugName,
										odd.spec spec,
										odd.price price,
										odd.packUnit packUnit,
										odd.number number,
										odd.amount amount
									FROM
										t_ph_outpatient_dispensing_information AS odi
									LEFT JOIN	t_ph_outpatient_dispensing_detail AS odd ON odi.dispenseId = odd.dispenseId 
									WHERE odi.dispensingTime BETWEEN @startTime AND @endTime
									UNION ALL
										SELECT
											drugId,
											drugName,
											spec,
											price,
											packUnit,
											retreatNumber AS number,
											price*retreatNumber AS amount
										FROM
											t_drug_arrange_info
									 	WHERE		agoPreparingUserTime BETWEEN @startTime AND @endTime
							) as tab 
							LEFT JOIN T_DRUG_DICTIONARY AS tdd ON tab.drugId = tdd.id
							LEFT JOIN (
								SELECT
									name,
									code
								FROM
									t_code_standard_code
								WHERE
									sysName = '药库管理系统'
								AND codeType = '产地厂家'
							) AS origin ON tdd.origin = origin.code
							GROUP BY
												tdd.drugCode,
												tab.drugName,
												tab.spec,
												tab.price,
												tab.packUnit,
												origin.name

							ORDER BY 数量 DESC
) as tb

UNION ALL 

SELECT '合计','','','','',SUM(number),'',SUM(amount) FROM (
SELECT * FROM (
							SELECT 
							TOP 100
							tdd.drugCode AS drugCode,
							tab.drugName AS drugName,
							tab.spec AS spec,
							origin.name AS originName,
							tab.price AS price,
							SUM (tab.number) AS number,
							tab.packUnit AS packUnit,
							SUM (tab.amount) AS amount
							FROM(
									SELECT
										odd.drugId drugId,
										odd.drugName drugName,
										odd.spec spec,
										odd.price price,
										odd.number number,
										odd.packUnit packUnit,
										odd.amount amount
									FROM
										t_ph_outpatient_dispensing_information AS odi
									LEFT JOIN	t_ph_outpatient_dispensing_detail AS odd ON odi.dispenseId = odd.dispenseId 
									WHERE odi.dispensingTime BETWEEN @startTime AND @endTime
									UNION ALL
										SELECT
											drugId,
											drugName,
											spec,
											price,
											retreatNumber AS number,
											packUnit,
											price*retreatNumber AS amount
										FROM
											t_drug_arrange_info
									 	WHERE		agoPreparingUserTime BETWEEN @startTime AND @endTime
							) as tab 
							LEFT JOIN T_DRUG_DICTIONARY AS tdd ON tab.drugId = tdd.id
							LEFT JOIN (
								SELECT
									name,
									code
								FROM
									t_code_standard_code
								WHERE
									sysName = '药库管理系统'
								AND codeType = '产地厂家'
							) AS origin ON tdd.origin = origin.code
							LEFT JOIN (
								SELECT
									name,
									code
								FROM
									t_code_standard_code
								WHERE
									sysName = '药库管理系统'
								AND codeType = '药品单位'
							) AS unit ON tdd.packUnit = unit.code
							GROUP BY
												tdd.drugCode,
												tab.drugName,
												tab.spec,
												tab.price,
												tab.packUnit,
												origin.name

							ORDER BY number DESC
) as tb
) as ab


		END

END
go

