CREATE PROCEDURE [dbo].[zy_purchase_plan_warn]
AS
  -- routine body goes here, e.g.
  -- SELECT 'Navicat for SQL Server'
SELECT tdd.id AS drugId,
        tdd.drugCode AS drugCode,
        tdd.inputCode AS inputCode,
        tdd.drugName AS drugName,
				tdd.spec AS drugSpec,
				tdd.singleMaxNumber AS singleMaxNumber,
        tdd.singleMaxDose AS singleMaxDose,
        tdd.origin AS drugOrigin,
        tdd.packNumber AS packNumber,
        tdd.largePackNumber AS largePackNumber,
        tdd.basicDose AS basicDose,
        tdd.doseUnit AS doseUnit,
        tdd.basicPackUnit AS basicPackUnit,
        tdd.packUnit AS packUnit,
        tdd.largePackUnit AS largePackUnit,
        tddi.currentRealIn AS inNumber,
        tddi.currentRealOut AS outNumber,
        tddi.number-tddi.predictNumber AS number,
				tddi.alertUpper as alertUpper,
        tdd.minInventory AS alertLower,
        tdd.price AS price,
        tdd.wholesale AS wholesale
        from t_drug_dictionary AS tdd 
        INNER JOIN t_dsh_drug_info AS tddi ON tdd.id=tddi.drugId
				WHERE tdd.status=1 and tddi.alertLower>tddi.number and  tddi.alertUpper<=tddi.number
go

exec sp_addextendedproperty 'MS_Description', '药品采购计划查询警戒药品', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_purchase_plan_warn'
go

