CREATE PROCEDURE [dbo].[report_outpatient_register_day]
  @yearDate NVARCHAR(100) = '2019-07-01 00:00:00,2019-07-31 23:59:59'
AS
BEGIN
	DECLARE @curDate VARCHAR (100) 
  SET @curDate = SUBSTRING(@yearDate,0,20)  
	select  * into #table00 FROM ( 
	SELECT 
		mdays.n_day AS '日期', 
		CASE WHEN ( 
			outDeptNum.neike IS NULL 
			OR outDeptNum.neike = '' 
		) THEN 0 ELSE outDeptNum.neike END AS '内科', 
		CASE WHEN ( 
			outDeptNum.outOtp IS NULL 
			OR outDeptNum.outOtp = '' 
		) THEN 0 ELSE outDeptNum.outOtp END AS '外科', 
		CASE WHEN ( 
			outDeptNum.kouqiang IS NULL 
			OR outDeptNum.kouqiang = '' 
		) THEN 0 ELSE outDeptNum.kouqiang END AS '口腔科', 
		CASE WHEN ( 
			outDeptNum.neike + outDeptNum.kouqiang + outDeptNum.outOtp IS NULL 
			OR outDeptNum.neike + outDeptNum.kouqiang + outDeptNum.outOtp = '' 
		) THEN 0 ELSE outDeptNum.neike + outDeptNum.kouqiang + outDeptNum.outOtp END AS '合计' 
	FROM 
		--临时表mdays，显示当月全部日期 
		( 
			SELECT 
				CAST( 
					DAY ( 
						CONVERT ( 
							NVARCHAR (10), 
							DateAdd( 
								dd, 
								number, 
								DATENAME(yy, @curDate) + DATENAME(mm, @curDate) + '01' 
							), 
							120 
						) 
					) AS VARCHAR 
				) AS n_day 
			FROM 
				master..spt_values 
			WHERE 
				type = 'p' 
				AND number < DAY ( 
					DATEADD(MM, 1, @curDate) - DAY (@curDate) 
				) 
		) mdays 
		LEFT JOIN ( 
			--  按科室进行合计 
			SELECT 
				SUM ( 
					CASE deptCode WHEN 'B101' THEN 1 ELSE 0 END 
				) AS neike, 
				SUM ( 
					CASE deptCode WHEN 'B105' THEN 1 ELSE 0 END 
				) AS kouqiang, 
				SUM ( 
					CASE deptCode WHEN 'B103' THEN 1 ELSE 0 END 
				) AS outOtp, 
				DAY (regDate) AS n_day 
			FROM 
				t_outpatient_registration_info 
			WHERE 
				visitStatus <> -1
				AND
				--当月的开始日期 
				regDate BETWEEN DATENAME(yy, @curDate) + DATENAME(mm, @curDate) + '01' 
				AND --当月的结束日期 
				DATENAME(yy, @curDate) + DATENAME(mm, @curDate) + CAST ( 
					DAY ( 
						DATEADD(MM, 1, @curDate) - DAY (@curDate) 
					) AS VARCHAR 
				) 
			GROUP BY 
				DAY (regDate) 
		) outDeptNum ON outDeptNum.n_day = mdays.n_day 
	)tt1
	SELECT 
		* 
	FROM 
		#table00 
	UNION ALL 
	SELECT 
		'合计' AS 日期, 
		SUM(内科) AS 内科, 
		SUM(外科) AS 外科, 
		SUM(口腔科) AS 口腔科, 
		SUM(合计) AS 合计 
	FROM 
		#table00
END;
go

