CREATE PROCEDURE [dbo].[report_inject_drug](
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-04-30 23:59:59'
)
AS
BEGIN
DECLARE 
@startDate nvarchar(100),
@endDate nvarchar(100)

SET @startDate = SUBSTRING(@timeString,0,20)
SET @endDate = SUBSTRING(@timeString,21,20);


/*
@sql nvarchar(MAX)
SET @sql ='
SELECT a.docDept ' + CHAR(39) +'科室编码'+ CHAR(39) + ',
tcdi.deptName ' + CHAR(39) +'科室名称'+ CHAR(39) + ',
a.odRecipe ' + CHAR(39) +'门诊处方数'+ CHAR(39) + ' ,
b.injectRecipe ' + CHAR(39) +'针剂处方数'+ CHAR(39) + ',
CONVERT (VARCHAR(20), CONVERT(DECIMAL(18,2),(b.injectRecipe * 100.0/a.odRecipe),2) ) + '+ CHAR(39) + CHAR(37)+ CHAR(39) +' '+ CHAR(39) +'针剂药物处方百分比'+ CHAR(39) + ',
c.odRecipeDrug ' + CHAR(39) +'门诊处方药物品种数'+ CHAR(39) + ',
d.injectRecipeDrug ' + CHAR(39) +'针剂药物品种数'+ CHAR(39) + ',
CONVERT (VARCHAR(20), CONVERT(DECIMAL(18,2),(d.injectRecipeDrug * 100.0/c.odRecipeDrug),2) ) + '+ CHAR(39) + CHAR(37)+ CHAR(39) +' '+ CHAR(39) + '针剂药物使用品种百分比'+ CHAR(39) + '
FROM (
SELECT docDept,COUNT(1) odRecipe FROM t_doc_recipe_serial_count '
IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' WHERE recipeTime BETWEEN @startDate AND @endDate ' 
	 END
SET @sql = @sql +'
GROUP BY docDept) a INNER JOIN (
SELECT docDept,COUNT(1) injectRecipe FROM (
SELECT tdrsc.docDept,tdrd.recipeId FROM t_doc_recipe_serial_count tdrsc 
INNER JOIN t_doc_recipe_detail tdrd ON tdrsc.recipeId = tdrd.recipeId
INNER JOIN t_drug_dictionary d ON tdrd.itemId = d.id
WHERE d.dispenseType = 0 '
IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' AND tdrsc.recipeTime BETWEEN @startDate AND @endDate ' 
	 END
SET @sql = @sql +'
GROUP BY tdrsc.docDept,tdrd.recipeId ) a GROUP BY docDept ) b ON a.docDept= b.docDept
INNER JOIN (
SELECT docDept,COUNT(1) odRecipeDrug FROM (
SELECT tdrsc.docDept,tdrd.itemId FROM t_doc_recipe_serial_count tdrsc 
INNER JOIN t_doc_recipe_detail tdrd ON tdrsc.recipeId = tdrd.recipeId
INNER JOIN t_drug_dictionary d ON tdrd.itemId = d.id'
IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' WHERE tdrsc.recipeTime BETWEEN @startDate AND @endDate ' 
	 END
SET @sql = @sql +'
GROUP BY tdrsc.docDept,tdrd.itemId ) b GROUP BY docDept) c ON b.docDept= c.docDept
INNER JOIN (
SELECT docDept,COUNT(1) injectRecipeDrug FROM (
SELECT tdrsc.docDept,tdrd.itemId FROM t_doc_recipe_serial_count tdrsc 
INNER JOIN t_doc_recipe_detail tdrd ON tdrsc.recipeId = tdrd.recipeId
INNER JOIN t_drug_dictionary d ON tdrd.itemId = d.id
WHERE d.dispenseType = 0'
IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' AND tdrsc.recipeTime BETWEEN @startDate AND @endDate ' 
	 END
SET @sql = @sql +'
GROUP BY tdrsc.docDept,tdrd.itemId ) c GROUP BY docDept ) d ON c.docDept= d.docDept
INNER JOIN t_code_department_information tcdi ON a.docDept = tcdi.id'

EXEC sp_executesql @sql,N'@startDate nvarchar(100),@endDate nvarchar(100)',@startDate,@endDate
END

*/


WITH a AS(
SELECT CONVERT (VARCHAR(20),a.docDept) '科室编码',
tcdi.deptName '科室名称',
a.odRecipe'门诊处方数' ,
b.injectRecipe '针剂处方数',
CONVERT (VARCHAR(20), CONVERT(DECIMAL(18,2),(b.injectRecipe * 100.0/a.odRecipe),2) ) +'%' '针剂药物处方百分比',
c.odRecipeDrug '门诊处方药物品种数',
d.injectRecipeDrug '针剂药物品种数',
CONVERT (VARCHAR(20), CONVERT(DECIMAL(18,2),(d.injectRecipeDrug * 100.0/c.odRecipeDrug),2) ) +'%' '针剂药物使用品种百分比'
FROM (
SELECT docDept,COUNT(1) odRecipe FROM t_doc_recipe_serial_count
WHERE recipeTime BETWEEN @startDate AND @endDate
GROUP BY docDept) a 
INNER JOIN (
SELECT docDept,COUNT(1) injectRecipe FROM (
SELECT tdrsc.docDept,tdrd.recipeId FROM t_doc_recipe_serial_count tdrsc 
INNER JOIN t_doc_recipe_detail tdrd ON tdrsc.recipeId = tdrd.recipeId
INNER JOIN t_drug_dictionary d ON tdrd.itemId = d.id
WHERE d.dispenseType = 0 AND tdrsc.recipeTime BETWEEN @startDate AND @endDate
GROUP BY tdrsc.docDept,tdrd.recipeId ) a GROUP BY docDept ) b ON a.docDept= b.docDept
INNER JOIN (
SELECT docDept,COUNT(1) odRecipeDrug FROM (
SELECT tdrsc.docDept,tdrd.itemId FROM t_doc_recipe_serial_count tdrsc 
INNER JOIN t_doc_recipe_detail tdrd ON tdrsc.recipeId = tdrd.recipeId
INNER JOIN t_drug_dictionary d ON tdrd.itemId = d.id
WHERE tdrsc.recipeTime BETWEEN @startDate AND @endDate
GROUP BY tdrsc.docDept,tdrd.itemId ) b GROUP BY docDept) c ON b.docDept= c.docDept
INNER JOIN (
SELECT docDept,COUNT(1) injectRecipeDrug FROM (
SELECT tdrsc.docDept,tdrd.itemId FROM t_doc_recipe_serial_count tdrsc 
INNER JOIN t_doc_recipe_detail tdrd ON tdrsc.recipeId = tdrd.recipeId
INNER JOIN t_drug_dictionary d ON tdrd.itemId = d.id
WHERE d.dispenseType = 0 AND tdrsc.recipeTime BETWEEN @startDate AND @endDate
GROUP BY tdrsc.docDept,tdrd.itemId ) c GROUP BY docDept ) d ON c.docDept= d.docDept
INNER JOIN t_code_department_information tcdi ON a.docDept = tcdi.id )

SELECT * FROM a
UNION ALL
SELECT '合计',' ',SUM(a.门诊处方数), SUM(a.针剂处方数),
CONVERT (VARCHAR(20), CONVERT(DECIMAL(18,2),(SUM(a.针剂处方数) * 100.0/SUM(a.门诊处方数)),2) ) + '%',
SUM(a.门诊处方药物品种数),
SUM(a.针剂药物品种数),
CONVERT (VARCHAR(20), CONVERT(DECIMAL(18,2),(SUM(a.针剂药物品种数) * 100.0/SUM(a.门诊处方药物品种数)),2) ) + '%' FROM a

END
go

