CREATE PROCEDURE [dbo].[fee_special_getSelfCareRatio]
@accCode VARCHAR(100),
@itemType VARCHAR(100),
@itemCode VARCHAR(100)
AS 
BEGIN
	SELECT selfCareRatio FROM t_code_fee_special
where
itemType=@itemType 
	AND itemCode=@itemCode
	AND status = '1'
END
go

exec sp_addextendedproperty 'MS_Description', '特殊收费-获取自理比例', 'SCHEMA', 'dbo', 'PROCEDURE',
     'fee_special_getSelfCareRatio'
go

