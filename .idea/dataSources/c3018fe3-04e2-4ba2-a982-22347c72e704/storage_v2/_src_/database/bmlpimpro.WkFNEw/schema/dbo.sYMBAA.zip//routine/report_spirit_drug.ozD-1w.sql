CREATE PROCEDURE [dbo].[report_spirit_drug](
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-04-30 23:59:59'
)
AS
BEGIN
DECLARE 
@startDate nvarchar(100),
@endDate nvarchar(100),
@sql nvarchar(MAX)

SET @sql ='
SELECT di.dispensingTime ' + CHAR(39) + '发药时间 ' + CHAR(39) + ',
di.patientName ' + CHAR(39) + '姓名' + CHAR(39) + ',
dd.drugName ' + CHAR(39) + '药品名称' + CHAR(39) + ',
dd.spec ' + CHAR(39) + '规格' + CHAR(39) + ',
CONVERT(varchar(10), dd.number) + dd.packUnit ' + CHAR(39) + '数量单位' + CHAR(39) + ',
 NULL' + CHAR(39) + '批号' + CHAR(39) + '
FROM 
t_drug_dictionary d
INNER JOIN t_ph_outpatient_dispensing_detail dd ON d.id = dd.drugId
INNER JOIN t_ph_outpatient_dispensing_information di ON di.dispenseId = dd.dispenseId
WHERE di.state = 3 AND d.drugAttribute IN(2,3) AND dd.number > 0'
IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' AND di.dispensingTime BETWEEN @startDate AND @endDate ' 
	 END
SET @sql = @sql +'
UNION ALL
SELECT 
dai.createTime ' + CHAR(39) + '发药时间' + CHAR(39) + ',
spbi.name ' + CHAR(39) + '姓名'+ CHAR(39) + ',
dai.drugName ' + CHAR(39) +'药品名称'+ CHAR(39) + ',
dai.spec ' + CHAR(39) + '规格' + CHAR(39) + ',
CONVERT(varchar(10), (dai.alreadyNumber- ISNULL(dai.pleaseReturnNumber,0))) + dai.packUnit ' + CHAR(39) + '数量单位' + CHAR(39) + ',
 NULL' + CHAR(39) + '批号' + CHAR(39) + '
FROM 
t_drug_dictionary d
INNER JOIN t_drug_arrange_info dai ON d.id = dai.drugId
INNER JOIN t_system_patient_basic_info spbi ON dai.outPNo = spbi.outPNo
WHERE d.drugAttribute IN(2,3) AND dai.alreadyNumber- ISNULL(dai.pleaseReturnNumber,0) >0'
IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' AND dai.createTime BETWEEN @startDate AND @endDate ' 
	 END	 
	 	 
EXEC sp_executesql @sql,N'@startDate nvarchar(100),@endDate nvarchar(100)',@startDate,@endDate
END
go

