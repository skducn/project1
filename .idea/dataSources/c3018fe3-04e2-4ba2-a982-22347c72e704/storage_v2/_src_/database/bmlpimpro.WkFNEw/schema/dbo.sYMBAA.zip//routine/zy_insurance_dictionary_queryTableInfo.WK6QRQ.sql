CREATE PROCEDURE [dbo].[zy_insurance_dictionary_queryTableInfo]
AS
Select a.colid,a.name AS columns,
			CONVERT(nvarchar(50),isnull(g.[value],''))as annotation
			FROM SysColumns as a
            left join sys.extended_properties as g
            on a.id=G.major_id
            and a.colid=g.minor_id
        Where id=Object_Id('t_code_insurance_dictionary') 
AND  a.colid BETWEEN 2 AND 3
go

exec sp_addextendedproperty 'MS_Description', '查询出医保表字段对应的注释', 'SCHEMA', 'dbo', 'PROCEDURE',
     'zy_insurance_dictionary_queryTableInfo'
go

