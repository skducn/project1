CREATE PROCEDURE [dbo].[report_outpatient_medicareFee_total]
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-04-30 23:59:59'
-- @recordCount int output --关键字代表输出参数
as
begin
declare @enterTime nvarchar(50),
@leaveTime nvarchar(50),
@allTime nvarchar(100)
set @allTime = @timeString
set @enterTime = substring(@allTime,0,20)
set @leaveTime = substring(@allTime,21,20)
CREATE TABLE #month_title 
-- 月份临时表及表头
( 
    title NVARCHAR(50),
    sort int
)INSERT INTO #month_title VALUES 
('一月份',1),('二月份',2),('三月份',3),('一季度',4), 
('四月份',5),('五月份',6),('六月份',7),('二季度',8),('上半年',9), 
('七月份',10),('八月份',11),('九月份',12),('三季度',13), 
('十月份',14),('十一月份',15),('十二月份', 16),('四季度',17),('下半年',18), 
('全年',19)
SELECT 
#month_title.title AS '年份', 
CASE WHEN ( 
 dataSet.allNum IS NULL 
 OR dataSet.allNum = '' 
) THEN 0 ELSE dataSet.allNum END AS '门急诊次数',
CASE WHEN ( 
dataSet.totalIncome IS NULL 
OR dataSet.totalIncome = '' 
) THEN 0 ELSE dataSet.totalIncome END AS '总收入（元）',
CASE WHEN ( 
dataSet.drugRatio IS NULL 
OR dataSet.drugRatio = '' 
) THEN 0 ELSE
Convert(decimal(18,2),dataSet.drugRatio * 100)
END AS '药占比（%）',
CASE WHEN ( 
dataSet.avgCost IS NULL 
OR dataSet.avgCost = '' 
) THEN 0 ELSE
Convert(decimal(18,2),dataSet.avgCost)
END AS '均次费（元）',
CASE WHEN ( 
dataSet.tcmNum IS NULL 
OR dataSet.tcmNum = '' 
) THEN 0 ELSE dataSet.tcmNum END AS '中药张数',
CASE WHEN ( 
dataSet.tcmTotal IS NULL 
OR dataSet.tcmTotal = '' 
) THEN 0 ELSE dataSet.tcmTotal END AS '中药收入（元）',
CASE WHEN ( 
dataSet.wmNum IS NULL 
OR dataSet.wmNum = '' 
) THEN 0 ELSE dataSet.wmNum END AS '西药张数',
CASE WHEN ( 
dataSet.wmTotal IS NULL 
OR dataSet.wmTotal = '' 
) THEN 0 ELSE dataSet.wmTotal END AS '西药收入（元）',
CASE WHEN ( 
dataSet.useUpTotal IS NULL 
OR dataSet.useUpTotal = '' 
) THEN 0 ELSE 
Convert(decimal(18,2),dataSet.useUpTotal)
--dataSet.useUpTotal
END AS '病房药房日消耗（元）'
FROM 
#month_title 
LEFT JOIN 
( 
 SELECT 
 CASE 
  WHEN Grouping(h_year)=1 AND Grouping(quarter)=1 AND Grouping(l_month)=1 THEN '全年' 
  WHEN Grouping(quarter)=1  AND Grouping(l_month)=1 THEN h_year 
  WHEN Grouping(l_month)=1 THEN quarter 
 ELSE 
  (CASE l_month WHEN '1' THEN '一月份' 
  WHEN '2' THEN '二月份' 
  WHEN '3' THEN '三月份' 
  WHEN '4' THEN '四月份' 
  WHEN '5' THEN '五月份' 
  WHEN '6' THEN '六月份' 
  WHEN '7' THEN '七月份' 
  WHEN '8' THEN '八月份' 
  WHEN '9' THEN '九月份' 
  WHEN '10' THEN '十月份' 
  WHEN '11' THEN '十一月份' 
  WHEN '12' THEN '十二月份' 
  ELSE l_month END) 
 END 
 AS title, 
 SUM(allNum) AS allNum,
 SUM(totalIncome) AS totalIncome,
avg(drugRatio) as drugRatio,
avg(avgCost) as avgCost,
 SUM(tcmNum) as tcmNum,
SUM(tcmTotal) as tcmTotal,
SUM(wmNum) as wmNum,
SUM(wmTotal) as wmTotal,
SUM(useUpTotal) as useUpTotal
 FROM (
select
--门急诊人次
SUM(b.allNum) as allNum,
--allNum,
--COUNT(DISTINCT b.visitId) as allNum,
--总收入
SUM(a.amount + b.amount) as totalIncome,
--药占比
SUM(a.medicineFee)/SUM(a.amount + b.amount) as drugRatio,
--AVG(a.useUpTotal/(a.amount + b.amount)) as drugRatio,
--AVG(a.medicineFee/(a.amount + b.amount)) as drugRatio,
--COUNT(b.allNum) as drugRatio,
--均次费(总收入/总人次)
case when COUNT(b.allNum)=0 then 0
else 
AVG((a.amount + b.amount)/b.allNum) END as avgCost,
--中药张数
SUM(a.tcmNum) as tcmNum,
--中药收入（元）
SUM(a.tcmTotal) as tcmTotal,
--西药张数
SUM(a.wmNum)as wmNum,
--西药收入（元）
SUM(a.wmTotal) as wmTotal,
--药房当天药品所有费
SUM(a.useUpTotal)/dbo.[report_days_func](MAX(b.regDate)) as useUpTotal,
CONVERT(VARCHAR, Month(b.regDate)) AS l_month, 
  CASE WHEN Month(b.regDate) < 4 THEN '一季度' 
   WHEN Month(b.regDate) < 7 THEN '二季度' 
   WHEN Month(b.regDate) < 10 THEN '三季度' 
   WHEN Month(b.regDate) < 13 THEN '四季度' 
  END 
  AS quarter, 
  CASE WHEN Month(b.regDate) < 7 THEN '上半年' 
   WHEN Month(b.regDate) < 13 THEN '下半年' 
  END 
  AS h_year 
from
( select
   reg_info.visitId,
   --门急诊人次
   COUNT(*) AS allNum,
   -- 挂号时间
	 Max(reg_info.regDate) regDate,
   -- 挂号费
   sum(reg_inv.totalFee) as amount
   from t_outpatient_registration_info AS reg_info
   LEFT JOIN t_outpatient_registration_data AS reg_data ON reg_data.visitId = reg_info.visitId
   LEFT JOIN t_outpatient_registration_invoice AS reg_inv ON reg_inv.invoiceId = reg_data.invoiceId
   where reg_info.regDate BETWEEN @enterTime AND @leaveTime and reg_info.visitStatus != -1 GROUP BY reg_info.visitId
 ) as b 
 LEFT JOIN (
   select
   visitId,
   sum(amount) as amount,
   --COUNT(DISTINCT visitId) AS allNum,
   -- 中药张数
  COUNT(
		CASE
			when itemType = 06 THEN itemType ELSE null END
		) AS tcmNum,
		-- 中药收入（元）
		SUM(
			CASE
			when itemType = 06 THEN amount ELSE 0 END
		) AS tcmTotal,
		-- 西药张数
		COUNT(
			CASE
			when itemType = 03 THEN itemType ELSE null END
		) AS wmNum,
		-- 西药收入（元）
		SUM(
			CASE
			when itemType = 03 THEN amount ELSE 0 END
		) AS wmTotal,
		-- 药房当天药品所有费
		SUM(
			CASE
			when itemType = 03 THEN amount
			when itemType = 06 THEN amount
			when itemType = 09 THEN amount END
		) AS useUpTotal,
    -- 药品所有费用
		SUM(
			CASE
			when itemType = 03 THEN amount
			when itemType = 06 THEN amount
			when itemType = 09 THEN amount END
		) AS medicineFee
   from t_outpatient_cashier_detail AS cas_det
   LEFT JOIN t_outpatient_cashier_invoice AS cas_inv ON cas_det.invoiceId = cas_inv.invoiceId
   where cas_det.detailTime BETWEEN @enterTime AND @leaveTime 
   AND cas_inv.invoiceStatus = 2 
   GROUP BY cas_det.visitId
 ) as a on a.visitId = b.visitId GROUP BY Month(b.regDate)) tab 
 GROUP BY h_year, quarter, l_month WITH rollup 
) dataSet ON dataSet.title = #month_title.title
ORDER BY #month_title.sort
end;
go

