CREATE PROCEDURE [dbo].[outpatient_income_sum]
@condition nvarchar(50)
        as
        begin
        DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
        IF (@condition IS NOT NULL AND @condition != '')
        BEGIN
        SET @startTime = SUBSTRING(@condition,0,20)
        SET @endTime = SUBSTRING(@condition,21,20)
        END

        select
        max(case when rownumber %3 = 1 then  typeName else null end) 收费项目1,
        Convert(decimal(18,2), Round( max(case when rownumber %3 = 1 then  amount else null end), 2 ) ) 项目金额1,
        max(case when rownumber %3 = 2 then  typeName else null end) 收费项目2,
        Convert(decimal(18,2), Round( max(case when rownumber %3 = 2 then  amount else null end), 2 ) ) 项目金额2,
        max(case when rownumber %3 = 0 then  typeName else null end) 收费项目3,
        Convert(decimal(18,2), Round( max(case when rownumber %3 = 0 then  amount else null end), 2 ) ) 项目金额3
        from
        (
        select rownumber = Row_number() over (order by t.itemType),* from
        (
        select detail.itemType,
        category.typeName,
        Convert(decimal(18,2), Round( sum(detail.amount), 2 ) ) as amount
        from bmlpimpro.dbo.t_outpatient_cashier_invoice invoice
        left join bmlpimpro.dbo.t_outpatient_cashier_detail detail on invoice.invoiceId = detail.invoiceId
        left join bmlpimpro.dbo.t_code_item_category category on detail.itemType = category.itemType
        where detail.itemType is not null and invoice.payDate > @startTime and invoice.payDate < @endTime and invoice.invoiceStatus in (0,1,2)
        group by detail.itemType,category.typeName
        )t
        )t1 group by (rownumber-1)/3

        UNION ALL

        select '合计',
        Convert(decimal(18,2), Round( sum(detail.amount), 2 ) ),
        null,null,null,null
        from bmlpimpro.dbo.t_outpatient_cashier_invoice invoice
        left join bmlpimpro.dbo.t_outpatient_cashier_detail detail on invoice.invoiceId = detail.invoiceId
        left join bmlpimpro.dbo.t_code_item_category category on detail.itemType = category.itemType
        where detail.itemType is not null and invoice.payDate > @startTime and invoice.payDate < @endTime and invoice.invoiceStatus in (0,1,2)
        end
go

