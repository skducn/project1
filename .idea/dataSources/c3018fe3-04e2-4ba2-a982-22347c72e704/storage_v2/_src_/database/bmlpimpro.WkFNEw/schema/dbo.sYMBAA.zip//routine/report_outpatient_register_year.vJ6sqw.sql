CREATE PROCEDURE [dbo].[report_outpatient_register_year]
  @yearDate NVARCHAR(100) = '2020-01-01 00:00:00,2020-12-31 23:59:59'
AS
BEGIN
	DECLARE @startDate VARCHAR (100),@endDate VARCHAR(100) 
	SET @startDate = SUBSTRING(@yearDate,0,20)
	SET @endDate = SUBSTRING(@yearDate,21,20)
	CREATE TABLE #month_title 
	-- 月份临时表及表头
	( 
			title NVARCHAR(50),
			sort int
	)INSERT INTO #month_title VALUES 
	('一月份',1),('二月份',2),('三月份',3),('一季度',4), 
	('四月份',5),('五月份',6),('六月份',7),('二季度',8),('上半年',9), 
	('七月份',10),('八月份',11),('九月份',12),('三季度',13), 
	('十月份',14),('十一月份',15),('十二月份', 16),('四季度',17),('下半年',18), 
	('全年',19)
	SELECT 
	#month_title.title AS '年份', 
	CASE WHEN ( 
	 dataSet.allNum IS NULL 
	 OR dataSet.allNum = '' 
	) THEN 0 ELSE dataSet.allNum END AS '总计', 
	CASE WHEN ( 
	 dataSet.outp_num IS NULL 
	 OR dataSet.outp_num = '' 
	) THEN 0 ELSE dataSet.outp_num END AS '门诊', 
	CASE WHEN ( 
	 dataSet.eme_num IS NULL 
	 OR dataSet.eme_num = '' 
	) THEN 0 ELSE dataSet.eme_num END AS '急诊', 
	CASE WHEN ( 
	 dataSet.in_num IS NULL 
	 OR dataSet.in_num = '' 
	) THEN 0 ELSE dataSet.in_num END AS '内科-合计', 
	CASE WHEN ( 
	 dataSet.in_outp_num IS NULL 
	 OR dataSet.in_outp_num = '' 
	) THEN 0 ELSE dataSet.in_outp_num END AS '内科-门诊', 
	CASE WHEN ( 
	 dataSet.in_eme_num IS NULL 
	 OR dataSet.in_eme_num = '' 
	) THEN 0 ELSE dataSet.in_eme_num END AS '内科-急诊', 
	CASE WHEN ( 
	 dataSet.sur_num IS NULL 
	 OR dataSet.sur_num = '' 
	) THEN 0 ELSE dataSet.sur_num END AS '外科-合计', 
	CASE WHEN ( 
	 dataSet.sur_outp_num IS NULL 
	 OR dataSet.sur_outp_num = '' 
	) THEN 0 ELSE dataSet.sur_outp_num END AS '外科-门诊', 
	CASE WHEN ( 
	 dataSet.sur_eme_num IS NULL 
	 OR dataSet.sur_eme_num = '' 
	) THEN 0 ELSE dataSet.sur_eme_num END AS '外科-急诊', 
	CASE WHEN ( 
	 dataSet.dep_num IS NULL 
	 OR dataSet.dep_num = '' 
	) THEN 0 ELSE dataSet.dep_num END AS '口腔科-合计', 
	CASE WHEN ( 
	 dataSet.dep_outp_num IS NULL 
	 OR dataSet.dep_outp_num = '' 
	) THEN 0 ELSE dataSet.dep_outp_num END AS '口腔科-门诊', 
	CASE WHEN ( 
	 dataSet.dep_eme_num IS NULL 
	 OR dataSet.dep_eme_num = '' 
	) THEN 0 ELSE dataSet.dep_eme_num END AS '口腔科-急诊'
	FROM 
	#month_title 
	LEFT JOIN 
	( 
	 SELECT 
	 CASE 
		WHEN Grouping(h_year)=1 AND Grouping(quarter)=1 AND Grouping(l_month)=1 THEN '全年' 
		WHEN Grouping(quarter)=1  AND Grouping(l_month)=1 THEN h_year 
		WHEN Grouping(l_month)=1 THEN quarter 
	 ELSE 
		(CASE l_month WHEN '1' THEN '一月份' 
		WHEN '2' THEN '二月份' 
		WHEN '3' THEN '三月份' 
		WHEN '4' THEN '四月份' 
		WHEN '5' THEN '五月份' 
		WHEN '6' THEN '六月份' 
		WHEN '7' THEN '七月份' 
		WHEN '8' THEN '八月份' 
		WHEN '9' THEN '九月份' 
		WHEN '10' THEN '十月份' 
		WHEN '11' THEN '十一月份' 
		WHEN '12' THEN '十二月份' 
		ELSE l_month END) 
	 END 
	 AS title, 
	 SUM(allNum) AS allNum,
	 SUM (outp_num) AS outp_num,
	 SUM (eme_num) AS eme_num,
	 SUM (in_num) AS in_num,
	 SUM (in_outp_num) AS in_outp_num,
	 SUM (in_eme_num) AS in_eme_num,
	 SUM (sur_num) AS sur_num,
	 SUM (sur_outp_num) AS sur_outp_num,
	 SUM (sur_eme_num) AS sur_eme_num,
	 SUM (dep_num) AS dep_num,
	 SUM (dep_outp_num) AS dep_outp_num,
	 SUM (dep_eme_num) AS dep_eme_num
	 FROM 
	 ( 
		SELECT 
	--  合计
	 COUNT(*) AS allNum, 
	--  门诊
	 SUM (
		CASE
		WHEN categoryCode = 1 THEN
		 1
		ELSE
		 0
		END
	 ) AS outp_num,
	-- 急诊
	 SUM (
		CASE
		WHEN categoryCode = 2 THEN
		 1
		ELSE
		 0
		END
	 ) AS eme_num,
	--  内科合计
	 SUM (
		CASE
		WHEN deptCode = 'B101' THEN
		 1
		ELSE
		 0
		END
	 ) AS in_num,
	--  内科门诊
	 SUM (
		CASE
		WHEN deptCode = 'B101' AND categoryCode = 1 THEN
		 1
		ELSE
		 0
		END
	 ) AS in_outp_num,
	--  内科急诊
	 SUM (
		CASE
		WHEN deptCode = 'B101' AND categoryCode = 2 THEN
		 1
		ELSE
		 0
		END
	 ) AS in_eme_num,
	--  外科合计
	 SUM (
		CASE
		WHEN deptCode = 'B103' THEN
		 1
		ELSE
		 0
		END
	 ) AS sur_num,
	--  外科门诊
	 SUM (
		CASE
		WHEN deptCode = 'B103' AND categoryCode = 1 THEN
		 1
		ELSE
		 0
		END
	 ) AS sur_outp_num,
	--  外科急诊
	 SUM (
		CASE
		WHEN deptCode = 'B103' AND categoryCode = 2 THEN
		 1
		ELSE
		 0
		END
	 ) AS sur_eme_num,
	--  口腔科合计
	 SUM (
		CASE
		WHEN deptCode = 'B105' THEN
		 1
		ELSE
		 0
		END
	 ) AS dep_num,
	--  口腔科门诊
	 SUM (
		CASE
		WHEN deptCode = 'B105' AND categoryCode = 1 THEN
		 1
		ELSE
		 0
		END
	 ) AS dep_outp_num,
	--  口腔科急诊
	 SUM (
		CASE
		WHEN deptCode = 'B105' AND categoryCode = 2 THEN
		 1
		ELSE
		 0
		END
	 ) AS dep_eme_num,
		CONVERT(VARCHAR, Month(regDate)) AS l_month, 
		CASE WHEN Month(regDate) < 4 THEN '一季度' 
		 WHEN Month(regDate) < 7 THEN '二季度' 
		 WHEN Month(regDate) < 10 THEN '三季度' 
		 WHEN Month(regDate) < 13 THEN '四季度' 
		END 
		AS quarter, 
		CASE WHEN Month(regDate) < 7 THEN '上半年' 
		 WHEN Month(regDate) < 13 THEN '下半年' 
		END 
		AS h_year 
		FROM t_outpatient_registration_info 
		WHERE visitStatus <> -1 AND regDate BETWEEN @startDate AND @endDate 
		GROUP BY Year(regDate), Month(regDate) 
	 ) tab 
	 GROUP BY h_year, quarter, l_month WITH rollup 
	) dataSet ON dataSet.title = #month_title.title
	ORDER BY #month_title.sort
END;
---------
go

