CREATE PROCEDURE [dbo].[outp_payment_summary](
@condition nvarchar(50))
as
begin
DECLARE
@startTime nvarchar(20),
@endTime nvarchar(20)
IF (@condition IS NOT NULL AND @condition != '')

    BEGIN
    SET @startTime = SUBSTRING(@condition,0,20)
    SET @endTime = SUBSTRING(@condition,21,20)
		END

-- select 
-- userNo as '编号',
-- userName as '收款员',
-- SUM(现金) 现金,
-- SUM(微信) 微信,
-- SUM(支付宝) 支付宝,
-- SUM(统筹支付) 统筹支付,
-- SUM(医保卡) 医保卡,
-- SUM(银联卡) 银联卡,
-- SUM(现金+微信+支付宝+统筹支付+医保卡+银联卡) 总计
-- from
-- (
-- 	select 
-- 	ii.userCode userno,
-- 	username username,
-- 	SUM(case   when payway=1  then ii.totalFee else 0 end ) 现金,
-- 	SUM(case   when payway=3  then ii.totalFee else 0 end ) 微信,
-- 	SUM(case   when payway=4  then ii.totalFee else 0 end ) 支付宝,
-- 	sum(case   when accCode =12 then ii.totalFee else 0 end ) 统筹支付,
-- 	SUM(case   when payway=8  then ii.totalFee else 0 end ) 医保卡,
-- 	SUM(case   when payway=6  then ii.totalFee else 0 end ) 银联卡
-- 	from 
-- 	t_outpatient_registration_invoice ii	
-- 	left join t_outpatient_registration_pay pp on ii.invoiceId=pp.invoiceId
-- 	left join bmluserpro.dbo.sys_user us on us.id = ii.userid
-- 	where payDate  between  @startTime  and  @endTime and invoiceStatus in (0,1,2)
-- 	group by ii.userCode,username
-- union ALL
-- 	select 
-- 	ii.userCode userno,
-- 	username username,
-- 	SUM(case   when payway=1  then pp.payAmount else 0 end ) 现金,
-- 	SUM(case   when payway=3  then pp.payAmount else 0 end ) 微信,
-- 	SUM(case   when payway=4  then pp.payAmount else 0 end ) 支付宝,
-- 	sum(case   when accCode =12 then pp.payAmount else 0 end ) 统筹支付,
-- 	SUM(case   when payway=8  then pp.payAmount else 0 end ) 医保卡,
-- 	SUM(case   when payway=6  then pp.payAmount else 0 end ) 银联卡
-- 	from 
-- 	t_outpatient_cashier_invoice ii	
-- 	left join t_outpatient_cashier_pay pp on ii.invoiceId=pp.invoiceId
-- 	left join bmluserpro.dbo.sys_user us on us.id = ii.userid
-- 	where payDate  between  @startTime  and  @endTime and invoiceStatus in (0,1,2)
-- 	group by ii.userCode,username
-- ) a 
-- group by a.userno,a.username

(
select 
userNo as '编号',
userName as '收款员',
SUM(现金) 现金,
SUM(微信) 微信,
SUM(支付宝) 支付宝,
SUM(统筹支付) 统筹支付,
SUM(医保卡) 医保卡,
SUM(银联卡) 银联卡,
SUM(合计) 总计
from
(
	select 
	ii.userCode userno,
	username username,
	SUM(case   when payway=1  then ii.totalFee else 0 end ) 现金,
	SUM(case   when payway=3  then ii.totalFee else 0 end ) 微信,
	SUM(case   when payway=4  then ii.totalFee else 0 end ) 支付宝,
	sum(case   when accCode =12 then ii.accFee else 0 end ) 统筹支付,
	SUM(case   when payway=8  then ii.totalFee else 0 end ) 医保卡,
	SUM(case   when payway=6  then ii.totalFee else 0 end ) 银联卡,
		SUM(ii.totalFee) 合计
	from 
	t_outpatient_registration_invoice ii	
	left join t_outpatient_registration_pay pp on ii.invoiceId=pp.invoiceId
	left join bmluserpro.dbo.sys_user us on us.id = ii.userid
	where payDate  between  @startTime  and  @endTime and invoiceStatus in (0,1,2) and ii.userCode != 6108
	group by ii.userCode,username
union ALL
	select 
	ii.userCode userno,
	username username,
	SUM(case   when payway=1  then pp.payAmount else 0 end ) 现金,
	SUM(case   when payway=3  then pp.payAmount else 0 end ) 微信,
	SUM(case   when payway=4  then pp.payAmount else 0 end ) 支付宝,
	sum( ii.refundAmount ) 统筹支付,
	SUM(case   when payway=8  then pp.payAmount else 0 end ) 医保卡,
	SUM(case   when payway=6  then pp.payAmount else 0 end ) 银联卡,
	SUM(ii.totalAmount) 合计
	from 
	t_outpatient_cashier_invoice ii	
	left join t_outpatient_cashier_pay pp on ii.invoiceId=pp.invoiceId
	left join bmluserpro.dbo.sys_user us on us.id = ii.userid
	where payDate  between  @startTime  and  @endTime and invoiceStatus in (0,1,2) and ii.userCode != 6108
	group by ii.userCode,username
) a 
group by a.userNo,a.userName
)

union ALL
(
select 
' ' as 编号,
'合计' as 收款员,
SUM(现金) 现金,
SUM(微信) 微信,
SUM(支付宝) 支付宝,
SUM(统筹支付) 统筹支付,
SUM(医保卡) 医保卡,
SUM(银联卡) 银联卡,
SUM(合计) 总计
from
(
	select 
	ii.userCode userno,
	username username,
	SUM(case   when payway=1  then ii.totalFee else 0 end ) 现金,
	SUM(case   when payway=3  then ii.totalFee else 0 end ) 微信,
	SUM(case   when payway=4  then ii.totalFee else 0 end ) 支付宝,
	sum(ii.accFee) 统筹支付,
	SUM(case   when payway=8  then ii.totalFee else 0 end ) 医保卡,
	SUM(case   when payway=6  then ii.totalFee else 0 end ) 银联卡,
		SUM(ii.totalFee) 合计
	from 
	t_outpatient_registration_invoice ii	
	left join t_outpatient_registration_pay pp on ii.invoiceId=pp.invoiceId
	left join bmluserpro.dbo.sys_user us on us.id = ii.userid
	where payDate  between  @startTime  and  @endTime and invoiceStatus in (0,1,2) and ii.userCode != 6108
	group by ii.userCode,username
union ALL
	select 
	ii.userCode userno,
	username username,
	SUM(case   when payway=1  then pp.payAmount else 0 end ) 现金,
	SUM(case   when payway=3  then pp.payAmount else 0 end ) 微信,
	SUM(case   when payway=4  then pp.payAmount else 0 end ) 支付宝,
	sum(ii.refundAmount ) 统筹支付,
	SUM(case   when payway=8  then pp.payAmount else 0 end ) 医保卡,
	SUM(case   when payway=6  then pp.payAmount else 0 end ) 银联卡,
	SUM(ii.totalAmount) 合计
	from 
	t_outpatient_cashier_invoice ii	
	left join t_outpatient_cashier_pay pp on ii.invoiceId=pp.invoiceId
	left join bmluserpro.dbo.sys_user us on us.id = ii.userid
	where  payDate  between  @startTime  and  @endTime and invoiceStatus in (0,1,2) and ii.userCode != 6108
	group by ii.userCode,username
) b
)
end
go

