CREATE PROCEDURE [dbo].[report_outpatient_drug_revenue_expenditure_details]
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-4-30 23:59:59'
as
begin
declare @enterTime nvarchar(50),
@leaveTime nvarchar(50),
@allTime nvarchar(100)
set @allTime = @timeString
set @enterTime = substring(@allTime,0,20)
set @leaveTime = substring(@allTime,21,20)
SELECT
    income.[payDateIN] AS 就诊日期,
    income.nameIN AS 姓名,
    income.outPNoIN AS 门诊号,
    income.[收入西药费],
    expenditure.[支出西药费],
    income.[收入成药费],
    expenditure.[支出成药费],
    income.[收入草药费],
    expenditure.[支出草药费]
FROM
    (
    SELECT CONVERT(VARCHAR(100 ), invoice.payDate, 23) AS payDateIN,
        invoice.name AS nameIN,
        invoice.outPNo AS outPNoIN,
        SUM ( CASE detail.itemType WHEN '03' THEN detail.amount ELSE 0 END ) AS 收入西药费,
        SUM ( CASE detail.itemType WHEN '06' THEN detail.amount ELSE 0 END ) AS 收入成药费,
        SUM ( CASE detail.itemType WHEN '09' THEN detail.amount ELSE 0 END ) AS 收入草药费
    FROM
        t_outpatient_cashier_invoice invoice
        INNER JOIN t_outpatient_cashier_detail detail ON detail.invoiceId = invoice.invoiceId
    WHERE
        invoice.payDate
				BETWEEN @enterTime
        AND @leaveTime
        AND detail.itemType IN ( '03', '06', '09' )
    GROUP BY
        CONVERT ( VARCHAR ( 100 ), invoice.payDate, 23 ),
        invoice.name,
        invoice.outPNo
    ) income
    LEFT JOIN (
    SELECT CONVERT
        (VARCHAR (100), information.settleAccountsTime, 23) AS payDateEX,
        invoice.name AS nameEX,
        invoice.outPNo AS outPNoEX,
        SUM ( CASE dis_detail.itemType WHEN '03' THEN dis_detail.amount ELSE 0 END ) AS 支出西药费,
        SUM ( CASE dis_detail.itemType WHEN '06' THEN dis_detail.amount ELSE 0 END ) AS 支出成药费,
        SUM ( CASE dis_detail.itemType WHEN '09' THEN dis_detail.amount ELSE 0 END ) AS 支出草药费
    FROM
        t_outpatient_cashier_invoice invoice
        INNER JOIN t_ph_outpatient_dispensing_information information ON information.invoiceId = invoice.invoiceId
        INNER JOIN t_ph_outpatient_dispensing_detail dis_detail ON information.dispenseId = dis_detail.dispenseId
    WHERE
        information.settleAccountsTime
				BETWEEN @enterTime
        AND @leaveTime
        AND dis_detail.itemType IN ( '03', '06', '09' )
				AND information.state = 3
    GROUP BY
        CONVERT ( VARCHAR ( 100 ), information.settleAccountsTime, 23 ),
        invoice.name,
        invoice.outPNo
    ) expenditure ON income.payDateIN= expenditure.payDateEX
    AND income.outPNoIN= expenditure.outPNoEX
END;
go

