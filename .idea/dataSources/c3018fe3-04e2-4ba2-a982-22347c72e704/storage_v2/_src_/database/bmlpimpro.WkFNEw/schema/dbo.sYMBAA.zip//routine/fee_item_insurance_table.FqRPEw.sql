CREATE PROCEDURE [dbo].[fee_item_insurance_table]
AS
BEGIN
	SELECT
	CONVERT(VARCHAR(100),B.name) AS columnName,
	CONVERT(VARCHAR(100),C.value) AS columnDesc
	FROM sys.objects AS A
	INNER JOIN sys.columns AS B ON B.object_id = A.object_id
	LEFT JOIN sys.extended_properties AS C ON C.major_id = B.object_id AND C.minor_id = B.column_id
	WHERE A.name = 't_code_insurance_dictionary'
	AND B.column_id BETWEEN 2 AND 3
END
go

exec sp_addextendedproperty 'MS_Description', '收费项目--获取医保表格结构', 'SCHEMA', 'dbo', 'PROCEDURE', 'fee_item_insurance_table'
go

