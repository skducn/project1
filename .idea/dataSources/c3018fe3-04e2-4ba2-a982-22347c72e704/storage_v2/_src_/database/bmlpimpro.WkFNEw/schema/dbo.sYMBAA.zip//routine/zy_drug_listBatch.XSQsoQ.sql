CREATE PROCEDURE [dbo].[zy_drug_listBatch](
@screen VARCHAR(50),
@westMedicine VARCHAR(50),
@centreMedicine VARCHAR(50),
@becomeMedicine VARCHAR(50),
@classify VARCHAR(50),
@filtrate VARCHAR(50),
@length INT,
@initialPosition INT,
@deptId INT
)
AS
DECLARE @sql nvarchar(MAX)
SET @sql = 'select dici.id AS drugId,
				dici.unifyPropertyBidInviting AS unifyPropertyBidInviting,
        dici.drugCategory AS drugType,
        dici.drugCode AS drugCode,
        dici.drugName AS drugName,
        dici.spec AS drugStandard,
        dici.inputCode AS inputCode,
        dici.origin AS origin,
        dici.largePackNumber AS largePackAmount,
        dici.largePackUnit AS largePackUnit,
        drug.wholesale AS wholesale,
        drug.price AS price,
				
				drug.lastRealOpening AS lastStock,
				(drug.lastRealOpening*drug.price) AS lastSum,
        drug.currentRealOpening AS lastRealOpening,
        drug.currentInvoiceOpening AS lastInvoiceOpening,
        drug.number AS currentRealOpening,
        drug.invoiceNumber AS currentInvoiceOpening,
				drug.currentInvoiceIn+drug.currentSpecialInvoiceIn AS currentInvoiceIn,
        drug.currentRealIn+drug.currentSpecialRealIn AS currentRealIn,
        drug.currentRealOut+drug.currentSpecialRealOut AS currentRealOut,
				drug.currentSpecialRealOpening AS currentSpecialRealOpening,
				drug.currentSpecialInvoiceOpening AS currentSpecialInvoiceOpening,
				drug.currentSpecialRealOut AS currentSpecialRealOut,
				drug.currentSpecialInvoiceIn AS currentSpecialInvoiceIn,
				drug.currentSpecialRealIn AS currentSpecialRealIn,
				
        drug.isSale AS which,
				stock.positionName AS positions,
        stock.BatchNo AS batchNo,
        stock.Validity AS validity,
        stock.costPrice AS costPrice,
        stock.number AS number,
        dici.soreCode AS orderCode
        from t_drug_dictionary AS dici right join t_dsh_drug_info AS drug on dici.id = drug.drugId
        left join t_dsh_outin_detail AS detail on detail.drugId = dici.id left join t_dsh_outin_info AS outin
        on detail.outinId = outin.Id left join t_dsh_stock_batch_number AS stock ON stock.drugId = dici.id WHERE dici.status=1 
				AND drug.deptId = '+CONVERT(nvarchar(10), @deptId)+''
				IF @classify = '-1'
				SET @sql = @sql+ 'AND 1=1'
				IF @classify != '-1'
				SET @sql = @sql+ 'AND SUBSTRING(dici.unifyPropertyBidInviting, '+CONVERT(nvarchar(10), @initialPosition)+','+CONVERT(nvarchar(10),@length)+') = '+CHAR(39)+@classify+CHAR(39)+''
				IF @screen IS NOT NULL
				SET @sql = @sql+'AND (dici.drugCode LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+' OR dici.drugName LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+'OR dici.inputCode LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+')'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03)'
				IF @westMedicine IS NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 09)'
				IF @westMedicine IS NULL AND @centreMedicine IS  NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 06)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03 OR dici.drugCategory = 09)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03 OR dici.drugCategory = 06)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03 OR dici.drugCategory = 09 OR dici.drugCategory = 06)'
				IF @westMedicine IS NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 09 OR dici.drugCategory = 06)'
				IF @filtrate = '所有'
				SET @sql = @sql+ 'AND 1=1'
				IF @filtrate = '上柜'
				SET @sql = @sql+ 'AND drug.isSale LIKE '+CHAR(39)+CHAR(37)+'1'+CHAR(37)+CHAR(39)+''
				IF @filtrate = '下柜'
				SET @sql = @sql+ 'AND drug.isSale LIKE '+CHAR(39)+CHAR(37)+'0'+CHAR(37)+CHAR(39)+''
				IF @filtrate = '有库存'
				SET @sql = @sql+ 'AND drug.number > 0'
				IF @filtrate = '无库存'
				SET @sql = @sql+ 'AND drug.number <= 0'
				IF @filtrate = '有发票库存'
				SET @sql = @sql+ 'AND drug.invoiceNumber > 0'
				SET @sql = @sql + 'GROUP BY 	dici.unifyPropertyBidInviting,dici.drugCategory,dici.drugCode,dici.drugName,dici.spec,dici.inputCode,dici.origin,dici.largePackNumber,dici.largePackUnit,drug.wholesale,drug.price,drug.lastRealOpening,drug.lastInvoiceOpening,dici.id,drug.isSale,dici.id,drug.number,drug.invoiceNumber,drug.currentSpecialRealOpening,drug.currentSpecialInvoiceOpening,drug.currentSpecialRealOut,drug.currentSpecialInvoiceIn,drug.currentSpecialRealIn,drug.currentRealOpening,drug.currentInvoiceOpening,drug.currentInvoiceIn,drug.currentRealIn,drug.currentRealOut,stock.positionName,stock.BatchNo,stock.Validity,stock.costPrice,stock.number,dici.soreCode,drug.lastRealOpening'
				EXEC(@sql)
go

exec sp_addextendedproperty 'MS_Description', '全库盘点----仓批查询实时药品数据
', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_drug_listBatch'
go

