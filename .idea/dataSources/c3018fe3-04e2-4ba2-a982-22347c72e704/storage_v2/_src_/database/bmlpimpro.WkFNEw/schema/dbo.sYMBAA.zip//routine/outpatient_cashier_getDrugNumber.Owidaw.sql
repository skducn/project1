CREATE PROCEDURE [dbo].[outpatient_cashier_getDrugNumber]
@deptId INT
AS
BEGIN
	SELECT drugId,SUM(ISNULL(number, 0)-ISNULL(previewNumber, 0)) AS number, price AS price
  FROM t_ph_outpatient_drug_info
	WHERE deptId = @deptId
  GROUP BY drugId,price
END
go

exec sp_addextendedproperty 'MS_Description', '门诊收费管理-获取药品数量', 'SCHEMA', 'dbo', 'PROCEDURE',
     'outpatient_cashier_getDrugNumber'
go

