CREATE PROCEDURE [dbo].[reportform_getPayWayFee]
@payWay nvarchar(200) OUTPUT
AS
BEGIN
	SET @payWay = '1-现金;2-支票;3-微信;4-支付宝;5-其他'
	SELECT @payWay
END
go

