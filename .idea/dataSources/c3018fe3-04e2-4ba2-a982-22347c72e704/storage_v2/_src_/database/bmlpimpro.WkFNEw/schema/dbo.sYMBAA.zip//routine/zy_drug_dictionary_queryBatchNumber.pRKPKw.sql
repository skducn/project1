CREATE PROCEDURE [dbo].[zy_drug_dictionary_queryBatchNumber]
AS

SELECT dici.id AS drugId,
			dici.drugName AS drugName,
			outinfo.batchNo AS drugBar,
			outinfo.barCode AS barCode,
			outinfo.validity AS validity,
			outinfo.wholesale AS costPrice,
			outinfo.price AS price,
			outinfo.cost AS wholesale,
			outinfo.costAmount AS costAmount,
			outinfo.priceAmount AS priceAmount,
			outinfo.wholesaleAmount AS wholesaleAmount,
			(SELECT SUM(s.number) FROM t_dsh_stock_batch_number AS s WHERE s.drugId = dici.id AND s.batchNo = outinfo.batchNo) AS actuaBatchNumber
        FROM t_dsh_outin_info AS outin
        INNER JOIN t_dsh_outin_detail AS detail ON outin.id = detail.outinId
        INNER JOIN t_dsh_outin_batch AS outinfo ON outinfo.detailId = detail.detailId
        INNER JOIN t_drug_dictionary AS dici ON dici.id = detail.drugId
        GROUP BY dici.drugName,dici.id,outinfo.batchNo,outinfo.barCode,outinfo.validity,outinfo.
					wholesale,outinfo.price,outinfo.cost,outinfo.costAmount,
					outinfo.priceAmount,outinfo.wholesaleAmount,outinfo.number
go

exec sp_addextendedproperty 'MS_Description', '结存批号表查询', 'SCHEMA', 'dbo', 'PROCEDURE',
     'zy_drug_dictionary_queryBatchNumber'
go

