CREATE PROCEDURE [dbo].[zy_purchase_plan_shortage]
AS
SELECT tdd.id AS drugId,
        tdd.drugCode AS drugCode,
        tdd.inputCode AS inputCode,
        tdd.drugName AS drugName,
				tdd.spec AS drugSpec,
        tdd.origin AS drugOrigin,
        tdd.packNumber AS packNumber,
        tdd.largePackNumber AS largePackNumber,
        tdd.basicDose AS basicDose,
        tdd.doseUnit AS doseUnit,
        tdd.basicPackUnit AS basicPackUnit,
        tdd.packUnit AS packUnit,
        tdd.largePackUnit AS largePackUnit,
        tdod.planNumber AS planNumber,
        tdod.realNumber AS realNumber,
        tddi.number AS number,
        (tdod.planNumber-tdod.alreadyNumber-number) AS shortageQuantity,
				tpgm.operateTime AS applyDate,
				tpgm.checkTime AS approveDate
        from t_drug_dictionary AS tdd 
        INNER JOIN t_dsh_drug_info AS tddi ON tdd.id=tddi.drugId				
        INNER JOIN t_dsh_outin_detail AS tdod ON tdd.id=tdod.drugId
			  INNER JOIN t_dsh_outin_info AS tdoi ON tdod.outinId=tdoi.id
			  LEFT JOIN	t_ph_get_medicine AS tpgm ON tdod.detailId=tpgm.detailId
        WHERE (tdod.planNumber-tdod.alreadyNumber-tddi.number)>0 AND tdoi.state!=3 AND tdd.status=1
go

exec sp_addextendedproperty 'MS_Description', '药品采购计划查询缺货药品', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_purchase_plan_shortage'
go

