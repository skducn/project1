CREATE PROCEDURE [dbo].[outpatient_generateInfo]
AS
BEGIN
	INSERT INTO t_code_open_consultation_information (visitingDate,week,outPName,categoryName,amNum,pmNum,amAdd,pmAdd,reservationLimit,amRegCount,pmRegCount,amRegBack,pmRegBack,amVisitCount,pmVisitCount,orgNo,subNo) VALUES (GETDATE(),(DATENAME(weekday,GETDATE())),'00','1',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'00','2',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'01','1',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'01','2',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'02','1',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'02','2',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'11','1',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'11','2',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'00','3',0,0,0,0,0,0,0,0,0,0,0,'001','001001'),(GETDATE(),(DATENAME(weekday,GETDATE())),'01','3',0,0,0,0,0,0,0,0,0,0,0,'001','001001')
END
go

