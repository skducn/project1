CREATE PROCEDURE [dbo].[fee_item_insurance_info]
@keyWord VARCHAR(100), 
@typeName VARCHAR(100)
AS
BEGIN
	IF(@keyWord IS NULL)
		BEGIN
			SELECT TOP 20 * FROM t_code_insurance_dictionary
			WHERE insuranceType = @typeName
		END
	ELSE
		BEGIN
			SELECT TOP 20 * FROM t_code_insurance_dictionary 			WHERE insuranceType = @typeName 
			AND (insuranceCode LIKE '%'+@keyWord+'%' 
			OR insuranceName LIKE '%'+@keyWord+'%')
		END
END
go

exec sp_addextendedproperty 'MS_Description', '收费项目--获取医保信息', 'SCHEMA', 'dbo', 'PROCEDURE', 'fee_item_insurance_info'
go

