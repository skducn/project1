CREATE PROCEDURE [dbo].[yibao_detailUpload_dealRecord]
@today nchar(8)
AS
BEGIN
--未明确字段先写死
	DECLARE @visitAmount money = 0,
	@startCashPayFee money = 0,
	@startAccountPayFee money = 0,
	@burdenReductionFlag int = 0,
	@burdenReductionItemTotalFee nchar(10) = ''
	BEGIN
		IF(@today IS NULL)
			SELECT @today = CONVERT(nchar(8),DATEADD(day,-1,getdate()),112)
	END
--开启事务
	BEGIN TRY 
	BEGIN TRANSACTION
--1.先删除数据
	DELETE FROM t_medicare_deal_record WHERE LEFT(returnTime, 8) = @today
--2.联表查询抽取数据
	INSERT INTO t_medicare_deal_record
	SELECT t_medicare_outpatient_register_cashier.centerStreamNo,
	t_medicare_outpatient_register_cashier.hospitalCode AS medicalInstitutionsCode,
	t_medicare_outpatient_register_cashier.cardNo,
	t_medicare_outpatient_register_cashier.accountFlag AS accFlag,
	t_medicare_outpatient_register_cashier.patientType,
	@visitAmount,
	t_medicare_outpatient_register_cashier.transmitDate+'/'+REPLACE(t_medicare_outpatient_register_cashier.transmitTime, ':', '')+'/' AS returnTime,
	t_medicare_outpatient_register_cashier.settleCategory AS settleType,
	t_medicare_outpatient_register_cashier.dealTotalFee,
	t_medicare_outpatient_register_cashier.curYearAccountPayFee AS curYearAccPayFee,
	t_medicare_outpatient_register_cashier.calendarAccountPayFee AS calendarAccPayFee,
	t_medicare_outpatient_register_cashier.conceitedCashPayFee,
	@startCashPayFee,
	@startAccountPayFee,
	t_medicare_outpatient_register_cashier.raiseCashPayFee,
	t_medicare_outpatient_register_cashier.raiseAccountPayFee AS raiseAccPayFee,
	t_medicare_outpatient_register_cashier.raisePayFee AS raiseFundPayFee,
	t_medicare_outpatient_register_cashier.subjoinCashPayFee AS appendCashPay,
	t_medicare_outpatient_register_cashier.subjoinAccountPayFee AS appendAccPay,
	t_medicare_outpatient_register_cashier.subjoinPayFee AS placeAppendPay,
	t_medicare_outpatient_register_cashier.medicalInvoiceTotalFee,
	t_medicare_outpatient_register_cashier.nonMedicalInvoiceSelfPay,
	t_medicare_outpatient_register_cashier.medicareWay,
	t_medicare_outpatient_register_cashier.invoiceNo,
	t_medicare_outpatient_register_cashier.cashierStatus AS chargeFlag,
	t_medicare_outpatient_register_cashier.transmitDate AS checkBeginDate,
	@burdenReductionFlag,
	@burdenReductionItemTotalFee
	FROM t_medicare_outpatient_register_cashier
	LEFT JOIN t_outpatient_registration_invoice
	ON t_outpatient_registration_invoice.invoiceNo = t_medicare_outpatient_register_cashier.invoiceNo
	WHERE t_medicare_outpatient_register_cashier.cashierStatus = 1
	AND t_medicare_outpatient_register_cashier.transmitDate = @today
	AND t_medicare_outpatient_register_cashier.centerStreamNo IS NOT NULL
--3.更新就诊次数字段
	UPDATE t_medicare_deal_record SET visitAmount = (SELECT COUNT(t_outpatient_registration_data.visitId)
	FROM t_medicare_deal_record 
	INNER JOIN t_outpatient_registration_invoice
	ON t_medicare_deal_record.invoiceNo = t_outpatient_registration_invoice.invoiceNo
	INNER JOIN t_outpatient_registration_data
	ON t_outpatient_registration_data.invoiceId = t_outpatient_registration_invoice.invoiceId)
	WHERE t_medicare_deal_record.settleType = '110'
--提交事务
COMMIT TRANSACTION
END TRY
--有异常被捕获
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION
END CATCH
END
go

exec sp_addextendedproperty 'MS_Description', '医保明细上传-抽取交易记录', 'SCHEMA', 'dbo', 'PROCEDURE',
     'yibao_detailUpload_dealRecord'
go

