-- =============================================
-- Author:	杨框
-- Create date: 2022-08-19
-- Description: 门诊科室就诊人次统计
--  要求：
-- 			1）在门诊类型维护基础数据中，维护医院的挂号类型分别为：计生、免费门诊、普通门诊、专家门诊、体检
-- 			2）通过挂号表，统计不同挂号类型的就诊人次，就诊人次通过接诊标识进行统计（表中字段医生开始时间有数据的代表已接诊）
-- 			3）科室信息：通过挂号表中挂号门诊科室进行统计。	
-- Param: @condition 时间区间（例：exec p_stat_outp_dept_visit '2022-01-01 00:00:00,2023-01-01 00:00:00'）
-- Return:	...
-- Modify [n]:  < Modifier,Date, Description >
-- =============================================
CREATE proc p_stat_outp_dept_visit(@condition nvarchar(50))
as
begin 
DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
IF (@condition IS NOT NULL AND @condition != '')
    BEGIN
			SET @startTime = SUBSTRING(@condition,0,20)
			SET @endTime = SUBSTRING(@condition,21,20)
		END		
 select 
	[科室名称]
	, isnull([计生], 0) as [计生]
	, isnull([免费门诊], 0) as [免费门诊]
	, isnull([普通门诊], 0) as [普通门诊]
	, isnull([专家门诊], 0) as [专家门诊]
	, isnull([体检], 0) as [体检]
	, isnull([合计], 0) as [合计]
from 
(
		select 
			isnull(dept.deptName, '合计') as [科室名称] 
			, isnull(cg.categoryName, '合计') as categoryName
			, count(r.id) as total
		from 
			(select distinct t2.deptCode, t2.deptName from t_outpatient_registration_info t1 inner join t_code_department_information t2 on t1.deptCode = t2.deptCode) dept
			left join t_code_outpatient_category cg on cg.categoryName in ('计生', '免费挂号', '普通门诊', '专家门诊', '体检')
			left join t_outpatient_registration_info r on r.categoryCode = cg.categoryCode and r.deptCode = dept.deptCode 
					and r.visitStatus >= 4 and r.visitStatus <= 6 and r.regDate >= @startTime and r.regDate <= @endTime
			group by 
				cube(dept.deptName, cg.categoryName)		
 ) t PIVOT 
 (sum(total) for categoryName in ([计生], [免费门诊], [普通门诊], [专家门诊], [体检], [合计])) as col
 ORDER BY (CASE [科室名称] WHEN '合计' THEN 0 ELSE 1 END ) DESC 
end
go

