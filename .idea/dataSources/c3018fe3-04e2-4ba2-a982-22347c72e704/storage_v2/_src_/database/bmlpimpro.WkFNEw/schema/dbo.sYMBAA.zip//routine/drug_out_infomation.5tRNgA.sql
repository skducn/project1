CREATE PROCEDURE [dbo].[drug_out_infomation]
	@timeString VARCHAR(100) = '2021-01-01 00:00:00,2022-02-01 00:00:00',
	@type AS VARCHAR(50)
AS
DECLARE
		@startDate VARCHAR(50),
		@endDate VARCHAR(50),
		@sumAll VARCHAR(50),
		@query VARCHAR(MAX)
BEGIN
	SET @startDate = CHAR(39) + SUBSTRING(@timeString, 0, 20) + CHAR(39)
	SET	@endDate = CHAR(39) + SUBSTRING(@timeString, 21, 20) + CHAR(39)
	SET @sumAll =  CHAR(39) + '合计' + CHAR(39)
END
IF (@type IS NULL OR @type = '' OR @type = '0')
	BEGIN
			SET @query='SELECT
		CASE
			WHEN info.relativeDeptName IS NULL THEN NULL
			ELSE info.relativeDeptId 
		END 科室编号,
		info.relativeDeptName 科室名称,
		info.receiptTypeName 出库类型,
		CASE info.receiptType
			WHEN 11 THEN SUM (detail.realNumber)
			WHEN 17 THEN SUM (detail.realNumber)
			ELSE SUM (detail.planNumber)
		END 数量,
		SUM (info.wholeSaleTotal) 进价金额,
		SUM (info.priceTotal) 零售金额,
		SUM (info.wholeSaleTotal - info.priceTotal) 进零差额
	FROM
		t_dsh_outin_info info
	LEFT JOIN t_dsh_outin_detail detail ON detail.outinId = info.id
	WHERE
		info.receiptTypeName IS NOT NULL 
		AND info.receiptType IN (11,13,14,15,16,17)
		and info.operateTime BETWEEN  '+ @startDate +' AND ' + @endDate + '
	GROUP BY
		info.relativeDeptId,
		info.relativeDeptName,
		receiptTypeName,
		info.receiptType

	UNION ALL
	-- 总量
	SELECT
			NULL 科室编号,
			'+ @sumAll +' 科室名称,
			NULL 出库类型,
			SUM(CASE info.receiptType
			WHEN 11 THEN detail.realNumber
			WHEN 17 THEN detail.realNumber
			ELSE detail.planNumber
			END)数量,
			SUM (info.wholeSaleTotal) 进价金额,
			SUM (info.priceTotal) 零售金额,
			SUM (info.wholeSaleTotal - info.priceTotal) 进零差额
		FROM
			t_dsh_outin_info info
		LEFT JOIN t_dsh_outin_detail detail ON detail.outinId = info.id
		WHERE
			info.receiptTypeName IS NOT NULL 
			AND info.receiptType IN (11,13,14,15,16,17)
			and info.operateTime BETWEEN '+ @startDate +' AND ' + @endDate + ';'
	END
ELSE
	BEGIN
		SET @query='SELECT
		CASE
			WHEN info.relativeDeptName IS NULL THEN NULL
			ELSE info.relativeDeptId 
		END 科室编号,
		info.relativeDeptName 科室名称,
		info.receiptTypeName 出库类型,
		CASE info.receiptType
			WHEN 11 THEN SUM (detail.realNumber)
			WHEN 17 THEN SUM (detail.realNumber)
			ELSE SUM (detail.planNumber)
		END 数量,
		SUM (info.wholeSaleTotal) 进价金额,
		SUM (info.priceTotal) 零售金额,
		SUM (info.wholeSaleTotal - info.priceTotal) 进零差额
	FROM
		t_dsh_outin_info info
	LEFT JOIN t_dsh_outin_detail detail ON detail.outinId = info.id
	WHERE
		info.receiptTypeName IS NOT NULL 
		AND info.receiptType IN ('+@type+')
		and info.operateTime BETWEEN  '+ @startDate +' AND ' + @endDate + '
	GROUP BY
		info.relativeDeptId,
		info.relativeDeptName,
		receiptTypeName,
		info.receiptType

	UNION ALL
	-- 总量
	SELECT
			NULL 科室编号,
			'+ @sumAll +' 科室名称,
			NULL 出库类型,
			ISNULL(SUM(CASE info.receiptType
			WHEN 11 THEN detail.realNumber
			WHEN 17 THEN detail.realNumber
			ELSE detail.planNumber
			END), 0)数量,
			ISNULL(SUM (info.wholeSaleTotal), 0) 进价金额,
			ISNULL(SUM (info.priceTotal), 0) 零售金额,
			ISNULL(SUM (info.wholeSaleTotal - info.priceTotal),0) 进零差额
		FROM
			t_dsh_outin_info info
		LEFT JOIN t_dsh_outin_detail detail ON detail.outinId = info.id
		WHERE
			info.receiptTypeName IS NOT NULL
			AND info.receiptType IN ('+@type+')
			and info.operateTime BETWEEN '+ @startDate +' AND ' + @endDate + ';'
	END

BEGIN
PRINT(@query)
EXEC(@query)
END
go

