CREATE PROCEDURE [dbo].[report_doc_recipeNum_detail]
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-4-30 23:59:59'
AS
BEGIN
declare @enterTime nvarchar(50),
@leaveTime nvarchar(50),
@allTime nvarchar(100)
set @allTime = @timeString
set @enterTime = substring(@allTime,0,20)
set @leaveTime = substring(@allTime,21,20)
SELECT
CASE WHEN grouping(c.docName) = '1' THEN '总计'
     when grouping(c.docName) = '0' and grouping(convert(char(10),a.recipeTime,120))='1'  then '合计' else c.docName END AS 姓名,
 convert(char(10),a.recipeTime,120) AS 日期,
case when SUM (b.amount)=0 then 0
  ELSE
  Convert(decimal(18,2),SUM(
			CASE
			when itemType = 03 THEN b.amount
			when itemType = 06 THEN b.amount
			when itemType = 09 THEN b.amount ELSE 0  END
		)/SUM (b.amount) * 100) end AS '药占比（%）',
  case when SUM (a.totalFee)=0 or COUNT (a.outPId)=0 then 0
  ELSE
  Convert(decimal(18,2),SUM (b.amount)/COUNT(DISTINCT a.outPId)) end AS 均次费,
 COUNT (DISTINCT a.recipeId) AS 处方张数,
 SUM (b.amount) AS 总金额
FROM
 t_doc_recipe_serial_count AS a
JOIN t_doc_recipe_detail AS b ON a.recipeId = b.recipeId
JOIN t_code_doctor_information AS c ON a.docUserId = c.docId
WHERE a.recipeTime BETWEEN @enterTime AND @leaveTime AND a.state != 2
GROUP BY
 c.docName,
 convert(char(10),a.recipeTime,120) WITH rollup order by c.docName desc,
 convert(char(10),a.recipeTime,120) desc
END
go

