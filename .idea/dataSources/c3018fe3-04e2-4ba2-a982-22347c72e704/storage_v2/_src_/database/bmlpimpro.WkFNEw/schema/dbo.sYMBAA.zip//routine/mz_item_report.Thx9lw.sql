create proc mz_item_report 
@startDate varchar(50),@endDate varchar(50)
as 
begin


set @startDate += ' 00:00:00'
set @endDate += ' 23:59:59'

select
b.typeName,a.amount
from
(
select
b.itemType,sum(b.amount) as amount
 from (select * from t_outpatient_cashier_invoice where payDate BETWEEN @startDate and @endDate and invoiceStatus = 2) a
join t_outpatient_cashier_detail b on a.invoiceId = b.invoiceId group by b.itemType

) a
left join t_code_item_category b
on a.itemType = b.itemType

end
go

