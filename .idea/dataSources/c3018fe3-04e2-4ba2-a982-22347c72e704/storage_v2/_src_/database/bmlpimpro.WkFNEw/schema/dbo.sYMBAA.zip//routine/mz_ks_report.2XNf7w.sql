create proc mz_ks_report 
@startDate varchar(50),@endDate varchar(50)
as 
begin
DECLARE item_cursor cursor 
FOR   
    select itemType,typeName 
		from t_code_item_category
for read only;

set @startDate += ' 00:00:00'
set @endDate += ' 23:59:59'
DECLARE @sql_str NVARCHAR(MAX);

set @sql_str = 'select (case when a.deptCode is null then b.deptCode else a.deptCode end) as 科室编号, (case when a.deptCode is null then b.deptName else a.deptName end) as 科室名称,  a.*,b.fee as 挂号费1, isNull(a.total,0)+isNull(b.fee,0) as 合计  from ( select  c.deptCode,c.deptName';

open item_cursor;
DECLARE @itemType nvarchar(32);
DECLARE @itemName nvarchar(32);
fetch next from item_cursor into @itemType,@itemName;
while (@@FETCH_STATUS=0)
begin 
	set @sql_str += ',sum(case when b.itemType = ';
	set  @sql_str += '''' +	@itemType + '''' ;
	set  @sql_str += 	' then b.amount else 0 end  ) as ';
	set  @sql_str += @itemName;
	fetch next from item_cursor into @itemType,@itemName;
	print @itemName;
end
close item_cursor;
deallocate item_cursor;


set  @sql_str += ',sum(b.amount) as total from (select * from t_outpatient_cashier_invoice where payDate BETWEEN '
set  @sql_str += '''' + @startDate +'''' 
set  @sql_str += ' and '
set  @sql_str += '''' + @endDate +''''
set  @sql_str += ' and invoiceStatus = 2) a '
set  @sql_str += ' join t_outpatient_cashier_detail b on a.invoiceId = b.invoiceId '
set  @sql_str += ' join t_code_department_information c on b.executeDept = c.id group by c.deptCode,c.deptName '





set @sql_str += ') a full join ( select e.deptCode,e.deptName, sum(a.totalFee) as fee from'
set @sql_str += ' (select * from t_outpatient_registration_invoice where  payDate BETWEEN '
set  @sql_str += '''' + @startDate +'''' 
set  @sql_str += ' and '
set  @sql_str += '''' + @endDate +''''
set  @sql_str += ' and invoiceStatus = 2) a '
set  @sql_str += ' join t_outpatient_registration_data b on a.invoiceId = b.invoiceId '
set  @sql_str += ' join t_outpatient_registration_info c on b.visitId = c.visitId  '
set  @sql_str += ' join t_code_outpatient_information d on d.outPCode = c.outPCode '
set  @sql_str +=' join t_code_department_information e on e.deptCode = d.deptCode group by e.deptCode,e.deptName '
set  @sql_str +=' ) b on a.deptCode= b.deptCode '

print @sql_str
exec(@sql_str)
end
go

