CREATE PROCEDURE [dbo].[outpatient_info_searchAllArea]
@keyWord VARCHAR(50)
AS
BEGIN
	--如果输入的是省
	IF (EXISTS (SELECT code FROM t_code_standard_code WHERE sysName = '收费挂号系统'
			AND codeType = '省' AND name LIKE '%'+@keyWord+'%'))
	BEGIN	
		SELECT 
				t1.code AS provinceCode,
				t1.name AS provinceName,
				t2.code AS cityCode,
				t2.name AS cityName,
				t3.code AS countyCode,
				t3.name AS countyName
		--第一级
		FROM (SELECT code,name,remark FROM t_code_standard_code WHERE sysName = 
			'收费挂号系统' AND codeType = '省' AND name LIKE '%'+@keyWord+'%') AS t1 
		--第二级
		INNER JOIN (SELECT code,name,remark FROM t_code_standard_code WHERE sysName =
			'收费挂号系统' AND codeType = '市') AS t2
		ON t1.code = t2.remark
		--第三级
		INNER JOIN 	(SELECT code,name,remark FROM t_code_standard_code WHERE sysName = 
			'收费挂号系统' AND codeType = '县') AS t3
		ON t2.code = t3.remark
	END
	--如果输入的是市
	IF (EXISTS (SELECT code FROM t_code_standard_code WHERE sysName = '收费挂号系统'
			AND codeType = '市' AND name LIKE '%'+@keyWord+'%'))
	BEGIN
		SELECT 
				t1.code AS provinceCode,
				t1.name AS provinceName,
				t2.code AS cityCode,
				t2.name AS cityName,
				t3.code AS countyCode,
				t3.name AS countyName
		--第二级
		FROM (SELECT code,name,remark FROM t_code_standard_code WHERE sysName = 
			'收费挂号系统' AND codeType = '市' AND name LIKE '%'+@keyWord+'%') AS t2
		--第一级
		INNER JOIN (SELECT code,name,remark FROM t_code_standard_code WHERE sysName = 
			'收费挂号系统' AND codeType = '省') AS t1 
		ON t2.remark = t1.code
		--第三级
		INNER JOIN 	(SELECT code,name,remark FROM t_code_standard_code WHERE sysName = 
			'收费挂号系统' AND codeType = '县') AS t3
		ON t2.code = t3.remark
	END
	--如果输入的是县
	IF (EXISTS (SELECT code FROM t_code_standard_code WHERE sysName = '收费挂号系统'
			AND codeType = '县' AND name LIKE '%'+@keyWord+'%'))
	BEGIN
		SELECT 
				t1.code AS provinceCode,
				t1.name AS provinceName,
				t2.code AS cityCode,
				t2.name AS cityName,
				t3.code AS countyCode,
				t3.name AS countyName
		--第三级
		FROM (SELECT code,name,remark FROM t_code_standard_code WHERE sysName = 
			'收费挂号系统' AND codeType = '县' AND name LIKE '%'+@keyWord+'%') AS t3
		--第二级
		INNER JOIN (SELECT code,name,remark FROM t_code_standard_code WHERE sysName =
			'收费挂号系统' AND codeType = '市') AS t2
		ON t3.remark = t2.code
		--第一级
		INNER JOIN 	(SELECT code,name,remark FROM t_code_standard_code WHERE sysName = 
			'收费挂号系统' AND codeType = '省') AS t1
		ON t2.remark = t1.code
	END
END
go

exec sp_addextendedproperty 'MS_Description', '患者信息-动态搜索行政区划', 'SCHEMA', 'dbo', 'PROCEDURE',
     'outpatient_info_searchAllArea'
go

