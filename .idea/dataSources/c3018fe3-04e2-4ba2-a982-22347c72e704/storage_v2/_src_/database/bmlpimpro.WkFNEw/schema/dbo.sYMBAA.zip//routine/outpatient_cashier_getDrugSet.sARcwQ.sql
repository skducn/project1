CREATE PROCEDURE [dbo].[outpatient_cashier_getDrugSet]
@drugType nvarchar(200) OUTPUT
-- 01	西药费
-- 02	成药费
-- 03	草药费
AS
BEGIN
	SET @drugType = '03,06,09,99;09'
	SELECT @drugType
END
go

exec sp_addextendedproperty 'MS_Description', '门诊收费管理-获取药品类别集合', 'SCHEMA', 'dbo', 'PROCEDURE',
     'outpatient_cashier_getDrugSet'
go

