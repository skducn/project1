CREATE PROCEDURE [dbo].[outpatient_cashier_getItemName]
@outPNo INT
AS
BEGIN
	SELECT t_code_item_category.id AS id,
		t_code_item_category.itemType AS itemType,
		t_code_item_category.typeName AS typeName,
		t_code_item_category.sort AS sort
	FROM t_code_item_category
	INNER JOIN t_outpatient_cashier_temp
	ON t_outpatient_cashier_temp.itemType = t_code_item_category.itemType
	WHERE t_outpatient_cashier_temp.outPNo = @outPNo
END
go

exec sp_addextendedproperty 'MS_Description', '门诊收费管理-获取项目名称', 'SCHEMA', 'dbo', 'PROCEDURE',
     'outpatient_cashier_getItemName'
go

