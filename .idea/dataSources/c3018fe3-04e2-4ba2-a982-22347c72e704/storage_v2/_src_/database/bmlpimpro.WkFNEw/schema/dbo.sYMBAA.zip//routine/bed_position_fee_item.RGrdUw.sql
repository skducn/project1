CREATE PROCEDURE [dbo].[bed_position_fee_item]
AS
BEGIN
  -- routine body goes here, e.g.
  -- SELECT 'Navicat for SQL Server'
select 
t.id,
t.itemType,
t.itemCode,
t.itemName,
t.enName,
t.spec,
t.unit,
t.price,
t.costPrice,
t.foreignPrice,
t.refundFlag,
t.suitedDept,
t.office,
t.insuranceCode,
t.status,
t.inputCode,
t.orderFlag,
t.sort,
t.enteredDate,
t.enteredTime,
t.enteredUserId,
t.validBeginDate,
t.validStopDate,
t.unifyProperty,
t.accDept,
t.itemSubCategory,
t.itemState,
t.priceClassify,
t.remark,
t.treatmentCode
 from t_code_fee_item t
END
go

