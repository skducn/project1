CREATE PROCEDURE [dbo].[zy_ph_dispensing_statistics_copy1]
@condition nvarchar(50)
as
begin
DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
IF (@condition IS NOT NULL AND @condition != '')

    BEGIN
    SET @startTime = SUBSTRING(@condition,0,20)
    SET @endTime = SUBSTRING(@condition,21,20)
		END


-- 药房当日发药统计
select 
'门诊' AS 类别, 
recipeIdCount AS 处方数, 
total AS 应收金额, 
total AS 实收金额, 
total AS 对账金额 
from (
select 
ISNULL(count(DISTINCT (info.recipeId)),0) AS recipeIdCount, 
ISNULL(sum(detail.price*detail.number),0) AS total 
from t_ph_outpatient_dispensing_information info
left join t_ph_outpatient_dispensing_detail detail
on info.dispenseId = detail.dispenseId
where info.settleAccountsTime > @startTime AND info.settleAccountsTime < @endTime
) t

UNION ALL

select 
'住院' AS 类别, 
0 AS 处方数, 
total AS 应收金额, 
total AS 实收金额, 
total AS 对账金额 
from (
select 
ISNULL(sum(price*pleaseNumber),0) total
from t_drug_arrange_info
where checkUserTime > @startTime AND checkUserTime < @endTime
) t

UNION ALL

select
'合计' AS 类别, 
recipeIdCount AS 处方数, 
total AS 应收金额, 
total AS 实收金额, 
total AS 对账金额 
from (
select 
ISNULL((select sum(price*pleaseNumber) AS total from t_drug_arrange_info where checkUserTime > @startTime AND checkUserTime < @endTime),0)
+ ISNULL((select sum(detail.price*detail.number) AS total 
from t_ph_outpatient_dispensing_information info
left join t_ph_outpatient_dispensing_detail detail
on info.dispenseId = detail.dispenseId
where info.settleAccountsTime > @startTime AND info.settleAccountsTime < @endTime),0) AS total,
ISNULL((select 
count(DISTINCT (recipeId)) AS recipeIdCount
from t_ph_outpatient_dispensing_information info 
where info.settleAccountsTime > @startTime AND info.settleAccountsTime < @endTime),0) AS recipeIdCount
) t


end
go

