CREATE PROCEDURE [dbo].[zy_purchase_plan_detail](
@planPeriod INT
)
AS
SELECT tdd.id AS drugId,
       tdd.drugCode AS drugCode,
        tdd.inputCode AS inputCode,
        tdd.drugName AS drugName,
				tdd.spec AS drugSpec,
        tdd.origin AS drugOrigin,
        tdd.packNumber AS packNumber,
        tdd.largePackNumber AS largePackNumber,
        tdd.basicDose AS basicDose,
        tdd.basicDose AS basicDose,
        tdd.doseUnit AS doseUnit,
        tdd.basicPackUnit AS basicPackUnit,
        tdd.packUnit AS packUnit,tdd.packUnit AS packUnit,
        tdd.largePackUnit AS largePackUnit,
        t.lastRealIn AS lastMonthIncome,
        t.lastRealOut AS lastMonthExpend,
        dd.currentRealOut AS recentConsumption,
				tddi.number AS number,
				y.pharmacyInventory AS pharmacyInventory,
				(y.pharmacyInventory+tddi.number) AS totalInventory,
        tdppi.procurementDetailId AS procurementDetailId,
				tdppi.planPeriod AS planPeriod,
        tdppi.supplierName AS supplyName,
        tdppi.supplierId AS supplyid,
        tdppi.plannedArrivalTime AS planDate,
        tdppi.plannedPurchaseVolume AS planNumber,
        tdppi.costPrice AS planPrice,
        tdppi.price AS price,
        tdppi.wholesale AS wholesale,
        tdppi.purchaseVolumeCompleted AS completionNumber,
        tdppi.completionTime AS completionDate,
        tdppi.state AS state,
        tdppi.remark AS remark
        from t_drug_dictionary AS tdd
        INNER JOIN t_dsh_drug_info AS tddi ON tdd.id=tddi.drugId
        INNER JOIN t_drug_purchase_plan_information AS tdppi ON tdd.id=tdppi.drugId
				left JOIN (SELECT drugId,SUM(number) AS pharmacyInventory FROM t_ph_outpatient_drug_info GROUP BY drugId) y
ON tdd.id=y.drugId
        left JOIN t_ph_outpatient_drug_info AS dd
        ON tdd.id=dd.drugId
				LEFT JOIN
				(SELECT drugId,lastRealOut,lastRealIn FROM t_dsh_drug_info) t
				ON t.drugId=tdd.id
        WHERE tdppi.planPeriod=@planPeriod AND tdppi.state!=2;
go

exec sp_addextendedproperty 'MS_Description', '按采购计划编号查采购计划明细', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_purchase_plan_detail'
go

