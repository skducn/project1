CREATE PROCEDURE [dbo].[reported_drug_dept_drug_consumption]
@startTime VARCHAR(10),
@endTime VARCHAR(10)
as 
begin 
SELECT dept.deptCode as 科室编码,dept.deptName as 科室名称,
sum(batch.costprice*batch.batchNumber) as 进价金额,
sum(batch.price*batch.batchNumber) as 零售价金额,
sum(batch.costprice*batch.batchNumber) -sum(batch.price*batch.batchNumber) as 差价金额
from t_ph_outpatient_batch as batch 
join t_ph_outpatient_dispensing_detail AS deta on deta.detailId = batch.detailId
join t_ph_outpatient_dispensing_information as info on deta.dispenseId = info.dispenseId
join t_code_department_information as dept on info.recipeDeptId = dept.id
where state =3 and preparingTime>=@startTime and preparingTime<=@endTime 
GROUP BY dept.deptCode,dept.deptName
end
go

