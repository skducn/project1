CREATE PROCEDURE [dbo].[report_valuable_drug](
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-04-30 23:59:59'
)
AS
BEGIN
DECLARE 
@startDate nvarchar(100),
@endDate nvarchar(100)

SET @startDate = SUBSTRING(@timeString,0,20)
SET @endDate = SUBSTRING(@timeString,21,20);

/*
@sql nvarchar(MAX)

SET @sql = '
SELECT d.drugCode ' + CHAR(39) +'药品编码'+ CHAR(39) + ',
d.drugName ' + CHAR(39) +'药品名称'+ CHAR(39) + ',
m.spec ' + CHAR(39) +'规格'+ CHAR(39) + ',
m.price ' + CHAR(39) +'药品单价'+ CHAR(39) + ',
m.useNumber ' + CHAR(39) + '药品消耗数量'+ CHAR(39) + ',
m.packUnit ' + CHAR(39) +'单位'+ CHAR(39) + ',
m.consumeMoney ' + CHAR(39) +'药品消耗金额'+ CHAR(39) + ',
CASE WHEN tpodi.number%tpodi.packAmount = 0
     THEN CONVERT(varchar(10),(tpodi.number/tpodi.packAmount)) + codes.name 
   ELSE 
     CONVERT(varchar(10),FLOOR(tpodi.number/tpodi.packAmount)) + codes.name + CONVERT(varchar(10),(tpodi.number % tpodi.packAmount)) + codes2.name
END ' + CHAR(39) +'库存数量'+ CHAR(39) + ',
tpodi.number/tpodi.packAmount * tpodi.price ' + CHAR(39) +'库存金额'+ CHAR(39) + '
FROM 
(SELECT drugId,spec,packUnit,price,SUM(useNumber) useNumber,SUM(consumeMoney) consumeMoney FROM (
SELECT tpodd.drugId,tpodd.spec,tpodd.packUnit,tpodd.price,SUM(tpodd.number) useNumber, SUM(tpodd.price * tpodd.number) consumeMoney
FROM t_drug_dictionary d
INNER JOIN t_ph_outpatient_dispensing_detail tpodd ON d.id = tpodd.drugId
INNER JOIN t_ph_outpatient_dispensing_information di ON di.dispenseId = tpodd.dispenseId
WHERE d.drugAttribute = 5 AND di.state = 3'
IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' AND di.dispensingTime BETWEEN @startDate AND @endDate ' 
	 END
SET @sql = @sql + '
GROUP BY tpodd.drugId,tpodd.spec,tpodd.packUnit,tpodd.price
UNION ALL 
SELECT tdai.drugId,tdai.spec,tdai.packUnit,tdai.price,SUM(tdai.alreadyNumber - ISNULL(tdai.pleaseReturnNumber,0)) useNumber , SUM(tdai.price * (tdai.alreadyNumber - ISNULL(tdai.pleaseReturnNumber,0))) consumeMoney
FROM t_drug_dictionary d
INNER JOIN t_drug_arrange_info tdai ON d.id = tdai.drugId
WHERE d.drugAttribute = 5 '
  IF (@timeString IS NOT NULL AND @timeString != '')
   BEGIN
	  SET @startDate = SUBSTRING(@timeString,0,20)
    SET @endDate = SUBSTRING(@timeString,21,20)
		SET @sql = @sql + ' AND tdai.createTime BETWEEN @startDate AND @endDate ' 
	 END
SET @sql = @sql + '
GROUP BY tdai.drugId,tdai.spec,tdai.packUnit,tdai.price ) n 
GROUP BY drugId,spec,packUnit,price) m
INNER JOIN t_drug_dictionary d ON m.drugId = d.id
INNER JOIN t_ph_outpatient_drug_info tpodi ON tpodi.drugId = d.id
INNER JOIN (SELECT code,name FROM t_code_standard_code WHERE sysName = ' + CHAR(39) +'药库管理系统'+ CHAR(39) + ' AND codeType = ' + CHAR(39) +'药品单位'+ CHAR(39) + ') codes ON tpodi.packUnit = codes.code
INNER JOIN (SELECT code,name FROM t_code_standard_code WHERE sysName = ' + CHAR(39) +'药库管理系统'+ CHAR(39) + ' AND codeType = ' + CHAR(39) +'药品单位'+ CHAR(39) + ') codes2 ON d.basicPackUnit = codes2.code'

EXEC sp_executesql @sql,N'@startDate nvarchar(100),@endDate nvarchar(100)',@startDate,@endDate

*/

WITH a AS (
SELECT code,name FROM t_code_standard_code WHERE sysName = '药库管理系统' AND codeType = '药品单位'
)

SELECT d.drugCode 药品编码,
d.drugName 药品名称,
m.spec 规格,
m.price 药品单价,
m.useNumber 药品消耗数量,
m.packUnit 单位,
m.consumeMoney 药品消耗金额,
CASE WHEN tpodi.number%tpodi.packAmount = 0
     THEN CONVERT(varchar(10),(tpodi.number/tpodi.packAmount)) + codes.name 
   ELSE 
     CONVERT(varchar(10),FLOOR(tpodi.number/tpodi.packAmount)) + codes.name + CONVERT(varchar(10),(tpodi.number % tpodi.packAmount)) + codes2.name
END 库存数量,
ROUND((tpodi.number * 1.0/tpodi.packAmount * tpodi.price),2) 库存金额
FROM 
(SELECT drugId,spec,packUnit,price,SUM(useNumber) useNumber,SUM(consumeMoney) consumeMoney FROM (
SELECT tpodd.drugId,tpodd.spec,tpodd.packUnit,tpodd.price,SUM(tpodd.number) useNumber, SUM(tpodd.price * tpodd.number) consumeMoney
FROM t_drug_dictionary d 
INNER JOIN t_ph_outpatient_dispensing_detail tpodd ON d.id = tpodd.drugId
INNER JOIN t_ph_outpatient_dispensing_information di ON di.dispenseId = tpodd.dispenseId
INNER JOIN (SELECT * FROM a) code1 ON d.basicPackUnit = code1.code
WHERE d.drugAttribute = 5 AND di.state = 3 AND (code1.name != tpodd.packUnit OR d.basicPackUnit = d.packUnit) AND di.dispensingTime BETWEEN @startDate AND @endDate
GROUP BY tpodd.drugId,tpodd.spec,tpodd.packUnit,tpodd.price
UNION ALL 
SELECT tdai.drugId,tdai.spec,tdai.packUnit,tdai.price,SUM(tdai.alreadyNumber - ISNULL(tdai.pleaseReturnNumber,0)) useNumber , SUM(tdai.price * (tdai.alreadyNumber - ISNULL(tdai.pleaseReturnNumber,0))) consumeMoney
FROM t_drug_dictionary d
INNER JOIN t_drug_arrange_info tdai ON d.id = tdai.drugId
INNER JOIN (SELECT * FROM a) codes ON d.basicPackUnit = codes.code
WHERE d.drugAttribute = 5 AND codes.name != tdai.packUnit AND tdai.createTime BETWEEN @startDate AND @endDate
GROUP BY tdai.drugId,tdai.spec,tdai.packUnit,tdai.price ) n 
GROUP BY drugId,spec,packUnit,price) m
INNER JOIN t_drug_dictionary d ON m.drugId = d.id
INNER JOIN t_ph_outpatient_drug_info tpodi ON tpodi.drugId = d.id
INNER JOIN (SELECT * FROM a) codes ON tpodi.packUnit = codes.code
INNER JOIN (SELECT * FROM a) codes2 ON d.basicPackUnit = codes2.code
END
go

