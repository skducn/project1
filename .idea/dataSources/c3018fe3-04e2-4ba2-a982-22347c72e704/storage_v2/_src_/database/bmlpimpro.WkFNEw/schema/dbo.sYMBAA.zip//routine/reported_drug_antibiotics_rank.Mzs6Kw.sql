CREATE PROCEDURE [dbo].[reported_drug_antibiotics_rank]
@timeString AS VARCHAR(50),
@type AS VARCHAR(50)
AS
DECLARE
@startTime VARCHAR(100),
@endTime VARCHAR(100),
@query VARCHAR(MAX),
@groupChar VARCHAR(2),
@sysName VARCHAR(20),
@codeType1 VARCHAR(10),
@codeType2 VARCHAR(10),
@pos VARCHAR(10),
@sumStr VARCHAR(10),
@empty VARCHAR(2)
SET @groupChar = 1
SET @sysName =  CHAR(39) +'药库管理系统'+ CHAR(39)
SET @codeType1 = CHAR(39) +'产地厂家' + CHAR(39)
SET @codeType2 = CHAR(39) +'药品单位' + CHAR(39)
SET @pos = CHAR(39) + '31' + CHAR(39) 
SET @sumStr = CHAR(39) + '合计' + CHAR(39)
SET @empty = CHAR(39) + '' + CHAR(39)
IF (@timeString IS NOT NULL AND @timeString != '')

    BEGIN
    SET @startTime = CHAR(39) + SUBSTRING(@timeString,0,20) + CHAR(39)
    SET @endTime = CHAR(39) + SUBSTRING(@timeString,21,20) + CHAR(39)
		END
--查询全部
IF (@type IS NULL OR @type = '' OR @type = '全部')
	BEGIN
			SET @query='SELECT
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@sumStr+' ELSE CAST(MIN(res.medicareId) AS VARCHAR(20)) END 医保编码,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.drugName END 药品名称,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.spec END 药品规格,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE MIN(res.name) END 厂家,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.packUnit END 单位,
SUM(res.number) AS 数量,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE CAST(res.price AS VARCHAR(20)) END 单价,
CAST(SUM(CAST(res.money AS DECIMAL(10,2))) AS VARCHAR(100)) AS 金额
FROM
	(
	SELECT
		dic.medicareId,
		detail.drugName,
		detail.spec,
		code.name,
		detail.price,
		(detail.realNumber-detail.returnNumber) AS number,
		detail.packUnit,
		detail.price * (detail.realNumber-detail.returnNumber) AS money 
	FROM
		t_ph_outpatient_dispensing_detail AS detail
		LEFT JOIN t_ph_outpatient_dispensing_information AS info ON detail.dispenseId = info.dispenseId
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= detail.drugId
		LEFT JOIN t_code_standard_code AS code ON code.sysName= '+@sysName+' 
		AND code.codeType= '+@codeType1+' 
		AND dic.origin = code.code 
	WHERE
		info.dispensingTime BETWEEN '+@startTime+' 
		AND '+@endTime+' 
		AND SUBSTRING ( dic.unifyPropertyBidInviting, 22, 2 ) = '+@pos+' UNION ALL
	SELECT
		dic.medicareId,
		arrange.drugName,
		arrange.spec,
		code.name,
		arrange.price,
		arrange.retreatNumber AS number,
		arrange.packUnit,
		arrange.price * arrange.retreatNumber AS money 
	FROM
		t_drug_arrange_info AS arrange
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= arrange.drugId
		LEFT JOIN t_code_standard_code AS code ON code.sysName= '+@sysName+' 
		AND code.codeType= '+@codeType1+' 
		AND dic.origin = code.code 
	WHERE
		arrange.agoPreparingUserTime BETWEEN '+@startTime+' 
		AND '+@endTime+' 
		AND SUBSTRING ( dic.unifyPropertyBidInviting, 22, 2 ) = '+@pos+' 
	) AS res 
GROUP BY
	res.drugName,res.spec,res.packUnit,res.price WITH ROLLUP HAVING GROUPING(res.drugName)=1 OR GROUPING(res.price)=0;'
			END
-- 查询门诊
IF (@type = '门诊')
	BEGIN
			SET @query='SELECT
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@sumStr+' ELSE CAST(MIN(res.medicareId) AS VARCHAR(20)) END 医保编码,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.drugName END 药品名称,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.spec END 药品规格,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE MIN(res.name) END 厂家,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.packUnit END 单位,
SUM(res.number) AS 数量,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE CAST(res.price AS VARCHAR(20)) END 单价,
CAST(SUM(CAST(res.money AS DECIMAL(10,2))) AS VARCHAR(100)) AS 金额
FROM
	(
	SELECT
		dic.medicareId,
		detail.drugName,
		detail.spec,
		code.name,
		detail.price,
		(detail.realNumber-detail.returnNumber) AS number,
		detail.packUnit,
		detail.price * (detail.realNumber-detail.returnNumber) AS money 
	FROM
		t_ph_outpatient_dispensing_detail AS detail
		LEFT JOIN t_ph_outpatient_dispensing_information AS info ON detail.dispenseId = info.dispenseId
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= detail.drugId
		LEFT JOIN t_code_standard_code AS code ON code.sysName= '+@sysName+' 
		AND code.codeType= '+@codeType1+' 
		AND dic.origin = code.code 
	WHERE
		info.dispensingTime BETWEEN '+@startTime+' 
		AND '+@endTime+' 
		AND SUBSTRING ( dic.unifyPropertyBidInviting, 22, 2 ) = '+@pos+'
	) AS res 
GROUP BY
	res.drugName,res.spec,res.packUnit,res.price WITH ROLLUP HAVING GROUPING(res.drugName)=1 OR GROUPING(res.price)=0;'
	END
-- 查询住院
IF (@type = '住院')
	BEGIN
			SET @query='SELECT
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@sumStr+' ELSE CAST(MIN(res.medicareId) AS VARCHAR(20)) END 医保编码,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.drugName END 药品名称,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.spec END 药品规格,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE MIN(res.name) END 厂家,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE res.packUnit END 单位,
SUM(res.number) AS 数量,
CASE WHEN GROUPING(res.drugName) = 1 THEN '+@empty+' ELSE CAST(res.price AS VARCHAR(20)) END 单价,
CAST(SUM(CAST(res.money AS DECIMAL(10,2))) AS VARCHAR(100)) AS 金额
FROM
	(
	SELECT
		dic.medicareId,
		arrange.drugName,
		arrange.spec,
		code.name,
		arrange.price,
		arrange.retreatNumber AS number,
		arrange.packUnit,
		arrange.price * arrange.retreatNumber AS money 
	FROM
		t_drug_arrange_info AS arrange
		LEFT JOIN t_drug_dictionary AS dic ON dic.id= arrange.drugId
		LEFT JOIN t_code_standard_code AS code ON code.sysName= '+@sysName+' 
		AND code.codeType= '+@codeType1+' 
		AND dic.origin = code.code 
	WHERE
		arrange.agoPreparingUserTime BETWEEN '+@startTime+' 
		AND '+@endTime+' 
		AND SUBSTRING ( dic.unifyPropertyBidInviting, 22, 2 ) = '+@pos+' 
	) AS res 
GROUP BY
	res.drugName,res.spec,res.packUnit,res.price WITH ROLLUP HAVING GROUPING(res.drugName)=1 OR GROUPING(res.price)=0;'
	END

BEGIN
PRINT(@query)
EXEC(@query)
END
go

