CREATE PROCEDURE [dbo].[t_outp_payin_informations]
AS
BEGIN
SELECT
	CONVERT(VARCHAR(100),B.name) AS property,
	CONVERT(VARCHAR(100),C.value) AS name
	FROM sys.objects AS A
	INNER JOIN sys.columns AS B ON B.object_id = A.object_id
	LEFT JOIN sys.extended_properties AS C ON C.major_id = B.object_id AND C.minor_id = B.column_id
	WHERE A.name = 't_outP_payIn_Information'
	AND B.column_id in (18,34,35,36,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74)
END
go

exec sp_addextendedproperty 'MS_Description', '动态返回缴款统计字段', 'SCHEMA', 'dbo', 'PROCEDURE', 't_outp_payin_informations'
go

