CREATE PROCEDURE [dbo].[zy_purchase_plan_pharmacy]
AS
SELECT tdd.drugCode AS drugCode,
tdd.inputCode AS inputCode,
tdd.drugName AS drugName,
tdd.id AS drugId,
tpod.deptId AS deptId,
tcdi.deptName AS deptName,
tdd.spec AS drugSpec,
tpod.price AS price,
tpod.isSale AS isSale,
tpod.number AS pharmacyInventory,
tpod.number/tpod.ratio AS phWarehouseNumber,
tpod.minInventory AS alertLower,
tdd.largePackNumber AS largePackNumber,
tpod.packAmount AS packNumber,tpod.isSeparate,
tddi.number AS number,
tpod.currentRealOut AS outNumber,
tdd.origin AS drugOrigin,
tpod.remark AS remark
FROM t_drug_dictionary AS tdd
JOIN t_ph_outpatient_drug_info AS tpod ON tpod.drugId=tdd.id
LEFT JOIN t_code_department_information AS tcdi ON tpod.deptId=tcdi.id
LEFT JOIN t_dsh_drug_info AS tddi ON tpod.drugId=tddi.drugId
WHERE tdd.status=1;
go

exec sp_addextendedproperty 'MS_Description', '药品采购计划查询药房', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_purchase_plan_pharmacy'
go

