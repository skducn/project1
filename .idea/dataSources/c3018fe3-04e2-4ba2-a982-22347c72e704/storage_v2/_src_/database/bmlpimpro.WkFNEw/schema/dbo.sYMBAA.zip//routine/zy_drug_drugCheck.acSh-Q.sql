CREATE PROCEDURE [dbo].[zy_drug_drugCheck](
@screen VARCHAR(50),
@westMedicine VARCHAR(50),
@centreMedicine VARCHAR(50),
@becomeMedicine VARCHAR(50),
@classify VARCHAR(50),
@filtrate VARCHAR(50),
@length INT,
@initialPosition INT,
@batchId INT,
@deptId INT
)
AS
DECLARE @sql nvarchar(MAX)
SET @sql = 'SELECT dici.id AS drugId,
				dici.unifyPropertyBidInviting AS unifyPropertyBidInviting,
        dici.drugCategory AS drugType,
        dici.drugCode AS drugCode,
        dici.drugName AS drugName,
        dici.spec AS drugStandard,
        dici.inputCode AS inputCode,
        dici.origin AS origin,
        dici.largePackNumber AS largePackAmount,
        dici.largePackUnit AS largePackUnit,
        drug.wholesale AS wholesale,
        drug.price AS price,
				
        info.currentRealOpening AS lastRealOpening,
        info.currentInvoiceOpening AS lastInvoiceOpening,
        info.number AS currentRealOpening,
        info.invoiceNumber AS currentInvoiceOpening,
				info.lastRealOpening AS lastStock,
				(info.lastRealOpening*drug.price) AS lastSum,
        info.currentInvoiceIn+info.currentSpecialInvoiceIn AS currentInvoiceIn,
        info.currentRealIn+info.currentSpecialRealIn AS currentRealIn,
        info.currentRealOut+info.currentSpecialRealOut AS currentRealOut,
				info.currentSpecialRealOpening AS currentSpecialRealOpening,
				info.currentSpecialInvoiceOpening AS currentSpecialInvoiceOpening,
				info.currentSpecialRealOut AS currentSpecialRealOut,
				info.currentSpecialInvoiceIn AS currentSpecialInvoiceIn,
				info.currentSpecialRealIn AS currentSpecialRealIn,
        
				info.isSale AS which,
        dici.soreCode AS orderCode
				FROM t_dc_inventory_detail AS drug INNER JOIN t_drug_dictionary AS dici
				ON dici.id = drug.drugId INNER JOIN t_dsh_drug_info AS info
				ON info.drugId = dici.id INNER JOIN t_dc_inventory_banlance AS banlance
				ON banlance.batchId = drug.checkId 
				WHERE banlance.batchId = '+CONVERT(nvarchar(10), @batchId)+' AND banlance.deptId = '+CONVERT(nvarchar(10), @deptId)+'AND banlance.iType =1'
				IF @classify = '-1'
				SET @sql = @sql+ 'AND 1=1'
				IF @classify != '-1'
				SET @sql = @sql+ 'AND SUBSTRING(dici.unifyPropertyBidInviting, '+CONVERT(nvarchar(10), @initialPosition)+','+CONVERT(nvarchar(10), @length)+') = '+CHAR(39)+@classify+CHAR(39)+''
				IF @screen IS NOT NULL
				SET @sql = @sql+'AND (dici.drugCode LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+' OR dici.drugName LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+'OR dici.inputCode LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+')'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03)'
				IF @westMedicine IS NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 09)'
				IF @westMedicine IS NULL AND @centreMedicine IS  NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 06)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03 OR dici.drugCategory = 09)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03 OR dici.drugCategory = 06)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03 OR dici.drugCategory = 06 OR dici.drugCategory = 09)'
				IF @westMedicine IS NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 09 OR dici.drugCategory = 06)'
			
				IF @filtrate = '所有'
				SET @sql = @sql+ 'AND 1=1'
				IF @filtrate = '上柜'
				SET @sql = @sql+ 'AND info.isSale LIKE '+CHAR(39)+CHAR(37)+'1'+CHAR(37)+CHAR(39)+''
				IF @filtrate = '下柜'
				SET @sql = @sql+ 'AND info.isSale LIKE '+CHAR(39)+CHAR(37)+'0'+CHAR(37)+CHAR(39)+''
				IF @filtrate = '有库存'
				SET @sql = @sql+ 'AND drug.blanceNumber > 0'
				IF @filtrate = '无库存'
				SET @sql = @sql+ 'AND drug.blanceNumber <= 0'
				IF @filtrate = '有发票库存'
				SET @sql = @sql+ 'AND drug.invoiceNumber > 0'
				SET @sql = @sql + 'GROUP BY dici.unifyPropertyBidInviting,dici.drugCategory,dici.drugCode,dici.drugName,dici.spec,dici.inputCode,dici.origin,dici.largePackNumber,dici.largePackUnit,drug.wholesale,drug.price,info.lastRealOpening,info.lastInvoiceOpening,dici.id,info.isSale,dici.soreCode,dici.id,info.number, info.invoiceNumber,info.currentSpecialRealOpening,info.currentSpecialInvoiceOpening,info.currentSpecialRealOut,info.currentSpecialInvoiceIn,info.currentSpecialRealIn,info.currentRealOpening,info.currentInvoiceOpening,info.currentInvoiceIn,info.currentRealIn,info.currentRealOut,info.lastRealOpening'
				PRINT @sql
				EXEC(@sql)
go

exec sp_addextendedproperty 'MS_Description', '药库全库盘点(查询已有盘点信息)
', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_drug_drugCheck'
go

