CREATE PROCEDURE [dbo].[reported_drug_in_summary]
@startTime VARCHAR(10),
@endTime VARCHAR(10)
as 
begin 
SELECT sinfo.name as 供应单位名称,count(DISTINCT detail.drugId) as 入库种类,
sum(detail.realNumber) as 入库总数据,
sum(batch.number*batch.cost) as 进价金额,
sum(batch.number*batch.wholesale) as 批发金额,
sum(batch.number*batch.price) as 零售金额,
sum(batch.number*batch.price)-sum(batch.number*batch.cost) as 进销差额
 from t_dsh_outin_batch as batch
join t_dsh_outin_detail as detail on detail.detailId = batch.detailId 
join t_dsh_outin_info as oinfo on detail.outinId = oinfo.id 
join t_drug_supply_info as sinfo on sinfo.id = oinfo.relativeDeptId 
where oinfo.state =3 and receiptType >0 and receiptType < 9 and checkTime>=@startTime and checkTime<=@endTime
GROUP BY sinfo.name
end
go

