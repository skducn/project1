CREATE PROCEDURE [dbo].[report_inpatient_medicareFee_total]
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-04-30 23:59:59'
-- @recordCount int output --关键字代表输出参数
as
begin
declare @enterTime nvarchar(50),
@leaveTime nvarchar(50),
@allTime nvarchar(100)
set @allTime = @timeString
set @enterTime = substring(@allTime,0,20)
set @leaveTime = substring(@allTime,21,20)
CREATE TABLE #month_title 
-- 月份临时表及表头
( 
    title NVARCHAR(50),
    sort int
)INSERT INTO #month_title VALUES 
('一月份',1),('二月份',2),('三月份',3),('一季度',4), 
('四月份',5),('五月份',6),('六月份',7),('二季度',8),('上半年',9), 
('七月份',10),('八月份',11),('九月份',12),('三季度',13), 
('十月份',14),('十一月份',15),('十二月份', 16),('四季度',17),('下半年',18), 
('全年',19)
SELECT 
#month_title.title AS '年份', 
/*CASE WHEN ( 
 dataSet.allNum IS NULL 
 OR dataSet.allNum = '' 
) THEN 0 ELSE dataSet.allNum END AS '门急诊人次',*/
CASE WHEN ( 
dataSet.totalIncome IS NULL 
OR dataSet.totalIncome = '' 
) THEN 0 ELSE dataSet.totalIncome END AS '总收入（元）',
CASE WHEN ( 
dataSet.drugRatio IS NULL 
OR dataSet.drugRatio = '' 
) THEN 0 ELSE
Convert(decimal(18,2),dataSet.drugRatio) * 100
END AS '药占比（%）',
CASE WHEN ( 
dataSet.avgCost IS NULL 
OR dataSet.avgCost = '' 
) THEN 0 ELSE
Convert(decimal(18,2),dataSet.avgCost)
END AS '均次费（元）',
CASE WHEN ( 
dataSet.tcmNum IS NULL 
OR dataSet.tcmNum = '' 
) THEN 0 ELSE dataSet.tcmNum END AS '中药张数',
CASE WHEN ( 
dataSet.tcmTotal IS NULL 
OR dataSet.tcmTotal = '' 
) THEN 0 ELSE dataSet.tcmTotal END AS '中药收入（元）',
CASE WHEN ( 
dataSet.wmNum IS NULL 
OR dataSet.wmNum = '' 
) THEN 0 ELSE dataSet.wmNum END AS '西药张数',
CASE WHEN ( 
dataSet.wmTotal IS NULL 
OR dataSet.wmTotal = '' 
) THEN 0 ELSE dataSet.wmTotal END AS '西药收入（元）',
CASE WHEN ( 
dataSet.useUpTotal IS NULL 
OR dataSet.useUpTotal = '' 
) THEN 0 ELSE 
Convert(decimal(18,2),dataSet.useUpTotal)
END AS '病房药房日消耗（元）'
FROM 
#month_title 
LEFT JOIN 
( 
 SELECT 
 CASE 
  WHEN Grouping(h_year)=1 AND Grouping(quarter)=1 AND Grouping(l_month)=1 THEN '全年' 
  WHEN Grouping(quarter)=1  AND Grouping(l_month)=1 THEN h_year 
  WHEN Grouping(l_month)=1 THEN quarter 
 ELSE 
  (CASE l_month WHEN '1' THEN '一月份' 
  WHEN '2' THEN '二月份' 
  WHEN '3' THEN '三月份' 
  WHEN '4' THEN '四月份' 
  WHEN '5' THEN '五月份' 
  WHEN '6' THEN '六月份' 
  WHEN '7' THEN '七月份' 
  WHEN '8' THEN '八月份' 
  WHEN '9' THEN '九月份' 
  WHEN '10' THEN '十月份' 
  WHEN '11' THEN '十一月份' 
  WHEN '12' THEN '十二月份' 
  ELSE l_month END) 
 END 
 AS title, 
 --sum(allNum) AS allNum,
 SUM(totalIncome) AS totalIncome,
avg(drugRatio) as drugRatio,
avg(avgCost) as avgCost,
 SUM(tcmNum) as tcmNum,
SUM(tcmTotal) as tcmTotal,
SUM(wmNum) as wmNum,
SUM(wmTotal) as wmTotal,
SUM(useUpTotal) as useUpTotal
 FROM 
 ( 
  SELECT 
--  门急诊人次
-- COUNT(DISTINCT visitId) AS allNum,
-- 总收入（元）
  SUM(
		CASE
		when itemType = 03 THEN fee
		when itemType = 06 THEN fee
		when itemType = 09 THEN fee END
	) AS totalIncome,
-- 药占比
case when SUM(
  CASE
  when itemType = 03 THEN fee
  when itemType = 06 THEN fee
  when itemType = 09 THEN fee END
)=0 or SUM(fee)=0  then 0
ELSE
SUM(
  CASE
  when itemType = 03 THEN fee
  when itemType = 06 THEN fee
  when itemType = 09 THEN fee END
)/SUM(fee) end AS drugRatio,
-- 均次费
case when SUM(
  CASE
  when itemType = 03 THEN fee
  when itemType = 06 THEN fee
  when itemType = 09 THEN fee END
)=0 or COUNT(DISTINCT inPId)=0  then 0
ELSE
SUM(
  CASE
  when itemType = 03 THEN fee
  when itemType = 06 THEN fee
  when itemType = 09 THEN fee END
)/COUNT(DISTINCT inPId) end AS avgCost,
-- 中药张数
  COUNT(
CASE
  when itemType = 06 THEN itemType ELSE null END
) AS tcmNum,
-- 中药收入（元）
SUM(
  CASE
  when itemType = 06 THEN fee ELSE 0 END
) AS tcmTotal,
-- 西药张数
COUNT(
  CASE
  when itemType = 03 THEN itemType ELSE null END
) AS wmNum,
-- 西药收入（元）
SUM(
  CASE
  when itemType = 03 THEN fee ELSE 0 END
) AS wmTotal,
-- 药房当天药品所有费
SUM(
  CASE
  when itemType = 03 THEN fee
  when itemType = 06 THEN fee
  when itemType = 09 THEN fee END
)/dbo.[report_days_func](MAX(feeTime)) AS useUpTotal,
  CONVERT(VARCHAR, Month(feeTime)) AS l_month, 
  CASE WHEN Month(feeTime) < 4 THEN '一季度' 
   WHEN Month(feeTime) < 7 THEN '二季度' 
   WHEN Month(feeTime) < 10 THEN '三季度' 
   WHEN Month(feeTime) < 13 THEN '四季度' 
  END 
  AS quarter, 
  CASE WHEN Month(feeTime) < 7 THEN '上半年' 
   WHEN Month(feeTime) < 13 THEN '下半年' 
  END 
  AS h_year 
  FROM bmlinppro.dbo.t_inpatient_patient_fee_serial_account
  WHERE feeTime BETWEEN @enterTime AND @leaveTime
  GROUP BY Year(feeTime), Month(feeTime)
 ) tab 
 GROUP BY h_year, quarter, l_month WITH rollup 
) dataSet ON dataSet.title = #month_title.title
ORDER BY #month_title.sort
end;
go

