CREATE PROCEDURE [dbo].[zy_drug_listBatchReferrer](
@screen VARCHAR(50),
@westMedicine VARCHAR(50),
@centreMedicine VARCHAR(50),
@becomeMedicine VARCHAR(50),
@classify VARCHAR(50),
@filtrate VARCHAR(50),
@length INT,
@initialPosition INT,
@batchId INT,
@deptId INT
)
AS
DECLARE @sql nvarchar(MAX)
SET @sql = 'select dici.id AS drugId,
				dici.unifyPropertyBidInviting AS unifyPropertyBidInviting,
        dici.drugCategory AS drugType,
        dici.drugCode AS drugCode,
        dici.drugName AS drugName,
        dici.spec AS drugStandard,
        dici.inputCode AS inputCode,
        dici.origin AS origin,
        dici.largePackNumber AS largePackAmount,
        dici.largePackUnit AS largePackUnit,
        drug.wholesale AS wholesale,
        drug.price AS price,
				
				drug.lastRealOpening AS lastStock,
				(drug.lastRealOpening*drug.price) AS lastSum,
        drug.currentRealOpening AS lastRealOpening,
        drug.currentInvoiceOpening AS lastInvoiceOpening,
        drug.number AS currentRealOpening,
        drug.invoiceNumber AS currentInvoiceOpening,
				drug.currentInvoiceIn+drug.currentSpecialInvoiceIn AS currentInvoiceIn,
        drug.currentRealIn+drug.currentSpecialRealIn AS currentRealIn,
        drug.currentRealOut+drug.currentSpecialRealOut AS currentRealOut,
				drug.currentSpecialRealOpening AS currentSpecialRealOpening,
				drug.currentSpecialInvoiceOpening AS currentSpecialInvoiceOpening,
				drug.currentSpecialRealOut AS currentSpecialRealOut,
				drug.currentSpecialInvoiceIn AS currentSpecialInvoiceIn,
				drug.currentSpecialRealIn AS currentSpecialRealIn,
				
        drug.isSale AS which,
				stock.positionName AS positions,
        stock.batch AS batchNo,
        stock.validity AS validity,
        stock.costPrice AS costPrice,
        stock.firmBatchNumber AS number,
        dici.soreCode AS orderCode
        from t_drug_dictionary AS dici inner join t_dsh_drug_info AS drug on dici.id = drug.drugId
        inner join t_dc_inventory_detail AS indetail on indetail.drugId = dici.id  inner join t_dc_inventory_lotnumber AS stock ON stock.drugId = dici.id INNER JOIN t_dc_inventory_banlance AS banlance ON banlance.batchId = indetail.checkId
				WHERE banlance.batchId = '+CONVERT(nvarchar(10), @batchId)+' AND banlance.deptId = '+CONVERT(nvarchar(10), @deptId)+'AND banlance.iType =1'
				IF @classify = '-1'
				SET @sql = @sql+ 'AND 1=1'
				IF @classify != '-1'
				SET @sql = @sql+ 'AND SUBSTRING(dici.unifyPropertyBidInviting, '+CONVERT(nvarchar(10), @initialPosition)+','+CONVERT(nvarchar(10),@length)+') = '+CHAR(39)+@classify+CHAR(39)+''
				IF @screen IS NOT NULL
				SET @sql = @sql+'AND (dici.drugCode LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+' OR dici.drugName LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+'OR dici.inputCode LIKE '+CHAR(39)+CHAR(37)+@screen+CHAR(37)+CHAR(39)+')'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 01)'
				IF @westMedicine IS NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03)'
				IF @westMedicine IS NULL AND @centreMedicine IS  NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 02)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 01 OR dici.drugCategory = 03)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 01 OR dici.drugCategory = 02)'
				IF @westMedicine IS NOT NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 01 OR dici.drugCategory = 03 OR dici.drugCategory = 02)'
				IF @westMedicine IS NULL AND @centreMedicine IS NOT NULL AND @becomeMedicine IS NOT NULL
				SET @sql = @sql+ 'AND (dici.drugCategory = 03 OR dici.drugCategory = 02)'
				IF @filtrate = '所有'
				SET @sql = @sql+ 'AND 1=1'
				IF @filtrate = '上柜'
				SET @sql = @sql+ 'AND drug.isSale LIKE '+CHAR(39)+CHAR(37)+'1'+CHAR(37)+CHAR(39)+''
				IF @filtrate = '下柜'
				SET @sql = @sql+ 'AND drug.isSale LIKE '+CHAR(39)+CHAR(37)+'0'+CHAR(37)+CHAR(39)+''
				IF @filtrate = '有库存'
				SET @sql = @sql+ 'AND indetail.blanceNumber > 0'
				IF @filtrate = '无库存'
				SET @sql = @sql+ 'AND indetail.blanceNumber <= 0'
				IF @filtrate = '有发票库存'
				SET @sql = @sql+ 'AND indetail.invoiceNumber > 0'
				SET @sql = @sql + 'GROUP BY 	dici.unifyPropertyBidInviting,dici.drugCategory,dici.drugCode,dici.drugName,dici.spec,dici.inputCode,
				dici.origin,dici.largePackNumber,dici.largePackUnit,drug.wholesale,drug.price,drug.lastRealOpening,drug.lastInvoiceOpening,
				dici.id,drug.isSale,dici.id,drug.number,drug.invoiceNumber,drug.currentSpecialRealOpening,drug.currentSpecialInvoiceOpening,
				drug.currentSpecialRealOut,drug.currentSpecialInvoiceIn,drug.currentSpecialRealIn,drug.currentRealOpening,drug.currentInvoiceOpening,
				drug.currentInvoiceIn,drug.currentRealIn,drug.currentRealOut,stock.positionName,stock.batch,stock.validity,stock.costPrice,stock.firmBatchNumber,
				dici.soreCode,drug.lastRealOpening'
				EXEC(@sql)
go

exec sp_addextendedproperty 'MS_Description', '药库全库盘点查询已有盘点信息的仓批数据', 'SCHEMA', 'dbo', 'PROCEDURE',
     'zy_drug_listBatchReferrer'
go

