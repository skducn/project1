CREATE PROCEDURE [dbo].[list_planPeriod](
@planPeriod nvarchar(10)
)
AS
select * from  t_drug_purchase_plan_periods where CONVERT(nvarchar(10), planPeriod) LIKE'%'+@planPeriod+'%'
go

exec sp_addextendedproperty 'MS_Description', '模糊查询采购计划期数', 'SCHEMA', 'dbo', 'PROCEDURE', 'list_planPeriod'
go

