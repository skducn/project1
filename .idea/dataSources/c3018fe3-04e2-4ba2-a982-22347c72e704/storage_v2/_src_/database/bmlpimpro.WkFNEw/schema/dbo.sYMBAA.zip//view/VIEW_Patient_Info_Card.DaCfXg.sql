CREATE VIEW [dbo].[VIEW_Patient_Info_Card] AS SELECT
	ci.outPNo,
	ci.cardNo,
	bi.name,
	bi.sex,
CASE

		WHEN bi.idCardNo IS NULL THEN
		bi.idCardNo ELSE dbo.AESdecrypt ( bi.idCardNo )
	END AS idCardNo,
CASE

		WHEN bi.cellphone IS NULL THEN
		bi.cellphone ELSE dbo.AESdecrypt ( bi.cellphone )
	END AS cellphone,
CASE

		WHEN bi.nowAddr IS NULL THEN
		bi.nowAddr ELSE dbo.AESdecrypt ( bi.nowAddr )
	END AS nowAddr,
	ci.cardCategory
FROM
	t_system_patient_card_info ci
	LEFT JOIN t_system_patient_basic_info bi ON ci.outPNo = bi.outPNo
go

