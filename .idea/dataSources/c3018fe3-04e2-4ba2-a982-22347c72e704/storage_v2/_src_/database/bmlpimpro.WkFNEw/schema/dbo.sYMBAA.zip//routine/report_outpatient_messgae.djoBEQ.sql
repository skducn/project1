CREATE PROCEDURE [dbo].[report_outpatient_messgae]
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-4-30 23:59:59'
-- @recordCount int output --关键字代表输出参数
as
begin
declare @enterTime nvarchar(50),
@leaveTime nvarchar(50),
@allTime nvarchar(100)
set @allTime = @timeString
set @enterTime = substring(@allTime,0,20)
set @leaveTime = substring(@allTime,21,20)
SELECT 
CASE WHEN GROUPING(a.inPNo)=1 THEN '总计' ELSE a.inPNo END AS 住院号,
CASE WHEN GROUPING(a.inPNo)=1 THEN Convert(VARCHAR,COUNT(a.name)) ELSE MAX(a.name) END AS 姓名,
CASE WHEN GROUPING(a.inPNo)=1 THEN null ELSE
 case MAX(a.sex)
    WHEN 0 THEN
     '男'
    WHEN 1 THEN
     '女'
    WHEN 2 THEN
     '未知'
    WHEN 3 THEN
     '未指定' ELSE '其他'
    END 
end AS 性别,
CASE WHEN GROUPING(a.inPNo)=1 THEN null ELSE MAX(a.inPAge) END AS 年龄,
CASE WHEN GROUPING(a.inPNo)=1 THEN null ELSE MAX(a.identification) END AS 身份,
CASE WHEN GROUPING(a.inPNo)=1 THEN null ELSE MAX(a.inPDatetime) END AS 入院日期,
CASE WHEN GROUPING(a.inPNo)=1 THEN null ELSE MAX(a.leaveDate) END AS 出院日期,
CASE WHEN GROUPING(a.inPNo)=1 THEN Convert(VARCHAR,SUM(DATEDIFF(day, a.inPDatetime, a.leaveDate))) ELSE MAX(DATEDIFF(day, a.inPDatetime, a.leaveDate)) END AS 住院天数,
CASE WHEN GROUPING(a.inPNo)=1 THEN null ELSE MAX(a.inPDiagnosisName) END AS 入院诊断,
CASE WHEN GROUPING(a.inPNo)=1 THEN null ELSE MAX(c.docName) END AS 负责医生 
FROM bmlinppro.dbo.t_inpatient_register AS a
left JOIN t_code_doctor_information AS c ON a.bedDoc = c.docId
--WHERE leaveStatus = 7 AND leaveDate BETWEEN substring(@timeString,0,20) AND substring(@timeString,21,20)
WHERE a.leaveStatus = 7 AND a.leaveDate BETWEEN @enterTime AND @leaveTime
GROUP BY a.inPNo WITH ROLLUP
end ;
go

