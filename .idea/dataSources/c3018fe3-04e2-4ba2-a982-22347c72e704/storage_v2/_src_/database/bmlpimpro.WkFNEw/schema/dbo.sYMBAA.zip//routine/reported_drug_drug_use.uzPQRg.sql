CREATE PROCEDURE [dbo].[reported_drug_drug_use]
  @startTime VARCHAR(10) , 
  @endTime VARCHAR(10)
AS
BEGIN

select medicareId as 医保码,genericName as 通用名,temp.drugName as 商品名,'' as 厂商,case dispenseType 
when 0 then '针剂'when 1 then '大输液'
when 2 then '片剂'when 3 then '口服液'
when 4 then '贴剂'when 5 then '中成药'
when 6 then '内服'when 7 then '外用'
when 8 then '粉散剂'when 9 then '胶囊剂'
when 10 then '丸剂' end as 剂型,
spec as 规格,0 as 订单量,temp.入库量,temp.出库量,
temp.处方数,temp.药品用量,temp.药品费用,0 as 累计订单量,temp.累计入库量,temp.累计出库量,
temp.累计处方,temp.累计药品用量,temp.累计药品费用 FROM t_drug_dictionary as dic
join (
	SELECT dic.id,	drugName,
	ISNULL(ru.realNumber, 0) AS 入库量,
	ISNULL(chu.realNumber, 0) AS 出库量,
		ISNULL(recnum.recipeId, 0) AS 处方数,
		ISNULL(recdrug.number, 0) AS 药品用量,
		ISNULL(recdrug.amount,0) AS 药品费用,
	ISNULL(ljru.realNumber, 0) AS 累计入库量,
	ISNULL(ljchu.realNumber, 0) AS 累计出库量,
		ISNULL(ljrecnum.recipeId, 0) AS 累计处方,
		ISNULL(ljrecdrug.ljnumber, 0) AS 累计药品用量,
		ISNULL(ljrecdrug.ljamount,0) AS 累计药品费用
	FROM t_drug_dictionary AS dic
left join (select sum(realNumber) as realNumber,de.drugId from t_dsh_outin_detail as de 
join t_dsh_outin_info as info on de.outinId =  info.id 
where info.receiptType >0 and info.receiptType <6 and state = 3
and info.checkTime>@startTime and info.checkTime<@endTime GROUP  BY de.drugId) as ru on ru.drugId = dic.id

left join (select sum(realNumber) as realNumber,de.drugId from t_dsh_outin_detail as de 
join t_dsh_outin_info as info on de.outinId =  info.id 
where info.receiptType =11  and state = 3
and info.checkTime>@startTime and info.checkTime<@endTime GROUP  BY de.drugId) as chu on chu.drugId = dic.id

left join (select sum(realNumber) as realNumber,de.drugId from t_dsh_outin_detail as de 
join t_dsh_outin_info as info on de.outinId =  info.id 
where info.receiptType >0 and info.receiptType <6  and state = 3 GROUP  BY de.drugId) as ljru on ljru.drugId = dic.id

left join (select sum(realNumber) as realNumber,de.drugId from t_dsh_outin_detail as de 
join t_dsh_outin_info as info on de.outinId =  info.id 
where info.receiptType =11  and state = 3 GROUP  BY de.drugId) as ljchu on ljchu.drugId = dic.id

	 left  join (
	select count(de.recipeId) AS recipeId,drugId  from t_ph_outpatient_dispensing_detail as de
	join t_ph_outpatient_dispensing_information as rinfo on  rinfo.recipeId = de.recipeId
	where state = 3 and rinfo.recipeTime>@startTime and rinfo.recipeTime<@endTime GROUP BY drugId
) as recnum on recnum.drugId = dic.id
	 left  join (
	select count(de.recipeId) AS recipeId,drugId  from t_ph_outpatient_dispensing_detail as de
	join t_ph_outpatient_dispensing_information as rinfo on  rinfo.recipeId = de.recipeId
	where state = 3 GROUP BY drugId
) as ljrecnum on ljrecnum.drugId = dic.id
	 left  join (
	select sum(de.number) as number,de.drugId as drugId,sum(de.price*de.number) as amount from t_ph_outpatient_dispensing_detail as de
	join t_ph_outpatient_dispensing_information as rinfo on  rinfo.recipeId = de.recipeId
	where state = 3 and rinfo.recipeTime>@startTime and rinfo.recipeTime<@endTime
 GROUP BY de.drugId
) as recdrug on recdrug.drugId = dic.id
 left join (
	select sum(de.number) as ljnumber,de.drugId as ljdrugId,sum(de.price*de.number) as ljamount  from t_ph_outpatient_dispensing_detail as de
	join t_ph_outpatient_dispensing_information as rinfo on  rinfo.recipeId = de.recipeId
	where state = 3  GROUP BY de.drugId
)  as ljrecdrug on ljrecdrug.ljdrugId = dic.id
	) as temp on dic.id = temp.id
end
go

