CREATE PROCEDURE [dbo].[report_inpatient_drug_Revenue_expenditure]
@timeString nvarchar(100) = '2020-01-01 00:00:00,2020-4-30 23:59:59'
as
begin
declare @enterTime nvarchar(50),
@leaveTime nvarchar(50),
@allTime nvarchar(100)
set @allTime = @timeString
set @enterTime = substring(@allTime,0,20)
set @leaveTime = substring(@allTime,21,20)

select reg.inPNo as 住院号, reg.name as 姓名,tui.收入西药费用,tui.收入中成药费用,tui.收入中草药费用,
shou.支出西药总费用,shou.支出成药总费用,shou.支出草药总费用 from 
						--住院药品收入费用统计
						(SELECT  inPId,
						SUM ( CASE itemType WHEN '03' THEN fee ELSE 0 END ) AS 收入西药费用,
						SUM ( CASE itemType WHEN '06' THEN fee ELSE 0 END ) AS 收入中成药费用,
						SUM ( CASE itemType WHEN '09' THEN fee ELSE 0 END ) AS 收入中草药费用
						FROM bmlinppro.dbo.t_inpatient_patient_fee_serial_account
									where 
									feeTime >=@enterTime and feeTime<@leaveTime
									AND itemType IN ( '03', '06', '09' )
						group by inPId)as tui
right JOIN(SELECT inPId,
SUM(x) 支出西药总费用,
SUM(y) 支出成药总费用,
SUM(z) 支出草药总费用
FROM
(SELECT inPId,
CASE itemType 
 WHEN '03' THEN 
       CASE WHEN r is null THEN alreadyNumber * price
      ELSE (alreadyNumber - r) * price
        END 
else 0
END x,
CASE itemType 
 WHEN '06' THEN 
       CASE WHEN r is null THEN alreadyNumber * price
      ELSE (alreadyNumber - r) * price
        END 
else 0
END y,
CASE itemType 
 WHEN '09' THEN 
       CASE WHEN r is null THEN alreadyNumber * price
      ELSE (alreadyNumber - r) * price
        END 
else 0
END z
from 
(SELECT inPId,itemType,price,alreadyNumber,r FROM (SELECT price,alreadyNumber,itemType,id,inPId from t_drug_arrange_info 
      where agoPreparingUserTime>=@enterTime and
      agoPreparingUserTime<@leaveTime and state = 2 ) a 
   LEFT JOIN 
   (SELECT SUM(pleaseNumber - retreatNumber) r,agoArrangeId
       FROM t_drug_arrange_info
       WHERE state = 22 and agoPreparingUserTime>=@enterTime and
      agoPreparingUserTime<@leaveTime  GROUP BY agoArrangeId) b ON b.agoArrangeId = a.id )
		c)
	d GROUP BY inPId) as shou on tui.inPId=shou.inPId
 left join bmlinppro.dbo.t_inpatient_register as reg on reg.inPId=shou.inPId
end
go

