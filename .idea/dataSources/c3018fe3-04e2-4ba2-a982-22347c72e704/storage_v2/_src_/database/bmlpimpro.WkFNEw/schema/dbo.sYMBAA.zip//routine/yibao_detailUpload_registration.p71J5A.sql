CREATE PROCEDURE [dbo].[yibao_detailUpload_registration]
@today nchar(8)
AS
BEGIN
	BEGIN
		IF(@today IS NULL)
			SELECT @today = CONVERT(nchar(8),DATEADD(day,-1,getdate()),112)
	END
--开启事务
	BEGIN TRY 
	BEGIN TRANSACTION
--1.先删除数据
	DELETE FROM t_medicare_registration WHERE LEFT(returnDate, 8) = @today
--2.从医保挂号收费库抽取数据
	INSERT INTO t_medicare_registration
	SELECT t_medicare_outpatient_register_cashier.centerStreamNo,
	t_medicare_outpatient_register_cashier.cardNo,
	t_medicare_outpatient_register_cashier.deptCode,
	t_medicare_outpatient_register_cashier.deptName,
	t_medicare_outpatient_register_cashier.registerFee,
	t_medicare_outpatient_register_cashier.clinicFee,
	t_medicare_outpatient_register_cashier.dealTotalFee,
	t_medicare_outpatient_register_cashier.medicalInvoiceTotalFee,
	t_medicare_outpatient_register_cashier.nonMedicalInvoiceSelfPay,
	t_medicare_outpatient_register_cashier.transmitDate+'/'+REPLACE(transmitTime, ':', '')+'/',
	t_medicare_outpatient_register_cashier.medicareWay,
	t_medicare_outpatient_register_cashier.settleCategory AS settleType,
	t_medicare_outpatient_register_cashier.cashierStatus AS chargeFlag,
	t_outpatient_registration_data.visitId
	FROM t_medicare_outpatient_register_cashier
	INNER JOIN t_outpatient_registration_invoice
	ON t_medicare_outpatient_register_cashier.invoiceNo = t_outpatient_registration_invoice.invoiceNo
	INNER JOIN t_outpatient_registration_data
	ON t_outpatient_registration_invoice.invoiceId = t_outpatient_registration_data.invoiceId
	WHERE t_medicare_outpatient_register_cashier.transmitDate = '1'
	AND t_medicare_outpatient_register_cashier.invoiceType = 0
	AND t_medicare_outpatient_register_cashier.settleType = 1
	AND t_medicare_outpatient_register_cashier.centerStreamNo IS NOT NULL
--提交事务
COMMIT TRANSACTION
END TRY
--有异常被捕获
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION
END CATCH
END
PRINT @today
go

exec sp_addextendedproperty 'MS_Description', '医保明细上传-抽取挂号数据', 'SCHEMA', 'dbo', 'PROCEDURE',
     'yibao_detailUpload_registration'
go

