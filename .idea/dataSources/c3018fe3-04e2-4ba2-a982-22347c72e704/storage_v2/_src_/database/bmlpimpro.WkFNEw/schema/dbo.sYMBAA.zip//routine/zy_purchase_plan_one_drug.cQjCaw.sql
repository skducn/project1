CREATE PROCEDURE [dbo].[zy_purchase_plan_one_drug](
@drugId INT,
@deptId INT
)
AS
SELECT f.lastRealIn AS lastMonthIncome,
        f.lastRealOut AS lastMonthExpend,
        x.inNumber AS lastLastMonthIncome,
        x.outNumber AS lastLastMonthExpend,
        e.drugCode AS drugCode,
        e.drugCategory AS type,
        e.medicareId AS medicareId,
    e.spec AS drugSpec,
    e.price AS price,
    e.wholesale AS wholesale,
        e.largePackNumber AS largePackNumber,
        e.packNumber AS packNumber,
        e.origin AS drugOrigin,
        e.basicDose AS basicDose,
        e.doseUnit AS doseUnit,
        e.basicPackUnit AS basicPackUnit,
        e.packUnit AS packUnit,
        e.largePackUnit AS largePackUnit,
        f.number AS number,
    y.pharmacyInventory AS pharmacyInventory
        FROM
        (SELECT id,spec,price,wholesale,drugCode,packNumber,drugCategory,medicareId,largePackNumber,
     origin,basicDose,doseUnit,basicPackUnit,packUnit,largePackUnit FROM t_drug_dictionary AS tdd WHERE id=@drugId) e
        INNER JOIN t_dsh_drug_info AS f
        ON f.drugId=e.id
    LEFT JOIN
    (SELECT inNumber,outNumber FROM t_dc_inventory_detail WHERE checkId =(SELECT TOP 1 batchId FROM (SELECT TOP 2 batchId FROM t_dc_inventory_banlance WHERE endTime IS NOT NULL ORDER BY batchId DESC) a ORDER BY a.batchId ASC) AND drugId = @drugId) x
    ON 1=1
    LEFT JOIN
(SELECT drugId,SUM(number) AS pharmacyInventory FROM t_ph_outpatient_drug_info GROUP BY drugId) y
ON y.drugId=@drugId
go

exec sp_addextendedproperty 'MS_Description', '药品采购计划查询一个药品信息', 'SCHEMA', 'dbo', 'PROCEDURE',
     'zy_purchase_plan_one_drug'
go

