CREATE PROCEDURE [dbo].[reported_drug_supplier_storage_total]
  @timeString VARCHAR(100)
AS
BEGIN

DECLARE
@startTime VARCHAR(100),
@endTime VARCHAR(100)

IF (@timeString IS NOT NULL AND @timeString != '')

    BEGIN
    SET @startTime = SUBSTRING(@timeString,0,20)
    SET @endTime = SUBSTRING(@timeString,21,20)
		END
--		IF (@startTime != '')
	--			BEGIN
		--			SET @startTime = '2020-03-01 00:00:00'
			--	END
--		IF (@endTime != '')
	--			BEGIN
		--			SET @endTime = '2021-03-05 00:00:00'
			--	END
-- 药品_药库药品信息表：T_DSH_drug_info
--药品_药房出入明细表：t_ph_outin_detail
--药品_药库出入信息表：T_DSH_outin_info	
SELECT
 	CASE WHEN grouping(supplyName) = '1' THEN	'合计' WHEN grouping(supplyName) = '0' AND grouping(drugName) = '1' THEN '小计' ELSE	supplyName END 供应商名称,
	drugName AS 药品名称, 
	CASE WHEN grouping(supplyName) = '1' THEN '' WHEN grouping(supplyName) = '0' AND grouping(drugName) = '1' THEN ''  ELSE MIN(spec) END 规格,
 SUM (number) AS 数量,
	CASE WHEN grouping(supplyName) = '1' THEN null WHEN grouping(supplyName) = '0' AND grouping(drugName) = '1' THEN null  ELSE MIN(wholesale) END 进价,
 SUM (wholesaleAmount) AS 进价总金额,
	CASE WHEN grouping(supplyName) = '1' THEN null WHEN grouping(supplyName) = '0' AND grouping(drugName) = '1' THEN null  ELSE MIN(price) END 零售价,
 SUM (priceAmount) AS 零售总金额,
	CASE WHEN grouping(supplyName) = '1' THEN null WHEN grouping(supplyName) = '0' AND grouping(drugName) = '1' THEN null  ELSE MIN(spread) END 进销差额
FROM
	(
		SELECT
 			info.relativeDeptName AS supplyName,
			detail.drugName AS drugName,
			drugInfo.spec AS spec,
			SUM (detail.realNumber) AS number,
			detail.wholesale AS wholesale,
			SUM (detail.wholesaleAmount) AS wholesaleAmount,
			detail.price AS price,
			SUM (detail.priceAmount) AS priceAmount,
			detail.wholesale - detail.price AS spread
		FROM
			t_dsh_outin_info AS info
		LEFT JOIN t_dsh_outin_detail AS detail ON info.id = detail.outinId
		LEFT JOIN t_drug_dictionary AS drugInfo ON detail.drugId = drugInfo.id
-- 		LEFT JOIN T_drug_supply_info AS supplyInfo ON drugInfo.supplierId = supplyInfo.supplyid
		WHERE info.receiptType BETWEEN 1
		AND 10
		AND info.operateTime BETWEEN @startTime AND @endTime
		GROUP BY
 			info.relativeDeptName,
			detail.drugName,
			drugInfo.spec,
			detail.wholesale,
			detail.price
	) tb
GROUP BY
	rollup (
 		supplyName,
		drugName
	)

END
go

