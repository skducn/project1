CREATE PROCEDURE [dbo].[inp_in_sum]
@condition nvarchar(50)
        as
        begin
        DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
        IF (@condition IS NOT NULL AND @condition != '')

        BEGIN
        SET @startTime = SUBSTRING(@condition,0,20)
        SET @endTime = SUBSTRING(@condition,21,20)
        END

        -- 住院收入汇总
        select
        Convert(decimal(18,2), Round( max(case when row %3 = 1 then  row else null end), 2 ) ) id,
        max(case when row %3 = 1 then  typeName else null end) 收费项目1,
        Convert(decimal(18,2), Round( max(case when row %3 = 1 then  fee else null end), 2 ) ) 项目金额1,
        Convert(decimal(18,2), Round( max(case when row %3 = 2 then  row else null end), 2 ) ) id2,
        max(case when row %3 = 2 then  typeName else null end) 收费项目2,
        Convert(decimal(18,2), Round( max(case when row %3 = 2 then  fee else null end), 2 ) ) 项目金额2,
        Convert(decimal(18,2), Round( max(case when row %3 = 0 then  row else null end), 2 ) ) id3,
        max(case when row %3 = 0 then  typeName else null end) 收费项目3,
        Convert(decimal(18,2), Round( max(case when row %3 = 0 then  fee else null end), 2 ) ) 项目金额3
        from (
        select ROW_NUMBER() OVER (order by tcic.typeName) row,tcic.typeName,
        sum(tipfa.fee) fee
        from bmlinppro.dbo.t_inpatient_invoice_info tiii
        left join bmlinppro.dbo.t_inpatient_patient_fee_serial_account tipfa
        on tiii.settleId = tipfa.settlementId
        left join bmlpimpro.dbo.t_code_item_category tcic
        on tipfa.itemType=tcic.itemType
        where tiii.settleDate > @startTime and tiii.settleDate < @endTime
and tipfa.status in (0,1,2)
        and tcic.typeName is not null
        group by tcic.typeName
        ) a
        group by (row-1)/3

        UNION ALL
        -- 总量
        select null id,'合计' 收费项目1,
        Convert(decimal(18,2), Round( sum(tipfa.fee), 2 ) ) 项目金额1,null id2,null 收费项目2,null 项目金额2,null id3,null 收费项目3,null 项目金额3
        from bmlinppro.dbo.t_inpatient_invoice_info tiii
        left join bmlinppro.dbo.t_inpatient_patient_fee_serial_account tipfa
        on tiii.settleId = tipfa.settlementId
        left join bmlpimpro.dbo.t_code_item_category tcic
        on tipfa.itemType=tcic.itemType
        where tiii.settleDate > @startTime and tiii.settleDate < @endTime
and tipfa.status in (0,1,2)
        and tcic.typeName is not null

        end
go

