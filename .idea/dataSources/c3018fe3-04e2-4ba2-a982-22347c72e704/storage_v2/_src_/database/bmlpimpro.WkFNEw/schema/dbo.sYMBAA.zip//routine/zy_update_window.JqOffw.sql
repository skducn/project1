CREATE PROCEDURE [dbo].[zy_update_window]
AS
BEGIN
 UPDATE t_code_outpatient_dispensing_window SET onWorkTime = getDate(),alreadyIssuedRecipe=0
END
go

exec sp_addextendedproperty 'MS_Description', '重置窗口时间', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_update_window'
go

