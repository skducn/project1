CREATE PROCEDURE [dbo].[zy_purchase_plan_market]
AS
SELECT tdd.id AS drugId,
        tdd.drugCode AS drugCode,
        tdd.inputCode AS inputCode,
        tdd.drugName AS drugName,
				tdd.spec AS drugSpec,
        tdd.origin AS drugOrigin,
        tdd.packNumber AS packNumber,
        tdd.largePackNumber AS largePackNumber,
        tdd.basicDose AS basicDose,
        tdd.doseUnit AS doseUnit,
        tdd.basicPackUnit AS basicPackUnit,
        tdd.packUnit AS packUnit,
        tdd.largePackUnit AS largePackUnit,
        tddi.price AS price,
        tddi.wholesale AS wholesale,
a.floorPrice AS floorPrice,
b.price AS recentPrice,
a.floorDiscount AS floorDiscount,
tdsi.name AS supplyName,
tdsi.supplyid AS supplyid,
tdsi.deliveryCycle AS deliveryCycle
        FROM t_drug_dictionary AS tdd
        INNER JOIN t_dsh_drug_info AS tddi ON tdd.id=tddi.drugId
INNER JOIN 
(SELECT t.drugId AS drugId,d.relativeDeptId AS supplyId,MIN(t.cost) AS floorPrice,MIN(t.discount) AS floorDiscount FROM t_dsh_outin_batch AS t 
INNER JOIN t_dsh_outin_info AS d ON t.outinId=d.id
WHERE d.receiptType >=0 AND d.receiptType<=10
GROUP BY d.relativeDeptId,t.drugId) AS a ON tdd.id=a.drugId
INNER JOIN t_drug_supply_info AS tdsi ON a.supplyId=tdsi.id
INNER JOIN (
SELECT aa.drugId,aa.relativeDeptId AS supplyId,MIN(d.cost) AS price FROM (SELECT c.drugId,a.relativeDeptId,MAX(a.operateTime) AS operateTime FROM t_dsh_outin_info AS a
INNER JOIN t_dsh_outin_detail AS c
ON a.id=c.outinId
WHERE a.receiptType >=0 AND a.receiptType<=10 GROUP BY c.drugId,relativeDeptId) AS aa 
INNER JOIN t_dsh_outin_info AS c
ON aa.operateTime=c.operateTime
INNER JOIN t_dsh_outin_batch AS d
ON c.id=d.outinId GROUP BY aa.drugId,aa.relativeDeptId
) b ON b.drugId=a.drugId AND a.supplyId=b.supplyId
WHERE tdd.status=1
ORDER BY drugCode ASC
go

exec sp_addextendedproperty 'MS_Description', '药品采购计划查询商情', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_purchase_plan_market'
go

