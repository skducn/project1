create proc mz_ys_report 
@startDate varchar(50),@endDate varchar(50)
as 
begin
DECLARE item_cursor cursor 
FOR   
    select itemType,typeName 
		from t_code_item_category
for read only;

set @startDate += ' 00:00:00'
set @endDate += ' 23:59:59'

DECLARE @sql_str NVARCHAR(MAX);
set @sql_str = 'select a.*,b.fee as 挂号费1 ,a.total as 合计 from ( select  d.docId,d.docName ';

open item_cursor;
DECLARE @itemType nvarchar(32);
DECLARE @itemName nvarchar(32);
fetch next from item_cursor into @itemType,@itemName;
while (@@FETCH_STATUS=0)
begin 
	set @sql_str += ',sum(case when b.itemType = ';
	set  @sql_str += '''' +	@itemType + '''' ;
	set  @sql_str += 	' then b.amount else 0 end  ) as ';
	set  @sql_str += @itemName;
	fetch next from item_cursor into @itemType,@itemName;
	print @itemName;
end
close item_cursor;
deallocate item_cursor;


set  @sql_str += ' ,sum(b.amount) as total from (select * from t_outpatient_cashier_invoice where payDate BETWEEN '
set  @sql_str += '''' + @startDate +'''' 
set  @sql_str += ' and '
set  @sql_str += '''' + @endDate +''''
set  @sql_str += ' and invoiceStatus = 2) a '
set  @sql_str += ' join t_outpatient_cashier_detail b on a.invoiceId = b.invoiceId '
set  @sql_str += ' join t_outpatient_cashier_recipe c on b.invoiceId = c.invoiceId and b.recipeId = c.recipeId '
set  @sql_str += ' join t_code_doctor_information d on c.docUserId = d.docId group by  d.docId,d.docName '

set  @sql_str += ') a full join ('
set  @sql_str += ' select b.docId,b.docName,sum(a.totalFee) as fee from '

set  @sql_str +='(select * from t_outpatient_registration_invoice where payDate BETWEEN '
set  @sql_str += '''' + @startDate +'''' 
set  @sql_str += ' and '
set  @sql_str += '''' + @endDate +''''
set  @sql_str += ' and invoiceStatus = 2) a '
set  @sql_str += '  join t_code_doctor_information b on a.userId = b.docId  group by b.docId,b.docName ) b'
 
set  @sql_str += ' on a.docId = b.docId '





print @sql_str
exec(@sql_str)
end
go

