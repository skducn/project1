CREATE PROCEDURE [dbo].[doctor_advice_additionalItem](
@keyWord VARCHAR(50)
)
AS

DECLARE @sql nvarchar(MAX)
SET @sql ='SELECT id ,
itemType ,
itemCode ,
itemName ,
spec ,
unit ,
price ,
refundFlag
FROM t_code_fee_item WHERE (itemType = 08 OR itemType = 10 or itemType = 17 or itemType = 18) AND status = '+char(39)+'1'+char(39)
IF @keyWord IS NOT NULL
SET @sql = @sql+ 'AND (itemCode LIKE '+ CHAR(39)+CHAR(37)+@keyWord+CHAR(37)+CHAR(39)+'OR itemName LIKE '+CHAR(39)+CHAR(37)+@keyWord+CHAR(37)+CHAR(39)+')'
EXEC (@sql)
go

