CREATE PROCEDURE [dbo].[yibao_detailUpload_cashier]
@today char(8)
AS
BEGIN
	BEGIN
		IF(@today IS NULL)
			SELECT @today = CONVERT(nchar(8),DATEADD(day,-1,getdate()),112)
	END
--开启事务
	BEGIN TRY 
	BEGIN TRANSACTION
--1.先删除数据
	DELETE FROM t_medicare_cashier WHERE LEFT(dealConfirmTime, 8) = @today
--2.联表抽取数据
	INSERT INTO t_medicare_cashier
	SELECT t_medicare_outpatient_register_cashier.centerStreamNo,
	t_medicare_outpatient_register_cashier.cardNo AS insuranceCardNo,
	t_code_department_information.insuranceCode AS deptCode,
	t_code_department_information.insuranceName AS deptName,
	t_outpatient_cashier_recipe.docUserCode AS docCode,
	t_code_doctor_information.docName AS docName,
	t_outpatient_cashier_recipe.recipeId AS recipeId,
	t_medicare_medical_detail.itemType AS itemType,
	t_medicare_medical_detail.itemCode AS detailItemCode,
	t_medicare_medical_detail.itemName AS detailItemName,
	t_medicare_medical_detail.itemUnit AS detailItemUnit,
	t_medicare_medical_detail.itemPrice AS detailItemPrice,
	t_medicare_medical_detail.itemNumber AS detailItemNumber,
	t_medicare_medical_detail.itemMoney AS detailItemAmount,
	t_medicare_medical_detail.dealTotalFee AS detailItemTotalAmount,
	t_medicare_medical_detail.medicalInvoiceTotalFee AS detailItemMedicalTotalAmount,
	t_medicare_medical_detail.refundFlag,
	t_medicare_medical_detail.transmitDate+'/'+REPLACE(t_medicare_medical_detail.transmitTime, ':', '')+'/' AS returnTime,
	t_medicare_outpatient_register_cashier.medicareWay,
	t_medicare_medical_detail.settleCategory AS settleTypeFlag,
	t_medicare_medical_detail.cashierStatus AS feeAndRefundFlag,
	t_outpatient_cashier_detail.visitId AS visitId,
	t_medicare_medical_detail.detailItemId,
	t_medicare_medical_detail.drugCommonName,
	t_medicare_medical_detail.registrationNo,
	t_medicare_medical_detail.detailItemSpec
	FROM t_medicare_outpatient_register_cashier
	INNER JOIN t_outpatient_cashier_invoice
	ON t_medicare_outpatient_register_cashier.invoiceNo = t_outpatient_cashier_invoice.invoiceNo
	INNER JOIN t_outpatient_cashier_recipe 
	ON t_outpatient_cashier_recipe.invoiceId = t_outpatient_cashier_invoice.invoiceId
	INNER JOIN t_outpatient_cashier_detail
	ON t_outpatient_cashier_detail.recipeId = t_outpatient_cashier_recipe.recipeId
	INNER JOIN t_outpatient_registration_info
	ON t_outpatient_cashier_detail.visitId = t_outpatient_registration_info.visitId
	INNER JOIN t_code_outpatient_information
	ON t_code_outpatient_information.outPCode = t_outpatient_registration_info.outPNo
	INNER JOIN t_code_department_information
	ON t_code_department_information.deptCode = t_code_outpatient_information.deptCode
	INNER JOIN t_code_doctor_information
	ON t_outpatient_cashier_recipe.docUserCode = t_code_doctor_information.docCode
	INNER JOIN t_medicare_medical_detail
	ON t_medicare_outpatient_register_cashier.invoiceNo = t_medicare_medical_detail.invoiceNo	
	WHERE t_medicare_outpatient_register_cashier.transmitDate = @today
	AND t_medicare_outpatient_register_cashier.invoiceType = 0
	AND t_medicare_outpatient_register_cashier.settleType = 1
	AND t_medicare_outpatient_register_cashier.centerStreamNo IS NOT NULL
--提交事务
COMMIT TRANSACTION
END TRY
--有异常被捕获
BEGIN CATCH
	IF @@TRANCOUNT > 0
		ROLLBACK TRANSACTION
END CATCH
END
go

exec sp_addextendedproperty 'MS_Description', '医保明细上传-抽取收费数据', 'SCHEMA', 'dbo', 'PROCEDURE',
     'yibao_detailUpload_cashier'
go

