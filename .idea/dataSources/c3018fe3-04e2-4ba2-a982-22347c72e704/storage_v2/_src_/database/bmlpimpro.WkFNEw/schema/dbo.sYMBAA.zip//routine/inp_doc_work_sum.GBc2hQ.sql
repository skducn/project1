CREATE PROCEDURE [dbo].[inp_doc_work_sum]
@condition nvarchar(50)
        as
        begin
        DECLARE
@startTime VARCHAR(20),
@endTime VARCHAR(20)
        IF (@condition IS NOT NULL AND @condition != '')

        BEGIN
        SET @startTime = SUBSTRING(@condition,0,20)
        SET @endTime = SUBSTRING(@condition,21,20)
        END

        -- 住院医师工作量统计
        select tcdi.docCode 医师编号,tcdi.docName 医师姓名,t.西药费,t.化验费,t.中成药费,t.检查费,t.中草药费,t.治疗费,t.护理费,t.手术费,t.床位费,t.诊察费,t.材料费,(t.合计-t.tempFee)其他费,t.合计
        from (
        select tipfa.docId,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 03 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 西药费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 05 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 化验费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 06 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 中成药费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 07 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 检查费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 09 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 中草药费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 10 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 治疗费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 13 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 护理费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 17 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 手术费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 18 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 床位费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 19 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 诊察费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 99 or tipfa.itemType = 08 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 材料费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType in( 03,05,06,07,09,10,13,17,18,19,99,08) THEN tipfa.fee ELSE 0 END ), 2 ) ) AS tempFee,
        Convert(decimal(18,2), Round( sum( tipfa.fee ), 2 ) ) as 合计
        from bmlinppro.dbo.t_inpatient_patient_fee_serial_account tipfa
        where tipfa.feeTime > @startTime and tipfa.feeTime < @endTime
and tipfa.status in (0,1,2)
        group by tipfa.docId
        )t
        left join bmlpimpro.dbo.t_code_doctor_information tcdi
        on t.docId=tcdi.docId
        where tcdi.docCode is not null

        UNION ALL
        -- 总量
        SELECT
        NULL 医师编号,
        '合计' 医师名称,
        sum( 西药费 ) 西药费,
        sum( 化验费 ) 化验费,
        sum( 中成药费 ) 中成药费,
        sum( 检查费 ) 检查费,
        sum( 中草药费 ) 中草药费,
        sum( 治疗费 ) 治疗费,
        sum( 护理费 ) 护理费,
        sum( 手术费 ) 手术费,
        sum( 床位费 ) 床位费,
        sum( 诊察费 ) 诊察费,
        sum( 材料费 ) 材料费,
        sum( 合计 - tempFee ) 其他费,
        sum( 合计 ) 合计
        FROM
        (
        SELECT
        tipfa.docId,
        1 temp,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 03 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 西药费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 05 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 化验费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 06 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 中成药费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 07 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 检查费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 09 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 中草药费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 10 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 治疗费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 13 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 护理费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 17 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 手术费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 18 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 床位费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 19 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 诊察费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType = 99 or tipfa.itemType = 08 THEN tipfa.fee ELSE 0 END ), 2 ) ) AS 材料费,
        Convert(decimal(18,2), Round( sum( CASE WHEN tipfa.itemType in( 03,05,06,07,09,10,13,17,18,19,99,08) THEN tipfa.fee ELSE 0 END ), 2 ) ) AS tempFee,
        Convert(decimal(18,2), Round( sum( tipfa.fee ), 2 ) ) as 合计
        FROM
        bmlinppro.dbo.t_inpatient_patient_fee_serial_account tipfa
        WHERE
        tipfa.feeTime > @startTime
				AND tipfa.feeTime < @endTime
and tipfa.status in (0,1,2)
        GROUP BY
        tipfa.docId
        ) t1
        GROUP BY
        t1.temp

        end
go

