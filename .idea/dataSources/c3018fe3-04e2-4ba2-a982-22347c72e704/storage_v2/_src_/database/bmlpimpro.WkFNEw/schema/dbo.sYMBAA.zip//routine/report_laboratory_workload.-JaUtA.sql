CREATE PROCEDURE [dbo].[report_laboratory_workload]
  @yearDate NVARCHAR(100) = '2020-01-01 00:00:00,2020-12-31 23:59:59',
  @labDept AS INT = 1
AS
BEGIN
	DECLARE @startDate VARCHAR (100),@endDate VARCHAR(100),@patientType INT
  SET @startDate = SUBSTRING(@yearDate,0,20)
	SET @endDate = SUBSTRING(@yearDate,21,20)
	SET @patientType = CASE @labDept WHEN 2 THEN 3 WHEN 3 THEN 2 ELSE @labDept END
	CREATE TABLE #month_title 
	-- 月份临时表及表头
	( 
			title NVARCHAR(50),
			sort int
	)INSERT INTO #month_title VALUES 
	('一月份',1),('二月份',2),('三月份',3),
	('四月份',4),('五月份',5),('六月份',6),
	('七月份',7),('八月份',8),('九月份',9),
	('十月份',10),('十一月份',11),('十二月份', 12),
	('全年合计',13)
	SELECT 
	#month_title.title AS '项目', 
	CASE WHEN ( 
	 dataSet.biochemistry IS NULL 
	 OR dataSet.biochemistry = '' 
	) THEN 0 ELSE dataSet.biochemistry END AS '生化', 
	CASE WHEN ( 
	 dataSet.bloodRoutine IS NULL 
	 OR dataSet.bloodRoutine = '' 
	) THEN 0 ELSE dataSet.bloodRoutine END AS '血常规', 
	CASE WHEN ( 
	 dataSet.urineRoutine IS NULL 
	 OR dataSet.urineRoutine = '' 
	) THEN 0 ELSE dataSet.urineRoutine END AS '尿常规', 
	CASE WHEN ( 
	 dataSet.manureRoutine IS NULL 
	 OR dataSet.manureRoutine = '' 
	) THEN 0 ELSE dataSet.manureRoutine END AS '粪常规', 
	CASE WHEN ( 
	 dataSet.fourItemsOfCoagulation IS NULL 
	 OR dataSet.fourItemsOfCoagulation = '' 
	) THEN 0 ELSE dataSet.fourItemsOfCoagulation END AS '凝血四项', 
	CASE WHEN ( 
	 dataSet.lipidsFull IS NULL 
	 OR dataSet.lipidsFull = '' 
	) THEN 0 ELSE dataSet.lipidsFull END AS '血脂全套', 
	CASE WHEN ( 
	 dataSet.liverFunctionFull IS NULL 
	 OR dataSet.liverFunctionFull = '' 
	) THEN 0 ELSE dataSet.liverFunctionFull END AS '肝功能全套',
	CASE WHEN ( 
	 dataSet.renalFunctionFull IS NULL 
	 OR dataSet.renalFunctionFull = '' 
	) THEN 0 ELSE dataSet.renalFunctionFull END AS '肾功能全套', 
	CASE WHEN ( 
	 dataSet.electrolyteFull IS NULL 
	 OR dataSet.electrolyteFull = '' 
	) THEN 0 ELSE dataSet.electrolyteFull END AS '电解质全套',
	CASE WHEN ( 
	 dataSet.hepBTwoOfHalf IS NULL 
	 OR dataSet.hepBTwoOfHalf = '' 
	) THEN 0 ELSE dataSet.hepBTwoOfHalf END AS '乙肝两对半',
	CASE WHEN ( 
	 dataSet.tumorLandmark IS NULL 
	 OR dataSet.tumorLandmark = '' 
	) THEN 0 ELSE dataSet.tumorLandmark END AS '肿瘤标志物'
	FROM 
	#month_title 
	LEFT JOIN 
	( 
	 SELECT 
	 CASE 
		WHEN Grouping(l_month)=1 THEN '全年合计'
	 ELSE 
		(CASE l_month WHEN '1' THEN '一月份' 
		WHEN '2' THEN '二月份' 
		WHEN '3' THEN '三月份' 
		WHEN '4' THEN '四月份' 
		WHEN '5' THEN '五月份' 
		WHEN '6' THEN '六月份' 
		WHEN '7' THEN '七月份' 
		WHEN '8' THEN '八月份' 
		WHEN '9' THEN '九月份' 
		WHEN '10' THEN '十月份' 
		WHEN '11' THEN '十一月份' 
		WHEN '12' THEN '十二月份' 
		ELSE l_month END) 
	 END 
	 AS title, 
	 SUM(biochemistry) AS biochemistry,
	 SUM (bloodRoutine) AS bloodRoutine,
	 SUM (urineRoutine) AS urineRoutine,
	 SUM (manureRoutine) AS manureRoutine,
	 SUM (fourItemsOfCoagulation) AS fourItemsOfCoagulation,
	 SUM (lipidsFull) AS lipidsFull,
	 SUM (liverFunctionFull) AS liverFunctionFull,
	 SUM (renalFunctionFull) AS renalFunctionFull,
	 SUM (electrolyteFull) AS electrolyteFull,
	 SUM (hepBTwoOfHalf) AS hepBTwoOfHalf,
	 SUM (tumorLandmark) AS tumorLandmark
	 FROM 
	 ( 
		SELECT 
	--  生化（大生化23项）
	--	血清总蛋白测定(干化学法、免疫散射比浊法),血清白蛋白测定(干化学法、免疫散射比浊法),葡萄糖测定(干化学法全自动生化仪)
	--	血清总胆固醇测定(干化学法),血清甘油三酯测定(干化学法),血清高密度脂蛋白胆固醇测定(干化学法)
	--	血清低密度脂蛋白胆固醇测定(干化学法),血清总胆红素测定(干化学法),血清直接胆红素测定(干化学法)
	--	血清丙氨酸氨基转移酶测定(干化学法),血清天门冬氨酸氨基转移酶测定(干化学法),血清γ-谷氨酰基转移酶测定(干化学法)
	--	血清碱性磷酸酶测定(干化学法),乳酸脱氢酶测定(干化学法),血清肌酸激酶测定(化学发光法),钾测定(干化学法)
	--	钠测定(干化学法),氯测定(干化学法),钙测定(干化学法),尿素测定(干化学法),肌酐测定(干化学法)
	--	血清尿酸测定（干化学法）,血清α羟基丁酸脱氢酶测定
	 SUM (
		CASE
		WHEN itemCode = 'S250301001b0010' 
			OR itemCode = 'S250301002c0010'
			OR itemCode = 'S250302001c0010'
			OR itemCode = 'S250303001b0010'
			OR itemCode = 'S250303002b0010'
			OR itemCode = 'S250303004a0010'
			OR itemCode = 'S250303005a0010'
			OR itemCode = 'S250305001b0010'
			OR itemCode = 'S250305002b0010'
			OR itemCode = 'S250305007b0010'
			OR itemCode = 'S250305008b0010'
			OR itemCode = 'S250305009b0010'
			OR itemCode = 'S250305011b0010'
			OR itemCode = 'S250306005b0010'
			OR itemCode = 'S250306001b0010'
			OR itemCode = 'S250304001c0010'
			OR itemCode = 'S250304002c0010'
			OR itemCode = 'S250304003c0010'
			OR itemCode = 'S250304004c0010'
			OR itemCode = 'S250307001b0010'
			OR itemCode = 'S250307002c0010'
			OR itemCode = 'S250307005b0010'
			OR itemCode = 'S25030600700010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS biochemistry,
	--  血常规（1项）
	--	血细胞分析(三分类)
	 SUM (
		CASE
		WHEN itemCode = 'S250101015b0010' THEN
		 1
		ELSE
		 0
		END
	 ) AS bloodRoutine,
	-- 尿常规（1项）
	--	尿液分析(尿9联及以上)
	 SUM (
		CASE
		WHEN itemCode = 'S250102035b0010' THEN
		 1
		ELSE
		 0
		END
	 ) AS urineRoutine,
	--  粪常规（2项）
	--	粪便常规（仪器法）,隐血试验(免疫学方法)
	 SUM (
		CASE
		WHEN itemCode = 'S250103001b0010'
			OR itemCode = 'S250103002b0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS manureRoutine,
	--  凝血四项（4项）
	--	血浆纤维蛋白原测定(仪器法),血浆凝血酶原时间测定(PT)(仪器法),活化部分凝血活酶时间测定(APTT),凝血酶时间测定(TT)(仪器法)
	 SUM (
		CASE
		WHEN itemCode = 'S250203030b0010'
			OR itemCode = 'S250203020b0010'
			OR itemCode = 'S250203025b0010'
			OR itemCode = 'S250203035b0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS fourItemsOfCoagulation,
	--  血脂全套（4项）
	--	血清总胆固醇测定(干化学法),血清甘油三酯测定(干化学法),血清高密度脂蛋白胆固醇测定(干化学法),血清低密度脂蛋白胆固醇测定(干化学法)
		SUM (
		CASE
		WHEN itemCode = 'S250303001b0010'
			OR itemCode = 'S250303002b0010'
			OR itemCode = 'S250303004a0010'
			OR itemCode = 'S250303005a0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS lipidsFull,
	--  肝功能全套（7项）
	--	血清总胆红素测定(干化学法),血清直接胆红素测定(干化学法),血清丙氨酸氨基转移酶测定(干化学法),血清天门冬氨酸氨基转移酶测定(干化学法),血清γ-谷氨酰基转移酶测定(干化学法),血清碱性磷酸酶测定(干化学法),乳酸脱氢酶测定(干化学法)
	 SUM (
		CASE
		WHEN itemCode = 'S250305001b0010'
			OR itemCode = 'S250305002b0010'
			OR itemCode = 'S250305007b0010'
			OR itemCode = 'S250305008b0010'
			OR itemCode = 'S250305009b0010'
			OR itemCode = 'S250305011b0010'
			OR itemCode = 'S250306005b0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS liverFunctionFull,
	--  肾功能全套（4项）
	--	尿素测定(干化学法),肌酐测定(干化学法),血清尿酸测定（干化学法）,血清肌酸激酶测定(干化学法)
	 SUM (
		CASE
		WHEN itemCode = 'S250307001b0010'
			OR itemCode = 'S250307002c0010'
			OR itemCode = 'S250307005b0010'
			OR itemCode = 'S250306001c0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS renalFunctionFull,
	--  电解质全套（4项）
	--	钾测定(干化学法),钠测定(干化学法),氯测定(干化学法),钙测定(干化学法)
	 SUM (
		CASE
		WHEN itemCode = 'S250304001c0010'
			OR itemCode = 'S250304002c0010'
			OR itemCode = 'S250304003c0010'
			OR itemCode = 'S250304004c0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS electrolyteFull,
	--  乙肝两对半（5项）
	--	乙型肝炎表面抗原测定(HBsAg),乙型肝炎表面抗体测定(Anti-HBs),乙型肝炎e抗原测定(HBeAg),乙型肝炎e抗体测定(Anti-HBe),乙型肝炎核心IgM抗体测定(Anti-HBcIgM)
	 SUM (
		CASE
		WHEN itemCode = 'S250403004b0010'
			OR itemCode = 'S250403005b0010'
			OR itemCode = 'S250403006b0010'
			OR itemCode = 'S250403007b0010'
			OR itemCode = 'S250403010b0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS hepBTwoOfHalf,
	--  肿瘤标志物（2项）
	--	'癌胚抗原测定(CEA)','甲胎蛋白测定(AFP)'
	 SUM (
		CASE
		WHEN itemCode = 'S250404001b0010'
			OR itemCode = 'S250404002b0010'
		THEN
		 1
		ELSE
		 0
		END
	 ) AS tumorLandmark,
		CONVERT(VARCHAR, Month(confirmDate)) AS l_month
		FROM (
		SELECT
		t_application_lis_application.confirmDate AS confirmDate,
		t_application_lis_application.patientType AS patientType,
		t_application_lis_application_detail.itemCode AS itemCode,
		t_application_lis_application_detail.itemName AS itemName
		FROM t_application_lis_application
		LEFT JOIN t_application_lis_application_detail
		ON 
		t_application_lis_application.applicationId=t_application_lis_application_detail.applicationId
	 ) tabAll
		WHERE patientType <> @patientType AND confirmDate BETWEEN @startDate AND @endDate 
		GROUP BY Year(confirmDate), Month(confirmDate) 
	 ) tab 
	 GROUP BY l_month WITH rollup 
	) dataSet ON dataSet.title = #month_title.title
	ORDER BY #month_title.sort
END;
go

