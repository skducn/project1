CREATE PROCEDURE [dbo].[zy_purchase_plan_stock]
AS
SELECT tdd.id AS drugId,
        tdd.drugCode AS drugCode,
        tdd.inputCode AS inputCode,
        tdd.drugName AS drugName,
				tdd.spec AS drugSpec,
				tdd.singleMaxNumber AS singleMaxNumber,
        tdd.singleMaxDose AS singleMaxDose,
        tdd.origin AS drugOrigin,
        tdd.packNumber AS packNumber,
        tdd.largePackNumber AS largePackNumber,
        tdd.basicDose AS basicDose,
        tdd.doseUnit AS doseUnit,
        tdd.basicPackUnit AS basicPackUnit,
        tdd.packUnit AS packUnit,
        tdd.largePackUnit AS largePackUnit,
        tddi.currentRealIn AS inNumber,
        tddi.currentRealOut AS outNumber,
				b.pharmacyInventory AS pharmacyInventory,
        tddi.number-tddi.predictNumber AS number,
				(b.pharmacyInventory+tddi.number) AS totalInventory,
        tdd.minInventory AS alertLower,
        tdd.price AS price,
        tdd.wholesale AS wholesale
        from t_drug_dictionary AS tdd 
        INNER JOIN t_dsh_drug_info AS tddi ON tdd.id=tddi.drugId
 left JOIN
(SELECT drugId,SUM(number) AS pharmacyInventory FROM t_ph_outpatient_drug_info GROUP BY drugId) b
ON tdd.id=b.drugId
WHERE tdd.status=1
go

exec sp_addextendedproperty 'MS_Description', '药品采购计划查询库存', 'SCHEMA', 'dbo', 'PROCEDURE', 'zy_purchase_plan_stock'
go

