CREATE PROCEDURE [dbo].[registration_number] 
		@regDate VARCHAR ( 20 ),
		@regCode VARCHAR ( 10 ),
		@id INT OUTPUT,
		@regNo INT OUTPUT
		AS 
		begin transaction tran_register
		DECLARE
		@number INT 
		SET @number = ( SELECT MAX ( t.regNo ) FROM t_outpatient_registration_number t WHERE t.regDate = @regDate AND t.regCode = @regCode ) 
		IF(@number is NULL)
		BEGIN
		SET @number = 1
		END
		else
		BEGIN
		SET @number = @number + 1
		END
		SET @regNo = @number
		PRINT @number
		INSERT INTO t_outpatient_registration_number(regNo,regCode,regDate) VALUES(@number,@regCode,@regDate)
		PRINT @regNo
		DECLARE
		@idSign INT 
	SET @idSign = ( SELECT t.id FROM t_outpatient_registration_number t WHERE t.regDate = @regDate AND t.regCode = @regCode AND t.regNo = @regNo ) 
	SET @id = @idSign
		IF @@ERROR != 0
   rollback transaction tran_register
   else
commit transaction tran_register
go

