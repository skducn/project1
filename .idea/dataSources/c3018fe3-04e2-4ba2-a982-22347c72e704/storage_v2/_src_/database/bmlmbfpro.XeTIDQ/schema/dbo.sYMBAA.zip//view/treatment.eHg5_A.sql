CREATE VIEW [dbo].[treatment] AS select a.medicareCode,
		b.orgNo,
	 priceCode,
        paymentMethod,
        projectName,
				name,
        projectConnotation,
        exclusions,
        a.unit,
				b.unit unithistroy,
        chargingStandard,
				price,
        comment,
        limitedContent,
        a.expenseCategory,
				b.expenseCategory as expenseCategoryhistroy,

	
				
				b.refundflag,
				b.isMedicarePayment,
				b.isDisabled
	 from (	
SELECT
       
        medicareCode,
       
        priceCode,
        paymentMethod,
        projectName,
        projectConnotation,
        exclusions,
        unit,
        chargingStandard,
        comment,
        limitedContent,
        expenseCategory
        FROM
        (
        SELECT
        *,
        ROW_NUMBER ( ) OVER ( PARTITION BY medicareCode ORDER BY modifyTime DESC, addTime DESC ) AS rownum
        FROM
        t_mbf_treatment_stack
        WHERE
        GETDATE( ) >= CAST ( effectiveDate AS datetime )
        AND GETDATE( ) <= CAST ( expirationDate + ' 23:59:59' AS datetime )
				
        ) t
        WHERE
        t.rownum = 1 ) a join 
				
				(select * from (	
SELECT
       
        medicareCode,
				price,
				name,
				unit,
				refundflag,
				isMedicarePayment,
				isDisabled,
				expenseCategory,
				orgNo
        FROM
        (
        SELECT
        *,
        ROW_NUMBER ( ) OVER ( PARTITION BY medicareCode,orgNo ORDER BY id DESC ) AS rownum
        FROM
        t_mbf_fee_history
        WHERE
        GETDATE( ) >= CAST ( effectiveDate AS datetime )
        AND GETDATE( ) <= CAST ( expirationDate + ' 23:59:59' AS datetime )
				
        ) t
        WHERE
        t.rownum = 1 )b )b on a.medicareCode=b.medicareCode
				join (select b.medicareCode from  [bmlpimpro].[dbo].[t_code_fee_item] a 
		left join [bmlmbfpro].[dbo].[t_mbf_fee_history]  b on  a.insuranceCode=b.medicareCode group by b.medicareCode) c
		on b.medicareCode=c.medicareCode
go

