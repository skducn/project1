CREATE VIEW [dbo].[v_pacs_apply_info] AS SELECT
	examination_num,
	c.pacs_org_code AS org_code,
	org_name,
	register_date AS examine_date,
	a.name AS person_name,
	id_card AS idcard_no,
	CASE sex_name WHEN '男性' THEN '男'
	WHEN '女性' THEN '女'
	ELSE sex_name END AS sex_name,
	age,
	'岁' AS age_unit,
	item_code,
	item_name,
	lb_classifier,
	phone,
	ISNULL( present_province_name, '' ) + ISNULL( present_city_name, '' ) + ISNULL( present_town_name, '' ) + ISNULL( present_village_name, '' ) + ISNULL( present_address, '' ) AS permanent_address 
FROM
	t_snr_patient_info a
	INNER JOIN (
SELECT
	org_code,
	pacs_org_code,
	ecg_item_code AS item_code,
	ecg_item_name AS item_name,
	'ECG' AS lb_classifier 
FROM
	t_snr_technology_config UNION
SELECT
	org_code,
	pacs_org_code,
	ultrasound_item_code AS item_code,
	ultrasound_item_name AS item_code,
	'US' AS lb_classifier 
FROM
	t_snr_technology_config 
	) c ON a.org_code = c.org_code 
WHERE 
	a.valid_status = 1
go

