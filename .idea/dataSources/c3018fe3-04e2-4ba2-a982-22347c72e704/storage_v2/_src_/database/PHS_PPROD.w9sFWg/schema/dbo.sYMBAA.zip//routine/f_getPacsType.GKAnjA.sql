CREATE FUNCTION [dbo].[f_getPacsType]
( @item_code AS varchar(30),
  @org_code AS varchar(30)
)
RETURNS varchar(20)
AS
BEGIN
DECLARE @ecgCount int = 0, @bCount int = 0, @type varchar(20)
	SET @ecgCount = (SELECT COUNT(1) FROM t_snr_technology_config 
	WHERE pacs_org_code = @org_code AND ecg_item_code = @item_code)
	SET @bCount = (SELECT COUNT(1) FROM t_snr_technology_config 
	WHERE pacs_org_code = @org_code AND ultrasound_item_code = @item_code)
	
	-- 心电图
	IF (@ecgCount > 0) BEGIN
	SET @type = 'ECG'
END
	-- B超
ELSE IF (@bCount > 0)BEGIN
	SET @type = 'US'
END 
ELSE BEGIN
	SET @type = ''
END

	RETURN @type
END
go

