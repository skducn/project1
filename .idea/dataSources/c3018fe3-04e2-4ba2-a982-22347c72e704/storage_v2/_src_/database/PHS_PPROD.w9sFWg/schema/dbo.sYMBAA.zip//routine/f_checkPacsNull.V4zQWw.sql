
CREATE FUNCTION [dbo].[f_checkPacsNull] (
@type AS VARCHAR (20),
@examination_num AS VARCHAR (20),
@org_code AS VARCHAR (30),
@item_code AS VARCHAR (30),
@ultrasound_model AS VARCHAR (200),
@ultrasound_num AS VARCHAR (100),
@ultrasound_part AS nvarchar (200),
@ultrasound_detail AS nvarchar (4000),
@ultrasound_impression AS nvarchar (4000),
@ecg_examine_result AS nvarchar (4000),
@ecg_examine_desc AS nvarchar (4000),
@pics_url AS VARCHAR (MAX),
@report_pdf AS VARCHAR (500),
@examine_doc_id AS VARCHAR (30),
@examine_doc_name AS VARCHAR (30),
@verify_doc_id AS VARCHAR (30),
@verify_doc_name AS VARCHAR (30),
@examine_date AS date,
@positive_sign AS VARCHAR (2) 
) RETURNS SMALLINT AS BEGIN-- return 1-无空字段 0-有空字段
IF
	@examination_num IS NOT NULL 
	AND @examination_num != '' 
	AND @org_code IS NOT NULL 
	AND @org_code != '' 
	AND @item_code IS NOT NULL 
	AND @item_code != '' 
	--AND @pics_url IS NOT NULL 
	--AND @pics_url != '' 
	AND @report_pdf IS NOT NULL 
	AND @report_pdf != '' 
	--AND @examine_doc_id IS NOT NULL 
	--AND @examine_doc_id != '' 
	--AND @examine_doc_name IS NOT NULL 
	--AND @examine_doc_name != '' 
	--AND @verify_doc_id IS NOT NULL 
	--AND @verify_doc_id != '' 
	--AND @verify_doc_name IS NOT NULL 
	--AND @verify_doc_name != '' 
	AND @examine_date IS NOT NULL 
	--AND @positive_sign IS NOT NULL 
	--AND @positive_sign != '' 
	AND (@positive_sign IS NULL OR @positive_sign = '' OR @positive_sign = '1' OR @positive_sign = '2') BEGIN
IF
	@type = 'ECG' BEGIN
IF
	@ecg_examine_result IS NOT NULL 
	AND @ecg_examine_result != '' BEGIN
	RETURN 1 
END ELSE BEGIN
	RETURN 0 
END 
END ELSE
IF
	@type = 'US' BEGIN
IF
	@ultrasound_model IS NOT NULL 
	AND @ultrasound_model != '' 
	AND @ultrasound_num IS NOT NULL 
	AND @ultrasound_num != '' 
	AND @ultrasound_part IS NOT NULL 
	AND @ultrasound_part != '' 
	AND @ultrasound_detail IS NOT NULL 
	AND @ultrasound_detail != '' 
	AND @ultrasound_impression IS NOT NULL 
	AND @ultrasound_impression != '' BEGIN
	RETURN 1 
END ELSE BEGIN
	RETURN 0 
END 
END ELSE BEGIN
	RETURN 1 
END 
END ELSE BEGIN
	RETURN 0 
	END RETURN 1 
END
go

