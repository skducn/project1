CREATE PROCEDURE [dbo].[f_hp_proc_log]
  @examination_num AS varchar(20),
  @org_code AS varchar(30),
  @item_code AS varchar(30),
  @ultrasound_model AS varchar(200),
  @ultrasound_num AS varchar(100),
  @ultrasound_part AS nvarchar(200),
  @ultrasound_detail AS nvarchar(4000),
  @ultrasound_impression AS nvarchar(4000),
  @ecg_examine_result AS nvarchar(4000),
  @ecg_examine_desc AS nvarchar(4000),
  @pics_url AS varchar(MAX),
  @report_pdf AS varchar(500),
  @examine_doc_id AS varchar(30),
  @examine_doc_name AS varchar(30),
  @verify_doc_id AS varchar(30),
  @verify_doc_name AS varchar(30),
  @examine_date AS date,
	-- (1-阴 2-阳)
  @positive_sign AS varchar(2)
AS
BEGIN 
--检测sql注入
declare @inputcheck Nvarchar(max)=''
set @inputcheck=
   isnull(@examination_num,'')
  +isnull(@org_code,'')
  +isnull(@item_code,'')
  +isnull(@ultrasound_model,'')
  +isnull(@ultrasound_num,'')
  +isnull(@ultrasound_part,'')
  +isnull(@ultrasound_detail,'')
  +isnull(@ultrasound_impression,'')
  +isnull(@ecg_examine_result,'')
  +isnull(@ecg_examine_desc,'')
  +isnull(@pics_url,'')
  +isnull(@report_pdf,'')
  +isnull(@examine_doc_id,'')
  +isnull(@examine_doc_name,'')
  +isnull(@verify_doc_id,'')
  +isnull(@verify_doc_name,'')
  +isnull(@positive_sign,'')
 if @inputcheck like '%select %' 
 or @inputcheck like '%update %'
 or @inputcheck like '%insert %'
 or @inputcheck like '%delete %'
 or @inputcheck like '%truncate %'
 or @inputcheck like '%drop %'
 or @inputcheck like '%union %'
 or @inputcheck like '%exec  %'
 or @inputcheck like '%xp_ %'
        begin
		  raiserror('输入变量值中包含sql注入！',16,1)
		  return
		end

DECLARE @risCount int = 0, @type varchar(20),@checkNull SMALLINT
	SET @risCount = (SELECT COUNT(1) FROM t_snr_examination_ris WHERE examination_num = @examination_num)
	-- 判断pacs类型
	SET @type = (SELECT dbo.f_getPacsType(@item_code,@org_code))
	-- 判断入参是否存在空
	SET @checkNull = (SELECT dbo.f_checkPacsNull(@type,@examination_num,@org_code,@item_code,@ultrasound_model,@ultrasound_num,@ultrasound_part,@ultrasound_detail,@ultrasound_impression,@ecg_examine_result,@ecg_examine_desc,@pics_url,@report_pdf,@examine_doc_id,@examine_doc_name,@verify_doc_id,@verify_doc_name,@examine_date,@positive_sign))
	--存入pacs日志表
	INSERT INTO t_snr_pacs_log (examination_num, pacs_detail) 
	VALUES(@examination_num, 'org_code: ' + ISNULL(@org_code,'null') + ', item_code: ' + ISNULL(@item_code,'null') + ', ultrasound_model: ' + ISNULL(@ultrasound_model,'null') + ', ultrasound_num: ' + ISNULL(@ultrasound_num,'null') + ', ultrasound_part: ' + ISNULL(@ultrasound_part,'null') + ', ultrasound_detail: ' + ISNULL(@ultrasound_detail,'null') + ', ultrasound_impression: ' + ISNULL(@ultrasound_impression,'null') + ', ecg_examine_result: ' + ISNULL(@ecg_examine_result,'null') + ', ecg_examine_desc: ' + ISNULL(@ecg_examine_desc,'null') + ', pics_url: ' + ISNULL(@pics_url,'null') + ', report_pdf: ' + ISNULL(@report_pdf,'null') + ', examine_doc_id: ' + ISNULL(@examine_doc_id,'null') + ', examine_doc_name : ' + ISNULL(@examine_doc_name,'null') + ', verify_doc_id : ' + ISNULL(@verify_doc_id,'null') + ', verify_doc_name: ' + ISNULL(@verify_doc_name,'null') + ', examine_date: ' + ISNULL(convert(varchar(50),@examine_date),'null') + ', positive_sign: ' + ISNULL(@positive_sign,'null'))
	--error 入参存在null或空字符串
	--return 0-错误 1-成功
	IF @checkNull = 0 BEGIN
	RAISERROR('必要参数为空或有误',16,1)
	RETURN 0
END
	--入参正常，执行保存操作
ELSE BEGIN
	-- 映射成我们系统的机构代码
	SET @org_code = (SELECT org_code FROM t_snr_technology_config WHERE pacs_org_code = @org_code)
	--新增
	IF @risCount = 0 BEGIN
	--心电图新增
	IF @type = 'ECG' BEGIN
	INSERT INTO t_snr_examination_ris (org_code, examination_num, ecg_result, ecg_describe, ecg_pic, ecg_pdf, ecg_examine_doc_id, ecg_examine_doc_name, ecg_verify_doc_id, ecg_verify_doc_name, ecg_date, ecg_code, ecg) 
	VALUES(@org_code, @examination_num, @ecg_examine_result, @ecg_examine_desc, @pics_url, @report_pdf, @examine_doc_id, @examine_doc_name, @verify_doc_id, @verify_doc_name, @examine_date, @positive_sign, CASE @positive_sign WHEN '1' THEN '正常' WHEN '2' THEN '异常' ELSE '' END)
END
	--B超新增
ELSE IF @type = 'US' BEGIN
	INSERT INTO t_snr_examination_ris (org_code, examination_num, ultrasound_model, ultrasound_num, ultrasound_part, ultrasound_detail, ultrasound_impression, ultrasound_pic, ultrasound_pdf, ultrasound_examine_doc_id, ultrasound_examine_doc_name, ultrasound_verify_doc_id, ultrasound_verify_doc_name, ultrasound_date, b_ultrasound_code, b_ultrasound_name) 
	VALUES(@org_code, @examination_num, @ultrasound_model, @ultrasound_num, @ultrasound_part, @ultrasound_detail, @ultrasound_impression, @pics_url, @report_pdf, @examine_doc_id, @examine_doc_name, @verify_doc_id, @verify_doc_name, @examine_date, @positive_sign, CASE @positive_sign WHEN '1' THEN '正常' WHEN '2' THEN '异常' ELSE '' END)
END
-- pacs类型未匹配成功
ELSE BEGIN
RAISERROR('pacs类型未匹配成功',16,1)
RETURN 0
END

END
	--修改
ELSE BEGIN
	--心电图修改
IF @type = 'ECG' BEGIN
	UPDATE t_snr_examination_ris SET ecg_result = @ecg_examine_result, ecg_describe = @ecg_examine_desc, ecg_pic = @pics_url, ecg_pdf = @report_pdf, ecg_examine_doc_id = @examine_doc_id, ecg_examine_doc_name = @examine_doc_name, ecg_verify_doc_id = @verify_doc_id, ecg_verify_doc_name = @verify_doc_name, ecg_date = @examine_date, ecg_code = @positive_sign, ecg = CASE @positive_sign WHEN '1' THEN '正常' WHEN '2' THEN '异常' ELSE '' END WHERE examination_num = @examination_num
END
	--B超修改
ELSE IF @type = 'US' BEGIN
	UPDATE t_snr_examination_ris SET ultrasound_model = @ultrasound_model, ultrasound_num = @ultrasound_num, ultrasound_part = @ultrasound_part, ultrasound_detail = @ultrasound_detail, ultrasound_impression = @ultrasound_impression, ultrasound_pic = @pics_url, ultrasound_pdf = @report_pdf, ultrasound_examine_doc_id = @examine_doc_id, ultrasound_examine_doc_name = @examine_doc_name, ultrasound_verify_doc_id = @verify_doc_id, ultrasound_verify_doc_name = @verify_doc_name, ultrasound_date = @examine_date, b_ultrasound_code = @positive_sign, b_ultrasound_name = CASE @positive_sign WHEN '1' THEN '正常' WHEN '2' THEN '异常' ELSE '' END WHERE examination_num = @examination_num
END
-- pacs类型未匹配成功
ELSE BEGIN
RAISERROR('pacs类型未匹配成功',16,1)
RETURN 0
END

END
--SELECT 'SUCCESS' AS result
RETURN 1
END


END
go

