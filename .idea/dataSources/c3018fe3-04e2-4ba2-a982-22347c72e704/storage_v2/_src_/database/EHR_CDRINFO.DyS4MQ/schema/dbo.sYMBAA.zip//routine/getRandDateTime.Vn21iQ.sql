CREATE PROCEDURE [dbo].[getRandDateTime]
@MinDate datetime,
@MaxDate datetime
as
 declare @RandValue int
 declare @ReturnValue int

--把GUID转换成二进制并转换成数字
select @RandValue= ABS(CAST(Cast(NEWID() as binary(8)) as int))

--用随机数对两个日期的差值取余

--用最小日期加上取到的余数，就可以得到指定范围的随机日期
select  CONVERT(Date,@MinDate+@RandValue%CAST((@MaxDate-@MinDate) as int))
go

