CREATE PROCEDURE [dbo].[computeTemporaryInfo]
AS
BEGIN



if exists(select *
          from sysobjects
          where name = 'temp_机构信息表'
            and type = 'U')
    drop table temp_机构信息表

if exists(select *
          from sysobjects
          where name = 'temp_汇总表'
            and type = 'U')
    drop table temp_汇总表

if exists(select *
          from sysobjects
          where name = 'temp_错误字段汇总表'
            and type = 'U')
    drop table temp_错误字段汇总表

if exists(select *
          from sysobjects
          where name = 'temp_全部规则字段表'
            and type = 'U')
    drop table temp_全部规则字段表

if exists(select *
          from sysobjects
          where name = 'temp_医生错误字段汇总表'
            and type = 'U')
    drop table temp_医生错误字段汇总表

if exists(select *
          from sysobjects
          where name = 'temp_医生汇总表'
            and type = 'U')
    drop table temp_医生汇总表


select *
into temp_机构信息表
from (
         SELECT org_code,
                org_name,
                max(hr_service_code) hr_service_code
         FROM report_qyyh
         GROUP BY org_code, org_name
     ) temp;
INSERT into
    temp_tables
VALUES(NEWID(),'temp_机构信息表',GETDATE());

with 封面汇总表 as (
    SELECT org_code,
           org_name,
           -- 签约居民人数
           count(*)           AS all_num,
           -- 签约未建档人数*(A+B)
           count(*) - sum(A4) AS lack_num,
           'HrCover'             TargetTable

    FROM report_qyyh
    GROUP BY org_code, org_name
),
     基本信息汇总表 as (
         SELECT org_code,
                org_name,
                -- 签约居民人数
                count(*)           AS all_num,
                -- 签约未建档人数*(A+B)
                count(*) - sum(A4) AS lack_num,
                'HrPersonBasicInfo'   TargetTable

         FROM report_qyyh
         GROUP BY org_code, org_name
     ),
     体检汇总表 as (
         SELECT org_code,
                org_name,
                -- 理论上总的体检表数量
                sum(CASE WHEN B3 > B4 THEN B3 ELSE B4 END)     AS all_num,
                -- 实际缺少的体检表数量
                sum(CASE WHEN B3 > B4 THEN B3 - B4 ELSE 0 END) AS lack_num,
                'HrHealthCheckup'                                 TargetTable

         FROM report_qyyh
         WHERE R5 = 0
         GROUP BY org_code, org_name
     ),
     高血压汇总表 as (
         SELECT org_code,
                org_name,
                -- 理论上总的高血压表数量
                sum(case when B5 > B6 then B5 else B6 end)     AS all_num,
                -- 实际缺少的高血压表数量
                sum(case when B5 > B6 then B5 - B6 else 0 end) AS lack_num,
                'HypertensionVisit'                               TargetTable
         FROM report_qyyh
         WHERE R2 = 1
            OR R3 = 1
            OR R6 = 1
            OR R7 = 1
         GROUP BY org_code, org_name
     ),
     糖尿病汇总表 as (
         SELECT org_code,
                org_name,
                -- 理论上总的糖尿病表数量
                sum(case when B7 > B8 then B7 else B8 end)     AS all_num,
                -- 实际缺少的糖尿病表数量
                sum(case when B7 > B8 then B7 - B8 else 0 end) AS lack_num,
                'DiabetesVisit'                                   TargetTable

         FROM report_qyyh
         WHERE R2 = 1
            OR R4 = 1
            OR R6 = 1
            OR R8 = 1
         GROUP BY org_code, org_name
     )


select *
into temp_汇总表
from (
         select t1.org_code, t1.org_name, isnull(t2.all_num, 0) all_num, isnull(t2.lack_num, 0) lack_num, TargetTable
         from temp_机构信息表 t1
                  left join (
             select *
             from 高血压汇总表
             union all
             select *
             from 糖尿病汇总表
             union all
             select *
             from 体检汇总表
             union all
             select *
             from 封面汇总表
             union all
             select *
             from 基本信息汇总表
         ) t2 on t1.org_code = t2.org_code
     ) temp
--给临时表添加索引
CREATE INDEX temp_汇总表_org_code_TargetTable ON temp_汇总表 (org_code, TargetTable);
INSERT into
    temp_tables
VALUES(NEWID(),'temp_汇总表',GETDATE());



with 封面错误字段统计表 as (
    select b.org_code,
           c.TargetField,
           c.targetFieldCn,
           TargetTable,
           count(distinct ArchiveNum + c.TargetField) error_num
    from HrRuleRecord a,
         report_qyyh b,
         HrRule c,
         HrRuleProps d
    where a.ArchiveNum = b.sfzh
      and a.RuleId = c.RuleId
      and c.TargetTable = 'HrCover'
      and c.RuleId = d.RuleId
      and d.ENABLE = '1'
      and A4 = 1
    group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable
),
     基本信息错误字段统计表 as (
         select b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct ArchiveNum + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'HrPersonBasicInfo'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable
     ),
     体检错误字段统计表 as (
         select b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct idOfTargetTable + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d,
              tb_dc_examination_info e
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'HrHealthCheckup'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
           and R5 = 0
           and e.orgcode = b.org_code
           and a.idOfTargetTable = e.guid
           and e.examinationDate >= '${质控数据开始时间}'
           and e.examinationDate <= '${质控数据截止时间}'
           -- and c.TargetField != 'HrPersonBasicInfo.ArchiveNum'
           -- and c.TargetField != 'tb_empi_index_root.name'
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable
     ),
     高血压错误字段统计表 as (
         select b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct idOfTargetTable + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d,
              tb_dc_htn_visit e
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'HypertensionVisit'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
           and e.orgcode = b.org_code
           and (R2 = 1 OR R3 = 1 OR R6 = 1 OR R7 = 1)
           and a.idOfTargetTable = e.guid
           and e.visitDate >= '${质控数据开始时间}'
           and e.visitDate <= '${质控数据截止时间}'
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable
     ),
     糖尿病错误字段统计表 as (
         select b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct idOfTargetTable + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d,
              tb_dc_dm_visit e
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'DiabetesVisit'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
           and e.orgcode = b.org_code
           and (R2 = 1 OR R4 = 1 OR R6 = 1 OR R8 = 1)
           and a.idOfTargetTable = e.guid
           and e.visitDate >= '${质控数据开始时间}'
           and e.visitDate <= '${质控数据截止时间}'
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable
     )
select *
into temp_错误字段汇总表
from (
         select *
         from 封面错误字段统计表
         union all
         select *
         from 基本信息错误字段统计表
         union all
         select *
         from 体检错误字段统计表
         union all
         select *
         from 高血压错误字段统计表
         union all
         select *
         from 糖尿病错误字段统计表
     ) temp
--给临时表添加索引
CREATE INDEX temp_错误字段汇总表_org_code_TargetTable_TargetField ON temp_错误字段汇总表 (org_code, TargetTable, TargetField);
INSERT into
    temp_tables
VALUES(NEWID(),'temp_错误字段汇总表',GETDATE());


with 医生封面错误字段统计表 as (
    select 
		       CZRYXM,
					 CZRYBM,
					 b.org_code,
           c.TargetField,
           c.targetFieldCn,
           TargetTable,
           count(distinct ArchiveNum + c.TargetField) error_num
    from HrRuleRecord a,
         report_qyyh b,
         HrRule c,
         HrRuleProps d
    where a.ArchiveNum = b.sfzh
      and a.RuleId = c.RuleId
      and c.TargetTable = 'HrCover'
      and c.RuleId = d.RuleId
      and d.ENABLE = '1'
      and A4 = 1
    group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable,CZRYXM,CZRYBM
),
     医生基本信息错误字段统计表 as (
         select 
				        CZRYXM,
					 CZRYBM,
				 b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct ArchiveNum + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'HrPersonBasicInfo'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable,CZRYXM,CZRYBM
     ),
    医生体检错误字段统计表 as (
         select 
				        CZRYXM,
					 CZRYBM,
				 b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct idOfTargetTable + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d,
              tb_dc_examination_info e
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'HrHealthCheckup'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
           and R5 = 0
           and e.orgcode = b.org_code
           and a.idOfTargetTable = e.guid
           and e.examinationDate >= '${质控数据开始时间}'
           and e.examinationDate <= '${质控数据截止时间}'
           -- and c.TargetField != 'HrPersonBasicInfo.ArchiveNum'
           -- and c.TargetField != 'tb_empi_index_root.name'
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable,CZRYXM,
					 CZRYBM
     ),
     医生高血压错误字段统计表 as (
         select
				        CZRYXM,
					 CZRYBM,
				 b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct idOfTargetTable + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d,
              tb_dc_htn_visit e
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'HypertensionVisit'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
           and e.orgcode = b.org_code
           and (R2 = 1 OR R3 = 1 OR R6 = 1 OR R7 = 1)
           and a.idOfTargetTable = e.guid
           and e.visitDate >= '${质控数据开始时间}'
           and e.visitDate <= '${质控数据截止时间}'
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable,       CZRYXM,
					 CZRYBM
     ),
     医生糖尿病错误字段统计表 as (
         select 
				        CZRYXM,
					 CZRYBM,
				 b.org_code,
                c.TargetField,
                c.targetFieldCn,
                TargetTable,
                count(distinct idOfTargetTable + c.TargetField) error_num
         from HrRuleRecord a,
              report_qyyh b,
              HrRule c,
              HrRuleProps d,
              tb_dc_dm_visit e
         where a.ArchiveNum = b.sfzh
           and a.RuleId = c.RuleId
           and c.TargetTable = 'DiabetesVisit'
           and c.RuleId = d.RuleId
           and d.ENABLE = '1'
           and A4 = 1
           and e.orgcode = b.org_code
           and (R2 = 1 OR R4 = 1 OR R6 = 1 OR R8 = 1)
           and a.idOfTargetTable = e.guid
           and e.visitDate >= '${质控数据开始时间}'
           and e.visitDate <= '${质控数据截止时间}'
         group by c.TargetField, c.targetFieldCn, b.org_code, TargetTable, CZRYXM,
					 CZRYBM
     )
select *
into temp_医生错误字段汇总表
from (
         select *
         from 医生封面错误字段统计表
         union all
         select *
         from 医生基本信息错误字段统计表
         union all
         select *
         from 医生体检错误字段统计表
         union all
         select *
         from 医生高血压错误字段统计表
         union all
         select *
         from 医生糖尿病错误字段统计表
     ) temp



--给临时表添加索引
CREATE INDEX temp_医生错误字段汇总表_org_code_TargetTable_TargetField ON temp_医生错误字段汇总表 (org_code, TargetTable, TargetField,CZRYXM,
					 CZRYBM );
INSERT into
    temp_tables
VALUES(NEWID(),'temp_医生错误字段汇总表',GETDATE());


with 医生封面汇总表 as (
    SELECT org_code,
           org_name,
CZRYXM, CZRYBM,
           -- 签约居民人数
           count(*)           AS all_num,
           -- 签约未建档人数*(A+B)
           count(*) - sum(A4) AS lack_num,
           'HrCover'             TargetTable

    FROM report_qyyh
    GROUP BY org_code, org_name,CZRYXM,CZRYBM
),
     医生基本信息汇总表 as (
         SELECT org_code,
                org_name,
CZRYXM,
					 CZRYBM,
                -- 签约居民人数
                count(*)           AS all_num,
                -- 签约未建档人数*(A+B)
                count(*) - sum(A4) AS lack_num,
                'HrPersonBasicInfo'   TargetTable

         FROM report_qyyh
         GROUP BY org_code, org_name,CZRYXM,
					 CZRYBM
     ),
     医生体检汇总表 as (
         SELECT org_code,
                org_name,
CZRYXM,
					 CZRYBM,
                -- 理论上总的体检表数量
                sum(CASE WHEN B3 > B4 THEN B3 ELSE B4 END)     AS all_num,
                -- 实际缺少的体检表数量
                sum(CASE WHEN B3 > B4 THEN B3 - B4 ELSE 0 END) AS lack_num,
                'HrHealthCheckup'                                 TargetTable

         FROM report_qyyh
         WHERE R5 = 0
         GROUP BY org_code, org_name,CZRYXM,
					 CZRYBM
     ),
    医生高血压汇总表 as (
         SELECT org_code,
                org_name,CZRYXM,
					 CZRYBM,
                -- 理论上总的高血压表数量
                sum(case when B5 > B6 then B5 else B6 end)     AS all_num,
                -- 实际缺少的高血压表数量
                sum(case when B5 > B6 then B5 - B6 else 0 end) AS lack_num,
                'HypertensionVisit'                               TargetTable
         FROM report_qyyh
         WHERE R2 = 1
            OR R3 = 1
            OR R6 = 1
            OR R7 = 1
         GROUP BY org_code, org_name,CZRYXM,
					 CZRYBM
     ),
     医生糖尿病汇总表 as (
         SELECT org_code,
                org_name,
CZRYXM,
					 CZRYBM,
                -- 理论上总的糖尿病表数量
                sum(case when B7 > B8 then B7 else B8 end)     AS all_num,
                -- 实际缺少的糖尿病表数量
                sum(case when B7 > B8 then B7 - B8 else 0 end) AS lack_num,
                'DiabetesVisit'                                   TargetTable

         FROM report_qyyh
         WHERE R2 = 1
            OR R4 = 1
            OR R6 = 1
            OR R8 = 1
         GROUP BY org_code, org_name,CZRYXM,CZRYBM
     )


select *
into temp_医生汇总表
from (
         select t1.org_code, t1.org_name,CZRYXM,
					 CZRYBM,isnull(t2.all_num, 0) all_num, isnull(t2.lack_num, 0) lack_num, TargetTable
         from temp_机构信息表 t1
             left join (
             select *
             from 医生高血压汇总表
             union all
             select *
             from 医生糖尿病汇总表
             union all
             select *
             from 医生体检汇总表
             union all
             select *
             from 医生封面汇总表
             union all
             select *
             from 医生基本信息汇总表
         ) t2 on t1.org_code = t2.org_code
     ) temp
--给临时表添加索引
CREATE INDEX temp_医生汇总表_org_code_TargetTable ON temp_医生汇总表 (org_code, TargetTable,CZRYXM,
					 CZRYBM);
INSERT into
    temp_tables
VALUES(NEWID(),'temp_医生汇总表',GETDATE());


with 缺失规则质控字段 as (
    SELECT *
    FROM (
             VALUES ('HrCover', 'HrCover.ArchiveNum', '档案编号'),
                    ('HrPersonBasicInfo', 'HrAssociationInfo.AssociationType', '暴露史'),
                    ('HrPersonBasicInfo', 'HrPersonBasicInfo.ArchiveNum', '档案编号'),
                    ('HrHealthCheckup', 'HrHealthCheckup.B超—其他', 'B超—其他'),
                    ('HrHealthCheckup', 'HrHealthCheckup.肝功能—白蛋白', '肝功能—白蛋白'),
                    ('HrHealthCheckup', 'HrHealthCheckup.肝功能—结合胆红素', '肝功能—结合胆红素'),
                    ('HrHealthCheckup', 'HrHealthCheckup.口腔—龋齿', '口腔—龋齿'),
                    ('HrHealthCheckup', 'HrHealthCheckup.口腔—缺齿', '口腔—缺齿'),
                    ('HrHealthCheckup', 'HrHealthCheckup.口腔—义齿', '口腔—义齿'),
                    ('HrHealthCheckup', 'HrHealthCheckup.肾功能—血钾浓度', '肾功能—血钾浓度'),
                    ('HrHealthCheckup', 'HrHealthCheckup.肾功能—血钠浓度', '肾功能—血钠浓度'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—放射物质', '职业病危害因素接触史—放射物质'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—放射物质防护措施', '职业病危害因素接触史—放射物质防护措施'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—粉尘', '职业病危害因素接触史—粉尘'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—粉尘防护措施', '职业病危害因素接触史—粉尘防护措施'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—化学物质', '职业病危害因素接触史—化学物质'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—化学物质防护措施', '职业病危害因素接触史—化学物质防护措施'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—其他', '职业病危害因素接触史—其他'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—其他防护措施', '职业病危害因素接触史—其他防护措施'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—物理因素', '职业病危害因素接触史—物理因素'),
                    ('HrHealthCheckup', 'HrHealthCheckup.职业病危害因素接触史—物理因素防护措施', '职业病危害因素接触史—物理因素防护措施'),
                    ('HypertensionVisit', 'HypertensionVisit.年龄', '年龄'),
                    ('DiabetesVisit', 'HypertensionVisit.其他随访方式', '其他随访方式'),
                    ('DiabetesVisit', 'HypertensionVisit.糖尿病新诊断并发症—确诊日期', '糖尿病新诊断并发症—确诊日期'),
                    ('DiabetesVisit', 'HypertensionVisit.用药情况—服药量单位', '用药情况—服药量单位')
         )
             AS X(TargetTable, TargetField, targetFieldCn)
),
     全部规则字段表temp as (
         select distinct TargetTable,
                         TargetField,
                         targetFieldCn
         from HrRule t2,
              HrRuleProps t3
         where t2.TargetTable in
               ('HrCover', 'HrPersonBasicInfo', 'HrHealthCheckup', 'HypertensionVisit', 'DiabetesVisit')
           and t2.ruleid = t3.ruleid
           and t2.ruleid not in (select ruleid from hrrule where TargetField = 'HrPersonBasicInfo.ArchiveNum')
           and t2.ruleid not in (select ruleid from hrrule where TargetField = 'tb_empi_index_root.name')
           and t2.ruleid not in
               (select ruleid from hrrule where targetFieldCn in ('职业病危害因素接触史—毒物种类', '职业病危害因素接触史—防护措施', '其他失访理由'))
           and t3.ENABLE = '1'

         union all
         select *
         from 缺失规则质控字段
     )

select *
into temp_全部规则字段表
from (
         select a.org_code, a.org_name, a.hr_service_code, b.TargetField, b.targetFieldCn, b.TargetTable
         from temp_机构信息表 a,
              全部规则字段表temp b
     ) temp
--给临时表添加索引
CREATE INDEX temp_全部规则字段表_org_code_TargetTable_TargetField ON temp_全部规则字段表 (org_code, TargetTable, TargetField)
INSERT into
    temp_tables
VALUES(NEWID(),'temp_全部规则字段表',GETDATE());



END
go

