CREATE FUNCTION [dbo].[f_getSWB](@sourceString NVARCHAR(MAX))
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @word NCHAR(1)
	DECLARE @SWB NVARCHAR(MAX)
	SET @SWB = ''
	WHILE LEN(@sourceString) > 0
		BEGIN
			SET @word = LEFT(@sourceString, 1)
			--如果非汉字字符，返回''
			SET @SWB = @SWB + ISNULL((SELECT TOP 1 SWB FROM [t_dic_character] WHERE [character] = @word), '')
			SET @sourceString = RIGHT(@sourceString, LEN(@sourceString) - 1)
		END
	RETURN @SWB
END
go

