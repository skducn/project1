CREATE FUNCTION [dbo].[f_getSP](@sourceString NVARCHAR(MAX))
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @word NCHAR(1)
	DECLARE @wordSP1 CHAR(1)
	DECLARE @wordSP2 CHAR(1)
	DECLARE @wordSP3 CHAR(1)
	DECLARE @wordSP4 CHAR(1)
	DECLARE @SP NVARCHAR(MAX)
	DECLARE @TempSP NVARCHAR(MAX)
	SET @SP = ''
	WHILE LEN(@sourceString) > 0
		BEGIN
			SET @word = LEFT(@sourceString, 1)
			SELECT TOP 1 @wordSP1 = SP1, @wordSP2 = SP2, @wordSP3 = SP3, @wordSP4 = SP4 FROM t_dic_character WHERE [character] = @word
			--如果非汉字字符，返回''
			IF ISNULL(@wordSP1, '') <> ''
				BEGIN
					SET @TempSP = @SP
					SET @SP = REPLACE(@TempSP, ',', @wordSP1 + ',') + @wordSP1
					IF ISNULL(@wordSP2, '') <> ''
						BEGIN
							SET @SP = @SP + ',' + REPLACE(@TempSP, ',', @wordSP2 + ',') + @wordSP2
						END
					IF ISNULL(@wordSP3, '') <> ''
						BEGIN
							SET @SP = @SP + ',' + REPLACE(@TempSP, ',', @wordSP3 + ',') + @wordSP3
						END
					IF ISNULL(@wordSP4, '') <> ''
						BEGIN
							SET @SP = @SP + ',' + REPLACE(@TempSP, ',', @wordSP4 + ',') + @wordSP4
						END
				END
			SET @sourceString = RIGHT(@sourceString, LEN(@sourceString) - 1)
		END
	IF @SP = ''
		SET @SP = NULL
	RETURN @SP
END
go

