CREATE PROCEDURE dbo.a_upload_procedure
AS 
SELECT 1

BEGIN
	update dbo.a_upload set s_value='500' where o_value='3000'
END
go

