CREATE FUNCTION [dbo].[GET_INCLUDE_OR_NOT](@BASIC_INFO_CODE varchar(100),@num nvarchar(4)) 

RETURNS int   --返回值的数据类型
as
BEGIN
	declare @cnt int
	if @BASIC_INFO_CODE=@num 
	   set @cnt=1
	if charindex(@num,@BASIC_INFO_CODE) = 0
		set @cnt=0
	if (@BASIC_INFO_CODE!=@num and charindex(@num,@BASIC_INFO_CODE) != 0 and charindex(N','+@num,@BASIC_INFO_CODE) !=0 and charindex(N','+@num,@BASIC_INFO_CODE) != len(@BASIC_INFO_CODE)-len(@num))
	or (@BASIC_INFO_CODE!=@num and charindex(@num,@BASIC_INFO_CODE) != 0 and charindex(N','+@num,@BASIC_INFO_CODE)  =0 and charindex(N','+@num,@BASIC_INFO_CODE) != len(@BASIC_INFO_CODE)-len(@num))
	 set @cnt=0
    if	(@BASIC_INFO_CODE!=@num and charindex(@num,@BASIC_INFO_CODE) != 0 and charindex(@num+',',@BASIC_INFO_CODE) = 1)
	 or (@BASIC_INFO_CODE!=@num and charindex(@num,@BASIC_INFO_CODE) != 0 and charindex(','+@num+',',@BASIC_INFO_CODE) != 0)
	 or (@BASIC_INFO_CODE!=@num and charindex(@num,@BASIC_INFO_CODE) != 0 and charindex(N','+@num,@BASIC_INFO_CODE) = len(@BASIC_INFO_CODE)-len(@num))
		set @cnt=1
  RETURN  @cnt
end
go

