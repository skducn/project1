CREATE FUNCTION [dbo].[Fn_GetPercent] (
    @分子 INT,
    @分母 INT
)
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @return VARCHAR(20);

    IF (@分母 IS NULL OR @分母 = 0)
    BEGIN
        SET @return = '0.00';
    END
    ELSE
    BEGIN
        SET @return = FORMAT(ROUND(@分子 * 100.0 / NULLIF(@分母, 0), 2), 'F2');
    END

    RETURN @return;
END;
go

