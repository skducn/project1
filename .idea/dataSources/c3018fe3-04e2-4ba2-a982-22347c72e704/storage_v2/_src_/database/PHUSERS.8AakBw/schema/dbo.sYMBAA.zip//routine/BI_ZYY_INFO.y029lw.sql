CREATE PROCEDURE [dbo].[BI_ZYY_INFO]
    @ORG_CODE NVARCHAR(50),
   @START_DATE DATE ,
		@END_DATE DATE
AS
BEGIN
DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE);
    -- SQL注入检查
    IF @ORG_CODE LIKE '%select %'
       OR @ORG_CODE LIKE '%update %'
       OR @ORG_CODE LIKE '%insert %'
       OR @ORG_CODE LIKE '%delete %'
       OR @ORG_CODE LIKE '%truncate %'
       OR @ORG_CODE LIKE '%drop %'
       OR @ORG_CODE LIKE '%union %'
       OR @ORG_CODE LIKE '%exec %'
       OR @ORG_CODE LIKE '%xp_%'
BEGIN
        RAISERROR('输入变量值中包含SQL注入！', 16, 1);
        RETURN;
END;

    IF @ORG_CODE = '370685'
BEGIN
        -- 创建并填充临时表 #S0
SELECT ORG_CODE, ORG_NAME
INTO #S0
FROM ZYCONFIG.DBO.SYS_HOSPITAL
UNION ALL
SELECT '370685', '招远卫健局';

-- 创建并填充临时表 #S1
SELECT
    org_code,
    sum(iif(EHR_ID is not null ,1,0) )AS num1
INTO #S1
FROM (
         SELECT
             t2.MANAGE_ORG_CODE,
             ISNULL(
                     (SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE),
                     MANAGE_ORG_CODE
                 ) AS ORG_CODE,
             t1.EHR_ID
         FROM (
                  SELECT EHR_ID
                  FROM T_SNR_EXAMINATION_TCM
                  WHERE FILL_FORM_DATE BETWEEN  @START_DATE AND  @END_DATE
                    AND DATEDIFF(MONTH, (SELECT BIRTH FROM T_EHR_INFO WHERE ID = EHR_ID),
                                        IIF(@YEAR = YEAR(GETDATE()), GETDATE(), DATEFROMPARTS(@YEAR, 12, 31))) / 12 >= 65
              ) t1
                  INNER JOIN T_EHR_INFO t2 ON t1.EHR_ID = t2.ID and  t2.IS_DELETE='0'
             and t2.FINAL_STATUS='0'
     ) m1
where ehr_id is not NULL
GROUP BY m1.ORG_CODE;

-- 创建并填充临时表 #S2
SELECT
    ORG_CODE,
    sum(iif(id is not null ,1,0) ) AS num2
INTO #S2
FROM (
         SELECT
             id,
             ISNULL(
                     (SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = CREATE_ORG_CODE),
                     CREATE_ORG_CODE
                 ) AS ORG_CODE
         FROM T_CHILD_INFO
         WHERE
                BIRTH BETWEEN  DATEADD(YEAR, -3, @end_date) and @end_date
           AND CLOSED_STATUS = '0'
           AND IS_DELETE = '0'
           AND (MANAGE_CATEGORY_CODE='1'OR MANAGE_CATEGORY_CODE='2')
     ) m2
WHERE id is not null
GROUP BY ORG_CODE;

-- 创建并填充临时表 #S3
SELECT
    ORG_CODE,
   sum(iif(id is not null ,1,0) ) AS num3
INTO #S3
FROM (
         SELECT
             id,
             ISNULL(
                     (SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE),
                     MANAGE_ORG_CODE
                 ) AS ORG_CODE
         FROM T_CHILD_INFO t1
         WHERE BIRTH BETWEEN  DATEADD(YEAR, -3, @end_date) and @end_date
           AND id IN (
             SELECT INFO_ID FROM T_CHILD_EXAMINATION WHERE  MONTH_AGE in ('06','12','18','24','30','36') AND MONTH_AGE is not null AND VISIT_DATE BETWEEN  @START_DATE AND  @END_DATE
           and IS_DELETE ='0'
     )
    AND CLOSED_STATUS = '0'
                AND IS_DELETE = '0'
								AND (MANAGE_CATEGORY_CODE='1'OR MANAGE_CATEGORY_CODE='2')
        ) m3
WHERE id is not null
GROUP BY ORG_CODE;

-- 创建并填充临时表 #S5
SELECT
    S0.ORG_CODE,
    S0.ORG_NAME,
    ISNULL(CEILING(
                   ((SELECT OLD_NUM FROM T_HOME WHERE ORG_CODE = S0.ORG_CODE AND YEAR = @YEAR))
               ),0) AS elderlyPermanentPopulation,
    ISNULL(SUM(S1.num1), 0) AS elderlyChineseMedicine,
    ISNULL(SUM(S2.num2), 0) AS childAdministration,
    ISNULL(SUM(S3.num3), 0) AS monthAgechildAdministration
INTO #S5
FROM #S0 as s0
         LEFT JOIN #S1  as s1 ON S0.ORG_CODE = S1.ORG_CODE
         LEFT JOIN #S2  as s2 ON S0.ORG_CODE = S2.ORG_CODE
         LEFT JOIN #S3  as s3 ON S0.ORG_CODE = S3.ORG_CODE
GROUP BY S0.ORG_CODE, S0.ORG_NAME;

-- 最终查询
SELECT
    S5.*,
    dbo.Fn_GetPercent(elderlyChineseMedicine, elderlyPermanentPopulation) AS elderlyManagementRate,
    dbo.Fn_GetPercent(monthAgechildAdministration, childAdministration) AS childRate
FROM #S5 as s5;

-- 删除临时表
DROP TABLE #S0;
DROP TABLE #S1;
DROP TABLE #S2;
DROP TABLE #S3;
DROP TABLE #S5;
END
ELSE
BEGIN
        -- 创建并填充临时表 #S0
SELECT
    ORG_sub_CODE,
    ORG_SUB_NAME
INTO #S00
FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL
WHERE org_code = @ORG_CODE
UNION ALL
SELECT
    @org_code,
    (SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE org_code = @org_code);

-- 创建并填充临时表 #S1
SELECT
    ORG_sub_CODE,
   sum(iif(EHR_ID is not null ,1,0) ) AS num1
INTO #S11
FROM (
         SELECT
             t2.MANAGE_ORG_CODE AS ORG_sub_CODE,
             t1.EHR_ID
         FROM (
                  SELECT EHR_ID
                  FROM T_SNR_EXAMINATION_TCM
                  WHERE FILL_FORM_DATE BETWEEN  @START_DATE AND  @END_DATE
                    AND DATEDIFF(MONTH, (SELECT BIRTH FROM T_EHR_INFO WHERE ID = EHR_ID),
                                        @END_DATE) / 12 >= 65
              ) t1
                  INNER JOIN T_EHR_INFO t2 ON t1.EHR_ID = t2.ID  and  t2.IS_DELETE='0'
             and t2.FINAL_STATUS='0'
         WHERE ISNULL(
                       (SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE),
                       MANAGE_ORG_CODE
                   ) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE))
     ) m1
WHERE ehr_id is not null


GROUP BY ORG_sub_CODE;

-- 创建并填充临时表 #S2
SELECT
    ORG_SUB_CODE,
      sum(iif(id is not null ,1,0) ) AS num2
INTO #S22
FROM (
         SELECT
             id,
             MANAGE_ORG_CODE AS ORG_sub_CODE
         FROM T_CHILD_INFO
         WHERE ISNULL(
                       (SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = CREATE_ORG_CODE),
                       CREATE_ORG_CODE
                   ) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE))
           AND  BIRTH BETWEEN  DATEADD(YEAR, -3, @end_date) and @end_date

           AND CLOSED_STATUS = '0'
           AND IS_DELETE = '0'
           AND (MANAGE_CATEGORY_CODE='1'OR MANAGE_CATEGORY_CODE='2')
     ) m2
WHERE id is not null

GROUP BY ORG_SUB_CODE;

-- 创建并填充临时表 #S3
SELECT
    ORG_SUB_CODE,
     sum(iif(id is not null ,1,0) ) AS num3
INTO #S33
FROM (
         SELECT
             id,
             MANAGE_ORG_CODE AS ORG_sub_CODE
         FROM T_CHILD_INFO t1
         WHERE ISNULL(
                       (SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE =MANAGE_ORG_CODE),
                        MANAGE_ORG_CODE
                   ) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE))
           AND BIRTH BETWEEN  DATEADD(YEAR, -3, @end_date) and @end_date
           AND id IN (
             SELECT INFO_ID FROM T_CHILD_EXAMINATION WHERE  MONTH_AGE in ('06','12','18','24','30','36') AND MONTH_AGE is not null AND VISIT_DATE BETWEEN @START_DATE AND  @END_DATE
           and IS_DELETE ='0'
     )
    AND CLOSED_STATUS = '0'
            AND IS_DELETE = '0'
							AND (MANAGE_CATEGORY_CODE='1'OR MANAGE_CATEGORY_CODE='2')

        ) m3
WHERE id is not NULL
GROUP BY ORG_sub_CODE;

-- 创建并填充临时表 #S5
SELECT
    S0.ORG_sub_CODE AS ORG_CODE,
    S0.ORG_SUB_NAME AS ORG_NAME,
    ISNULL(CEILING(
                   (SELECT OLD_NUM FROM T_SUB_HOME WHERE ORG_SUB_CODE = S0.ORG_sub_CODE AND YEAR = @YEAR)
               ), 0) AS elderlyPermanentPopulation,
    ISNULL(SUM(S1.num1), 0) AS elderlyChineseMedicine,
    ISNULL(SUM(S2.num2), 0) AS childAdministration,
    ISNULL(SUM(S3.num3), 0) AS monthAgechildAdministration
INTO #S55
FROM #S00 as s0
         LEFT JOIN #S11 as s1 ON S0.ORG_sub_CODE = S1.ORG_sub_CODE
         LEFT JOIN #S22 as s2  ON S0.ORG_sub_CODE = S2.ORG_sub_CODE
         LEFT JOIN #S33  as  s3 ON S0.ORG_sub_CODE = S3.ORG_sub_CODE
GROUP BY S0.ORG_sub_CODE, S0.ORG_SUB_NAME;

-- 最终查询
SELECT
    S5.*,
    dbo.Fn_GetPercent(elderlyChineseMedicine, elderlyPermanentPopulation) AS elderlyManagementRate,
    dbo.Fn_GetPercent(monthAgechildAdministration, childAdministration) AS childRate
FROM #S55 as s5
ORDER BY ORG_CODE DESC;

-- 删除临时表
DROP TABLE #S00;
DROP TABLE #S11;
DROP TABLE #S22;
DROP TABLE #S33;
DROP TABLE #S55;
END;

END;
go

