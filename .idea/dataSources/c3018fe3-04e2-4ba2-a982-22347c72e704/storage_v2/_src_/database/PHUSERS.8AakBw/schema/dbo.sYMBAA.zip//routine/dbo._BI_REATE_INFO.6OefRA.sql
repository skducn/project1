CREATE PROCEDURE [dbo.[BI_REATE_INFO]
AS
BEGIN 
DECLARE @YEAR INT ;
DECLARE @START_DATE DATE;
DECLARE @END_DATE DATE;
DECLARE @neonateRate decimal(10,2) ;
DECLARE @childHealthManagementRate decimal(10,2) ;
DECLARE @jurisdictionChildExaminationRate decimal(10,2) ;
DECLARE @elderlyManagementRate decimal(10,2) ;
DECLARE @elderlyZyymentRate decimal(10,2) ;
DECLARE @gxynormManageRate decimal(10,2) ;
DECLARE @manageBpControlRate decimal(10,2) ;
DECLARE @tnbnormManageRate decimal(10,2) ;
DECLARE @manageBgControlRate decimal(10,2) ;
DECLARE @buildRate decimal(10,2) ;
DECLARE @pregnancyRate decimal(10,2) ;
DECLARE @managementRate decimal(10,2) ;
DECLARE @regularMedicationRate decimal(10,2) ;
DECLARE @jsbMedicationRate decimal(10,2) ;
		 SET @START_DATE = DATEFROMPARTS(@YEAR, 1, 1); 
		 SET @END_DATE =GETDATE();
		 SET  @YEAR=YEAR(GETDATE());
		 
		

END
go

