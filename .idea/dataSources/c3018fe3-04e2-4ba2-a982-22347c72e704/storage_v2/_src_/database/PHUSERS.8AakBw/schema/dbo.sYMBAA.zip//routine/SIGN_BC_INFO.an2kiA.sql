CREATE PROCEDURE [dbo].[SIGN_BC_INFO]
@startDate as DATE, @endDate as DATE, @userId AS int,@orgCode NVARCHAR(50)
AS
BEGIN
IF @userId is NULL BEGIN
	WITH S1 AS (

	SELECT
	t.ORG_CODE,
	COUNT (DISTINCT t.ID) as kpTotal,
	SUM( IIF ( t.VALUE = '2', 1, 0 ) ) as age0To6Num,
  SUM( IIF ( t.VALUE = '3' , 1, 0 ) ) as age60To64Num,
  SUM( IIF ( t.VALUE = '4', 1, 0 ) ) as ageOver65Num,
  SUM( IIF ( t.VALUE = '5', 1, 0 ) ) as pwNum,
  SUM( IIF ( t.VALUE = '6', 1, 0 ) ) as disNum,
  SUM( IIF ( t.VALUE = '7', 1, 0 ) ) as htnNum,
  SUM( IIF ( t.VALUE = '8', 1, 0 ) ) as dmNum,
  SUM( IIF ( t.VALUE = '9', 1, 0 ) ) as hpl64Num,
  SUM( IIF ( t.VALUE = '10', 1, 0 ) ) as chdNum,
  SUM( IIF ( t.VALUE = '11', 1, 0 ) ) as dntNum,
  SUM( IIF ( t.VALUE = '12', 1, 0 ) ) as tbNum,
  SUM( IIF ( t.VALUE = '13', 1, 0 ) ) as smiNum,
  SUM( IIF ( t.VALUE = '14', 1, 0 ) ) as fpNum,
  SUM( IIF ( t.VALUE = '15', 1, 0 ) ) as poNum,
  SUM( IIF ( t.VALUE = '16', 1, 0 ) ) as maNum,
  SUM( IIF ( t.VALUE = '17', 1, 0 ) ) as saNum,
  SUM( IIF ( t.VALUE = '18', 1, 0 ) ) as fgNum,
	SUM( IIF ( t.VALUE = '19', 1, 0 ) ) as fppNum,
	SUM( IIF ( t.VALUE = '20', 1, 0 ) ) as copdNum
FROM
   (SELECT
	a.ID,
	VALUE,
	SIGN_TYPE_CODE,
	IIF(h.ID is null, a.ORG_CODE, h.ORG_CODE) as ORG_CODE
FROM
	T_SIGN_INFO a CROSS APPLY STRING_SPLIT ( BASIC_INFO_CODE, ',' )
	LEFT JOIN ZYCONFIG.dbo.SYS_SUB_HOSPITAL h ON h.ORG_SUB_CODE = a.ORG_CODE
WHERE
	a.SIGN_STATUS = 1 AND a.SIGN_DATE BETWEEN  @startDate AND @endDate AND VALUE != '1' AND VALUE != '' AND VALUE is not NULL ) t GROUP BY t.ORG_CODE), S2 AS (

	SELECT t.ORG_CODE, COUNT(DISTINCT t.ID) as total FROM (SELECT
		a.ID,
		IIF ( h.ID IS NULL, a.ORG_CODE, h.ORG_CODE ) AS ORG_CODE
	FROM
		T_SIGN_INFO a
		LEFT JOIN ZYCONFIG.dbo.SYS_SUB_HOSPITAL h ON h.ORG_SUB_CODE = a.ORG_CODE
	WHERE
		a.SIGN_STATUS = 1
		AND a.SIGN_DATE BETWEEN  @startDate AND @endDate ) t
		GROUP BY t.ORG_CODE
	),
	S3 as (
	SELECT COUNT(DISTINCT t.ID) as kpFamilyTotal,t.ORG_CODE FROM (
	SELECT
	 a.ID,
	IIF(h.ID is null, a.ORG_CODE, h.ORG_CODE) as ORG_CODE
FROM
	T_SIGN_INFO a CROSS APPLY STRING_SPLIT ( BASIC_INFO_CODE, ',' )
	LEFT JOIN ZYCONFIG.dbo.SYS_SUB_HOSPITAL h ON h.ORG_SUB_CODE = a.ORG_CODE
WHERE
	a.SIGN_STATUS = 1 AND a.SIGN_DATE BETWEEN  @startDate AND @endDate AND VALUE != '1' AND VALUE != '' AND VALUE is not NULL AND SIGN_TYPE_CODE = '2') t GROUP BY t.ORG_CODE
				)
SELECT t1.*,t2.total,h.ORG_NAME as orgName,t3.kpFamilyTotal FROM S1 t1 LEFT JOIN S2 t2 ON t1.ORG_CODE = t2.ORG_CODE
                                                                       LEFT JOIN ZYCONFIG.dbo.SYS_HOSPITAL h on t1.ORG_CODE = h.ORG_CODE LEFT JOIN S3 t3 ON t1.ORG_CODE = t3.ORG_CODE ORDER BY h.ORG_NAME;
END
ELSE BEGIN
  WITH TEAM AS (
            SELECT
                ID AS TEAM_ID
            FROM
                T_TEAM
            WHERE
                ORG_CODE IN (SELECT ORG_SUB_CODE FROM ZYCONFIG.dbo.SYS_SUB_HOSPITAL WHERE ORG_CODE = @orgCode) OR ORG_CODE = @orgCode
                AND IS_DELETE = 0
        ),
	 S1 as (
	   SELECT
		        t.TEAM_ID,
            count(DISTINCT a.ID ) as kpTotal,
            SUM( IIF ( VALUE = '2', 1, 0 ) ) as age0To6Num,
            SUM( IIF ( VALUE = '3' , 1, 0 ) ) as age60To64Num,
            SUM( IIF ( VALUE = '4', 1, 0 ) ) as ageOver65Num,
            SUM( IIF ( VALUE = '5', 1, 0 ) ) as pwNum,
            SUM( IIF (  VALUE = '6', 1, 0 ) ) as disNum,
            SUM( IIF ( VALUE = '7', 1, 0 ) ) as htnNum,
            SUM( IIF ( VALUE = '8', 1, 0 ) ) as dmNum,
            SUM( IIF ( VALUE = '9', 1, 0 ) ) as hpl64Num,
            SUM( IIF ( VALUE = '10', 1, 0 ) ) as chdNum,
            SUM( IIF ( VALUE = '11', 1, 0 ) ) as dntNum,
            SUM( IIF ( VALUE = '12', 1, 0 ) ) as tbNum,
            SUM( IIF ( VALUE = '13', 1, 0 ) ) as smiNum,
            SUM( IIF ( VALUE = '14', 1, 0 ) ) as fpNum,
            SUM( IIF ( VALUE = '15', 1, 0 ) ) as poNum,
            SUM( IIF ( VALUE = '16', 1, 0 ) ) as maNum,
            SUM( IIF ( VALUE = '17', 1, 0 ) ) as saNum,
            SUM( IIF ( VALUE = '18', 1, 0 ) ) as fgNum,
						SUM( IIF ( VALUE = '19', 1, 0 ) ) as fppNum,
	          SUM( IIF ( VALUE = '20', 1, 0 ) ) as copdNum
        FROM
            T_SIGN_INFO a CROSS APPLY STRING_SPLIT ( a.BASIC_INFO_CODE, ',' )
						RIGHT JOIN TEAM t on a.TEAM_ID = t.TEAM_ID AND a.SIGN_DATE BETWEEN  @startDate AND @endDate AND VALUE != '1' AND VALUE != '' AND VALUE is not NULL AND a.SIGN_STATUS = 1
				GROUP BY t.TEAM_ID),
				S2 as (
				SELECT TEAM_ID, COUNT(*) as total FROM T_SIGN_INFO  where SIGN_STATUS = 1 AND TEAM_ID in (SELECT TEAM_ID FROM TEAM) AND SIGN_DATE BETWEEN  @startDate AND @endDate GROUP BY TEAM_ID
				),
				S3 as (
				SELECT
				TEAM_ID,
			 count(DISTINCT ID ) as kpFamilyTotal
        FROM
            T_SIGN_INFO CROSS APPLY STRING_SPLIT ( BASIC_INFO_CODE, ',' )
        where SIGN_STATUS = 1
				AND SIGN_DATE BETWEEN  @startDate AND @endDate AND VALUE != '1' AND VALUE != '' AND VALUE is not NULL AND TEAM_ID IN (SELECT TEAM_ID FROM TEAM) AND SIGN_TYPE_CODE = '2' GROUP BY TEAM_ID)
SELECT t1.*,t.TEAM_NAME as orgName,t2.total as total,t3.kpFamilyTotal FROM S1 t1 LEFT JOIN T_TEAM t on TEAM_ID = t.ID LEFT JOIN S2 t2 ON t1.TEAM_ID = t2.TEAM_ID LEFT JOIN S3 t3 ON t1.TEAM_ID = t3.TEAM_ID ORDER BY t.TEAM_NAME;
END
END
go

