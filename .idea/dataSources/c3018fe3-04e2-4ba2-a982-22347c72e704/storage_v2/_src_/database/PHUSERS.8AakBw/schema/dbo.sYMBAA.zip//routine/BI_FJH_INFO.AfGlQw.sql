CREATE PROCEDURE [dbo].[BI_FJH_INFO]
    @ORG_CODE NVARCHAR(50),
    @START_DATE DATE ,
		@END_DATE DATE
AS
BEGIN
-- 去年年份

 DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE);

 DECLARE @QUARTE  INT;
		SET @QUARTE  =
(SELECT DATENAME(QUARTER, @END_DATE) ) ;


DECLARE @PREV_YEAR NVARCHAR(4);
SET @PREV_YEAR = CONVERT(NVARCHAR(4), CAST(@YEAR AS INT) - 1);
    -- SQL注入检查
    IF @ORG_CODE LIKE '%select %' OR @ORG_CODE LIKE '%update %' OR @ORG_CODE LIKE '%insert %' OR @ORG_CODE LIKE '%delete %' OR
       @ORG_CODE LIKE '%truncate %' OR @ORG_CODE LIKE '%drop %' OR @ORG_CODE LIKE '%union %' OR @ORG_CODE LIKE '%exec %' OR
       @ORG_CODE LIKE '%xp_%' OR @YEAR LIKE '%select %' OR @YEAR LIKE '%update %' OR @YEAR LIKE '%insert %' OR
       @YEAR LIKE '%delete %' OR @YEAR LIKE '%truncate %' OR @YEAR LIKE '%drop %' OR @YEAR LIKE '%union %' OR
       @YEAR LIKE '%exec %' OR @YEAR LIKE '%xp_%'
BEGIN
        RAISERROR('输入变量值中包含SQL注入！', 16, 1);
        RETURN;
END;

    -- 如果 @ORG_CODE 为 '370685'，执行以下逻辑
    IF @ORG_CODE = '370685'
BEGIN
        -- 定义公用表表达式 s1
WITH

    S0 AS ( SELECT ORG_CODE, ORG_NAME FROM ZYCONFIG.DBO.SYS_HOSPITAL UNION ALL SELECT '370685', '招远卫健局' ),

    s1 AS (
        SELECT
            t2.MANAGE_ORG_CODE,
            t2.MANAGE_ORG_NAME,
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t2.MANAGE_ORG_CODE), t2.MANAGE_ORG_CODE) AS UP_orgcode,
            t2.IDCARD,
            t1.ID,
						t2.FINAL_STATUS
        FROM
            (SELECT DISTINCT IDCARD, ID FROM T_TB_INFO WHERE IS_DELETE = '0') t1
               INNER JOIN T_EHR_INFO t2 ON t1.IDCARD = t2.IDCARD
        WHERE
                ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t2.MANAGE_ORG_CODE), t2.MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE)) and  t2.IS_DELETE=0 and t2.FINAL_STATUS !=2
    ),
    -- 定义公用表表达式 s2
    s2 AS (
        SELECT ID FROM T_TB_INFO WHERE CREATE_DATE<= @END_DATE AND ID IN (SELECT ID FROM s1 WHERE FINAL_STATUS=0) 
    ),
    s3 AS (
        SELECT ID FROM T_TB_INFO WHERE ID IN (SELECT INFO_ID FROM T_TB_VISIT WHERE YEAR(STOP_TREATMENT_DATE) = @PREV_YEAR) AND ID IN (SELECT ID FROM s1) and CLOSED_STATUS=0
    ),
    s4 AS (
SELECT ID FROM T_TB_INFO WHERE ID IN (SELECT INFO_ID FROM T_TB_VISIT WHERE YEAR(STOP_TREATMENT_DATE) = @PREV_YEAR  AND TAKE_RATE >= 95) AND ID IN (SELECT ID FROM s1)
    )

SELECT s0.org_code AS orgCode,
       s0.org_name AS orgName,
       ISNULL((CASE WHEN @QUARTE =1  THEN U.TB_NUM_QUARTER_1
                    WHEN @QUARTE =2  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2
                    WHEN @QUARTE=3  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3
                    WHEN @QUARTE =4 THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3+U.TB_NUM_QUARTER_4

                    ELSE 0
           END
                  ),0) AS NumberOfConfirmedCases
        ,dbo.Fn_GetPercent(u.num1, (CASE WHEN @QUARTE =1  THEN U.TB_NUM_QUARTER_1
                                         WHEN @QUARTE =2  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2
                                         WHEN @QUARTE=3  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3
                                         WHEN @QUARTE =4 THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3+U.TB_NUM_QUARTER_4

                                         ELSE 0
    END
    ))AS managementRate,
       dbo.Fn_GetPercent( u.num2, u.num3) AS regularMedicationRate,
       ISNULL(u.num1, 0)  AS managementNumber,
       ISNULL(u.num2,0) AS treatNumber,
       ISNULL(u.num3,0) AS regularMedication
FROM
    s0 LEFT JOIN
    (
        SELECT o.*,T.TB_NUM_QUARTER_1 ,T.TB_NUM_QUARTER_2 ,T.TB_NUM_QUARTER_3 ,T.TB_NUM_QUARTER_4  FROM (
                                                                                                            SELECT
                                                                                                                s1.UP_orgcode AS org_code,
                                                                                                                (SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE ORG_CODE = s1.UP_orgcode) AS org_name,
                                                                                                                SUM(IIF(s2.ID IS NOT NULL, 1, 0)) AS num1,
                                                                                                                SUM(IIF(s3.ID IS NOT NULL, 1, 0)) AS num2,
                                                                                                                SUM(IIF(s4.ID IS NOT NULL, 1, 0)) AS num3
                                                                                                            FROM
                                                                                                                s1
                                                                                                                    LEFT JOIN s2 ON s1.ID = s2.ID
                                                                                                                    LEFT JOIN s3 ON s1.ID = s3.ID
                                                                                                                    LEFT JOIN s4 ON s4.ID = s1.ID
                                                                                                            GROUP BY
                                                                                                                s1.UP_orgcode
                                                                                                        ) o
                                                                                                            LEFT JOIN T_HOME t ON o.org_code = t.ORG_CODE AND t.YEAR = @YEAR
    ) u  on s0.org_code=u.org_code
ORDER BY s0.org_code DESC
END
ELSE
BEGIN
WITH
    S0 AS (
        SELECT
            ORG_sub_CODE as org_code,
            ORG_SUB_NAME as org_name
        FROM
            ZYCONFIG.DBO.SYS_SUB_HOSPITAL
        WHERE
                org_code =@ORG_CODE UNION ALL
        SELECT
            @org_code,
            ( SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE org_code =@org_code )
    ),


    s1 AS (
        SELECT
            t2.MANAGE_ORG_CODE,
            t2.MANAGE_ORG_NAME,
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t2.MANAGE_ORG_CODE), t2.MANAGE_ORG_CODE) AS UP_orgcode,
            t2.IDCARD,
            t1.ID,
						t2.FINAL_STATUS
        FROM
            (SELECT DISTINCT IDCARD, ID FROM T_TB_INFO WHERE IS_DELETE = '0') t1
               INNER  JOIN T_EHR_INFO t2 ON t1.IDCARD = t2.IDCARD
        WHERE
                ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t2.MANAGE_ORG_CODE), t2.MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE)) and  t2.IS_DELETE=0 and t2.FINAL_STATUS !=2
    ),
    s2 AS (
        SELECT ID FROM T_TB_INFO WHERE YEAR(CREATE_DATE) = @YEAR AND ID IN (SELECT ID FROM s1 WHERE FINAL_STATUS=0)
    ),
    s3 AS (
SELECT ID FROM T_TB_INFO WHERE ID IN (SELECT INFO_ID FROM T_TB_VISIT WHERE YEAR(STOP_TREATMENT_DATE) = @PREV_YEAR) AND ID IN (SELECT ID FROM s1) and CLOSED_STATUS=0
    ),
    s4 AS (
SELECT ID FROM T_TB_INFO WHERE ID IN (SELECT INFO_ID FROM T_TB_VISIT WHERE YEAR(STOP_TREATMENT_DATE ) = @PREV_YEAR AND TAKE_RATE >= 90 ) AND ID IN (SELECT ID FROM s1)
    )


SELECT s0.ORG_CODE,
       s0.org_name,
       dbo.Fn_GetPercent(u.num1, (CASE WHEN @QUARTE =1  THEN U.TB_NUM_QUARTER_1
                                       WHEN @QUARTE =2  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2
                                       WHEN @QUARTE=3  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3
                                       WHEN @QUARTE =4 THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3+U.TB_NUM_QUARTER_4

                                       ELSE 0
           END
           ))AS managementRate,
       dbo.Fn_GetPercent( u.num2, u.num3) AS regularMedicationRate,
       ISNULL((CASE WHEN @QUARTE =1  THEN U.TB_NUM_QUARTER_1
                    WHEN @QUARTE =2  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2
                    WHEN @QUARTE=3  THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3
                    WHEN @QUARTE =4 THEN U.TB_NUM_QUARTER_1+U.TB_NUM_QUARTER_2+U.TB_NUM_QUARTER_3+U.TB_NUM_QUARTER_4

                    ELSE 0
           END
                  ),0) AS NumberOfConfirmedCases ,
       ISNULL(u.num1, 0) AS managementNumber,
       ISNULL( u.num2 ,0)AS treatNumber,
       ISNULL(u.num3,0) AS regularMedication
FROM
    s0 LEFT JOIN
    (
        SELECT o.*,T.TB_NUM_QUARTER_1 ,T.TB_NUM_QUARTER_2 ,T.TB_NUM_QUARTER_3 ,T.TB_NUM_QUARTER_4 FROM (
                                                                                                           SELECT
                                                                                                               s1.MANAGE_ORG_CODE AS ORG_CODE,
                                                                                                               s1.MANAGE_ORG_NAME AS org_name,
                                                                                                               SUM(IIF(s2.ID IS NOT NULL, 1, 0)) AS num1,
                                                                                                               SUM(IIF(s3.ID IS NOT NULL, 1, 0)) AS num2,
                                                                                                               SUM(IIF(s4.ID IS NOT NULL, 1, 0)) AS num3
                                                                                                           FROM
                                                                                                               s1
                                                                                                                   LEFT JOIN s2 ON s1.ID = s2.ID
                                                                                                                   LEFT JOIN s3 ON s1.ID = s3.ID
                                                                                                                   LEFT JOIN s4 ON s4.ID = s1.ID
                                                                                                           GROUP BY
                                                                                                               s1.MANAGE_ORG_CODE,
                                                                                                               s1.MANAGE_ORG_NAME
                                                                                                       ) o
                                                                                                           LEFT JOIN T_HOME t ON o.org_code = t.ORG_CODE AND t.YEAR = @YEAR
    ) u
    on s0.org_code=u.org_code
ORDER BY s0.org_code DESC
END;

END;
go

