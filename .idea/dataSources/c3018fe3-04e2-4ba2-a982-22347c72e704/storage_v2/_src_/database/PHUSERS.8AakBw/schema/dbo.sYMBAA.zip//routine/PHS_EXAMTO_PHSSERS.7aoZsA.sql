CREATE PROCEDURE [dbo].[PHS_EXAMTO_PHSSERS]
AS
BEGIN
declare @UPDATE_DATE datetime;
-- 建立远程连接
	IF EXISTS 
	(SELECT 
  name,
  is_data_access_enabled 
FROM sys.servers
WHERE name ='ITSV2'
)
BEGIN
exec sp_dropserver 'ITSV2', 'droplogins '
exec sp_addlinkedserver 'ITSV2', ' ', 'SQLOLEDB ', '192.168.0.234'
exec sp_addlinkedsrvlogin 'ITSV2', 'false ',null, 'sa', 'Zy_123456789' 
END
ELSE 
BEGIN

exec sp_addlinkedserver 'ITSV2', ' ', 'SQLOLEDB ', '192.168.0.235'
exec sp_addlinkedsrvlogin 'ITSV2', 'false ',null, 'sa', 'Zy_123456789' 
END

SET @UPDATE_DATE=  CONVERT(datetime, CONVERT(date,  DATEADD(DAY, -1, GETDATE()))) + CAST('00:05:00' AS datetime);
	PRINT @UPDATE_DATE;
		--1 更新体体检数据 
	UPDATE [dbo].[T_SNR_EXAMINATION_INFO] 
SET 
 [PATIENT_ID]=t1.[odlId],
[ORG_CODE]=t1.[ORG_CODE],
[EHR_ID]=t1.[EHR_ID],
[SYMPTOM_CODE]=t1.[SYMPTOM_CODE],
[SYMPTOM]=t1.[SYMPTOM],
[SYMPTOM_OTHER]=t1.[SYMPTOM_OTHER],
[TEMPERATURE]=t1.[TEMPERATURE],
[PULSE_RATE]=t1.[PULSE_RATE],
[BREATH_RATE]=t1.[BREATH_RATE],
[LEFT_DBP]=t1.[LEFT_DBP],
[LEFT_SBP]=t1.[LEFT_SBP],
[RIGHT_DBP]=t1.[RIGHT_DBP],
[RIGHT_SBP]=t1.[RIGHT_SBP],
[HEIGHT]=t1.[HEIGHT],
[WEIGHT]=t1.[WEIGHT],
[WAISTLINE]=t1.[WAISTLINE],
[BMI]=t1.[BMI],
[HEALTH_ASSESSMENT_CODE]=t1.[HEALTH_ASSESSMENT_CODE],
[HEALTH_ASSESSMENT_NAME]=t1.[HEALTH_ASSESSMENT_NAME],
[CARE_ABILITY_ASSESSMENT_CODE]=t1.[CARE_ABILITY_ASSESSMENT_CODE],
[CARE_ABILITY_ASSESSMENT_NAME]=t1.[CARE_ABILITY_ASSESSMENT_NAME],
[COGNITIVE_FUNCTION_CODE]=t1.[COGNITIVE_FUNCTION_CODE],
[COGNITIVE_FUNCTION_NAME]=t1.[COGNITIVE_FUNCTION_NAME],
[COGNITIVE_FUNCTION_SCORE]=t1.[COGNITIVE_FUNCTION_SCORE],
[EMOTIONAL_STATE_CODE]=t1.[EMOTIONAL_STATE_CODE],
[EMOTIONAL_STATE_NAME]=t1.[EMOTIONAL_STATE_NAME],
[EMOTIONAL_STATE_SCORE]=t1.[EMOTIONAL_STATE_SCORE],
[EXERCISE_FREQUENCY_CODE]=t1.[EXERCISE_FREQUENCY_CODE],
[EXERCISE_FREQUENCY_NAME]=t1.[EXERCISE_FREQUENCY_NAME],
[EVERY_EXERCISE_TIME]=t1.[EVERY_EXERCISE_TIME],
[EXERCISE_TIME]=t1.[EXERCISE_TIME],
[EXERCISE_MODE]=t1.[EXERCISE_MODE],
[EATING_HABITS_CODE]=t1.[EATING_HABITS_CODE],
[EATING_HABITS_NAME]=t1.[EATING_HABITS_NAME],
[SMOKING_STATUS_CODE]=t1.[SMOKING_STATUS_CODE],
[SMOKING_STATUS_NAME]=t1.[SMOKING_STATUS_NAME],
[DAILY_SMOKING]=t1.[DAILY_SMOKING],
[START_SMOKING_AGE]=t1.[START_SMOKING_AGE],
[CESSATION_SMOKING_AGE]=t1.[CESSATION_SMOKING_AGE],
[DRINKING_FREQUENCY_CODE]=t1.[DRINKING_FREQUENCY_CODE],
[DRINKING_FREQUENCY_NAME]=t1.[DRINKING_FREQUENCY_NAME],
[DAILY_DRINKING]=t1.[DAILY_DRINKING],
[QUIT_DRINKING_CODE]=t1.[QUIT_DRINKING_CODE],
[QUIT_DRINKING_NAME]=t1.[QUIT_DRINKING_NAME],
[QUIT_DRINKING_AGE]=t1.[QUIT_DRINKING_AGE],
[START_DRINKING_AGE]=t1.[START_DRINKING_AGE],
[DRUNK_FLAG]=t1.[DRUNK_FLAG],
[DRINKING_TYPE_CODE]=t1.[DRINKING_TYPE_CODE],
[DRINKING_TYPE_NAME]=t1.[DRINKING_TYPE_NAME],
[OCCUPATIONAL_DISEASES_FLAG]=t1.[OCCUPATIONAL_DISEASES_FLAG],
[OCCUPATIONAL_WORK_TYPE]=t1.[OCCUPATIONAL_WORK_TYPE],
[OCCUPATIONAL_WORK_TIME]=t1.[OCCUPATIONAL_WORK_TIME],
[LIP_CODE]=t1.[LIP_CODE],
[LIP_NAME]=t1.[LIP_NAME],
[DENTITION_CODE]=t1.[DENTITION_CODE],
[DENTITION_NAME]=t1.[DENTITION_NAME],
[PHARYNX_CODE]=t1.[PHARYNX_CODE],
[PHARYNX_NAME]=t1.[PHARYNX_NAME],
[VISION_LEFT]=t1.[VISION_LEFT],
[VISION_RIGHT]=t1.[VISION_RIGHT],
[CORRECTED_VISION_LEFT]=t1.[CORRECTED_VISION_LEFT],
[CORRECTED_VISION_RIGHT]=t1.[CORRECTED_VISION_RIGHT],
[HEARING_CODE]=t1.[HEARING_CODE],
[HEARING_NAME]=t1.[HEARING_NAME],
[MOTOR_FUNCTION_CODE]=t1.[MOTOR_FUNCTION_CODE],
[MOTOR_FUNCTION_NAME]=t1.[MOTOR_FUNCTION_NAME],
[FUNDUS_CODE]=t1.[FUNDUS_CODE],
[FUNDUS_NAME]=t1.[FUNDUS_NAME],
[FUNDUS_ABNORMAL]=t1.[FUNDUS_ABNORMAL],
[SKIN_CODE]=t1.[SKIN_CODE],
[SKIN_NAME]=t1.[SKIN_NAME],
[SKIN_ABNORMAL]=t1.[SKIN_ABNORMAL],
[SCLERA_CODE]=t1.[SCLERA_CODE],
[SCLERA_NAME]=t1.[SCLERA_NAME],
[SCLERA_ABNORMAL]=t1.[SCLERA_ABNORMAL],
[LYMPH_NODES_CODE]=t1.[LYMPH_NODES_CODE],
[LYMPH_NODES_NAME]=t1.[LYMPH_NODES_NAME],
[LYMPH_NODES_ABNORMAL]=t1.[LYMPH_NODES_ABNORMAL],
[BARREL_CHEST_CODE]=t1.[BARREL_CHEST_CODE],
[BARREL_CHEST_NAME]=t1.[BARREL_CHEST_NAME],
[BARREL_CHEST_ABNORMAL]=t1.[BARREL_CHEST_ABNORMAL],
[BREATH_SOUNDS_CODE]=t1.[BREATH_SOUNDS_CODE],
[BREATH_SOUNDS_NAME]=t1.[BREATH_SOUNDS_NAME],
[BREATH_SOUNDS_ABNORMAL]=t1.[BREATH_SOUNDS_ABNORMAL],
[RALES_CODE]=t1.[RALES_CODE],
[RALES_NAME]=t1.[RALES_NAME],
[RALES_ABNORMAL]=t1.[RALES_ABNORMAL],
[HEART_RATE]=t1.[HEART_RATE],
[HEART_RHYTHM_CODE]=t1.[HEART_RHYTHM_CODE],
[HEART_RHYTHM_NAME]=t1.[HEART_RHYTHM_NAME],
[HEART_NOISE_CODE]=t1.[HEART_NOISE_CODE],
[HEART_NOISE_NAME]=t1.[HEART_NOISE_NAME],
[HEART_NOISE_ABNORMAL]=t1.[HEART_NOISE_ABNORMAL],
[TENDERNESS_CODE]=t1.[TENDERNESS_CODE],
[TENDERNESS_NAME]=t1.[TENDERNESS_NAME],
[TENDERNESS_ABNORMAL]=t1.[TENDERNESS_ABNORMAL],
[PACKET_BLOCK_CODE]=t1.[PACKET_BLOCK_CODE],
[PACKET_BLOCK_NAME]=t1.[PACKET_BLOCK_NAME],
[PACKET_BLOCK_ABNORMAL]=t1.[PACKET_BLOCK_ABNORMAL],
[HEPATOMEGALY_CODE]=t1.[HEPATOMEGALY_CODE],
[HEPATOMEGALY_NAME]=t1.[HEPATOMEGALY_NAME],
[HEPATOMEGALY_ABNORMAL]=t1.[HEPATOMEGALY_ABNORMAL],
[SPLENOMEGALY_CODE]=t1.[SPLENOMEGALY_CODE],
[SPLENOMEGALY_NAME]=t1.[SPLENOMEGALY_NAME],
[SPLENOMEGALY_ABNORMAL]=t1.[SPLENOMEGALY_ABNORMAL],
[SHIFTING_DULLNESS_CODE]=t1.[SHIFTING_DULLNESS_CODE],
[SHIFTING_DULLNESS_NAME]=t1.[SHIFTING_DULLNESS_NAME],
[SHIFTING_DULLNESS_ABNORMAL]=t1.[SHIFTING_DULLNESS_ABNORMAL],
[LOWER_EXTREMITY_EDEMA_CODE]=t1.[LOWER_EXTREMITY_EDEMA_CODE],
[LOWER_EXTREMITY_EDEMA_NAME]=t1.[LOWER_EXTREMITY_EDEMA_NAME],
[DORSAL_ARTERY_PULSATION_CODE]=t1.[DORSAL_ARTERY_PULSATION_CODE],
[DORSAL_ARTERY_PULSATION_NAME]=t1.[DORSAL_ARTERY_PULSATION_NAME],
[ANAL_DIAGNOSIS_CODE]=t1.[ANAL_DIAGNOSIS_CODE],
[ANAL_DIAGNOSIS_NAME]=t1.[ANAL_DIAGNOSIS_NAME],
[ANAL_DIAGNOSIS_ABNORMAL]=t1.[ANAL_DIAGNOSIS_ABNORMAL],
[BREAST_CODE]=t1.[BREAST_CODE],
[BREAST_NAME]=t1.[BREAST_NAME],
[BREAST_ABNORMAL]=t1.[BREAST_ABNORMAL],
[VULVA_CODE]=t1.[VULVA_CODE],
[VULVA_NAME]=t1.[VULVA_NAME],
[VULVA_ABNORMAL]=t1.[VULVA_ABNORMAL],
[VAGINA_CODE]=t1.[VAGINA_CODE],
[VAGINA_NAME]=t1.[VAGINA_NAME],
[VAGINA_ABNORMAL]=t1.[VAGINA_ABNORMAL],
[CERVIX_CODE]=t1.[CERVIX_CODE],
[CERVIX_NAME]=t1.[CERVIX_NAME],
[CERVIX_ABNORMAL]=t1.[CERVIX_ABNORMAL],
[CORPUS_UTERI_CODE]=t1.[CORPUS_UTERI_CODE],
[CORPUS_UTERI_NAME]=t1.[CORPUS_UTERI_NAME],
[CORPUS_UTERI_ABNORMAL]=t1.[CORPUS_UTERI_ABNORMAL],
[GYNECOLOGICALACCESSORIES_CODE]=t1.[GYNECOLOGICALACCESSORIES_CODE],
[GYNECOLOGICALACCESSORIES_NAME]=t1.[GYNECOLOGICALACCESSORIES_NAME],
[GYNECOLOGICALACCESSORIES_ABNORMAL]=t1.[GYNECOLOGICALACCESSORIES_ABNORMAL],
[OTHER]=t1.[OTHER],
[CEREBROVASCULAR_DISEASE_CODE]=t1.[CEREBROVASCULAR_DISEASE_CODE],
[CEREBROVASCULAR_DISEASE_NAME]=t1.[CEREBROVASCULAR_DISEASE_NAME],
[CEREBROVASCULAR_DISEASE_OTHER]=t1.[CEREBROVASCULAR_DISEASE_OTHER],
[KIDNEY_DISEASE_CODE]=t1.[KIDNEY_DISEASE_CODE],
[KIDNEY_DISEASE_NAME]=t1.[KIDNEY_DISEASE_NAME],
[KIDNEY_DISEASE_OTHER]=t1.[KIDNEY_DISEASE_OTHER],
[EYE_DISEASE_CODE]=t1.[EYE_DISEASE_CODE],
[EYE_DISEASE_NAME]=t1.[EYE_DISEASE_NAME],
[EYE_DISEASE_OTHER]=t1.[EYE_DISEASE_OTHER],
[NERVOUS_DISEASE_CODE]=t1.[NERVOUS_DISEASE_CODE],
[NERVOUS_DISEASE_NAME]=t1.[NERVOUS_DISEASE_NAME],
[NERVOUS_DISEASE_OTHER]=t1.[NERVOUS_DISEASE_OTHER],
[OTHER_DISEASE_CODE]=t1.[OTHER_DISEASE_CODE],
[OTHER_DISEASE_NAME]=t1.[OTHER_DISEASE_NAME],
[OTHER_DISEASE_OTHER]=t1.[OTHER_DISEASE_OTHER],
[HEALTH_EVALUATION_CODE]=t1.[HEALTH_EVALUATION_CODE],
[HEALTH_EVALUATION_NAME]=t1.[HEALTH_EVALUATION_NAME],
[EVALUATION_DESCRIBE]=t1.[EVALUATION_DESCRIBE],
[HEALTH_GUIDE_CODE]=t1.[HEALTH_GUIDE_CODE],
[HEALTH_GUIDE_NAME]=t1.[HEALTH_GUIDE_NAME],
[CHRONIC_DISEASE_CODE]=t1.[CHRONIC_DISEASE_CODE],
[CHRONIC_DISEASE_NAME]=t1.[CHRONIC_DISEASE_NAME],
[REGISTER_TYPE_CODE]=t1.[REGISTER_TYPE_CODE],
[REGISTER_TYPE_NAME]=t1.[REGISTER_TYPE_NAME],
[REGISTER_TYPE_OTHER]=t1.[REGISTER_TYPE_OTHER],
[WEIGHT_LOSS_GOALS]=t1.[WEIGHT_LOSS_GOALS],
[VACCINE_CODE]=t1.[VACCINE_CODE],
[VACCINE_NAME]=t1.[VACCINE_NAME],
[ADVICE]=t1.[ADVICE],
[VALID_STATUS]=t1.[VALID_STATUS],
[INQUIRY_DATE]=t1.[INQUIRY_DATE],
[INQUIRY_DOC_ID]=t1.[INQUIRY_DOC_ID],
[INQUIRY_DOC_NAME]=t1.[INQUIRY_DOC_NAME],
[UPDATE_DATE]=t1.[UPDATE_DATE],
[UPDATE_ID]=t1.[UPDATE_ID],
[UPDATE_NAME]=t1.[UPDATE_NAME],
[INSPECTION_DATE]=t1.[INSPECTION_DATE],
[INSPECTION_DOC_ID]=t1.[INSPECTION_DOC_ID],
[INSPECTION_DOC_NAME]=t1.[INSPECTION_DOC_NAME],
[OTHER_DISEASE_FLAG]=t1.[OTHER_DISEASE_FLAG],
[INSPECTION_CREATE_STATUS]=t1.[INSPECTION_CREATE_STATUS],
[INSPECTION_CREATE_DATE]=t1.[INSPECTION_CREATE_DATE],
[MISSING_LEFT_UP]=t1.[MISSING_LEFT_UP],
[MISSING_LEFT_DOWN]=t1.[MISSING_LEFT_DOWN],
[MISSING_RIGHT_UP]=t1.[MISSING_RIGHT_UP],
[MISSING_RIGHT_DOWN]=t1.[MISSING_RIGHT_DOWN],
[CARDIOVASCULAR_DISEASE_CODE]=t1.[CARDIOVASCULAR_DISEASE_CODE],
[CARDIOVASCULAR_DISEASE_NAME]=t1.[CARDIOVASCULAR_DISEASE_NAME],
[CARDIOVASCULAR_DISEASE_OTHER]=t1.[CARDIOVASCULAR_DISEASE_OTHER],
[CARIES_LEFT_UP]=t1.[CARIES_LEFT_UP],
[CARIES_LEFT_DOWN]=t1.[CARIES_LEFT_DOWN],
[CARIES_RIGHT_UP]=t1.[CARIES_RIGHT_UP],
[CARIES_RIGHT_DOWN]=t1.[CARIES_RIGHT_DOWN],
[DENTURE_LEFT_UP]=t1.[DENTURE_LEFT_UP],
[DENTURE_LEFT_DOWN]=t1.[DENTURE_LEFT_DOWN],
[DENTURE_RIGHT_UP]=t1.[DENTURE_RIGHT_UP],
[DENTURE_RIGHT_DOWN]=t1.[DENTURE_RIGHT_DOWN],
[IDCARD]=t1.[IDCARD],
[SOURCE]=t1.[SOURCE],
[SOURCE_NAME] =t1.[SOURCE_NAME] 

FROM
(
	SELECT
		[odlId],
		[org_code],
		t2.ID as [EHR_ID]  ,
		[symptom_code],
		[symptom],
		[symptom_other],
		[temperature],
		[pulse_rate],
		[breath_rate],
		[left_dbp],
		[left_sbp],
		[right_dbp],
		[right_sbp],
		[height],
		[weight],
		[waistline],
		[bmi],
		[health_assessment_code],
		[health_assessment_name],
		[care_ability_assessment_code],
		[care_ability_assessment_name],
		[cognitive_function_code],
		[cognitive_function_name],
		[cognitive_function_score],
		[emotional_state_code],
		[emotional_state_name],
		[emotional_state_score],
		[exercise_frequency_code],
		[exercise_frequency_name],
		[every_exercise_time],
		[exercise_time],
		[exercise_mode],
		[eating_habits_code],
		[eating_habits_name],
		[smoking_status_code],
		[smoking_status_name],
		[daily_smoking],
		[start_smoking_age],
		[cessation_smoking_age],
		[drinking_frequency_code],
		[drinking_frequency_name],
		[daily_drinking],
		ISNULL( [quit_drinking_code], '' ) AS QUIT_DRINKING_CODE,
		[quit_drinking_name],
		[quit_drinking_age],
		[start_drinking_age],
		ISNULL( [drunk_flag], '' ) AS drunk_flag,
		[drinking_type_code],
		[drinking_type_name],
		[occupational_diseases_flag],
		[occupational_work_type],
		[occupational_work_time],
		[lip_code],
		[lip_name],
		[dentition_code],
		[dentition_name],
		[pharynx_code],
		[pharynx_name],
		[vision_left],
		[vision_right],
		[corrected_vision_left],
		[corrected_vision_right],
		[hearing_code],
		[hearing_name],
		[motor_function_code],
		[motor_function_name],
		ISNULL( [fundus_code], '' ) AS [fundus_code],
		[fundus_name],
		[fundus_abnormal],
		[skin_code],
		[skin_name],
		[skin_abnormal],
		[sclera_code],
		[sclera_name],
		[sclera_abnormal],
		[lymph_nodes_code],
		[lymph_nodes_name],
		[lymph_nodes_abnormal],
		[barrel_chest_code],
		[barrel_chest_name],
		[barrel_chest_abnormal],
		ISNULL( [breath_sounds_code], '' ) AS [breath_sounds_code],
		[breath_sounds_name],
		[breath_sounds_abnormal],
		[rales_code],
		[rales_name],
		[rales_abnormal],
		[heart_rate],
		[heart_rhythm_code],
		[heart_rhythm_name],
		ISNULL( [heart_noise_code], '' ) AS [heart_noise_code],
		[heart_noise_name],
		[heart_noise_abnormal],
		[tenderness_code],
		[tenderness_name],
		[tenderness_abnormal],
		ISNULL( [packet_block_code], '' ) AS [packet_block_code],
		[packet_block_name],
		[packet_block_abnormal],
		ISNULL( [hepatomegaly_code], '' ) AS [hepatomegaly_code],
		[hepatomegaly_name],
		[hepatomegaly_abnormal],
		ISNULL( [splenomegaly_code], '' ) [splenomegaly_code],
		[splenomegaly_name],
		[splenomegaly_abnormal],
		ISNULL( [shifting_dullness_code], '' ) AS [shifting_dullness_code],
		[shifting_dullness_name],
		[shifting_dullness_abnormal],
		[lower_extremity_edema_code],
		[lower_extremity_edema_name],
		[dorsal_artery_pulsation_code],
		[dorsal_artery_pulsation_name],
		[anal_diagnosis_code],
		[anal_diagnosis_name],
		[anal_diagnosis_abnormal],
		[breast_code],
		[breast_name],
		[breast_abnormal],
		ISNULL( [vulva_code], '' ) AS [vulva_code],
		[vulva_name],
		[vulva_abnormal],
		ISNULL( [vagina_code], '' ) AS [vagina_code],
		[vagina_name],
		[vagina_abnormal],
		ISNULL( [cervix_code], '' ) AS [cervix_code],
		[cervix_name],
		[cervix_abnormal],
		ISNULL( [corpus_uteri_code], '' ) AS [corpus_uteri_code],
		[corpus_uteri_name],
		[corpus_uteri_abnormal],
		ISNULL( gynecologicalaccessories_code, '' ) AS [gynecologicalaccessories_code],
		[gynecologicalaccessories_name],
		[gynecologicalaccessories_abnormal],
		[other],
		[cerebrovascular_disease_code],
		[cerebrovascular_disease_name],
		[cerebrovascular_disease_other],
		[kidney_disease_code],
		[kidney_disease_name],
		[kidney_disease_other],
		[eye_disease_code],
		[eye_disease_name],
		[eye_disease_other],
		ISNULL( nervous_disease_code, '' ) AS nervous_disease_code,
		[nervous_disease_name],
		[nervous_disease_other],
		[other_disease_code],
		[other_disease_name],
		[other_disease_other],
		ISNULL( [health_evaluation_code], '' ) AS [health_evaluation_code],
		[health_evaluation_name],
		[evaluation_describe],
		[health_guide_code],
		[health_guide_name],
		[chronic_disease_code],
		[chronic_disease_name],
		[register_type_code],
		[register_type_name],
		[register_type_other],
		[weight_loss_goals],
		[vaccine_code],
		[vaccine_name],
		[advice],
		[valid_status],
		[inquiry_date],
		[inquiry_doc_id],
		[inquiry_doc_name],
		[update_date],
		[update_id],
		[update_name],
		[inspection_date],
		[inspection_doc_id],
		[inspection_doc_name],
		ISNULL( other_disease_flag, '' ) AS [other_disease_flag],
		[inspection_create_status],
		[inspection_create_date],
		[missing_left_up],
		[missing_left_down],
		[missing_right_up],
		[missing_right_down],
		[cardiovascular_disease_code],
		[cardiovascular_disease_name],
		[cardiovascular_disease_other],
		[caries_left_up],
		[caries_left_down],
		[caries_right_up],
		[caries_right_down],
		[denture_left_up],
		[denture_left_down],
		[denture_right_up],
		[denture_right_down],
		[id_card] as IDCARD,
		'4' AS [SOURCE],
		'第三方接入' AS [SOURCE_NAME] 
	FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
	WHERE
		t1.UPDATE_date >= @UPDATE_DATE
	AND t1.[odlId]  IN ( SELECT PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) 
) t1 
WHERE[PATIENT_ID]=t1.[odlId]
	
	
	
		PRINT 'T_SNR_EXAMINATION_INFO 体检主表 更新完成' 

--2 插入没有体检人的数据
	INSERT INTO T_SNR_EXAMINATION_INFO (
	[PATIENT_ID],
	[ORG_CODE],
	[EHR_ID],
	[SYMPTOM_CODE],
	[SYMPTOM],
	[SYMPTOM_OTHER],
	[TEMPERATURE],
	[PULSE_RATE],
	[BREATH_RATE],
	[LEFT_DBP],
	[LEFT_SBP],
	[RIGHT_DBP],
	[RIGHT_SBP],
	[HEIGHT],
	[WEIGHT],
	[WAISTLINE],
	[BMI],
	[HEALTH_ASSESSMENT_CODE],
	[HEALTH_ASSESSMENT_NAME],
	[CARE_ABILITY_ASSESSMENT_CODE],
	[CARE_ABILITY_ASSESSMENT_NAME],
	[COGNITIVE_FUNCTION_CODE],
	[COGNITIVE_FUNCTION_NAME],
	[COGNITIVE_FUNCTION_SCORE],
	[EMOTIONAL_STATE_CODE],
	[EMOTIONAL_STATE_NAME],
	[EMOTIONAL_STATE_SCORE],
	[EXERCISE_FREQUENCY_CODE],
	[EXERCISE_FREQUENCY_NAME],
	[EVERY_EXERCISE_TIME],
	[EXERCISE_TIME],
	[EXERCISE_MODE],
	[EATING_HABITS_CODE],
	[EATING_HABITS_NAME],
	[SMOKING_STATUS_CODE],
	[SMOKING_STATUS_NAME],
	[DAILY_SMOKING],
	[START_SMOKING_AGE],
	[CESSATION_SMOKING_AGE],
	[DRINKING_FREQUENCY_CODE],
	[DRINKING_FREQUENCY_NAME],
	[DAILY_DRINKING],
	[QUIT_DRINKING_CODE],
	[QUIT_DRINKING_NAME],
	[QUIT_DRINKING_AGE],
	[START_DRINKING_AGE],
	[DRUNK_FLAG],
	[DRINKING_TYPE_CODE],
	[DRINKING_TYPE_NAME],
	[OCCUPATIONAL_DISEASES_FLAG],
	[OCCUPATIONAL_WORK_TYPE],
	[OCCUPATIONAL_WORK_TIME],
	[LIP_CODE],
	[LIP_NAME],
	[DENTITION_CODE],
	[DENTITION_NAME],
	[PHARYNX_CODE],
	[PHARYNX_NAME],
	[VISION_LEFT],
	[VISION_RIGHT],
	[CORRECTED_VISION_LEFT],
	[CORRECTED_VISION_RIGHT],
	[HEARING_CODE],
	[HEARING_NAME],
	[MOTOR_FUNCTION_CODE],
	[MOTOR_FUNCTION_NAME],
	[FUNDUS_CODE],
	[FUNDUS_NAME],
	[FUNDUS_ABNORMAL],
	[SKIN_CODE],
	[SKIN_NAME],
	[SKIN_ABNORMAL],
	[SCLERA_CODE],
	[SCLERA_NAME],
	[SCLERA_ABNORMAL],
	[LYMPH_NODES_CODE],
	[LYMPH_NODES_NAME],
	[LYMPH_NODES_ABNORMAL],
	[BARREL_CHEST_CODE],
	[BARREL_CHEST_NAME],
	[BARREL_CHEST_ABNORMAL],
	[BREATH_SOUNDS_CODE],
	[BREATH_SOUNDS_NAME],
	[BREATH_SOUNDS_ABNORMAL],
	[RALES_CODE],
	[RALES_NAME],
	[RALES_ABNORMAL],
	[HEART_RATE],
	[HEART_RHYTHM_CODE],
	[HEART_RHYTHM_NAME],
	[HEART_NOISE_CODE],
	[HEART_NOISE_NAME],
	[HEART_NOISE_ABNORMAL],
	[TENDERNESS_CODE],
	[TENDERNESS_NAME],
	[TENDERNESS_ABNORMAL],
	[PACKET_BLOCK_CODE],
	[PACKET_BLOCK_NAME],
	[PACKET_BLOCK_ABNORMAL],
	[HEPATOMEGALY_CODE],
	[HEPATOMEGALY_NAME],
	[HEPATOMEGALY_ABNORMAL],
	[SPLENOMEGALY_CODE],
	[SPLENOMEGALY_NAME],
	[SPLENOMEGALY_ABNORMAL],
	[SHIFTING_DULLNESS_CODE],
	[SHIFTING_DULLNESS_NAME],
	[SHIFTING_DULLNESS_ABNORMAL],
	[LOWER_EXTREMITY_EDEMA_CODE],
	[LOWER_EXTREMITY_EDEMA_NAME],
	[DORSAL_ARTERY_PULSATION_CODE],
	[DORSAL_ARTERY_PULSATION_NAME],
	[ANAL_DIAGNOSIS_CODE],
	[ANAL_DIAGNOSIS_NAME],
	[ANAL_DIAGNOSIS_ABNORMAL],
	[BREAST_CODE],
	[BREAST_NAME],
	[BREAST_ABNORMAL],
	[VULVA_CODE],
	[VULVA_NAME],
	[VULVA_ABNORMAL],
	[VAGINA_CODE],
	[VAGINA_NAME],
	[VAGINA_ABNORMAL],
	[CERVIX_CODE],
	[CERVIX_NAME],
	[CERVIX_ABNORMAL],
	[CORPUS_UTERI_CODE],
	[CORPUS_UTERI_NAME],
	[CORPUS_UTERI_ABNORMAL],
	[GYNECOLOGICALACCESSORIES_CODE],
	[GYNECOLOGICALACCESSORIES_NAME],
	[GYNECOLOGICALACCESSORIES_ABNORMAL],
	[OTHER],
	[CEREBROVASCULAR_DISEASE_CODE],
	[CEREBROVASCULAR_DISEASE_NAME],
	[CEREBROVASCULAR_DISEASE_OTHER],
	[KIDNEY_DISEASE_CODE],
	[KIDNEY_DISEASE_NAME],
	[KIDNEY_DISEASE_OTHER],
	[EYE_DISEASE_CODE],
	[EYE_DISEASE_NAME],
	[EYE_DISEASE_OTHER],
	[NERVOUS_DISEASE_CODE],
	[NERVOUS_DISEASE_NAME],
	[NERVOUS_DISEASE_OTHER],
	[OTHER_DISEASE_CODE],
	[OTHER_DISEASE_NAME],
	[OTHER_DISEASE_OTHER],
	[HEALTH_EVALUATION_CODE],
	[HEALTH_EVALUATION_NAME],
	[EVALUATION_DESCRIBE],
	[HEALTH_GUIDE_CODE],
	[HEALTH_GUIDE_NAME],
	[CHRONIC_DISEASE_CODE],
	[CHRONIC_DISEASE_NAME],
	[REGISTER_TYPE_CODE],
	[REGISTER_TYPE_NAME],
	[REGISTER_TYPE_OTHER],
	[WEIGHT_LOSS_GOALS],
	[VACCINE_CODE],
	[VACCINE_NAME],
	[ADVICE],
	[VALID_STATUS],
	[INQUIRY_DATE],
	[INQUIRY_DOC_ID],
	[INQUIRY_DOC_NAME],
	[UPDATE_DATE],
	[UPDATE_ID],
	[UPDATE_NAME],
	[INSPECTION_DATE],
	[INSPECTION_DOC_ID],
	[INSPECTION_DOC_NAME],
	[OTHER_DISEASE_FLAG],
	[INSPECTION_CREATE_STATUS],
	[INSPECTION_CREATE_DATE],
	[MISSING_LEFT_UP],
	[MISSING_LEFT_DOWN],
	[MISSING_RIGHT_UP],
	[MISSING_RIGHT_DOWN],
	[CARDIOVASCULAR_DISEASE_CODE],
	[CARDIOVASCULAR_DISEASE_NAME],
	[CARDIOVASCULAR_DISEASE_OTHER],
	[CARIES_LEFT_UP],
	[CARIES_LEFT_DOWN],
	[CARIES_RIGHT_UP],
	[CARIES_RIGHT_DOWN],
	[DENTURE_LEFT_UP],
	[DENTURE_LEFT_DOWN],
	[DENTURE_RIGHT_UP],
	[DENTURE_RIGHT_DOWN],
	[IDCARD],
	[SOURCE],
	[SOURCE_NAME] 
	) (
	SELECT
		[odlId],
		[org_code],
		t2.ID ,
		[symptom_code],
		[symptom],
		[symptom_other],
		[temperature],
		[pulse_rate],
		[breath_rate],
		[left_dbp],
		[left_sbp],
		[right_dbp],
		[right_sbp],
		[height],
		[weight],
		[waistline],
		[bmi],
		[health_assessment_code],
		[health_assessment_name],
		[care_ability_assessment_code],
		[care_ability_assessment_name],
		[cognitive_function_code],
		[cognitive_function_name],
		[cognitive_function_score],
		[emotional_state_code],
		[emotional_state_name],
		[emotional_state_score],
		[exercise_frequency_code],
		[exercise_frequency_name],
		[every_exercise_time],
		[exercise_time],
		[exercise_mode],
		[eating_habits_code],
		[eating_habits_name],
		[smoking_status_code],
		[smoking_status_name],
		[daily_smoking],
		[start_smoking_age],
		[cessation_smoking_age],
		[drinking_frequency_code],
		[drinking_frequency_name],
		[daily_drinking],
		ISNULL( [quit_drinking_code], '' ) AS QUIT_DRINKING_COD,
		[quit_drinking_name],
		[quit_drinking_age],
		[start_drinking_age],
		ISNULL( [drunk_flag], '' ) AS drunk_flag,
		[drinking_type_code],
		[drinking_type_name],
		[occupational_diseases_flag],
		[occupational_work_type],
		[occupational_work_time],
		[lip_code],
		[lip_name],
		[dentition_code],
		[dentition_name],
		[pharynx_code],
		[pharynx_name],
		[vision_left],
		[vision_right],
		[corrected_vision_left],
		[corrected_vision_right],
		[hearing_code],
		[hearing_name],
		[motor_function_code],
		[motor_function_name],
		ISNULL( [fundus_code], '' ) AS [fundus_code],
		[fundus_name],
		[fundus_abnormal],
		[skin_code],
		[skin_name],
		[skin_abnormal],
		[sclera_code],
		[sclera_name],
		[sclera_abnormal],
		[lymph_nodes_code],
		[lymph_nodes_name],
		[lymph_nodes_abnormal],
		[barrel_chest_code],
		[barrel_chest_name],
		[barrel_chest_abnormal],
		ISNULL( [breath_sounds_code], '' ) AS [breath_sounds_code],
		[breath_sounds_name],
		[breath_sounds_abnormal],
		[rales_code],
		[rales_name],
		[rales_abnormal],
		[heart_rate],
		[heart_rhythm_code],
		[heart_rhythm_name],
		ISNULL( [heart_noise_code], '' ) AS [heart_noise_code],
		[heart_noise_name],
		[heart_noise_abnormal],
		[tenderness_code],
		[tenderness_name],
		[tenderness_abnormal],
		ISNULL( [packet_block_code], '' ) AS [packet_block_code],
		[packet_block_name],
		[packet_block_abnormal],
		ISNULL( [hepatomegaly_code], '' ) AS [hepatomegaly_code],
		[hepatomegaly_name],
		[hepatomegaly_abnormal],
		ISNULL( [splenomegaly_code], '' ) [splenomegaly_code],
		[splenomegaly_name],
		[splenomegaly_abnormal],
		ISNULL( [shifting_dullness_code], '' ) AS [shifting_dullness_code],
		[shifting_dullness_name],
		[shifting_dullness_abnormal],
		[lower_extremity_edema_code],
		[lower_extremity_edema_name],
		[dorsal_artery_pulsation_code],
		[dorsal_artery_pulsation_name],
		[anal_diagnosis_code],
		[anal_diagnosis_name],
		[anal_diagnosis_abnormal],
		[breast_code],
		[breast_name],
		[breast_abnormal],
		ISNULL( [vulva_code], '' ) AS [vulva_code],
		[vulva_name],
		[vulva_abnormal],
		ISNULL( [vagina_code], '' ) AS [vagina_code],
		[vagina_name],
		[vagina_abnormal],
		ISNULL( [cervix_code], '' ) AS [cervix_code],
		[cervix_name],
		[cervix_abnormal],
		ISNULL( [corpus_uteri_code], '' ) AS [corpus_uteri_code],
		[corpus_uteri_name],
		[corpus_uteri_abnormal],
		ISNULL( gynecologicalaccessories_code, '' ) AS [gynecologicalaccessories_code],
		[gynecologicalaccessories_name],
		[gynecologicalaccessories_abnormal],
		[other],
		[cerebrovascular_disease_code],
		[cerebrovascular_disease_name],
		[cerebrovascular_disease_other],
		[kidney_disease_code],
		[kidney_disease_name],
		[kidney_disease_other],
		[eye_disease_code],
		[eye_disease_name],
		[eye_disease_other],
		ISNULL( nervous_disease_code, '' ) AS nervous_disease_code,
		[nervous_disease_name],
		[nervous_disease_other],
		[other_disease_code],
		[other_disease_name],
		[other_disease_other],
		ISNULL( [health_evaluation_code], '' ) AS [health_evaluation_code],
		[health_evaluation_name],
		[evaluation_describe],
		[health_guide_code],
		[health_guide_name],
		[chronic_disease_code],
		[chronic_disease_name],
		[register_type_code],
		[register_type_name],
		[register_type_other],
		[weight_loss_goals],
		[vaccine_code],
		[vaccine_name],
		[advice],
		[valid_status],
		[inquiry_date],
		[inquiry_doc_id],
		[inquiry_doc_name],
		[update_date],
		[update_id],
		[update_name],
		[inspection_date],
		[inspection_doc_id],
		[inspection_doc_name],
		ISNULL( other_disease_flag, '' ) AS [other_disease_flag],
		[inspection_create_status],
		[inspection_create_date],
		[missing_left_up],
		[missing_left_down],
		[missing_right_up],
		[missing_right_down],
		[cardiovascular_disease_code],
		[cardiovascular_disease_name],
		[cardiovascular_disease_other],
		[caries_left_up],
		[caries_left_down],
		[caries_right_up],
		[caries_right_down],
		[denture_left_up],
		[denture_left_down],
		[denture_right_up],
		[denture_right_down],
		[id_card],
		'3' AS [SOURCE],
		'老年人体检' AS [SOURCE_NAME] 
	FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
	WHERE
		t1.UPDATE_date >= @UPDATE_DATE
	AND t1.[odlId] NOT IN ( SELECT PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) 
	);
		PRINT 'T_SNR_EXAMINATION_INFO 体检主表 插入完成' 
	

		
		
		--删除更新数据 老年人生活自理能力评估表
		
		DELETE  FROM [dbo].[T_SNR_EXAMINATION_ASSESS]
		WHERE  [EXAMINATION_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		
				PRINT 'T_SNR_EXAMINATION_ASSESS 更新数据删除 完成' 
		-- 老年人生活自理能力评估表 插入
		INSERT INTO [dbo].[T_SNR_EXAMINATION_ASSESS] ( [MEAL_SCORE], [FRESHEN_SCORE], [DRESSING_SCORE], [TOILET_SCORE], [ACTIVITY_SCORE], [TOTAL_SCORE], [VALID_STATUS], [EXAMINATION_ID] ) SELECT
s1.[meal_score],
s1.[freshen_score],
s1.[dressing_score],
s1.[toilet_score],
s1.[activity_score],
s1.[total_score],
s1.[valid_status],
s2.id 
FROM
	ITSV2.PHS.dbo.V_SNR_EXAMINATION_ASSESS S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.OLDID= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_ID FROM T_SNR_EXAMINATION_ASSESS )
	
		PRINT 'T_SNR_EXAMINATION_ASSESS  老年人生活自理能力评估表 插入完成'
		 
		
		
		--删除更新数据 老年人抑郁量表
		
		DELETE  FROM [dbo].[T_SNR_EXAMINATION_DEPRESSION]
		WHERE  [EXAMINATION_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		
			PRINT 'T_SNR_EXAMINATION_DEPRESSION  老年人抑郁量表  删除完成'
	-- 老年人抑郁量表 插入
	
	INSERT INTO [dbo].[T_SNR_EXAMINATION_DEPRESSION] (
	[EXAMINATION_ID],
	[ORG_CODE],
	[ID_CARD],
	[NAME],
	[ADDRESS],
	[PHONE],
	[QUESTION_1],
	[QUESTION_2],
	[QUESTION_3],
	[QUESTION_4],
	[QUESTION_5],
	[QUESTION_6],
	[QUESTION_7],
	[QUESTION_8],
	[QUESTION_9],
	[QUESTION_10],
	[QUESTION_11],
	[QUESTION_12],
	[QUESTION_13],
	[QUESTION_14],
	[QUESTION_15],
	[QUESTION_16],
	[QUESTION_17],
	[QUESTION_18],
	[QUESTION_19],
	[QUESTION_20],
	[QUESTION_21],
	[QUESTION_22],
	[QUESTION_23],
	[QUESTION_24],
	[QUESTION_25],
	[QUESTION_26],
	[QUESTION_27],
	[QUESTION_28],
	[QUESTION_29],
	[QUESTION_30],
	[TOTAL],
	[CREATE_DATE],
	[IS_DELETE] 
) SELECT
s2.id ,
[org_code],
[id_card],
[name],
[address],
[phone],
[question_1],
[question_2],
[question_3],
[question_4],
[question_5],
[question_6],
[question_7],
[question_8],
[question_9],
[question_10],
[question_11],
[question_12],
[question_13],
[question_14],
[question_15],
[question_16],
[question_17],
[question_18],
[question_19],
[question_20],
[question_21],
[question_22],
[question_23],
[question_24],
[question_25],
[question_26],
[question_27],
[question_28],
[question_29],
[question_30],
[total],
[create_date],
[is_delete] 
FROM
	ITSV2.PHS.dbo.v_snr_examination_depression S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.OLDID= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_ID FROM T_SNR_EXAMINATION_DEPRESSION )
	
		PRINT 'T_SNR_EXAMINATION_DEPRESSION  老年人抑郁量表  插入完成'
		
		
		--
	
		--删除更新数据 老年体检用药表
		
		DELETE  FROM [dbo].[T_SNR_EXAMINATION_DRUG]
		WHERE  [EXAMINATION_INFO_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
	
			PRINT 'T_SNR_EXAMINATION_DRUG  老年体检用药表更新  删除完成'
			
			
			INSERT INTO [dbo].[T_SNR_EXAMINATION_DRUG] ( [EXAMINATION_INFO_ID], [DRUG_ID], [DRUG_NAME], [USE_WAY_CODE], [USE_WAY_NAME], [FREQUENCY_CODE], [FREQUENCY_NAME], [SINGLE_DOSE], [DOSAGE_UNIT], [DAILY_DOSE], [DRUG_DATE], [COMPLIANCE_CODE], [COMPLIANCE_NAME], [VALID_STATUS]) 
			
	SELECT 
s2.id, [drug_id], [drug_name], [use_way_code], [use_way_name], [frequency_code], [frequency_name], [single_dose], [dosage_unit], [daily_dose], [drug_date], [compliance_code], [compliance_name], [valid_status]


	
	FROM
	ITSV2.PHS.dbo.v_snr_examination_drug S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.examination_info_id= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_INFO_ID FROM T_SNR_EXAMINATION_DRUG )
	
	PRINT 'T_SNR_EXAMINATION_DRUG  老年体检用药表更新  插入完成'
	
	-- 检职业暴露信息 删除
	
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_EXPOSURE]
		WHERE  [EXAMINATION_INFO_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
	
			PRINT 'T_SNR_EXAMINATION_EXPOSUR  检职业暴露信息  删除完成'
			
				INSERT INTO [dbo].[T_SNR_EXAMINATION_EXPOSURE] ( [EXAMINATION_INFO_ID],[risk_type_code], [risk_type_name], [risk_name], [protective_measures_flag], [protective_measures], [valid_status]

) 
			
	SELECT 
s2.id, [risk_type_code], [risk_type_name], [risk_name], [protective_measures_flag], [protective_measures], [valid_status]



	FROM
	ITSV2.PHS.dbo.v_snr_examination_EXPOSURE S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.examination_info_id= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_INFO_ID FROM T_SNR_EXAMINATION_EXPOSURE)
	
	PRINT 'T_SNR_EXAMINATION_EXPOSUR  检职业暴露信息  插入完成'
	
	
	-- 体检家族史 删除
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_FAMILY]
		WHERE  [EXAMINATION_INFO_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
			
			
			PRINT 'T_SNR_EXAMINATION_FAMILY  体检家族史 删除 删除完成'
			
			
			INSERT INTO [dbo].[T_SNR_EXAMINATION_FAMILY] ( [EXAMINATION_INFO_ID],[build_bed_date], [remove_bed_date], [reason], [build_org_code], [build_org_name], [record_num], [valid_status]

) 
			
	SELECT 
s2.id , [build_bed_date], [remove_bed_date], [reason], [build_org_code], [build_org_name], [record_num], [valid_status]


	FROM
	ITSV2.PHS.dbo.v_snr_examination_family S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.examination_info_id= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_INFO_ID FROM T_SNR_EXAMINATION_FAMILY )
	
	PRINT 'T_SNR_EXAMINATION_FAMILY  体检家族史 插入完成'
	
	
	
		-- 体检住院信息表 删除
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_IP]
		WHERE  [EXAMINATION_INFO_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		PRINT 'T_SNR_EXAMINATION_IP  体检住院信息表 删除'
		
			INSERT INTO [dbo].[T_SNR_EXAMINATION_IP] ( [EXAMINATION_INFO_ID],[admission_date], [leave_date], [reason], [admission_org_code], [admission_org_name], [record_num], [valid_status], [org_code]

) 
			
	SELECT 
s2.id ,[admission_date], [leave_date], [reason], [admission_org_code], [admission_org_name], [record_num], [valid_status], [org_code] 
	FROM
	ITSV2.PHS.dbo.v_snr_examination_ip S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.examination_info_id= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_INFO_ID FROM t_snr_examination_ip )
		
			PRINT 'T_SNR_EXAMINATION_IP  体检住院信息表 插入完成';
			
			
			
				-- 体检住院信息表 删除
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_LIS]
		WHERE  [EXAMINATION_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		PRINT 'T_SNR_EXAMINATION_LIS  体检检验 删除'
			
				INSERT INTO [dbo].[T_SNR_EXAMINATION_LIS]( [org_code], EXAMINATION_ID ,  [hemoglobin], [hemoglobin_unit], [hemoglobin_ref], [hemoglobin_flag], [hemameba], [hemameba_unit], [hemameba_ref], [hemameba_flag], [platelet], [platelet_unit], [platelet_ref], [platelet_flag], [blood_other], [urine_protein_code], [urine_protein_name], [urine_protein_volume], [urine_protein_unit], [urine_protein_ref], [urine_protein_flag], [urine_sugar_code], [urine_sugar_name], [urine_sugar_volume], [urine_sugar_unit], [urine_sugar_ref], [urine_sugar_flag], [urinary_ketone_bodies_code], [urinary_ketone_bodies_name], [urinary_ketone_bodies_flag], [urinary_occult_blood_code], [urinary_occult_blood_name], [urinary_occult_blood_flag], [urine_specific_gravity], [urine_specific_gravity_flag], [urine_ph], [urine_ph_flag], [urine_routine_other], [fasting_blood_glucose], [fasting_blood_glucose_unit], [fasting_blood_glucose_ref], [fasting_blood_glucose_flag], [two_hours_glucose], [two_hours_glucose_unit], [two_hours_glucose_ref], [two_hours_glucose_flag], [microalbuminuria], [microalbuminuria_unit], [microalbuminuria_ref], [microalbuminuria_flag], [fecal_occult_blood_code], [fecal_occult_blood_name], [glycosylated_hemoglobin], [glycosylated_hemoglobin_unit], [glycosylated_hemoglobin_ref], [glycosylated_hemoglobin_flag], [hbsag_code], [hbsag_name], [hbveag_code], [hbveag_name], [hbsab_code], [hbsab_name], [hbseab_code], [hbseab_name], [hbcab_code], [hbcab_name], [sgpt], [sgpt_unit], [sgpt_ref], [sgpt_flag], [sgot], [sgot_unit], [sgot_ref], [sgot_flag], [albumin], [albumin_unit], [albumin_ref], [albumin_flag], [bilirubin_total], [bilirubin_total_unit], [bilirubin_total_ref], [bilirubin_total_flag], [conjugated_bilirubin], [conjugated_bilirubin_unit], [conjugated_bilirubin_ref], [conjugated_bilirubin_flag], [scr], [scr_unit], [scr_ref], [scr_flag], [blood_urea], [blood_urea_unit], [blood_urea_ref], [blood_urea_flag], [blood_potassium_concentratio], [blood_potassium_concentratio_unit], [blood_potassium_concentratio_ref], [blood_potassium_concentratio_flag], [blood_sodium_concentration], [blood_sodium_concentration_unit], [blood_sodium_concentration_ref], [blood_sodium_concentration_flag], [cholesterol_total], [cholesterol_total_unit], [cholesterol_total_ref], [cholesterol_total_flag], [triglyceride], [triglyceride_unit], [triglyceride_ref], [triglyceride_flag], [serum_low_density], [serum_low_density_unit], [serum_low_density_ref], [serum_low_density_flag], [serum_high_density], [serum_high_density_unit], [serum_high_density_ref], [serum_high_density_flag], [cea_concentration], [cea_concentration_unit], [cea_concentration_ref], [cea_concentration_flag], [blood_examine_doc_id], [blood_examine_doc_name], [blood_verify_doc_id], [blood_verify_doc_name], [blood_examine_date], [rummage_examine_doc_id], [rummage_examine_doc_name], [rummage_verify_doc_id], [rummage_verify_doc_name], [rummage_examine_date], [urine_examine_doc_id], [urine_examine_doc_name], [urine_verify_doc_id], [urine_verify_doc_name], [urine_examine_date], [valid_status], [update_id], [update_name], [update_date], [urine_specific_gravity_ref], [urine_ph_ref], [blood_examine_doc_sign], [blood_verify_doc_sign], [rummage_examine_doc_sign], [rummage_verify_doc_sign], [urine_examine_doc_sign], [urine_verify_doc_sign], [uric_acid], [uric_acid_unit], [uric_acid_ref], [uric_acid_flag], [urine_hemameba_code], [urine_hemameba_name]

) 
			
	SELECT 
[org_code], s2.id ,  [hemoglobin], [hemoglobin_unit], [hemoglobin_ref], [hemoglobin_flag], [hemameba], [hemameba_unit], [hemameba_ref], [hemameba_flag], [platelet], [platelet_unit], [platelet_ref], [platelet_flag], [blood_other], [urine_protein_code], [urine_protein_name], [urine_protein_volume], [urine_protein_unit], [urine_protein_ref], [urine_protein_flag], [urine_sugar_code], [urine_sugar_name], [urine_sugar_volume], [urine_sugar_unit], [urine_sugar_ref], [urine_sugar_flag], [urinary_ketone_bodies_code], [urinary_ketone_bodies_name], [urinary_ketone_bodies_flag], [urinary_occult_blood_code], [urinary_occult_blood_name], [urinary_occult_blood_flag], [urine_specific_gravity], [urine_specific_gravity_flag], [urine_ph], [urine_ph_flag], [urine_routine_other], [fasting_blood_glucose], [fasting_blood_glucose_unit], [fasting_blood_glucose_ref], [fasting_blood_glucose_flag], [two_hours_glucose], [two_hours_glucose_unit], [two_hours_glucose_ref], [two_hours_glucose_flag], [microalbuminuria], [microalbuminuria_unit], [microalbuminuria_ref], [microalbuminuria_flag], [fecal_occult_blood_code], [fecal_occult_blood_name], [glycosylated_hemoglobin], [glycosylated_hemoglobin_unit], [glycosylated_hemoglobin_ref], [glycosylated_hemoglobin_flag], [hbsag_code], [hbsag_name], [hbveag_code], [hbveag_name], [hbsab_code], [hbsab_name], [hbseab_code], [hbseab_name], [hbcab_code], [hbcab_name], [sgpt], [sgpt_unit], [sgpt_ref], [sgpt_flag], [sgot], [sgot_unit], [sgot_ref], [sgot_flag], [albumin], [albumin_unit], [albumin_ref], [albumin_flag], [bilirubin_total], [bilirubin_total_unit], [bilirubin_total_ref], [bilirubin_total_flag], [conjugated_bilirubin], [conjugated_bilirubin_unit], [conjugated_bilirubin_ref], [conjugated_bilirubin_flag], [scr], [scr_unit], [scr_ref], [scr_flag], [blood_urea], [blood_urea_unit], [blood_urea_ref], [blood_urea_flag], [blood_potassium_concentratio], [blood_potassium_concentratio_unit], [blood_potassium_concentratio_ref], [blood_potassium_concentratio_flag], [blood_sodium_concentration], [blood_sodium_concentration_unit], [blood_sodium_concentration_ref], [blood_sodium_concentration_flag], [cholesterol_total], [cholesterol_total_unit], [cholesterol_total_ref], [cholesterol_total_flag], [triglyceride], [triglyceride_unit], [triglyceride_ref], [triglyceride_flag], [serum_low_density], [serum_low_density_unit], [serum_low_density_ref], [serum_low_density_flag], [serum_high_density], [serum_high_density_unit], [serum_high_density_ref], [serum_high_density_flag], [cea_concentration], [cea_concentration_unit], [cea_concentration_ref], [cea_concentration_flag], [blood_examine_doc_id], [blood_examine_doc_name], [blood_verify_doc_id], [blood_verify_doc_name], [blood_examine_date], [rummage_examine_doc_id], [rummage_examine_doc_name], [rummage_verify_doc_id], [rummage_verify_doc_name], [rummage_examine_date], [urine_examine_doc_id], [urine_examine_doc_name], [urine_verify_doc_id], [urine_verify_doc_name], [urine_examine_date], [valid_status], [update_id], [update_name], [update_date], [urine_specific_gravity_ref], [urine_ph_ref], [blood_examine_doc_sign], [blood_verify_doc_sign], [rummage_examine_doc_sign], [rummage_verify_doc_sign], [urine_examine_doc_sign], [urine_verify_doc_sign], [uric_acid], [uric_acid_unit], [uric_acid_ref], [uric_acid_flag], [urine_hemameba_code], [urine_hemameba_name]
	FROM
	ITSV2.PHS.dbo.v_snr_examination_lis S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.oldid= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_ID FROM t_snr_examination_LIS )
		
			PRINT 'T_SNR_EXAMINATION_LIS  体检住院信息表 插入完成';
			
			
						
				-- 简易智力状态检验表 删除
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_MENTAL]
		WHERE  [EXAMINATION_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		PRINT 'T_SNR_EXAMINATION_MENTAL 简易智力状态检验表  删除完成'
			
			
			
				
			INSERT INTO [dbo].[T_SNR_EXAMINATION_MENTAL] (EXAMINATION_ID, [org_code], [id_card], [name], [sex_code], [sex_name], [age], [education], [time_question_1], [time_question_2], [time_question_3], [time_question_4], [time_question_5], [location_question_1], [location_question_2], [location_question_3], [location_question_4], [location_question_5], [immediate_recall_question_1], [immediate_recall_question_2], [immediate_recall_question_3], [attention_numeracy_question_1], [attention_numeracy_question_2], [attention_numeracy_question_3], [attention_numeracy_question_4], [attention_numeracy_question_5], [recall_question_1], [recall_question_2], [recall_question_3], [name_question_1], [name_question_2], [language_repeat_question_1], [comprehension_question_1], [comprehension_question_2], [comprehension_question_3], [read_question_1], [write_question_1], [draw_question_1], [total], [create_date], [is_delete]
) 
			
	SELECT 
 
s2.ID, [org_code], [id_card], [name], [sex_code], [sex_name], [age], [education], [time_question_1], [time_question_2], [time_question_3], [time_question_4], [time_question_5], [location_question_1], [location_question_2], [location_question_3], [location_question_4], [location_question_5], [immediate_recall_question_1], [immediate_recall_question_2], [immediate_recall_question_3], [attention_numeracy_question_1], [attention_numeracy_question_2], [attention_numeracy_question_3], [attention_numeracy_question_4], [attention_numeracy_question_5], [recall_question_1], [recall_question_2], [recall_question_3], [name_question_1], [name_question_2], [language_repeat_question_1], [comprehension_question_1], [comprehension_question_2], [comprehension_question_3], [read_question_1], [write_question_1], [draw_question_1], [total], [create_date], [is_delete]

	FROM
	ITSV2.PHS.dbo.v_snr_examination_MENTAL S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.oldid= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_ID FROM T_SNR_EXAMINATION_MENTAL )
		
			PRINT 'T_SNR_EXAMINATION_MENTAL 简易智力状态检验表   插入完成';
			
			
			
							
				-- 体检检查表 删除
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_RIS]
		WHERE  [EXAMINATION_ID] IN(
		
		SELECT 
		T3.ID
		
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		PRINT 'T_SNR_EXAMINATION_RIS 体检检查表  T_SNR_EXAMINATION_RIS 删除完成'
		
		
		
		
			
			INSERT INTO [dbo].[T_SNR_EXAMINATION_ris] (EXAMINATION_ID,[ecg_code], [ecg], [ecg_summary], [ecg_result], [ecg_describe], [ecg_pic], [ecg_pdf], [ecg_examine_doc_id], [ecg_examine_doc_name], [ecg_verify_doc_id], [ecg_verify_doc_name], [ecg_date], [chest_radiograph_code], [chest_radiograph_name], [chest_radiograph_abnormal], [b_ultrasound_code], [b_ultrasound_name], [b_ultrasound_abnormal], [ultrasound_model], [ultrasound_num], [ultrasound_part], [ultrasound_detail], [ultrasound_impression], [ultrasound_pic], [ultrasound_examine_doc_id], [ultrasound_pdf], [ultrasound_examine_doc_name], [ultrasound_verify_doc_id], [ultrasound_verify_doc_name], [ultrasound_date], [cervical_smear_code], [cervical_smear_name], [cervical_smear_abnormal], [other_accessory], [valid_status], [update_id], [update_name], [update_date], [pulse_rate], [heart_rate])
			
	SELECT 
 
s2.ID, ISNULL([ecg_code],'') as [ecg_code], [ecg], [ecg_summary], [ecg_result], [ecg_describe], [ecg_pic], [ecg_pdf], [ecg_examine_doc_id], [ecg_examine_doc_name], [ecg_verify_doc_id], [ecg_verify_doc_name], [ecg_date], ISNULL([chest_radiograph_code], '') AS [chest_radiograph_code], [chest_radiograph_name], [chest_radiograph_abnormal], ISNULL([b_ultrasound_code], '')as [b_ultrasound_code], [b_ultrasound_name], [b_ultrasound_abnormal], [ultrasound_model], [ultrasound_num], [ultrasound_part], [ultrasound_detail], [ultrasound_impression], [ultrasound_pic], [ultrasound_examine_doc_id], [ultrasound_pdf], [ultrasound_examine_doc_name], [ultrasound_verify_doc_id], [ultrasound_verify_doc_name], [ultrasound_date], ISNULL([cervical_smear_code], '') as [cervical_smear_code], [cervical_smear_name], [cervical_smear_abnormal], [other_accessory], [valid_status], [update_id], [update_name], [update_date], [pulse_rate], [heart_rate]


	FROM
	ITSV2.PHS.dbo.v_snr_examination_ris S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.oldid= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_ID FROM T_SNR_EXAMINATION_RIS )
		
			PRINT 'T_SNR_EXAMINATION_RIS 体检检查表   插入完成';
			
			
			
			-- 体检检查表 删除
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_TCM]
		WHERE  [EXAMINATION_NUM] IN(
		SELECT 
		T3.ID
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		PRINT 'T_SNR_EXAMINATION_TCM 中医药管理   删除完成'
		
			
			INSERT INTO [dbo].[T_SNR_EXAMINATION_TCM] ([examination_num], [EHR_ID], [org_code], [name], [sex_code], [sex_name], [age], [question_score], [create_date], [doc_id], [doc_name], [update_id], [update_name], [update_date], [valid_status]
) 
			
	SELECT 
 
s2.ID,  [ehr_num], [org_code], [name], [sex_code], [sex_name], [age], [question_score], [create_date], [doc_id], [doc_name], [update_id], [update_name], [update_date], [valid_status]
	FROM
	ITSV2.PHS.dbo.v_snr_examination_tcm S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.oldid= s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_NUM FROM T_SNR_EXAMINATION_TCM )
		
			PRINT 'T_SNR_EXAMINATION_TCM 中医药管理   插入完成';
			
			
			
			
			-- 体检疫苗接种删除
	DELETE  FROM [dbo].[T_SNR_EXAMINATION_VACCINE]
		WHERE  EXAMINATION_INFO_ID IN(
		SELECT 
		T3.ID
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
		PRINT 'T_SNR_EXAMINATION_TCM  体检疫苗接种 删除完成'
		
			
			INSERT INTO [dbo].[T_SNR_EXAMINATION_vaccine] (EXAMINATION_INFO_ID,[vaccine_code], [vaccine_name], [vaccination_date], [vaccine_org_code], [vaccine_org_name], [valid_status]
) 
			
	SELECT 


s2.ID,  [vaccine_code], [vaccine_name], [vaccination_date], [vaccine_org_code], [vaccine_org_name], [valid_status]
	FROM
	ITSV2.PHS.dbo.v_snr_examination_vaccine S1
	INNER JOIN ( SELECT ID, PATIENT_ID FROM T_SNR_EXAMINATION_INFO ) S2 ON S1.examination_info_id =s2.PATIENT_ID 
WHERE
	s2.ID NOT IN ( SELECT EXAMINATION_INFO_ID FROM T_SNR_EXAMINATION_VACCINE)
		
			PRINT ' T_SNR_EXAMINATION_TCM 体检疫苗接种 插入完成';
			
		-- 更新中医药管理数据	
			UPDATE

T_SNR_EXAMINATION_TCM
SET 
EHR_ID=t1.EHR_ID,
ID_CARD=t1.IDCARD
FROM 
T_SNR_EXAMINATION_INFO t1 
WHERE 
T_SNR_EXAMINATION_TCM.EXAMINATION_NUM !=''
AND
T_SNR_EXAMINATION_TCM.EXAMINATION_NUM=t1.ID;


PRINT ' T_SNR_EXAMINATION_TCM 中医药管理  更新完成';







	DELETE  FROM [dbo].[T_SNR_EXAMINATION_PHYSIQUE]
		WHERE  TCM_ID IN(
		SELECT 
		T4.ID
		FROM
		ITSV2.PHS.dbo.V_SNR_EXAMINATION_INFO t1
		INNER JOIN ( SELECT ID, IDCARD FROM T_EHR_INFO WHERE IS_DELETE = 0 AND FINAL_STATUS = 0 ) t2 ON t1.ID_CARD= t2.IDCARD 
		INNER JOIN T_SNR_EXAMINATION_INFO T3 
		ON T1.[odlId]=T3.[PATIENT_ID]
		INNER JOIN 
		T_SNR_EXAMINATION_TCM  t4 ON
		t3.ID=t4.EXAMINATION_NUM
		AND t4.EXAMINATION_NUM!=''
	WHERE
		t1.UPDATE_date  >= @UPDATE_DATE
		
		)
PRINT 'T_SNR_EXAMINATION_PHYSIQUE  中医药体质详情 删除完成';


INSERT INTO [dbo].[T_SNR_EXAMINATION_PHYSIQUE] ( [TCM_ID], [IDENTIFY_CODE], [IDENTIFY_NAME], [GUIDE_CODE], [GUIDE_NAME], [SCORE], [TYPE])

SELECT 
t2.ID,
t1.[IDENTIFY_CODE], 
t1.[IDENTIFY_NAME], 
t1.[GUIDE_CODE], 
t1.[GUIDE_NAME],
t1. [SCORE],
t1.	[TYPE]
 FROM
ITSV2.PHS.dbo.V_SNR_EXAMINATION_PHYSIQUE t1  INNER JOIN

T_SNR_EXAMINATION_TCM t2 
ON 
t1.oldid=t2.EXAMINATION_NUM
WHERE t2.EXAMINATION_NUM !=''
PRINT ' T_SNR_EXAMINATION_PHYSIQUE 中医药体质详情  新增完成';
PRINT '老年人数据更新完成'
		
END
go

