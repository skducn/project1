CREATE PROCEDURE [dbo].[BI_LNR_INFO]
    @ORG_CODE NVARCHAR(50),
   @START_DATE DATE ,
		@END_DATE DATE 
AS
BEGIN

 DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE)

    -- 检查 @ORG_CODE 和 @YEAR 中是否存在SQL注入
    IF @ORG_CODE LIKE '%select %'
        OR @ORG_CODE LIKE '%update %'
        OR @ORG_CODE LIKE '%insert %'
        OR @ORG_CODE LIKE '%delete %'
        OR @ORG_CODE LIKE '%truncate %'
        OR @ORG_CODE LIKE '%drop %'
        OR @ORG_CODE LIKE '%union %'
        OR @ORG_CODE LIKE '%exec %'
        OR @ORG_CODE LIKE '%xp_%'
        OR @YEAR LIKE '%select %'
        OR @YEAR LIKE '%update %'
        OR @YEAR LIKE '%insert %'
        OR @YEAR LIKE '%delete %'
        OR @YEAR LIKE '%truncate %'
        OR @YEAR LIKE '%drop %'
        OR @YEAR LIKE '%union %'
        OR @YEAR LIKE '%exec %'
        OR @YEAR LIKE '%xp_%'
    BEGIN
        RAISERROR('输入变量值中包含SQL注入！', 16, 1);
        RETURN;
    END;



    IF @ORG_CODE = '370685'
    BEGIN 
        -- 创建临时表
        IF OBJECT_ID('tempdb..#S0') IS NOT NULL DROP TABLE #S0;
        CREATE TABLE #S0 (ORG_CODE VARCHAR(50), ORG_NAME VARCHAR(255));
        
        IF OBJECT_ID('tempdb..#S1') IS NOT NULL DROP TABLE #S1;
        CREATE TABLE #S1 (ID INT, MANAGE_ORG_CODE VARCHAR(50), MANAGE_ORG_NAME VARCHAR(255), SJJG VARCHAR(50), CREATE_DATE DATE);
 		create index ix_tmp_si_id on #S1(id)
		create index ix_tmp_si_si on #S1(SJJG,id)	
			
        IF OBJECT_ID('tempdb..#S2') IS NOT NULL DROP TABLE #S2;
        CREATE TABLE #S2 (EHR_ID INT);
        
        IF OBJECT_ID('tempdb..#S3') IS NOT NULL DROP TABLE #S3;
        CREATE TABLE #S3 (EHR_ID INT, LNRJKTJ_FLAG INT);
        
        IF OBJECT_ID('tempdb..#S6') IS NOT NULL DROP TABLE #S6;
        CREATE TABLE #S6 (ORG_CODE VARCHAR(50), LWLNR INT, LNRJKTJ_NUM INT, JSJKGL_NUM INT, RESIDENT_NUM INT, GGL FLOAT);

        -- 插入数据到 #S0
        INSERT INTO #S0 (ORG_CODE, ORG_NAME)
        SELECT ORG_CODE, ORG_NAME FROM ZYCONFIG.DBO.SYS_HOSPITAL
        UNION ALL
        SELECT '370685', '招远卫健局';

        -- 插入数据到 #S1
        INSERT INTO #S1 (ID, MANAGE_ORG_CODE, MANAGE_ORG_NAME, SJJG, CREATE_DATE)
        SELECT ID, MANAGE_ORG_CODE, MANAGE_ORG_NAME, ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS SJJG, CREATE_DATE
        FROM T_EHR_INFO
        WHERE IS_DELETE = '0'
        AND ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT * FROM dbo.GET_ORGCODE(@ORG_CODE))
        AND BIRTH <= DATEADD(YEAR, -65, @END_DATE );

        -- 插入数据到 #S2
        INSERT INTO #S2 (EHR_ID)
        SELECT DISTINCT info.EHR_ID
        FROM (SELECT ID, INQUIRY_DATE, VALID_STATUS, EHR_ID FROM T_SNR_EXAMINATION_INFO WHERE EHR_ID IN (SELECT ID FROM #S1)) info
        LEFT JOIN T_SNR_EXAMINATION_LIS lis ON info.ID = lis.EXAMINATION_ID AND info.INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE AND info.VALID_STATUS = '1'
        LEFT JOIN T_SNR_EXAMINATION_RIS ris ON info.ID = ris.EXAMINATION_ID AND info.INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE AND info.VALID_STATUS = '1'
        WHERE lis.ID IS NOT NULL AND ris.ID IS NOT NULL
				and lis.HEMOGLOBIN !=-1
				AND lis.HEMAMEBA !=-1
				and lis.PLATELET !=-1
				and lis.URINE_PROTEIN_CODE !=''
				and lis.URINE_SUGAR_CODE !=''
				and lis.URINE_HEMAMEBA_CODE !=''
				and lis.URINARY_KETONE_BODIES_CODE!='' and lis.URINARY_OCCULT_BLOOD_CODE !=''
				and lis.SGPT !=-1
				and lis.SGOT !=-1
				and lis.BILIRUBIN_TOTAL != -1
				and lis.SCR !=-1
				and lis.BLOOD_UREA !=-1
				and lis.FASTING_BLOOD_GLUCOSE !=-1
				and lis.CHOLESTEROL_TOTAL !=-1
				and lis.TRIGLYCERIDE !=-1
				and lis.SERUM_LOW_DENSITY!=-1
				and lis.SERUM_HIGH_DENSITY !=-1
				and ris.ECG_CODE !=''
				and ris.B_ULTRASOUND_CODE !=''
				;

        -- 插入数据到 #S3
        INSERT INTO #S3 (EHR_ID, LNRJKTJ_FLAG)
        SELECT DISTINCT info.EHR_ID, IIF(info.EHR_ID IS NULL, 0, 1) AS LNRJKTJ_FLAG
        FROM #S1
        INNER JOIN T_SNR_EXAMINATION_INFO info ON #S1.ID = info.EHR_ID 
        WHERE info.INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE AND info.VALID_STATUS = '1';

        -- 插入数据到 #S6
        INSERT INTO #S6 (ORG_CODE, LWLNR, LNRJKTJ_NUM, JSJKGL_NUM, RESIDENT_NUM, GGL)
        SELECT s1.SJJG AS ORG_CODE,
            SUM(IIF(s1.CREATE_DATE <= @END_DATE,1,0)) AS LWLNR,
            SUM(IIF(s3.LNRJKTJ_FLAG = 1, 1, 0)) AS LNRJKTJ_NUM,
            SUM(IIF(s2.EHR_ID IS NOT NULL, 1, 0)) AS JSJKGL_NUM,
            (SELECT OLD_NUM from t_home WHERE ORG_CODE=s1.SJJG AND  [YEAR] =@YEAR ) AS RESIDENT_NUM,
            dbo.Fn_GetPercent(SUM(IIF(s2.EHR_ID IS NOT NULL, 1, 0)),  (SELECT OLD_NUM from t_home WHERE ORG_CODE=s1.SJJG AND  [YEAR] =@YEAR )) AS GGL
        FROM #S1 s1
        LEFT JOIN #S3 s3 ON s1.ID = s3.EHR_ID
        LEFT JOIN #S2 s2 ON s1.ID = s2.EHR_ID
      
        GROUP BY s1.SJJG

        -- 最终选择语句
        SELECT u.ORG_CODE, u.ORG_NAME, u.establishHealthRecords, u.numberOfHealthCheckUps, u.numberOfRecipients, ISNULL(u.permanentPopulation, 0) AS permanentPopulation, dbo.Fn_GetPercent(u.numberOfRecipients, ISNULL(u.permanentPopulation, 0)) AS elderlyManagementRate
        FROM (
            SELECT s0.ORG_CODE, s0.ORG_NAME,
                ISNULL(s6.LWLNR, 0) AS establishHealthRecords,
                ISNULL(s6.LNRJKTJ_NUM, 0) AS numberOfHealthCheckUps,
                ISNULL(s6.JSJKGL_NUM, 0) AS numberOfRecipients,
                ISNULL(s6.RESIDENT_NUM, 0) AS permanentPopulation
            FROM #S0 s0
            LEFT JOIN #S6 s6 ON s0.ORG_CODE = s6.ORG_CODE
        ) u;

    END
    ELSE
    BEGIN
        -- 创建临时表
        IF OBJECT_ID('tempdb..#K0') IS NOT NULL DROP TABLE #K0;
        CREATE TABLE #K0 (ORG_SUB_CODE VARCHAR(50), ORG_SUB_NAME VARCHAR(255));
        
        IF OBJECT_ID('tempdb..#K1') IS NOT NULL DROP TABLE #K1;
        CREATE TABLE #K1 (ID INT, MANAGE_ORG_CODE VARCHAR(50), MANAGE_ORG_NAME VARCHAR(255), SJJG VARCHAR(50), CREATE_DATE DATE);
		create index ix_tmp_k1_id on #K1(id)
        
        IF OBJECT_ID('tempdb..#K2') IS NOT NULL DROP TABLE #K2;
        CREATE TABLE #K2 (EHR_ID INT);
        
        IF OBJECT_ID('tempdb..#K3') IS NOT NULL DROP TABLE #K3;
        CREATE TABLE #K3 (EHR_ID INT, LNRJKTJ_FLAG INT);
        
        IF OBJECT_ID('tempdb..#K6') IS NOT NULL DROP TABLE #K6;
        CREATE TABLE #K6 (ORG_CODE VARCHAR(50), ORG_NAME VARCHAR(255), permanentPopulation INT, numberOfHealthCheckUps INT, JSJKGL_NUM INT);

        IF OBJECT_ID('tempdb..#K7') IS NOT NULL DROP TABLE #K7;
        CREATE TABLE #K7 (ORG_CODE VARCHAR(50), OLD_NUM INT);

        -- 插入数据到 #K0
        INSERT INTO #K0 (ORG_SUB_CODE, ORG_SUB_NAME)
        SELECT ORG_SUB_CODE, ORG_SUB_NAME FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_CODE = @ORG_CODE
        UNION ALL
        SELECT ORG_CODE, ORG_NAME FROM ZYCONFIG.DBO.SYS_HOSPITAL WHERE ORG_CODE = @ORG_CODE;

        -- 插入数据到 #K1
        INSERT INTO #K1 (ID, MANAGE_ORG_CODE, MANAGE_ORG_NAME, SJJG, CREATE_DATE)
        SELECT ID, MANAGE_ORG_CODE, MANAGE_ORG_NAME, ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS SJJG, CREATE_DATE
        FROM T_EHR_INFO
        WHERE IS_DELETE = '0'
        AND BIRTH <=  DATEADD(YEAR, -65, @END_DATE)
        AND ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT * FROM dbo.GET_ORGCODE(@ORG_CODE));

        -- 插入数据到 #K2
        INSERT INTO #K2 (EHR_ID)
        SELECT DISTINCT info.EHR_ID
        FROM (SELECT ID, INQUIRY_DATE, VALID_STATUS, EHR_ID FROM T_SNR_EXAMINATION_INFO WHERE EHR_ID IN (SELECT ID FROM #K1)) info
        LEFT JOIN T_SNR_EXAMINATION_LIS lis ON info.ID = lis.EXAMINATION_ID AND info.INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE AND info.VALID_STATUS = '1'
        LEFT JOIN T_SNR_EXAMINATION_RIS ris ON info.ID = ris.EXAMINATION_ID AND info.INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE AND info.VALID_STATUS = '1'
        WHERE lis.ID IS NOT NULL AND ris.ID IS NOT NULL
				and lis.HEMOGLOBIN !=-1
				AND lis.HEMAMEBA !=-1
				and lis.PLATELET !=-1
				and lis.URINE_PROTEIN_CODE !=''
				and lis.URINE_SUGAR_CODE !=''
				and lis.URINE_HEMAMEBA_CODE !=''
				and lis.URINARY_KETONE_BODIES_CODE!='' and lis.URINARY_OCCULT_BLOOD_CODE !=''
				and lis.SGPT !=-1
				and lis.SGOT !=-1
				and lis.BILIRUBIN_TOTAL != -1
				and lis.SCR !=-1
				and lis.BLOOD_UREA !=-1
				and lis.FASTING_BLOOD_GLUCOSE !=-1
				and lis.CHOLESTEROL_TOTAL !=-1
				and lis.TRIGLYCERIDE !=-1
				and lis.SERUM_LOW_DENSITY!=-1
				and lis.SERUM_HIGH_DENSITY !=-1
				and ris.ECG_CODE !=''
				and ris.B_ULTRASOUND_CODE !=''
				
				
				;

        -- 插入数据到 #K3
        INSERT INTO #K3 (EHR_ID, LNRJKTJ_FLAG)
        SELECT DISTINCT info.EHR_ID, IIF(info.EHR_ID IS NULL, 0, 1) AS LNRJKTJ_FLAG
        FROM #K1
        INNER JOIN T_SNR_EXAMINATION_INFO info ON #K1.ID = info.EHR_ID 
        WHERE info.INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE AND info.VALID_STATUS = '1';

        -- 插入数据到 #K6
        INSERT INTO #K6 (ORG_CODE, ORG_NAME, permanentPopulation, numberOfHealthCheckUps, JSJKGL_NUM)
        SELECT s1.MANAGE_ORG_CODE AS ORG_CODE,
            s1.MANAGE_ORG_NAME AS ORG_NAME,
            SUM(IIF(s1.CREATE_DATE <= @END_DATE,1,0)) AS permanentPopulation,
            SUM(IIF(s3.LNRJKTJ_FLAG = 1, 1, 0)) AS numberOfHealthCheckUps,
            SUM(IIF(s2.EHR_ID IS NOT NULL, 1, 0)) AS JSJKGL_NUM
        FROM #K1 s1
        LEFT JOIN #K3 s3 ON s1.ID = s3.EHR_ID
        LEFT JOIN #K2 s2 ON s1.ID = s2.EHR_ID
        GROUP BY s1.MANAGE_ORG_CODE, s1.MANAGE_ORG_NAME;

        -- 插入数据到 #K7
        INSERT INTO #K7 (ORG_CODE, OLD_NUM )
        SELECT ORG_CODE, OLD_NUM FROM T_HOME WHERE ORG_CODE = @ORG_CODE AND [YEAR] = @YEAR
        UNION ALL
        SELECT ORG_SUB_CODE,OLD_NUM FROM T_SUB_HOME WHERE ORG_CODE = @ORG_CODE AND [YEAR] = @YEAR;

        -- 最终选择语句
        SELECT s0.ORG_SUB_CODE AS orgCode,
            s0.ORG_SUB_NAME AS orgName,
            ISNULL(s6.permanentPopulation, 0) AS establishHealthRecords,
            ISNULL(s6.numberOfHealthCheckUps, 0) AS numberOfHealthCheckUps,
            ISNULL(s6.JSJKGL_NUM, 0) AS numberOfRecipients,
            ISNULL(S7.OLD_NUM, 0) AS permanentPopulation,
            ISNULL(dbo.Fn_GetPercent(s6.JSJKGL_NUM, ISNULL(S7.OLD_NUM, 0)), 0.00) AS elderlyManagementRate
        FROM #K0 s0
        LEFT JOIN #K6 s6 ON s0.ORG_SUB_CODE = s6.ORG_CODE
        LEFT JOIN #K7 s7 ON s0.ORG_SUB_CODE = s7.ORG_CODE
        ORDER BY s0.ORG_SUB_CODE DESC;

    END

END;
go

