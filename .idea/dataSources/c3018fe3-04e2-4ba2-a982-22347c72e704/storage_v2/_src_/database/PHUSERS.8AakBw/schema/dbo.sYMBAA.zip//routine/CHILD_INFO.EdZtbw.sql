CREATE PROCEDURE [dbo].[CHILD_INFO]
		@ORG_CODE NVARCHAR(50),
		 @START_DATE DATE ,
		@END_DATE DATE
AS
BEGIN

    DECLARE @inputcheck NVARCHAR(20) = '';
		 DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE);


		DECLARE @QUARTE  INT;
		SET @QUARTE  =
(SELECT DATENAME(QUARTER, @END_DATE) ) ;

		    -- 检测@IDCARD是否有sql注入
    IF @inputcheck LIKE '%select %'
        OR @inputcheck LIKE '%update %'
        OR @inputcheck LIKE '%insert %'
        OR @inputcheck LIKE '%delete %'
        OR @inputcheck LIKE '%truncate %'
        OR @inputcheck LIKE '%drop %'
        OR @inputcheck LIKE '%union %'
        OR @inputcheck LIKE '%exec %'
        OR @inputcheck LIKE '%xp_%'
BEGIN
        RAISERROR('输入变量值中包含sql注入！', 16, 1);
        RETURN;
END;

		IF @ORG_CODE = '370685'
BEGIN
		--卫建委账号逻辑
				-- 创建临时表 t0
SELECT ORG_CODE, ORG_NAME INTO #t0
FROM ZYCONFIG.DBO.SYS_HOSPITAL
UNION ALL
SELECT '370685', '招远市卫建局';

-- 创建临时表 t1
SELECT
    t.MANAGE_ORG_CODE,
    COALESCE(sh.ORG_CODE, t.MANAGE_ORG_CODE) AS UP_orgcode,
    t.ID
INTO #t1
FROM
    (SELECT DISTINCT ID, CREATE_ORG_CODE as  MANAGE_ORG_CODE FROM T_CHILD_INFO WHERE IS_DELETE = 0 and CLOSED_STATUS='0') t
        LEFT JOIN ZYCONFIG.dbo.SYS_SUB_HOSPITAL sh ON sh.ORG_SUB_CODE = t.MANAGE_ORG_CODE
WHERE
    EXISTS (SELECT 1 FROM dbo.GET_ORGCODE(@ORG_CODE) WHERE ORG_CODE = COALESCE(sh.ORG_CODE, t.MANAGE_ORG_CODE));






-- 创建临时表 cehv


-- 创建临时表 t2
SELECT
    ORG_CODE,
    SUM(num1) AS num1,
    SUM(num2) AS num2,
    sum(num3) as num3
INTO #t2
FROM (
         SELECT
             #t1.UP_orgcode as ORG_CODE,
             CASE
                 WHEN EXISTS (
                     SELECT 1
                     FROM  T_CHILD_HOME_VISIT
                     WHERE INFO_ID = i.ID
                       and   VISIT_DATE>= @START_DATE  AND VISIT_DATE<=@END_DATE
                       AND IS_DELETE =0

                 ) AND BIRTH BETWEEN @START_DATE AND @END_DATE
                     and (i.MANAGE_CATEGORY_CODE='1' OR i.MANAGE_CATEGORY_CODE='3')

                     THEN 1 ELSE 0
                 END AS num1,
             CASE
                 WHEN EXISTS (
                     SELECT 1
                     FROM T_CHILD_HOME_VISIT
                     WHERE INFO_ID = i.ID
                       AND  VISIT_DATE BETWEEN @START_DATE  AND @END_DATE


                 )
                     and (i.MANAGE_CATEGORY_CODE='1' OR i.MANAGE_CATEGORY_CODE='2')
                     AND i.BIRTH BETWEEN DATEADD(YEAR, -6, @end_date) and @end_date

                     AND i.CLOSED_STATUS=0
                     and i.IS_DELETE=0
                     THEN 1 ELSE 0
                 END AS num2  ,

             CASE
                 WHEN
                         (i.MANAGE_CATEGORY_CODE='1' OR i.MANAGE_CATEGORY_CODE='2')
                         AND i.BIRTH BETWEEN DATEADD(YEAR, -6, @end_date) and @end_date
                         AND i.CLOSED_STATUS=0
                         and i.IS_DELETE=0


                     THEN 1 ELSE 0
                 END AS num3


         FROM
             T_CHILD_INFO i
                 INNER JOIN #t1 ON i.ID = #t1.ID


     ) s
GROUP BY
    s.ORG_CODE;

-- 最终查询
SELECT
    #t0.ORG_CODE,
    #t0.ORG_NAME,
    ISNULL(
            CASE WHEN @QUARTE =1 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1
                 WHEN @QUARTE =2 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2
                 WHEN @QUARTE =3 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3
                 WHEN @QUARTE =4 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3+h.CHILD_LIVE_BIRTH_NUM_QUARTER_4
                 ELSE 0
                END


        , 0) AS CHILD_LIVE_BIRTH_NUM,
    ISNULL(#t2.num3, 0) AS CHILD_NUM,
    ISNULL(#t2.num1, 0) AS neonate,
    ISNULL(#t2.num2, 0) AS children,
    dbo.Fn_GetPercent(#t2.num1, ISNULL(
            CASE WHEN @QUARTE =1 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1
                 WHEN @QUARTE =2 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2
                 WHEN @QUARTE =3 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3
                 WHEN @QUARTE =4 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3+h.CHILD_LIVE_BIRTH_NUM_QUARTER_4
                 ELSE 0
                END


        , 0)) AS neonateRate,
    dbo.Fn_GetPercent(#t2.num2, #t2.num3) AS childrenRate
FROM
    #t0
        LEFT JOIN #t2 ON #t0.ORG_CODE = #t2.ORG_CODE
        LEFT JOIN T_HOME h ON h.ORG_CODE = #t2.ORG_CODE AND h.YEAR = @YEAR;

-- 删除临时表
DROP TABLE #t0;
DROP TABLE #t1;

DROP TABLE #t2;

END;
ELSE
BEGIN
		--其他账号逻辑
		  -- 创建临时表 t0
SELECT
    ORG_SUB_CODE AS ORG_CODE,
    ORG_SUB_NAME AS ORG_NAME
INTO #tb0
FROM
    ZYCONFIG.DBO.SYS_SUB_HOSPITAL
WHERE
        org_code = @ORG_CODE
UNION ALL
SELECT
    @ORG_CODE AS ORG_CODE,
    (SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE org_code = @ORG_CODE) AS ORG_NAME;

-- 创建临时表 t1
SELECT
    t.MANAGE_ORG_CODE AS ORG_CODE,
    t.MANAGE_ORG_NAME AS ORG_NAME,
    ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
    t.ID INTO #tb1
FROM
    (SELECT DISTINCT ID,  CREATE_ORG_CODE as  MANAGE_ORG_CODE, MANAGE_ORG_NAME FROM T_CHILD_INFO WHERE IS_DELETE = 0
                                                                                                   and CLOSED_STATUS='0'
    ) t
WHERE
        ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t.MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE));

-- 创建临时表 cehv

-- 创建临时表 t2
SELECT
    s.ORG_CODE,
    SUM(num1) AS num1,
    SUM(num2) AS num2,
    sum(num3) as num3
INTO #tb2
FROM (
         SELECT
             #tb1.ORG_CODE,
             CASE
                 WHEN EXISTS (
                     SELECT 1
                     FROM  T_CHILD_HOME_VISIT
                     WHERE INFO_ID = i.ID
                       and   VISIT_DATE>= @START_DATE  AND VISIT_DATE<=@END_DATE
                       AND IS_DELETE =0

                 ) AND BIRTH BETWEEN @START_DATE AND @END_DATE
                     and (i.MANAGE_CATEGORY_CODE='1' OR i.MANAGE_CATEGORY_CODE='3') THEN 1 ELSE 0
                 END AS num1,
             CASE
                 WHEN EXISTS (
                     SELECT 1
                     FROM T_CHILD_HOME_VISIT
                     WHERE INFO_ID = i.ID
                       AND  VISIT_DATE BETWEEN @START_DATE  AND @END_DATE


                 )
                     and (i.MANAGE_CATEGORY_CODE='1' OR i.MANAGE_CATEGORY_CODE='2')
                     AND i.BIRTH BETWEEN DATEADD(YEAR, -6, @end_date) and @end_date
                     AND i.CLOSED_STATUS=0
                     and i.IS_DELETE=0
                     THEN 1 ELSE 0
                 END AS num2  ,

             CASE
                 WHEN
                         (i.MANAGE_CATEGORY_CODE='1' OR i.MANAGE_CATEGORY_CODE='2')
                         AND i.BIRTH BETWEEN DATEADD(YEAR, -6, @end_date) and @end_date
                         AND i.CLOSED_STATUS=0
                         and i.IS_DELETE=0

                     THEN 1 ELSE 0
                 END AS num3



         FROM
             T_CHILD_INFO i
                 INNER  JOIN #tb1 ON i.ID = #tb1.ID

     ) s
GROUP BY
    s.ORG_CODE;

-- 最终查询
SELECT
    #tb0.ORG_CODE,
    #tb0.ORG_NAME,
    ISNULL(
            CASE WHEN @QUARTE =1 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1
                 WHEN @QUARTE =2 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2
                 WHEN @QUARTE =3 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3
                 WHEN @QUARTE =4 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3+h.CHILD_LIVE_BIRTH_NUM_QUARTER_4
                 ELSE 0
                END


        , 0) AS CHILD_LIVE_BIRTH_NUM,
    isnull(#tb2.num3,0) AS CHILD_NUM,
    ISNULL(#tb2.num1, 0) AS neonate,
    ISNULL(#tb2.num2, 0) AS children,
    dbo.Fn_GetPercent(#tb2.num1, ISNULL(
            CASE WHEN @QUARTE =1 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1
                 WHEN @QUARTE =2 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2
                 WHEN @QUARTE =3 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3
                 WHEN @QUARTE =4 THEN h.CHILD_LIVE_BIRTH_NUM_QUARTER_1+h.CHILD_LIVE_BIRTH_NUM_QUARTER_2+h.CHILD_LIVE_BIRTH_NUM_QUARTER_3+h.CHILD_LIVE_BIRTH_NUM_QUARTER_4
                 ELSE 0
                END


        , 0)) AS neonateRate,
    dbo.Fn_GetPercent(#tb2.num2,#tb2.num3) AS childrenRate
FROM
    #tb0
        LEFT JOIN #tb2 ON #tb0.ORG_CODE = #tb2.ORG_CODE
        LEFT JOIN T_HOME h ON h.ORG_CODE = #tb2.ORG_CODE AND h.YEAR = @YEAR;

-- 删除临时表
DROP TABLE #tb0;
DROP TABLE #tb1;

DROP TABLE #tb2;
END;
END;
go

