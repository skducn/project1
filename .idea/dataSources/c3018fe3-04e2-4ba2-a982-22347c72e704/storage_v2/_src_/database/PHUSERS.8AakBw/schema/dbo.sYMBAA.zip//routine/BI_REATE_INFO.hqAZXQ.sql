CREATE PROCEDURE [dbo].[BI_REATE_INFO] AS BEGIN-- Declare variables
	DECLARE
		@YEAR INT;
	DECLARE
		@START_DATE_BI DATE;
	DECLARE
		@END_DATE_BI DATE;
	DECLARE
		@neonateRate DECIMAL ( 10, 2 );
	DECLARE
		@childHealthManagementRate DECIMAL ( 10, 2 );
	DECLARE
		@jurisdictionChildExaminationRate DECIMAL ( 10, 2 );
	DECLARE
		@elderlyZyymentRate DECIMAL ( 10, 2 );
	DECLARE
	  @elderlyManagementRate DECIMAL ( 10, 2 );
	DECLARE 
	  @gxynormManageRate DECIMAL ( 10, 2 );
	DECLARE 
	  @manageBpControlRate DECIMAL ( 10, 2 );
		DECLARE 
	  @tnbnormManageRate DECIMAL ( 10, 2 );
	DECLARE 
	  @manageBgControlRate DECIMAL ( 10, 2 );
		DECLARE 
	  @buildRate DECIMAL ( 10, 2 );
		DECLARE 
	  @pregnancyRate DECIMAL ( 10, 2 );
			DECLARE 
	  @managementRate DECIMAL ( 10, 2 );
		DECLARE 
	  @regularMedicationRate DECIMAL ( 10, 2 );
			DECLARE 
		@jsbMedicationRate DECIMAL(10,2);
		
		
	SET @YEAR = YEAR ( GETDATE( ) );
	SET @START_DATE_BI = DATEFROMPARTS ( @YEAR, 1, 1 );
	SET @END_DATE_BI = GETDATE( );
	CREATE TABLE #ChildData (
		ORG_CODE NVARCHAR(50),
		org_name NVARCHAR(50),
		CHILD_LIVE_BIRTH_NUM INT,
		childNum INT,
		neonate INT,
		children INT,
		neonateRate DECIMAL ( 6, 2 ),-- Add the 5th and 6th fields
		childrenRate DECIMAL ( 6, 2 ) 
	);
-- Execute CHILD_INFO and insert results into the temporary table
	INSERT INTO #ChildData  EXEC CHILD_INFO @ORG_CODE = '370685',
	@START_DATE = @START_DATE_BI,
	@END_DATE = @END_DATE_BI;
-- Calculate rates from stored data
	SELECT
		@neonateRate = dbo.Fn_GetPercent ( SUM ( neonate ), SUM ( CHILD_LIVE_BIRTH_NUM ) ),
		@childHealthManagementRate = dbo.Fn_GetPercent ( SUM ( children ), SUM ( childNum ) ) 
	FROM
		#ChildData;
		
	
		  
		;
		CREATE TABLE #zzdData (
		ORG_CODE NVARCHAR(50),
		org_name NVARCHAR(50),
		elderlyPermanentPopulation INT,
		elderlyChineseMedicine INT,
		childAdministration INT,
		monthAgechildAdministration INT,
		elderlyManagementRate DECIMAL ( 6, 2 ),-- Add the 5th and 6th fields
		childRate DECIMAL ( 6, 2 ) 
	);
	
	
	INSERT INTO #zzdData  EXEC BI_ZYY_INFO @ORG_CODE = '370685',
	@START_DATE = @START_DATE_BI,
	@END_DATE = @END_DATE_BI;
	
	SELECT
		@jurisdictionChildExaminationRate = dbo.Fn_GetPercent ( SUM ( monthAgechildAdministration ), SUM ( childAdministration) ),
		@elderlyZyymentRate = dbo.Fn_GetPercent ( SUM ( elderlyChineseMedicine ), SUM ( elderlyPermanentPopulation ) ) 
	FROM
		#zzdData;
		
		
		CREATE TABLE #lnrData (
		ORG_CODE NVARCHAR(50),
		org_name NVARCHAR(50),
		establishHealthRecords INT,
		numberOfHealthCheckUps INT,
		numberOfRecipients INT,
		permanentPopulation INT,
		elderlyManagementRate DECIMAL ( 6, 2 )-- Add the 5th and 6th fields
		
	);
	
	
		INSERT INTO #lnrData  EXEC BI_LNR_INFO @ORG_CODE = '370685',
	@START_DATE = @START_DATE_BI,
	@END_DATE = @END_DATE_BI;
	
	SELECT
		@elderlyManagementRate = dbo.Fn_GetPercent ( SUM ( numberOfRecipients ), SUM ( permanentPopulation) )
	
	FROM
		#lnrData;
	
							
	CREATE TABLE #gxyData (
		ORG_CODE NVARCHAR(50),
		org_name NVARCHAR(50),
		shallManageNum INT,
		 managedNum INT,
		normManageNum2 INT,
		normManageNum INT,
		lastBpStandardNum	INT,
		normManageRate DECIMAL ( 10, 2 ),-- Add the 5th and 6th fields
		manageBpControlRate DECIMAL ( 10, 2 ) 
	);
	
	
		INSERT INTO #gxyData  EXEC BI_GXY_INFO @ORG_CODE = '370685',
	@START_DATE = @START_DATE_BI,
	@END_DATE = @END_DATE_BI;
	
	SELECT
		@gxynormManageRate = dbo.Fn_GetPercent ( SUM ( normManageNum ), SUM ( managedNum) ),
			@manageBpControlRate = dbo.Fn_GetPercent ( SUM ( lastBpStandardNum), SUM ( managedNum) )
	
	FROM
		#gxyData ;
		--- 糖尿病
		CREATE TABLE #tnbData (
		ORG_CODE NVARCHAR(50),
		org_name NVARCHAR(50),
		shallManageNum INT,
		 managedNum INT,
		normManageNum2 INT,
		normManageNum INT,
		lastBgStandardNum	INT,
		normManageRate DECIMAL ( 10, 2 ),-- Add the 5th and 6th fields
		manageBgControlRate DECIMAL ( 10, 2 ) 
	);
	
	
		INSERT INTO #tnbData  EXEC BI_GXY_INFO @ORG_CODE = '370685',
	@START_DATE = @START_DATE_BI,
	@END_DATE = @END_DATE_BI;
	
	SELECT
		@tnbnormManageRate = dbo.Fn_GetPercent ( SUM ( normManageNum ), SUM ( managedNum) ),
			@manageBgControlRate = dbo.Fn_GetPercent ( SUM ( lastBgStandardNum), SUM ( managedNum) )
	
	FROM
		#tnbData ;
			--- 孕产妇
		CREATE TABLE #pwData (
		ORG_CODE NVARCHAR(50),
		org_name NVARCHAR(50),
		LIVE_BIRTH_NUM INT,
		 build INT,
		pregnancy INT,
		buildRate DECIMAL ( 10, 2 ),-- Add the 5th and 6th fields
		pregnancyRate DECIMAL ( 10, 2 ) 
	);
	
	
		INSERT INTO #pwData  EXEC BI_PW_INFO @ORG_CODE = '370685',
	@START_DATE = @START_DATE_BI,
	@END_DATE = @END_DATE_BI;
	
	SELECT
		@buildRate = dbo.Fn_GetPercent ( SUM ( build ), SUM ( LIVE_BIRTH_NUM) ),
			@pregnancyRate = dbo.Fn_GetPercent ( SUM (pregnancy), SUM (LIVE_BIRTH_NUM) )
	
	FROM
		#pwData;
	
			--- 肺结核
		CREATE TABLE #FJHData (
		ORG_CODE NVARCHAR(50),
		org_name NVARCHAR(50),
		NumberOfConfirmedCases INT,
		managementRate DECIMAL ( 10, 2 ),
		regularMedicationRate DECIMAL ( 10, 2 ),
		 managementNumber INT,
		treatNumber INT,
		regularMedication INT 
	);
	
	
		INSERT INTO #FJHData  EXEC BI_FJH_INFO @ORG_CODE = '370685',
	@START_DATE = @START_DATE_BI,
	@END_DATE = @END_DATE_BI;
	
	SELECT
		@managementRate = dbo.Fn_GetPercent ( SUM ( managementNumber ), SUM ( NumberOfConfirmedCases) ),
			@regularMedicationRate = dbo.Fn_GetPercent ( SUM (regularMedication), SUM (treatNumber) )
	
	FROM
		#FJHData  ;
		-- 精神病
			SELECT
				
				t2.IDCARD,
				t1.ID ,
				t1.CLOSED_STATUS
				
				 INTO #S1 
			FROM
				( SELECT DISTINCT IDCARD, id , CLOSED_STATUS FROM T_SMI_INFO WHERE IS_DELETE = '0' AND id in (SELECT  info_id FROM T_SMI_INFO_DETAIL WHERE FILL_FORM_DATE <=  @END_DATE_BI ) ) t1
				INNER JOIN T_EHR_INFO t2 ON t1.IDCARD = t2.IDCARD  and t2.IS_DELETE='0'and t2.FINAL_STATUS='0'
			;
			
			--辖区内在管患者的确诊严重精神障碍患者人数（人）
			SELECT  DISTINCT idcard  INTO #S2  from  #s1 where  CLOSED_STATUS ='0'   ;
			
			-- 辖区内按照规范要求进行管理的严重精神障碍患者人数（人）
			WITH SMI_VISIT_LOG AS (
	--第一次时间
	select smi.IDCARD,ISNULL(NTI.CREATE_DATE, @START_DATE_BI) AS VISIT_DATE --,SMI.IDCARD ISNULL(FTI.VISIT_DATE, '2023-09-30'),
	FROM 
	#s2 as smi
	
	LEFT JOIN
	(
	SELECT IDCARD,max(CONVERT(DATE, CREATE_DATE)) AS CREATE_DATE
	from T_SMI_INFO
	WHERE CREATE_DATE>= @START_DATE_BI
	and IS_DELETE=0
	group by IDCARD
	)AS NTI ON SMI.IDCARD=NTI.IDCARD
	--今年随访
	union all
	SELECT SI.IDCARD,SV.VISIT_DATE
	FROM T_SMI_VISIT SV
	left JOIN T_SMI_INFO SI on SV.INFO_ID=SI.ID
	WHERE SV.VISIT_DATE  BETWEEN  @START_DATE_BI AND @END_DATE_BI
	--最后时间
	
)

select IDCARD  INTO #S3
FROM
(
select *,DATEDIFF(DAY,LAG(VISIT_DATE, 1) OVER (PARTITION BY IDCARD ORDER BY VISIT_DATE), VISIT_DATE) AS DaysDifference
from SMI_VISIT_LOG
) as SVL
WHERE DaysDifference>90
group by IDCARD
;



		SET @jsbMedicationRate = dbo.Fn_GetPercent ( (SELECT COUNT(*)FROM #S3)  , (SELECT COUNT(*) FROM #S2)  );
		
	
		UPDATE T_BI_RATE  
		set 
		neonateRate=@neonateRate ,
		childHealthManagementRate=@childHealthManagementRate ,
		jurisdictionChildExaminationRate=	@jurisdictionChildExaminationRate,
		elderlyZyymentRate=@elderlyZyymentRate,
		elderlyManagementRate=@elderlyManagementRate,
		gxynormManageRate=@gxynormManageRate,
		manageBpControlRate=@manageBpControlRate,
		tnbnormManageRate=@tnbnormManageRate,
		manageBgControlRate=@manageBgControlRate,
		buildRate=@buildRate,
		pregnancyRate=@pregnancyRate,
		managementRate=@managementRate,
		regularMedicationRate=@regularMedicationRate,
		jsbMedicationRate=@jsbMedicationRate
		
		
		 WHERE [YEAR]=@year
		
-- Clean up temporary table
DROP TABLE #ChildData;
DROP TABLE #zzdData;
DROP TABLE  #lnrData ;
DROP TABLE  #gxyData ;
DROP TABLE  #tnbData  ;
DROP TABLE #pwData ;
DROP TABLE #FJHData ;
DROP TABLE #S1;
DROP TABLE #S2;
DROP TABLE #S3;
END;
go

