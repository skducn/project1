CREATE PROCEDURE [dbo].[ORG_SIGN_INFO] (@startDate as DATE, @endDate as DATE,@userId AS int,@orgCode NVARCHAR(50))
AS
BEGIN
      IF @userId is NOT NULL
BEGIN
WITH TEAM AS (
    SELECT
        ID AS TEAM_ID
    FROM
        T_TEAM
    WHERE
            ORG_CODE IN (SELECT ORG_SUB_CODE FROM ZYCONFIG.dbo.SYS_SUB_HOSPITAL WHERE ORG_CODE = @orgCode) OR ORG_CODE = @orgCode AND IS_DELETE = 0
),
     S1 AS (
         SELECT
             t.TEAM_ID,
             COUNT(DISTINCT a.ID) AS total,
             SUM( IIF ( a.PERFORM_STATUS = 2, 1, 0 ) ) as startPerformNum,
             SUM( IIF ( a.PERFORM_STATUS = 3, 1, 0 ) ) as finishPerformNum,
             SUM(IIF(a.SIGN_TYPE_CODE = '2',1, 0)) as familyTotal
         FROM
             T_SIGN_INFO a RIGHT JOIN TEAM t on a.TEAM_ID = t.TEAM_ID AND a.SIGN_STATUS = 1 AND a.SIGN_DATE BETWEEN  @startDate AND @endDate	GROUP BY t.TEAM_ID),S2 AS (SELECT
                                                                                                                                                                               a.TEAM_ID,
                                                                                                                                                                               COUNT(b.ITEM_ID) as serviceNum,
                                                                                                                                                                               SUM( IIF (per.ID is not NULL	, 1, 0 ) ) as finishServiceNum
                                                                                                                                                                           FROM
                                                                                                                                                                               T_SIGN_INFO a LEFT JOIN T_SERVICE_PACKAGE_ITEM b ON a.SERVICE_ID = b.PACKAGE_ID
-- 	LEFT JOIN T_SERVICE_ITEM it on b.ITEM_ID = it.Id
                                                                                                                                                                                             LEFT JOIN (
                                                                                                                                                                                   SELECT
                                                                                                                                                                                       *
                                                                                                                                                                                   FROM
                                                                                                                                                                                       (
                                                                                                                                                                                           SELECT ID,
                                                                                                                                                                                                  SIGN_INFO_ID,
                                                                                                                                                                                                  SERVICE_ITEM_ID,
                                                                                                                                                                                                  RESIDUAL_DEGREE,
                                                                                                                                                                                                  IS_IMMUNITY,
                                                                                                                                                                                                  row_number ( ) OVER ( partition BY SERVICE_ITEM_ID ORDER BY ID DESC) AS num
                                                                                                                                                                                           FROM
                                                                                                                                                                                               T_SIGN_PERFORM
                                                                                                                                                                                           WHERE
                                                                                                                                                                                                   IS_DELETE = 0
                                                                                                                                                                                       ) t
                                                                                                                                                                                   WHERE
                                                                                                                                                                                           t.num = 1
                                                                                                                                                                               ) per ON a.ID = per.SIGN_INFO_ID AND b.ITEM_ID = per.SERVICE_ITEM_ID
                                                                                                                                                                           WHERE
                                                                                                                                                                                   a.SIGN_STATUS = 1 AND a.SIGN_DATE BETWEEN  @startDate AND @endDate AND a.TEAM_ID IN (SELECT TEAM_ID FROM TEAM)	GROUP BY a.TEAM_ID)
SELECT S3.* FROM (SELECT S1.*,S2.serviceNum,S2.finishServiceNum,h.TEAM_NAME as orgName FROM S1 LEFT JOIN S2 on S1.TEAM_ID = S2.TEAM_ID LEFT JOIN T_TEAM h on S1.TEAM_ID = h.ID) S3 ORDER BY S3.orgName;
END

ELSE
BEGIN
WITH S1 AS (SELECT
                t.ORG_CODE,
                COUNT ( DISTINCT t.ID ) AS total,
                SUM ( IIF ( t.PERFORM_STATUS = 2, 1, 0 ) ) AS startPerformNum,
                SUM ( IIF ( t.PERFORM_STATUS = 3, 1, 0 ) ) AS finishPerformNum,
                SUM(IIF(t.SIGN_TYPE_CODE = '2',1, 0)) as familyTotal
            FROM
                (
                    SELECT
                        a.ID,
                        IIF ( h.ID IS NULL, a.ORG_CODE, h.ORG_CODE ) AS ORG_CODE,
                        a.PERFORM_STATUS,
                        a.SIGN_TYPE_CODE
                    FROM
                        T_SIGN_INFO a
                            LEFT JOIN ZYCONFIG.dbo.SYS_SUB_HOSPITAL h ON h.ORG_SUB_CODE = a.ORG_CODE
                    WHERE
                            a.SIGN_STATUS = 1
                      AND a.SIGN_DATE BETWEEN  @startDate AND @endDate
                ) t
            GROUP BY
                t.ORG_CODE),S2 AS (SELECT
                                       t.ORG_CODE,
                                       SUM ( IIF ( t.ITEM_ID IS NOT NULL, 1, 0 ) ) AS serviceNum,
                                       SUM ( IIF ( t.ID IS NOT NULL, 1, 0 ) ) AS finishServiceNum
                                   FROM
                                       (
                                           SELECT
                                               IIF ( h.ID IS NULL, a.ORG_CODE, h.ORG_CODE ) AS ORG_CODE,
                                               b.ITEM_ID,
                                               per.ID
                                           FROM
                                               T_SIGN_INFO a
                                                   LEFT JOIN T_SERVICE_PACKAGE_ITEM b ON a.SERVICE_ID = b.PACKAGE_ID
-- 		LEFT JOIN T_SERVICE_ITEM it ON b.ITEM_ID = it.Id
                                                   LEFT JOIN (
                                                   SELECT
                                                       *
                                                   FROM
                                                       (
                                                           SELECT
                                                               ID,
                                                               SIGN_INFO_ID,
                                                               SERVICE_ITEM_ID,
                                                               RESIDUAL_DEGREE,
                                                               IS_IMMUNITY,
                                                               row_number ( ) OVER ( partition BY SERVICE_ITEM_ID ORDER BY ID DESC ) AS num
                                                           FROM
                                                               T_SIGN_PERFORM
                                                           WHERE
                                                                   IS_DELETE = 0
                                                       ) t
                                                   WHERE
                                                           t.num = 1
                                               ) per ON a.ID = per.SIGN_INFO_ID AND b.ITEM_ID = per.SERVICE_ITEM_ID
                                                   LEFT JOIN ZYCONFIG.dbo.SYS_SUB_HOSPITAL h ON h.ORG_SUB_CODE = a.ORG_CODE
                                           WHERE
                                                   a.SIGN_STATUS = 1
                                             AND a.SIGN_DATE BETWEEN   @startDate AND @endDate
                                       ) t
                                   GROUP BY
                                       t.ORG_CODE)
SELECT S3.* FROM (SELECT S1.*,S2.serviceNum,S2.finishServiceNum,h.ORG_NAME as orgName,h.ORG_CODE as orgCode FROM S1 LEFT JOIN S2 on S1.ORG_CODE = S2.ORG_CODE LEFT JOIN ZYCONFIG.dbo.SYS_HOSPITAL h on s1.ORG_CODE = h.ORG_CODE) S3 ORDER BY S3.orgName;
END
END
go

