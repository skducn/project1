CREATE PROCEDURE [dbo].[BI_EHR_INFO]
    @ORG_CODE NVARCHAR(50),
    @START_DATE DATE,
		@END_DATE DATE
AS
BEGIN

    DECLARE @inputcheck NVARCHAR(20) = '';
	  DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE)

    -- 检测@IDCARD是否有sql注入
    IF @inputcheck LIKE '%select %'
        OR @inputcheck LIKE '%update %'
        OR @inputcheck LIKE '%insert %'
        OR @inputcheck LIKE '%delete %'
        OR @inputcheck LIKE '%truncate %'
        OR @inputcheck LIKE '%drop %'
        OR @inputcheck LIKE '%union %'
        OR @inputcheck LIKE '%exec %'
        OR @inputcheck LIKE '%xp_%'
BEGIN
        RAISERROR('输入变量值中包含sql注入！', 16, 1);
        RETURN;
END;

    IF @ORG_CODE = '370685'
BEGIN



                 SELECT
                     UP_orgcode,
                     SUM(IIF(S1.IDCARD IS NOT NULL,1,0 )) AS jdrs,
                     SUM(IIF(S2.IDCARD IS NOT NULL,1,0 ))  AS bdrs
										 INTO #S1 
                 FROM
                     (
                         SELECT
                             IDCARD,

                             ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode
                         FROM
                             T_EHR_INFO
                         WHERE
                                 CREATE_DATE <= @END_DATE

                           and FINAL_STATUS = '0'
													 AND  IS_DELETE='0'

                     ) s1

                         LEFT JOIN (

                         SELECT
                             DISTINCT IDCARD

                         FROM
                             (
                                 SELECT IDCARD  from  T_EHR_INFO WHERE id in ( SELECT ehr_id  FROM T_SNR_EXAMINATION_info WHERE INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE and VALID_STATUS=1)
                                 UNION ALL
                                 SELECT t2.zjhm FROM TB_GXY_HZSFK t1 INNER JOIN TB_GXY_HZGLK t2 ON t1.cid = t2.cid WHERE SFRQ BETWEEN @START_DATE AND @END_DATE and t1.XGBZ=0
                                 UNION ALL
                                 SELECT t2.zjhm FROM TB_GXz_HZSFK t1 INNER JOIN TB_GXz_HZGLK t2 ON t1.cid = t2.cid WHERE SFRQ BETWEEN @START_DATE AND @END_DATE and t1.XGBZ=0

                                 UNION ALL
                                 SELECT t2.zjhm FROM TB_tnb_HZSFK t1 INNER JOIN TB_tnb_HZGLK t2 ON t1.GLKBH = t2.glkbh WHERE SFRQ BETWEEN @START_DATE AND @END_DATE  and t1.XGBZ=0

                                 UNION ALL
                                 SELECT t2.IDCARD FROM t_chd_visit t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_CHD_VISIT t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_SMI_VISIT t1 INNER JOIN T_SMI_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE  BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_CHILD_HOME_VISIT t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE  and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_CHILD_EXAMINATION t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_FIRST_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.FILL_FORM_DATE BETWEEN @START_DATE AND @END_DATE
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_OTHER_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_POSTPARTUM_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_POSTPARTUM_42_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_TB_VISIT t1 INNER JOIN T_TB_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE  and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_TB_FIRST_VISIT t1 INNER JOIN T_TB_INFO t2 ON t1.INFO_ID = t2.id WHERE FILL_FORM_DATE BETWEEN @START_DATE AND @END_DATE
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_smi_VISIT t1 INNER JOIN T_smi_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_dis_VISIT_new t1 INNER JOIN T_dis_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 union all
                                 SELECT SFZH from T_YLFW_JZJL WHERE JZRQ BETWEEN @START_DATE AND @END_DATE and SCBZ=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_DNT_VISIT t1 INNER JOIN T_dnt_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                             ) s1
                         WHERE s1.IDCARD != ''
                     ) s2

                                   ON S1.IDCARD=S2.IDCARD



                 GROUP BY
                     UP_orgcode;

WITH S0 AS ( SELECT ORG_CODE, ORG_NAME FROM ZYCONFIG.DBO.SYS_HOSPITAL UNION ALL SELECT '370685', '招远卫健局' ),

            


     s1 AS (
         SELECT

             UP_orgcode as  ORG_CODE,
             ISNULL( #S1.jdrs, 0) as jdrs,
             dbo.Fn_GetPercent( ISNULL( #S1.jdrs, 0),  (SELECT RESIDENT_NUM FROM T_HOME WHERE ORG_CODE = UP_orgcode AND YEAR = @YEAR))as jkdajdl,

             ISNULL( #S1.bdrs, 0) as bdrs,
             dbo.Fn_GetPercent(ISNULL( #S1.jdrs, 0),  (SELECT RESIDENT_NUM FROM T_HOME WHERE ORG_CODE = UP_orgcode AND YEAR = @YEAR))as jkdajdl2,
             dbo.Fn_GetPercent(ISNULL( #S1.bdrs, 0),ISNULL( #S1.JDRS, 0)) as dasyl


         FROM
				 #S1
             

     )


-- 返回报表结果
SELECT S0.ORG_CODE,S0.ORG_NAME,
       isnull( ( SELECT RESIDENT_NUM FROM T_HOME WHERE ORG_CODE = S0.ORG_CODE AND YEAR =@YEAR ) ,0) AS permanentPopulation,
       ISNULL(S1.bdrs,0) AS dynamicArchives ,

       ISNULL(S1.dasyl,0.00) AS applyArchivesRate,
       ISNULL(S1.jdrs,0) AS numberFilingPersonnel,
       ISNULL(S1.jdrs,0) AS electronNumberFilingPersonnel,
       ISNULL(S1.jkdajdl2,0) AS healthRecordsRate,
       ISNULL(S1.jkdajdl,0) AS electronNumberFilingPersonnelRate
FROM  S0 LEFT JOIN s1 ON S0.ORG_CODE=S1.ORG_CODE  ORDER BY S0.ORG_CODE desc ;
END
ELSE
BEGIN


                 SELECT
                     MANAGE_ORG_CODE,
                     sum(  iif(s1.IDCARD is not null,1,0)) as jdrs,
                     sum(  iif(s2.IDCARD is not null,1,0))  AS bdrs INTO  #S11
                 FROM
                     (
                         SELECT
                             MANAGE_ORG_CODE,

                             IDCARD

                         FROM
                             T_EHR_INFO
                         WHERE
                                 CREATE_DATE <=@end_DATE
                           AND ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) = @ORG_CODE
                           AND FINAL_STATUS = '0'
													 AND IS_DELETE='0'
                     ) s1


                         LEFT JOIN (

                         SELECT
                             DISTINCT IDCARD

                         FROM
                             (   SELECT IDCARD  from  T_EHR_INFO WHERE id in ( SELECT ehr_id  FROM T_SNR_EXAMINATION_info WHERE INQUIRY_DATE BETWEEN @START_DATE AND @END_DATE and VALID_STATUS =1)
                                 UNION ALL
                                 SELECT t2.zjhm FROM TB_GXY_HZSFK t1 INNER JOIN TB_GXY_HZGLK t2 ON t1.cid = t2.cid WHERE SFRQ BETWEEN @START_DATE AND @END_DATE and t1.XGBZ=0
                                 UNION ALL
                                 SELECT t2.zjhm FROM TB_GXz_HZSFK t1 INNER JOIN TB_GXz_HZGLK t2 ON t1.cid = t2.cid WHERE SFRQ BETWEEN @START_DATE AND @END_DATE and t1.XGBZ=0
                                 UNION ALL
                                 SELECT t2.zjhm FROM TB_tnb_HZSFK t1 INNER JOIN TB_tnb_HZGLK t2 ON t1.GLKBH = t2.glkbh WHERE SFRQ BETWEEN @START_DATE AND @END_DATE  and t1.XGBZ=0

                                 UNION ALL
                                 SELECT t2.IDCARD FROM t_chd_visit t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_CHD_VISIT t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_SMI_VISIT t1 INNER JOIN T_SMI_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE  BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_CHILD_HOME_VISIT t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE  and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_CHILD_EXAMINATION t1 INNER JOIN T_CHD_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_FIRST_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.FILL_FORM_DATE BETWEEN @START_DATE AND @END_DATE
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_OTHER_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_POSTPARTUM_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_PW_POSTPARTUM_42_VISIT t1 INNER JOIN T_PW_INFO t2 ON t1.INFO_ID = t2.id WHERE t1.VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_TB_VISIT t1 INNER JOIN T_TB_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE  and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_TB_FIRST_VISIT t1 INNER JOIN T_TB_INFO t2 ON t1.INFO_ID = t2.id WHERE FILL_FORM_DATE BETWEEN @START_DATE AND @END_DATE
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_smi_VISIT t1 INNER JOIN T_smi_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_dis_VISIT_new t1 INNER JOIN T_dis_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                                 union all
                                 SELECT SFZH from T_YLFW_JZJL WHERE JZRQ BETWEEN @START_DATE AND @END_DATE and SCBZ=0
                                 UNION ALL
                                 SELECT t2.IDCARD FROM T_DNT_VISIT t1 INNER JOIN T_dnt_INFO t2 ON t1.INFO_ID = t2.id WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE and t1.IS_DELETE=0
                             ) s1
                         WHERE s1.IDCARD != ''
                     ) s2

                                   ON S1.IDCARD=S2.IDCARD

                 GROUP BY MANAGE_ORG_CODE;









WITH S0 AS (
    SELECT
        ORG_sub_CODE,
        ORG_SUB_NAME
    FROM
        ZYCONFIG.DBO.SYS_SUB_HOSPITAL
    WHERE
            org_code =@ORG_CODE UNION ALL
    SELECT
        @org_code,
        ( SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE org_code =@org_code )
),

     s2 AS (
         SELECT
             MANAGE_ORG_CODE as ORG_CODE,

             ISNULL(s1.jdrs, 0) as jdrs,
             dbo.Fn_GetPercent(ISNULL(s1.jdrs, 0), (SELECT RESIDENT_NUM FROM T_SUB_HOME WHERE ORG_SUB_CODE = MANAGE_ORG_CODE AND YEAR = @YEAR))as jkdajdl,

             ISNULL( s1.bdrs,0) as bdrs,
             dbo.Fn_GetPercent(ISNULL(s1.jdrs, 0), (SELECT RESIDENT_NUM FROM T_SUB_HOME WHERE ORG_SUB_CODE = MANAGE_ORG_CODE AND YEAR = @YEAR))as jkdajdl2,
             dbo.Fn_GetPercent(ISNULL( s1.bdrs,0), ISNULL(s1.JDRS, 0)) as dasyl
         FROM
             #S11 AS s1


     )
-- 返回报表结果
SELECT S0.ORG_SUB_CODE AS ORG_CODE ,S0.ORG_SUB_NAME AS ORG_NAME ,
       isnull( ( SELECT RESIDENT_NUM FROM T_SUB_HOME WHERE ORG_SUB_CODE = S0.ORG_SUB_CODE AND YEAR =@YEAR ) ,0) AS permanentPopulation,
       ISNULL(S2.bdrs,0) AS dynamicArchives ,

       ISNULL(S2.dasyl,0.00) AS applyArchivesRate,
       ISNULL(S2.jdrs,0) AS numberFilingPersonnel,
       ISNULL(S2.jdrs,0) AS electronNumberFilingPersonnel,
       ISNULL(S2.jkdajdl2,0) AS healthRecordsRate,
       ISNULL(S2.jkdajdl,0) AS electronNumberFilingPersonnelRate
FROM  S0 LEFT JOIN s2 ON S0.ORG_SUB_CODE=S2.ORG_CODE ORDER BY S0.ORG_SUB_CODE DESC ;
END;

END;
go

