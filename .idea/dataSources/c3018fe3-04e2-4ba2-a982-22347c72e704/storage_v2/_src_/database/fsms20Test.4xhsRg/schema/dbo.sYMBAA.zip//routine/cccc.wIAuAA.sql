CREATE PROCEDURE cccc (@years int, @months varchar(50)
)as
 	
	declare @days int;
	set @days = case 
	when @months='1' then 31
	when @months='2'and @years%4 = 0  then 28  
	when @months='2'and @years%4 = 1 then 29
else 30
	end
	print @days
go

