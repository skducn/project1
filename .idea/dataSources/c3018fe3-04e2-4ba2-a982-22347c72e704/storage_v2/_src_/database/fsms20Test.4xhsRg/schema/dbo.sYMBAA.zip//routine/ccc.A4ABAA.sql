CREATE PROCEDURE ccc (@years int, @months varchar(50))as
begin 	
	declare @days int
	set @days = case @months 
	when '1' then 31
-- 	when @years / 4 = 0 then 29 
-- 	when  @years / 4 != 0 then 28
else 30
	end
	print @days
end
go

