CREATE FUNCTION [dbo].[f_getSP1](@sourceString NVARCHAR(MAX))
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @word NCHAR(1)
	DECLARE @SP NVARCHAR(MAX)
	SET @SP = ''
	WHILE LEN(@sourceString) > 0
		BEGIN
			SET @word = LEFT(@sourceString, 1)
			--如果非汉字字符，返回''
			SET @SP = @SP + ISNULL((SELECT TOP 1 SP1 FROM [t_dic_character] WHERE [character] = @word), '')
			SET @sourceString = RIGHT(@sourceString, LEN(@sourceString) - 1)
		END
	RETURN @SP
END
go

