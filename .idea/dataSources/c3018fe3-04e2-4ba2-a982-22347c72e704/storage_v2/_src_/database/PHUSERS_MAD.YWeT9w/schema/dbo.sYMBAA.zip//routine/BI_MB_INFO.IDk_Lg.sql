CREATE  PROCEDURE [dbo].[BI_MB_INFO] 
@ORG_CODE NVARCHAR (50),
@YEAR NVARCHAR (4)
AS
BEGIN
	-- SQL注入检查
	IF @ORG_CODE LIKE '%select %' 
		OR @ORG_CODE LIKE '%update %' 
		OR @ORG_CODE LIKE '%insert %' 
		OR @ORG_CODE LIKE '%delete %' 
		OR @ORG_CODE LIKE '%truncate %' 
		OR @ORG_CODE LIKE '%drop %' 
		OR @ORG_CODE LIKE '%union %' 
		OR @ORG_CODE LIKE '%exec %' 
		OR @ORG_CODE LIKE '%xp_%'
	BEGIN
		RAISERROR ('输入变量值中包含SQL注入！', 16, 1);
		RETURN;
	END;

	IF @ORG_CODE = '370685'
	BEGIN
		-- 创建临时表 #S0
		SELECT ORG_CODE, ORG_NAME 
		INTO #S0
		FROM ZYCONFIG_MAD.DBO.SYS_HOSPITAL
		UNION ALL
		SELECT '370685', '招远卫健局';

		-- 创建临时表 #s1
		SELECT
			t2.MANAGE_ORG_CODE,
			ISNULL((SELECT ORG_CODE FROM ZYCONFIG_MAD.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
			t2.IDCARD,
			t1.cid
		INTO #s1
		FROM
			(SELECT DISTINCT ZJHM, cid FROM TB_GXY_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND QZRQ <= (@year + '-12-31')) t1
		LEFT JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0';

		-- 创建临时表 #s2
		SELECT
			CID,
			CASE
				WHEN (@YEAR < YEAR(GETDATE()) AND SUM(SFJD) = 10 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					OR (@YEAR = YEAR(GETDATE()) AND SUM(SFJD) = 10 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					THEN 1
				WHEN @YEAR = YEAR(GETDATE()) AND SUM(1) >= DATEPART(QUARTER, GETDATE()) THEN 1
				ELSE 0
			END AS NUM2
		INTO #s2
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s1) AND YEAR(SFRQ) = @YEAR AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #s3
		SELECT
			CID,
			CASE
				WHEN (@YEAR < YEAR(GETDATE()) AND SUM(SFJD) = 10 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					OR (@YEAR = YEAR(GETDATE()) AND SUM(SFJD) = 10 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					THEN 1
				WHEN @YEAR = YEAR(GETDATE()) AND SUM(1) >= DATEPART(QUARTER, GETDATE()) THEN 1
				ELSE 0
			END AS NUM2
		INTO #s3
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s1) AND SFRQ BETWEEN (@year + '-01-01') AND (@year + '-12-31')
			
						AND (SFFSDM = '1' OR SFFSDM = '2') AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #max_sfrq
		SELECT CID, MAX(SFRQ) AS max_sfrq
		INTO #max_sfrq
		FROM TB_GXY_HZSFK
		WHERE CID IN (SELECT CID FROM #s1)
		GROUP BY CID;

		-- 创建临时表 #filtered_data
		SELECT
			t.CID,
			t.SFRQ,
			t.SZY,
			t.ssy,
			s.IDCARD
		INTO #filtered_data
		FROM TB_GXY_HZSFK t
		INNER JOIN #max_sfrq m ON t.CID = m.CID AND t.SFRQ = m.max_sfrq
		INNER JOIN #s1 s ON t.CID = s.CID;

		-- 创建临时表 #s4
		SELECT
			CID,
			IIF(
				(dbo.FN_GETAGE(IDCARD, SFRQ) < 65 AND SZY < 90 AND ssy < 140)
				OR (dbo.FN_GETAGE(idcard, SFRQ) >= 65 AND SZY < 90 AND ssy < 150),
				1,
				0
			) AS num
		INTO #s4
		FROM #filtered_data;
		
		
	  SELECT cid ,1 AS NUM5 INTO #GW_GXY FROM #s1  WHERE CID  in (SELECT CID  from TB_GXY_HZSFK WHERE SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')  and ZZLXR is not null );
		
			SELECT
			s.cid ,
			1 AS NUM6
			
			
		INTO #GXY_SFYY
		FROM TB_GXY_HZSFK t
		INNER JOIN #max_sfrq m ON t.CID = m.CID AND t.SFRQ = m.max_sfrq
		INNER JOIN #s1 s ON t.CID = s.CID
		WHERE t.SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')
		and t.vid in (SELECT vid  from TB_GXY_SFFYXX )
		;
		

		-- 创建临时表 #s6
		SELECT
			#s1.cid,
			IIF(SUM(#s2.num2) >= 1, 1, 0) AS NUM2,
			IIF(SUM(#s3.num2) >= 1, 1, 0) AS NUM3,
			IIF(SUM(#s4.num) >= 1, 1, 0) AS NUM4,
			IIF(SUM(#GW_GXY.num5) >= 1, 1, 0) AS NUM5,
			IIF(SUM(#GXY_SFYY.num6) >= 1, 1, 0) AS NUM6
			
			
		INTO #s6
		FROM #s1
		LEFT JOIN #s2 ON #s1.CID = #s2.CID
		LEFT JOIN #s3 ON #s1.CID = #s3.CID
		LEFT JOIN #s4 ON #s1.CID = #s4.CID
		LEFT JOIN #GW_GXY ON #S1.CID=#GW_GXY.CID
		LEFT JOIN #GXY_SFYY ON #S1.CID=#GXY_SFYY.CID
		GROUP BY #s1.cid;




--- 糖尿病 
 SELECT
            t2.MANAGE_ORG_CODE,
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG_MAD.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
            t2.IDCARD,
            t1.GLKBH
        INTO #TNB1
        FROM
            (SELECT DISTINCT ZJHM, GLKBH FROM TB_TNB_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND QZRQ <= (@year + '-12-31')) t1
            INNER JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0';

        -- 定义临时表 #TNB2
        SELECT
            GLKBH,
            CASE
                WHEN (@YEAR < YEAR(GETDATE()) AND SUM(SFJD) = 10 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                OR (@YEAR = YEAR(GETDATE()) AND SUM(SFJD) = 10 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                THEN 1
                WHEN @YEAR = YEAR(GETDATE()) AND SUM(1) >= DATEPART(QUARTER, GETDATE())
                THEN 1
                ELSE 0
            END AS NUM2
        INTO #TNB2
        FROM
            (SELECT
                GLKBH,
                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #TNB1)
                AND SFRQ BETWEEN (@year + '-01-01') AND (@year + '-12-31')
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
        GROUP BY s2.GLKBH;

        -- 定义临时表 #TNB3
        SELECT
            GLKBH,
            CASE
                WHEN (@YEAR < YEAR(GETDATE()) AND COUNT(SFJD) >= 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                OR (@YEAR = YEAR(GETDATE()) AND COUNT(SFJD) >= 4 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                THEN 1
                WHEN @YEAR = YEAR(GETDATE()) AND SUM(1) >= DATEPART(QUARTER, GETDATE())
                THEN 1
                ELSE 0
            END AS NUM2
        INTO #TNB3
        FROM
            (SELECT
                GLKBH,
                                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #TNB1)
                AND SFRQ BETWEEN (@year + '-01-01') AND (@year + '-12-31')
                AND (SFFSDM = '1' OR SFFSDM = '2')
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
 GROUP BY s2.GLKBH;

        -- 定义临时表 #max_sfrq
        SELECT GLKBH, MAX(SFRQ) AS max_sfrq
        INTO #tnb_max_sfrq
        FROM TB_TNB_HZSFK
        WHERE GLKBH IN (SELECT GLKBH FROM #TNB1)
        GROUP BY GLKBH;

        -- 定义临时表 #filtered_data
        SELECT
            t.GLKBH,
            t.SFRQ,
            t.FPG,
            s.IDCARD
        INTO #tnb_filtered_data
        FROM
            TB_TNB_HZSFK t
            INNER JOIN #tnb_max_sfrq m ON t.GLKBH = m.GLKBH AND t.SFRQ = m.max_sfrq
            INNER JOIN #TNB1 s ON t.GLKBH = s.GLKBH;

        -- 定义临时表 #TNB4
        SELECT
            GLKBH,
            IIF(TRY_CAST(FPG AS DECIMAL(10, 2)) < 7.00, 1, 0) AS num
        INTO #TNB4
 FROM #tnb_filtered_data
        WHERE ISNUMERIC(FPG) = 1;
				
				
				-- 糖尿病管理 
				 SELECT GLKBH ,1 AS NUM5 INTO #GW_TNB FROM #TNB1  WHERE GLKBH  in (SELECT GLKBH  from TB_TNB_HZSFK WHERE SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')  and ZZLXR is not null );
		
			SELECT
			s.GLKBH ,
			1 AS NUM6
			
			
		INTO #TNB_SFYY
		FROM TB_tnb_HZSFK t
		INNER JOIN #TNB_max_sfrq m ON t.GLKBH = m.GLKBH AND t.SFRQ = m.max_sfrq
		INNER JOIN #TNB1 s ON t.GLKBH = s.GLKBH
		WHERE t.SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')
		and t.SFKBH in (SELECT SFKBH  from TB_TNB_SFFYXX )

        -- 定义临时表 #TNB6
        SELECT
            s1.GLKBH,
            IIF(SUM(s2.NUM2) >= 1, 1, 0) AS NUM2,
            IIF(SUM(s3.NUM2) >= 1, 1, 0) AS NUM3,
            IIF(SUM(s4.num) >= 1, 1, 0) AS NUM4,
						IIF(SUM(s5.num5) >= 1, 1, 0) AS NUM5,
						IIF(SUM(s6.num6) >= 1, 1, 0) AS NUM6
        INTO #TNB6
        FROM
            #TNB1 s1
            LEFT JOIN #TNB2 s2 ON s1.GLKBH = s2.GLKBH
            LEFT JOIN #TNB3 s3 ON s1.GLKBH = s3.GLKBH
            LEFT JOIN #TNB4 s4 ON s1.GLKBH = s4.GLKBH
						LEFT JOIN #GW_TNB S5 ON S1.GLKBH =S5.GLKBH
						LEFT JOIN #TNB_SFYY S6 ON S1.GLKBH =S6.GLKBH
        GROUP BY s1.GLKBH;

        -- 定义临时表 #TNB5
        SELECT
            S0.ORG_CODE,
            S0.ORG_NAME,
            ISNULL(CEILING((SELECT RESIDENT_NUM FROM T_HOME WHERE ORG_CODE = S0.ORG_CODE AND YEAR = @YEAR) * 0.8 * 0.252 * 0.4), 0) AS TNB_shallManageNum,
            COUNT(DISTINCT s1.GLKBH) AS TNB_managedNum,
            ISNULL(SUM(S6.NUM2), 0) AS TNB_normManageNum2,
            ISNULL(SUM(S6.NUM3), 0) AS TNB_normManageNum,
            ISNULL(SUM(S6.NUM4), 0) AS TNB_lastFbgStandardNum,
						 ISNULL(SUM(S6.NUM5), 0) AS TNB_TNBGL,
						 ISNULL(SUM(S6.NUM6), 0) AS TNB_TNBYY
						 
						
        INTO #TNB5
        FROM
            #s0 S0
            LEFT JOIN #TNB1 s1 ON s1.UP_orgcode = S0.ORG_CODE
 LEFT JOIN #TNB6 s6 ON s1.GLKBH = s6.GLKBH
        GROUP BY
            S0.ORG_CODE,
            S0.ORG_NAME;




		-- 创建临时表 #s5
		SELECT
			#S0.ORG_CODE,
			#S0.ORG_NAME,
			
			ISNULL(COUNT(#s6.cid), 0) AS managedNum,
			ISNULL(SUM(#s6.num2), 0) AS normManageNum2,
			ISNULL(SUM(#s6.num3), 0) AS normManageNum,
			ISNULL(SUM(#s6.num4), 0) AS lastBpStandardNum,
			ISNULL(SUM(#s6.num5), 0) AS GWGL,
			ISNULL(SUM(#s6.num6), 0) AS SFYY
		INTO #s5
		FROM #S0
		LEFT JOIN #s1 ON #S0.org_code = #s1.UP_orgcode
		LEFT JOIN #s6 ON #s1.CID = #s6.CID
		GROUP BY #S0.ORG_CODE, #S0.ORG_NAME;
		
		
		SELECT
			M1.ORG_CODE,
			M1.ORG_NAME,
			m1.GWGL as gwGxyManageNum ,
			m1.gwgl as gwGxyNum,
			100.00 as gwGxyManageRate,
			M2.TNB_TNBGL as gwTnbManageNum,
			M2.TNB_TNBGL  as gwTnbNum,
			100.00 as gwTnbManageRate,
			m1.normManageNum as  gxynormManageNum,
			m1.managedNum as gxymanagedNum,
			dbo.Fn_GetPercent(M1.normManageNum, M1.managedNum) AS gxynormManageRate,
			M2.TNB_normManageNum as tnbnormManageNum,
			M2.TNB_managedNum as tnbmanagedNum,
			dbo.Fn_GetPercent(M2.TNB_normManageNum, M2.TNB_managedNum) AS tnbnormManageRate,
			M1.SFYY AS gxyUserDurgNum,
			dbo.Fn_GetPercent( M1.SFYY, M1.managedNum) AS gxyUserDurgRate,
			M2.TNB_TNBYY AS tnbUserDurgNum,
			dbo.Fn_GetPercent(M2.TNB_TNBYY, M2.TNB_managedNum) AS tnbUserDurgRate,
			M1.lastBpStandardNum AS lastBpStandardNum,
			dbo.Fn_GetPercent( M1.lastBpStandardNum, M1.managedNum) AS manageBpControlRate,
			M2.TNB_lastFbgStandardNum AS lastFbgStandardNum,
			dbo.Fn_GetPercent(M2.TNB_lastFbgStandardNum, M2.TNB_managedNum) AS manageBgControlRate,
	    100.00 AS mbKnowlRate,
			100.00 AS mbDangerlRate
		FROM #s5 M1 LEFT JOIN #TNB5 M2  ON M1.ORG_CODE=M2.ORG_CODE  
		ORDER BY org_code DESC;

		-- 删除临时表
		DROP TABLE #S0, #s1, #s2, #s3, #max_sfrq, #filtered_data, #s4, #s6, #s5,#GW_GXY ,#GXY_SFYY,#TNB1,#TNB2,#TNB3,#TNB4,#TNB5,#TNB6,#tnb_max_sfrq,#tnb_filtered_data,#GW_TNB,#TNB_SFYY;
	END
	ELSE
	BEGIN
		-- 创建临时表 #S0
		SELECT
			ORG_sub_CODE,
			ORG_SUB_NAME
		INTO #S00
		FROM ZYCONFIG_MAD.DBO.SYS_SUB_HOSPITAL
		WHERE org_code = @ORG_CODE
		UNION ALL
		SELECT
			@org_code,
			(SELECT org_name FROM ZYCONFIG_MAD.dbo.SYS_HOSPITAL WHERE org_code = @org_code);

		-- 创建临时表 #s1
		SELECT
			t2.MANAGE_ORG_CODE,
			t2.MANAGE_ORG_name,
			t2.IDCARD,
						t1.cid
		INTO #s11
		FROM
			(SELECT DISTINCT ZJHM, cid FROM TB_GXY_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND QZRQ <= (@year + '-12-31')) t1
		LEFT JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0'
		WHERE ISNULL((SELECT ORG_CODE FROM ZYCONFIG_MAD.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@org_code));

		-- 创建临时表 #s2
		SELECT
			CID,
			CASE
				WHEN (@YEAR < YEAR(GETDATE()) AND SUM(SFJD) = 10 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					OR (@YEAR = YEAR(GETDATE()) AND SUM(SFJD) = 10 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					THEN 1
				WHEN @YEAR = YEAR(GETDATE()) AND SUM(1) >= DATEPART(QUARTER, GETDATE()) THEN 1
				ELSE 0
			END AS NUM2
		INTO #s22
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s11) AND YEAR(SFRQ) = @YEAR AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #s3
		SELECT
			CID,
			CASE
				WHEN (@YEAR < YEAR(GETDATE()) AND SUM(SFJD) = 10 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					OR (@YEAR = YEAR(GETDATE()) AND SUM(SFJD) = 10 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)))
					THEN 1
				WHEN @YEAR = YEAR(GETDATE()) AND SUM(1) >= DATEPART(QUARTER, GETDATE()) THEN 1
				ELSE 0
			END AS NUM2
		INTO #s33
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s11) AND SFRQ BETWEEN (@year + '-01-01') AND (@year + '-12-31') AND (SFFSDM = '1' OR SFFSDM = '2') AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #max_sfrq
		SELECT CID, MAX(SFRQ) AS max_sfrq
		INTO #max_sfrq1
		FROM TB_GXY_HZSFK
		WHERE CID IN (SELECT CID FROM #s11)
		GROUP BY CID;

		-- 创建临时表 #filtered_data
		SELECT
			t.CID,
			t.SFRQ,
			t.SZY,
			t.ssy,
			s.IDCARD
		INTO #filtered_data1
		FROM TB_GXY_HZSFK t
		INNER JOIN #max_sfrq1 m ON t.CID = m.CID AND t.SFRQ = m.max_sfrq
		INNER JOIN #s11 s ON t.CID = s.CID;

		-- 创建临时表 #s4
		SELECT
			CID,
			IIF(
				(dbo.FN_GETAGE(IDCARD, SFRQ) < 65 AND SZY < 90 AND ssy < 140)
				OR (dbo.FN_GETAGE(idcard, SFRQ) >= 65 AND SZY < 90 AND ssy < 150),
				1,
				0
			) AS num
		INTO #s44
		FROM #filtered_data1;
		
		
		
		 SELECT cid ,1 AS NUM5 INTO #GW_GXY_s1 FROM #s11 WHERE CID  in (SELECT CID  from TB_GXY_HZSFK WHERE SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')  and ZZLXR is not null );
		
			SELECT
			s.cid ,
			1 AS NUM6
			
			
		INTO #GXY_SFYY_s1
		FROM TB_GXY_HZSFK t
		INNER JOIN #max_sfrq1 m ON t.CID = m.CID AND t.SFRQ = m.max_sfrq
		INNER JOIN #s11 s ON t.CID = s.CID
		WHERE t.SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')
		and t.vid in (SELECT vid  from TB_GXY_SFFYXX )
		;

		-- 创建临时表 #s6
		SELECT
			#s11.cid,
			IIF(SUM(#s22.num2) >= 1, 1, 0) AS NUM2,
			IIF(SUM(#s33.num2) >= 1, 1, 0) AS NUM3,
			IIF(SUM(#s44.num) >= 1, 1, 0) AS NUM4,
			IIF(SUM(#GW_GXY_s1.num5) >= 1, 1, 0) AS NUM5,
			IIF(SUM(#GXY_SFYY_s1.num6) >= 1, 1, 0) AS NUM6
			
		INTO #s66
		FROM #s11
		LEFT JOIN #s22 ON #s11.CID = #s22.CID
		LEFT JOIN #s33 ON #s11.CID = #s33.CID
		LEFT JOIN #s44 ON #s11.CID = #s44.CID
		LEFT JOIN #GW_GXY_s1 ON #s11.cid=#GW_GXY_s1.cid
		LEFT JOIN #GXY_SFYY_s1 on #s11.cid=#GXY_SFYY_s1.cid 
		GROUP BY #s11.cid;

		-- 创建临时表 #s5
		SELECT
			#S00.ORG_sub_CODE AS ORG_CODE,
			#S00.ORG_SUB_NAME AS ORG_NAME,
			ISNULL(COUNT(#s66.cid), 0) AS managedNum,
			ISNULL(SUM(#s66.num2), 0) AS normManageNum2,
			ISNULL(SUM(#s66.num3), 0) AS normManageNum,
			ISNULL(SUM(#s66.num4), 0) AS lastBpStandardNum,
			ISNULL(SUM(#s66.num5), 0) AS GWGL,
			ISNULL(SUM(#s66.num6), 0) AS SFYY
			
		INTO #s55
		FROM #S00
		LEFT JOIN #s11 ON #S00.ORG_sub_CODE = #s11.MANAGE_ORG_CODE
		LEFT JOIN #s66 ON #s11.CID = #s66.CID
	
		GROUP BY #S00.ORG_sub_CODE, #S00.ORG_SUB_NAME;
		
		
		-- 糖尿病
		
		    SELECT
            t2.MANAGE_ORG_CODE,
            t2.MANAGE_ORG_NAME,
            t2.IDCARD,
            t1.GLKBH
        INTO #TNBS11
        FROM
            (SELECT DISTINCT ZJHM, GLKBH FROM TB_TNB_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND QZRQ <= (@YEAR + '-12-31')) t1
            INNER JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0'
        WHERE
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG_MAD.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t2.MANAGE_ORG_CODE), MANAGE_ORG_CODE) = @ORG_CODE;

        -- 定义临时表 #TNBS2
        SELECT
            GLKBH,
            CASE
                WHEN (@YEAR < YEAR(GETDATE()) AND COUNT(SFJD) >= 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                OR (@YEAR = YEAR(GETDATE()) AND COUNT(SFJD) >= 4 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                THEN 1
                WHEN @YEAR = YEAR(GETDATE()) AND SUM(1) >= DATEPART(QUARTER, GETDATE())
                THEN 1
                ELSE 0
            END AS NUM2
        INTO #TNBS22
        FROM
            (SELECT
                GLKBH,
                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #TNBS11)
                AND SFRQ BETWEEN (@YEAR + '-01-01') AND (@YEAR + '-12-31')
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
        GROUP BY s2.GLKBH;

        -- 定义临时表 #TNBS3
        SELECT
            GLKBH,
            CASE
                WHEN (@YEAR < YEAR(GETDATE()) AND COUNT(SFJD) >= 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                OR (@YEAR = YEAR(GETDATE()) AND COUNT(SFJD) >= 4 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_TNB_HZGLK WHERE GLKBH = S2.GLKBH)))
                THEN 1
                WHEN @YEAR = YEAR(GETDATE()) AND COUNT(SFJD) >= DATEPART(QUARTER, GETDATE())
                THEN 1
                ELSE 0
            END AS NUM2
        INTO #TNBS33
        FROM
            (SELECT
                GLKBH,
                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #TNBS11)
                AND SFRQ BETWEEN (@YEAR + '-01-01') AND (@YEAR + '-12-31')
                AND (SFFSDM = '1' OR SFFSDM = '2')
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
        GROUP BY s2.GLKBH;

        -- 定义临时表 #TNBmax_sfrq
        SELECT GLKBH, MAX(SFRQ) AS max_sfrq
        INTO #TNBmax_sfrq1
        FROM TB_TNB_HZSFK
        WHERE GLKBH IN (SELECT GLKBH FROM #TNBS11)
        GROUP BY GLKBH;

        -- 定义临时表 #TNB
				        -- 定义临时表 #TNBfiltered_data
        SELECT
            t.GLKBH,
            t.SFRQ,
            t.FPG,
            s.IDCARD
        INTO #TNBfiltered_data1
        FROM
            TB_TNB_HZSFK t
            INNER JOIN #TNBmax_sfrq1 m ON t.GLKBH = m.GLKBH AND t.SFRQ = m.max_sfrq
            INNER JOIN #TNBS11 s ON t.GLKBH = s.GLKBH;

        -- 定义临时表 #TNBS4
        SELECT
            GLKBH,
            IIF(TRY_CAST(FPG AS DECIMAL(10, 2)) < 7.00, 1, 0) AS num
        INTO #TNBS44
        FROM #TNBfiltered_data1
        WHERE ISNUMERIC(FPG) = 1;
				
				
				--糖尿病管理
				
				
				 SELECT GLKBH ,1 AS NUM5 INTO #GW_TNB_s1 FROM #TNBS11 WHERE GLKBH  in (SELECT GLKBH  from TB_TNB_HZSFK WHERE SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')  and ZZLXR is not null );
		
			SELECT
			s.GLKBH ,
			1 AS NUM6
			
			
		INTO #TNB_SFYY_S1
		FROM TB_tnb_HZSFK t
		INNER JOIN #TNBmax_sfrq1 m ON t.GLKBH = m.GLKBH AND t.SFRQ = m.max_sfrq
		INNER JOIN #TNBS11 s ON t.GLKBH = s.GLKBH
		WHERE t.SFRQ BETWEEN 
		(@year+'-01-01') and 	(@year+'-12-31')
		and t.SFKBH in (SELECT SFKBH  from TB_TNB_SFFYXX )
				
				
				

        -- 定义临时表 #TNBS6
        SELECT
            s1.GLKBH,
            IIF(SUM(s2.NUM2) >= 1, 1, 0) AS NUM2,
            IIF(SUM(s3.NUM2) >= 1, 1, 0) AS NUM3,
            IIF(SUM(s4.num) >= 1, 1, 0) AS NUM4,
						IIF(SUM(s5.num5) >= 1, 1, 0) AS NUM5,
						IIF(SUM(s6.num6) >= 1, 1, 0) AS NUM6
        INTO #TNBS66
        FROM
            #TNBS11 s1
            LEFT JOIN #TNBS22 s2 ON s1.GLKBH = s2.GLKBH
            LEFT JOIN #TNBS33 s3 ON s1.GLKBH = s3.GLKBH
            LEFT JOIN #TNBS44 s4 ON s1.GLKBH = s4.GLKBH
						LEFT JOIN #GW_TNB_s1  s5 on s1.GLKBH=s5.GLKBH
						LEFT JOIN #TNB_SFYY_S1 s6 on s1.GLKBH=s6.GLKBH
        GROUP BY s1.GLKBH;

        -- 定义临时表 #TNBS5
        SELECT
            S0.ORG_sub_CODE as ORG_CODE,
            S0.ORG_SUB_NAME AS ORG_NAME,
            ISNULL(COUNT(s6.GLKBH), 0) AS TNB_managedNum,
            ISNULL(SUM(S6.NUM2), 0) AS TNB_normManageNum2,
            ISNULL(SUM(S6.NUM3), 0) AS TNB_normManageNum,
            ISNULL(SUM(S6.NUM4), 0) AS TNB_lastFbgStandardNum,
						ISNULL(SUM(S6.NUM5), 0) AS TNB_TNBGL,
						ISNULL(SUM(S6.NUM6), 0) AS TNB_TNBYY
        INTO #TNBS55
        FROM
            #S00 S0
            LEFT JOIN #TNBS11 s1 ON S0.ORG_sub_CODE = s1.MANAGE_ORG_CODE
            LEFT JOIN #TNBS66 s6 ON s1.GLKBH = s6.GLKBH
        GROUP BY
            S0.ORG_sub_CODE,
            S0.ORG_SUB_NAME;

        -- 最终选择结果
     
		
		  
		
		
		
		
		

			SELECT
			M1.ORG_CODE,
			M1.ORG_NAME,
			m1.GWGL as gwGxyManageNum ,
			m1.gwgl as gwGxyNum,
			100.00 as gwGxyManageRate,
			M2.TNB_TNBGL as gwTnbManageNum,
			M2.TNB_TNBGL  as gwTnbNum,
			100.00 as gwTnbManageRate,
			m1.normManageNum as  gxynormManageNum,
			m1.managedNum as gxymanagedNum,
			dbo.Fn_GetPercent(M1.normManageNum, M1.managedNum) AS gxynormManageRate,
			M2.TNB_normManageNum as tnbnormManageNum,
			M2.TNB_managedNum as tnbmanagedNum,
			dbo.Fn_GetPercent(M2.TNB_normManageNum, M2.TNB_managedNum) AS tnbnormManageRate,
			M1.SFYY AS gxyUserDurgNum,
			dbo.Fn_GetPercent( M1.SFYY, M1.managedNum) AS gxyUserDurgRate,
			M2.TNB_TNBYY AS tnbUserDurgNum,
			dbo.Fn_GetPercent(M2.TNB_TNBYY, M2.TNB_managedNum) AS tnbUserDurgRate,
			M1.lastBpStandardNum AS lastBpStandardNum,
			dbo.Fn_GetPercent( M1.lastBpStandardNum, M1.managedNum) AS manageBpControlRate,
			M2.TNB_lastFbgStandardNum AS lastFbgStandardNum,
			dbo.Fn_GetPercent(M2.TNB_lastFbgStandardNum, M2.TNB_managedNum) AS manageBgControlRate,
	    100.00 AS mbKnowlRate,
			100.00 AS mbDangerlRate
		
			
			
		FROM #s55 M1 LEFT JOIN #TNBS55 M2  ON M1.ORG_CODE=M2.ORG_CODE  
		ORDER BY org_code DESC;

		-- 删除临时表
		DROP TABLE #S00, #s11, #s22, #s33, #max_sfrq1, #filtered_data1, #s44, #s66, #s55;
	END
END;
go

