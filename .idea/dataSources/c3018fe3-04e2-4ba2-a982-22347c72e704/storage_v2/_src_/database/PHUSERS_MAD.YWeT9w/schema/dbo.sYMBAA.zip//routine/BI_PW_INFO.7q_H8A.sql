CREATE PROCEDURE [dbo].[BI_PW_INFO]
	
		@ORG_CODE NVARCHAR(50),
		 @START_DATE DATE ,
		@END_DATE DATE 
    
AS
BEGIN

    DECLARE @inputcheck NVARCHAR(20) = '';
		 DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE)
		
		    -- 检测@IDCARD是否有sql注入
    IF @inputcheck LIKE '%select %'
        OR @inputcheck LIKE '%update %'
        OR @inputcheck LIKE '%insert %'
        OR @inputcheck LIKE '%delete %'
        OR @inputcheck LIKE '%truncate %'
        OR @inputcheck LIKE '%drop %'
        OR @inputcheck LIKE '%union %'
        OR @inputcheck LIKE '%exec %'
        OR @inputcheck LIKE '%xp_%'
    BEGIN
        RAISERROR('输入变量值中包含sql注入！', 16, 1);
        RETURN;
    END;
		
		IF @ORG_CODE = '370685'
    BEGIN
		--卫建委账号逻辑
		-- 创建临时表 temp_t0
				SELECT
						ORG_CODE,
						ORG_NAME
				INTO #temp_t0
				FROM ZYCONFIG.DBO.SYS_HOSPITAL
				UNION ALL
				SELECT '370685', '招远市卫建局';

				-- 创建临时表 temp_t1
				SELECT
						t2.MANAGE_ORG_CODE,
						ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
						t2.IDCARD,
						t1.ID
				INTO #temp_t1
				FROM
						(SELECT DISTINCT ID, IDCARD FROM T_PW_INFO WHERE IS_DELETE = 0 and  CLOSED_STATUS = 0) t1
				INNER JOIN T_EHR_INFO t2 ON t1.IDCARD = t2.IDCARD
				WHERE
						ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t2.MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE))
						AND t2.IS_DELETE=0 AND FINAL_STATUS !='2'
						;

				-- 创建临时表 temp_t2
				SELECT
						s2.ORG_CODE,
						ISNULL((SELECT LIVE_BIRTH_NUM FROM T_HOME WHERE ORG_CODE = s2.ORG_CODE AND YEAR = @YEAR), 0) AS LIVE_BIRTH_NUM,
						SUM(s2.num1) AS num1,
						SUM(s2.num2) AS num2
				INTO #temp_t2
				FROM (
						SELECT
								i.ID,
								#temp_t1.UP_orgcode AS ORG_CODE,
								IIF(
										i.ID IN (SELECT INFO_ID FROM T_PW_FIRST_VISIT WHERE FILL_FORM_DATE BETWEEN   @START_DATE AND @END_DATE AND PREGNANT_WEEK < 13 and IS_DELETE=0),
										1,
										0
								) AS num1,
								IIF(
										i.ID IN (SELECT INFO_ID FROM T_PW_POSTPARTUM_VISIT WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE AND IS_DELETE=0),
										1,
										0
								) AS num2
						FROM
								T_PW_INFO i
						LEFT JOIN #temp_t1 ON i.ID = #temp_t1.ID
						WHERE
								i.ID IN (SELECT ID FROM #temp_t1)
				) s2
				GROUP BY
						s2.ORG_CODE;

				-- 最终查询
				SELECT 
						#temp_t0.ORG_CODE,
						#temp_t0.ORG_NAME,
						IIF(#temp_t2.LIVE_BIRTH_NUM = '-1', 0, ISNULL(#temp_t2.LIVE_BIRTH_NUM, 0)) AS LIVE_BIRTH_NUM,
						ISNULL(#temp_t2.num1, 0) AS build,
						ISNULL(#temp_t2.num2, 0) AS pregnancy,
						dbo.Fn_GetPercent(#temp_t2.num1, #temp_t2.LIVE_BIRTH_NUM) AS buildRate,
						dbo.Fn_GetPercent(#temp_t2.num2, #temp_t2.LIVE_BIRTH_NUM) AS pregnancyRate
				FROM
						#temp_t0
				LEFT JOIN #temp_t2 ON #temp_t0.ORG_CODE = #temp_t2.ORG_CODE;

				-- 删除临时表
				DROP TABLE #temp_t0;
				DROP TABLE #temp_t1;
				DROP TABLE #temp_t2;

		END;
    ELSE
    BEGIN
		--其他账号逻辑
		  		-- 创建临时表 tb0
				SELECT
						ORG_SUB_CODE AS ORG_CODE,
						ORG_SUB_NAME AS ORG_NAME
				INTO #tb0
				FROM
						ZYCONFIG.DBO.SYS_SUB_HOSPITAL 
				WHERE
						org_code = @ORG_CODE
				UNION ALL
				SELECT
						@ORG_CODE AS ORG_CODE,
						(SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE org_code = @ORG_CODE) AS ORG_NAME;

				-- 创建临时表 tb1
				SELECT
						e.MANAGE_ORG_CODE AS ORG_CODE,
						e.MANAGE_ORG_NAME AS ORG_NAME,
						e.IDCARD,
						info.ID
				INTO #tb1
				FROM
						(SELECT DISTINCT ID, IDCARD FROM T_PW_INFO WHERE IS_DELETE = 0 and  CLOSED_STATUS = 0) info
				INNER JOIN T_EHR_INFO e ON info.IDCARD = e.IDCARD
				WHERE
				
				 e.IS_DELETE=0 AND e.FINAL_STATUS !='2' AND
						ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = e.MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@ORG_CODE)) ;

				-- 创建临时表 tb2
				SELECT
						s2.ORG_CODE,
						SUM(s2.num1) AS num1,
						SUM(s2.num2) AS num2
				INTO #tb2
				FROM (
						SELECT
								i.ID,
								#tb1.ORG_CODE,
								IIF(
										i.ID IN (SELECT INFO_ID FROM T_PW_FIRST_VISIT WHERE FILL_FORM_DATE BETWEEN   @START_DATE AND @END_DATE AND PREGNANT_WEEK < 13 and IS_DELETE=0),
										1,
										0
								) AS num1,
								IIF(
										i.ID IN (SELECT INFO_ID FROM T_PW_POSTPARTUM_VISIT WHERE VISIT_DATE BETWEEN @START_DATE AND @END_DATE AND IS_DELETE=0),
										1,
										0
								) AS num2
						FROM
								T_PW_INFO i
						LEFT JOIN #tb1 ON i.ID = #tb1.ID
						WHERE
								i.ID IN (SELECT ID FROM #tb1)
				) s2
				GROUP BY
						s2.ORG_CODE;

				-- 创建临时表 tb3
				SELECT 
						#tb0.ORG_CODE,
						#tb0.ORG_NAME,
					 0 AS LIVE_BIRTH_NUM,
						ISNULL(#tb2.num1, 0) AS build,
						ISNULL(#tb2.num2, 0) AS pregnancy
				INTO #tb3
				FROM #tb0
				LEFT JOIN #tb2 ON #tb0.ORG_CODE = #tb2.ORG_CODE;

				-- 最终查询
				SELECT 
						*,
						dbo.Fn_GetPercent(#tb3.build, #tb3.LIVE_BIRTH_NUM) AS buildRate,
						dbo.Fn_GetPercent(#tb3.pregnancy, #tb3.LIVE_BIRTH_NUM) AS pregnancyRate
				FROM #tb3;

				-- 删除临时表
				DROP TABLE #tb0;
				DROP TABLE #tb1;
				DROP TABLE #tb2;
				DROP TABLE #tb3;
		END;

END;
go

