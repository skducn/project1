CREATE PROCEDURE [dbo].[BI_AGENT_INFO] AS BEGIN-- 创建临时表 #S0
SELECT
    ORG_CODE,
    ORG_NAME INTO #S0
FROM
    ZYCONFIG.DBO.SYS_HOSPITAL UNION ALL
SELECT
    '370685',
    '招远卫健局';
-- 创建临时表 #s1
SELECT
    IDCARD,
    ISNULL( ( SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE ), MANAGE_ORG_CODE ) AS UP_orgcode INTO #S1
FROM
    T_EHR_INFO
WHERE
        FINAL_STATUS = '0'
  AND IS_DELETE = '0'
  AND IS_OPEN=1 -- 居民注册或绑定数
SELECT DISTINCT
    IDCARD INTO #S2
FROM
    T_AGENT
WHERE
        AGENT_TYPE = 1;
-- 上一年度居民注册或绑定数（人）
SELECT DISTINCT
    IDCARD INTO #S3
FROM
    T_AGENT
WHERE
        AGENT_TYPE = 1
  AND ACCESS_TIME BETWEEN DATEFROMPARTS(YEAR(GETDATE()) - 1, 1, 1)
    AND DATEFROMPARTS(YEAR(GETDATE()) - 1, 12, 31);
--本年度居民注册或绑定数（人）
SELECT DISTINCT
    IDCARD INTO #S4
FROM
    T_AGENT
WHERE
        AGENT_TYPE = 1
  AND ACCESS_TIME BETWEEN DATEFROMPARTS(YEAR(GETDATE()) , 1, 1)
    AND DATEFROMPARTS(YEAR(GETDATE()) , 12, 31);
-- 居民浏览或查询数（人）
SELECT DISTINCT
    IDCARD INTO #S5
FROM
    T_AGENT
WHERE
        AGENT_TYPE = 2;
-- 上一年度居民浏览或查询数（人）
SELECT DISTINCT
    IDCARD INTO #S6
FROM
    T_AGENT
WHERE
        AGENT_TYPE = 2
  AND ACCESS_TIME BETWEEN DATEFROMPARTS(YEAR(GETDATE()) -1, 1, 1)
    AND DATEFROMPARTS(YEAR(GETDATE()) - 1, 12, 31);
--本年度居民浏览或查询数（人）
SELECT DISTINCT
    IDCARD INTO #S7
FROM
    T_AGENT
WHERE
        AGENT_TYPE = 2
  AND ACCESS_TIME BETWEEN DATEFROMPARTS(YEAR(GETDATE()) , 1, 1)
    AND DATEFROMPARTS(YEAR(GETDATE()) , 12, 31);
SELECT
    #s1.up_orgcode AS org_code,
    COUNT ( * ) AS num1,
    SUM ( iif ( #s2.idcard IS NOT NULL, 1, 0 ) ) AS num2,
    SUM ( iif ( #s3.idcard IS NOT NULL, 1, 0 ) ) AS num3,
    SUM ( iif ( #s4.idcard IS NOT NULL, 1, 0 ) ) AS num4,
    SUM ( iif ( #s5.idcard IS NOT NULL, 1, 0 ) ) AS num5,
    SUM ( iif ( #s6.idcard IS NOT NULL, 1, 0 ) ) AS num6,
    SUM ( iif ( #s7.idcard IS NOT NULL, 1, 0 ) ) AS num7 INTO #s8
FROM
    #s1
        LEFT JOIN #s2 ON #s1.IDCARD=#s2.IDCARD
        LEFT JOIN #s3 ON #s1.IDCARD=#s3.IDCARD
        LEFT JOIN #s4 ON #s1.IDCARD=#s4.IDCARD
        LEFT JOIN #s5 ON #s1.IDCARD=#s5.IDCARD
        LEFT JOIN #s6 ON #s1.IDCARD=#s6.IDCARD
        LEFT JOIN #s7 ON #s1.IDCARD=#s7.IDCARD
GROUP BY
    #s1.up_orgcode ;
SELECT
    #S0.ORG_CODE,
    #S0.ORG_NAME,
    ISNULL( #S8.num1, 0 ) AS openEhrNum,
    ISNULL( #S8.num2, 0 ) AS AccessNum,
    dbo.Fn_GetPercent(ISNULL( #S8.num2, 0),ISNULL( #S8.num1, 0)) as AccessRate,
    ISNULL( #S8.num3, 0 ) AS lastYearAccessNum,
    dbo.Fn_GetPercent(ISNULL( #S8.num3, 0),ISNULL( #S8.num1, 0)) as lastYearAccessRate,
    ISNULL( #S8.num4, 0 ) AS yearAccessNum,
    dbo.Fn_GetPercent(ISNULL( #S8.num4, 0),ISNULL( #S8.num1, 0)) as yearAccessRate,
    ISNULL( #S8.num5, 0 ) AS visitNum,
    dbo.Fn_GetPercent(ISNULL(#S8.num5, 0),ISNULL( #S8.num1, 0)) as visitRate,
    ISNULL( #S8.num6, 0 ) AS lastYearVisitNum,
    dbo.Fn_GetPercent(ISNULL(#S8.num6, 0),ISNULL( #S8.num1, 0)) as lastYearVisitRate,
    ISNULL( #S8.num7, 0 ) AS yearVisitNum,
    dbo.Fn_GetPercent(ISNULL(#S8.num7, 0),ISNULL( #S8.num1, 0)) as yearVisitRate

FROM
    #S0
        LEFT JOIN #s8 ON #S0.ORG_CODE=#S8.ORG_CODE
ORDER BY
    #S0.ORG_CODE DESC;

END
go

