CREATE VIEW [dbo].[TB_EB_ETJKTJDJ] AS SELECT
	a.ID as TJDJBDH, 
	a.MANAGE_ORG_CODE as YLJGDM, 
	a.ID  as ETBSFID, 
	a.MANAGE_ORG_CODE as DJJGDM, 
	a.NAME as XM, 
	a.SEX_CODE as XB, 
	a.BIRTH as CSRQ, 
	cast(c.PREGNANT_WEEK as VARCHAR) + '.' + cast(c.PREGNANT_DAY as VARCHAR) as CSYZ, 
	a.FATHER_NAME as FQXM, 
	a.MOTHER_NAME as MQXM, 
	NULL as YQYNBYY, 
	null as BYYM, 
	1 as TS, 
	null as CC, 
	null as ZSCSM, 
	null as CSQKBM, 
	null as CSQKMC, 
	null as YWGM, 
	b.WEIGHT as CSTZ, 
	b.HEIGHT as CSSG, 
	a.MOTHER_PHONE as LXDH, 
	'' as JZLY, 
	'' as HK, 
	null as CSQXBZ, 
	REPLACE(c.DISEASE_SCREENING_NAME, '其他', c.OTHER_DISEASE_SCREENING) as XSEJBSCJG, 
	null as ABO_XX, 
	null as RH_XX, 
	a.CREATE_DATE as JDRQ, 
	null as JDRYGH, 
	null as JDRYXM, 
	a.CREATE_ORG_NAME as JDJGMC, 
	null as FYFSDM, 
	null as FYFSMC, 
	null as MJ, 
	null as XGBZ, 
		CONVERT(DATEtime,CASE
		WHEN CONVERT(varchar(100), b.UPDATE_DATE, 23) != '1900-01-01' THEN b.UPDATE_DATE
		ELSE null
	END , 120) as  SJSCSJ,
	null as YLYL1, 
	null as YLYL2
FROM
	T_CHILD_INFO as a
LEFT JOIN T_CHILD_EXAMINATION b ON a.ID = b.INFO_ID
LEFT JOIN T_CHILD_HOME_VISIT c on a.ID = c.INFO_ID
WHERE b.ID is not NULL
go

