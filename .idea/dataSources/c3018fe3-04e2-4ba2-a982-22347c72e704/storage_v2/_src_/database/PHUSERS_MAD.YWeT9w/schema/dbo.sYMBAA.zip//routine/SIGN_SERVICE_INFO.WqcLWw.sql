CREATE PROCEDURE [dbo].[SIGN_SERVICE_INFO]
@startDate as DATE, @endDate as DATE, @userId int,@orgCode NVARCHAR(50)
AS
BEGIN
IF @userId is NULL BEGIN
 WITH S1 AS (SELECT
	t.ORG_CODE,
	COUNT ( t.ID ) AS total,
	SUM ( IIF ( t.SERVICE_PACKAGE = '基础服务包', 1, 0 ) ) AS pac1Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '0~6岁儿童个性签约服务包', 1, 0 ) ) AS pac2Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '孕产妇个性签约服务包', 1, 0 ) ) AS pac3Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '老年人个性签约服务包', 1, 0 ) ) AS pac4Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '高血压个性签约服务包', 1, 0 ) ) AS pac5Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '糖尿病个性签约服务包', 1, 0 ) ) AS pac6Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '一般人群健康包', 1, 0 ) ) AS pac7Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '基础服务包（2019版）', 1, 0 ) ) AS pac8Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '0-6岁儿童个性签约服务包（2019版）', 1, 0 ) ) AS pac9Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '糖尿病个性签约服务包（2019版）', 1, 0 ) ) AS pac10Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '孕产妇个性签约服务包（2019版）', 1, 0 ) ) AS pac11Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '高血压个性签约服务包（2019版）', 1, 0 ) ) AS pac12Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '老年人签约服务包（2019版）', 1, 0 ) ) AS pac13Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '糖尿病', 1, 0 ) ) AS pac14Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '60-64岁老年人个性包', 1, 0 ) ) AS pac15Num,
	SUM ( IIF ( t.SERVICE_PACKAGE = '60-64岁老年人签约服务包（2019版）', 1, 0 ) ) AS pac16Num
FROM
	(
	SELECT
		a.ID,
		IIF ( h.ID IS NULL, a.ORG_CODE, h.ORG_CODE ) AS ORG_CODE,
		b.SERVICE_PACKAGE
	FROM
		T_SIGN_INFO a
		LEFT JOIN T_SERVICE_PACKAGE b ON a.SERVICE_ID = b.ID
		LEFT JOIN ZYCONFIG.dbo.SYS_SUB_HOSPITAL h ON h.ORG_SUB_CODE = a.ORG_CODE
	WHERE
		a.SIGN_STATUS = 1
		AND a.SERVICE_ID IS NOT NULL
		AND a.SIGN_DATE BETWEEN  @startDate AND @endDate
	) t
GROUP BY
	t.ORG_CODE
)
SELECT t1.*,h.ORG_NAME as ORG_NAME FROM S1 t1 LEFT JOIN ZYCONFIG.dbo.SYS_HOSPITAL h on t1.ORG_CODE = h.ORG_CODE ORDER BY h.ORG_NAME;
END
ELSE BEGIN
	WITH TEAM AS (
            SELECT
                ID AS TEAM_ID
            FROM
                T_TEAM
            WHERE
               ORG_CODE IN (SELECT ORG_SUB_CODE FROM ZYCONFIG.dbo.SYS_SUB_HOSPITAL WHERE ORG_CODE = @orgCode) OR ORG_CODE = @orgCode
                AND IS_DELETE = 0
        ),
	S1 AS (
	SELECT
  t.TEAM_ID,
  COUNT(a.ID) as total,
	SUM (IIF(b.SERVICE_PACKAGE = '基础服务包', 1,0)) as pac1Num,
	SUM (IIF(b.SERVICE_PACKAGE = '0~6岁儿童个性签约服务包', 1,0)) as pac2Num,
	SUM (IIF(b.SERVICE_PACKAGE = '孕产妇个性签约服务包', 1,0)) as pac3Num,
	SUM (IIF(b.SERVICE_PACKAGE = '老年人个性签约服务包', 1,0)) as pac4Num,
	SUM (IIF(b.SERVICE_PACKAGE = '高血压个性签约服务包', 1,0)) as pac5Num,
	SUM (IIF(b.SERVICE_PACKAGE = '糖尿病个性签约服务包', 1,0)) as pac6Num,
	SUM (IIF(b.SERVICE_PACKAGE = '一般人群健康包', 1,0)) as pac7Num,
	SUM (IIF(b.SERVICE_PACKAGE = '基础服务包（2019版）', 1,0)) as pac8Num,
	SUM (IIF(b.SERVICE_PACKAGE = '0-6岁儿童个性签约服务包（2019版）', 1,0)) as pac9Num,
	SUM (IIF(b.SERVICE_PACKAGE = '糖尿病个性签约服务包（2019版）', 1,0)) as pac10Num,
	SUM (IIF(b.SERVICE_PACKAGE = '孕产妇个性签约服务包（2019版）', 1,0)) as pac11Num,
	SUM (IIF(b.SERVICE_PACKAGE = '高血压个性签约服务包（2019版）', 1,0)) as pac12Num,
	SUM (IIF(b.SERVICE_PACKAGE = '老年人签约服务包（2019版）', 1,0)) as pac13Num,
	SUM (IIF(b.SERVICE_PACKAGE = '糖尿病', 1,0)) as pac14Num,
	SUM (IIF(b.SERVICE_PACKAGE = '60-64岁老年人个性包', 1,0)) as pac15Num,
	SUM (IIF(b.SERVICE_PACKAGE = '60-64岁老年人签约服务包（2019版）', 1,0)) as pac16Num
FROM
	T_SIGN_INFO a LEFT JOIN T_SERVICE_PACKAGE b on a.SERVICE_ID = b.ID
	RIGHT JOIN TEAM t on a.TEAM_ID = t.TEAM_ID
	 and  a.SIGN_STATUS = 1 AND a.SERVICE_ID is NOT NULL AND a.SIGN_DATE BETWEEN  @startDate AND @endDate  GROUP BY t.TEAM_ID
	)
SELECT S1.*, t.TEAM_NAME as orgName FROM S1 LEFT JOIN T_TEAM t ON TEAM_ID = t.ID ORDER BY t.TEAM_NAME;
END
END
go

