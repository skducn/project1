CREATE PROCEDURE [dbo].[BI_GXY_INFO] 
@ORG_CODE NVARCHAR (50),
  @START_DATE DATE ,
		@END_DATE DATE 
AS
BEGIN

 DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE)
	-- SQL注入检查
	IF @ORG_CODE LIKE '%select %' 
		OR @ORG_CODE LIKE '%update %' 
		OR @ORG_CODE LIKE '%insert %' 
		OR @ORG_CODE LIKE '%delete %' 
		OR @ORG_CODE LIKE '%truncate %' 
		OR @ORG_CODE LIKE '%drop %' 
		OR @ORG_CODE LIKE '%union %' 
		OR @ORG_CODE LIKE '%exec %' 
		OR @ORG_CODE LIKE '%xp_%'
	BEGIN
		RAISERROR ('输入变量值中包含SQL注入！', 16, 1);
		RETURN;
	END;

	IF @ORG_CODE = '370685'
	BEGIN
		-- 创建临时表 #S0
		SELECT ORG_CODE, ORG_NAME 
		INTO #S0
		FROM ZYCONFIG.DBO.SYS_HOSPITAL
		UNION ALL
		SELECT '370685', '招远卫健局';
    
		
	
	
		
		
		-- 创建临时表 #s1
	
		SELECT
			t2.MANAGE_ORG_CODE,
			ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
			t2.IDCARD,
			t1.cid,t1.CREATE_TIME as CREATE_DATE
		INTO #s1
		FROM
			(SELECT DISTINCT ZJHM, cid,CREATE_TIME FROM TB_GXY_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND JKSJ <=@END_DATE) t1
		LEFT JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0' and t1.CID in (SELECT  CID from  TB_GXY_HZSFK WHERE SFRQ BETWEEN @START_DATE AND  @END_DATE and  XGBZ='0');
		
		
		
			-- 查询应随访次数  
			
			 SELECT  cid  , (SELECT DATEDIFF(qq, iif(CREATE_date > @START_DATE,CREATE_date,@START_DATE),@END_DATE )+1) AS QuarterDifference   INTO #visit_num    from #s1 ;

		-- 创建临时表 #s2
		SELECT
			CID,
			CASE
			WHEN 
					 ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where CID=S2.CID ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID)and  VALID_STATUS=1))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where CID=S2.CID )) and  DATEPART(QUARTER, @END_DATE) !=4 THEN 1
				ELSE 0
			END AS NUM2
		INTO #s2
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s1) AND SFRQ BETWEEN @START_DATE AND @END_DATE  AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #s3
		SELECT
			CID,
			CASE
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where CID=S2.CID ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID) and VALID_STATUS=1 ))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where CID=S2.CID ))  and  DATEPART(QUARTER, @END_DATE) !=4 THEN 1
				ELSE 0
			END AS NUM2
		INTO #s3
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s1) AND SFRQ BETWEEN @START_DATE  AND @END_DATE 
			
						AND (SFFSDM = '1' OR SFFSDM = '2') AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #max_sfrq
		SELECT CID, MAX(SFRQ) AS max_sfrq
		INTO #max_sfrq
		FROM TB_GXY_HZSFK
		WHERE CID IN (SELECT CID FROM #s1)
		GROUP BY CID;

		-- 创建临时表 #filtered_data
		SELECT
			t.CID,
			t.SFRQ,
			t.SZY,
			t.ssy,
			s.IDCARD
		INTO #filtered_data
		FROM TB_GXY_HZSFK t
		INNER JOIN #max_sfrq m ON t.CID = m.CID AND t.SFRQ = m.max_sfrq
		INNER JOIN #s1 s ON t.CID = s.CID;

		-- 创建临时表 #s4
		SELECT
			CID,
			IIF(
				(dbo.FN_GETAGE(IDCARD, SFRQ) < 65 AND SZY < 90 AND ssy < 140)
				OR (dbo.FN_GETAGE(idcard, SFRQ) >= 65 AND SZY < 90 AND ssy < 150),
				1,
				0
			) AS num
		INTO #s4
		FROM #filtered_data;

		-- 创建临时表 #s6
		SELECT
			#s1.cid,
			IIF(SUM(#s2.num2) >= 1, 1, 0) AS NUM2,
			IIF(SUM(#s3.num2) >= 1, 1, 0) AS NUM3,
			IIF(SUM(#s4.num) >= 1, 1, 0) AS NUM4
		INTO #s6
		FROM #s1
		LEFT JOIN #s2 ON #s1.CID = #s2.CID
		LEFT JOIN #s3 ON #s1.CID = #s3.CID
		LEFT JOIN #s4 ON #s1.CID = #s4.CID
		GROUP BY #s1.cid;

		-- 创建临时表 #s5
		SELECT
			#S0.ORG_CODE,
			#S0.ORG_NAME,
			ISNULL((SELECT HTN_NUM FROM T_HOME WHERE ORG_CODE = #S0.ORG_CODE AND YEAR = @YEAR) , 0) AS shallManageNum,
			ISNULL(COUNT(#s6.cid), 0) AS managedNum,
			ISNULL(SUM(#s6.num2), 0) AS normManageNum2,
			ISNULL(SUM(#s6.num3), 0) AS normManageNum,
			ISNULL(SUM(#s6.num4), 0) AS lastBpStandardNum
		INTO #s5
		FROM #S0
		LEFT JOIN #s1 ON #S0.org_code = #s1.UP_orgcode
		LEFT JOIN #s6 ON #s1.CID = #s6.CID
		GROUP BY #S0.ORG_CODE, #S0.ORG_NAME;

		SELECT
			*,
			dbo.Fn_GetPercent(normManageNum, managedNum) AS normManageRate,
			dbo.Fn_GetPercent(lastBpStandardNum, managedNum) AS manageBpControlRate
		FROM #s5
		ORDER BY org_code DESC;

		-- 删除临时表
		DROP TABLE #S0, #s1, #s2, #s3, #max_sfrq, #filtered_data, #s4, #s6, #s5;
	END
	ELSE
	BEGIN
		-- 创建临时表 #S0
		SELECT
			ORG_sub_CODE,
			ORG_SUB_NAME
		INTO #S00
		FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL
		WHERE org_code = @ORG_CODE
		UNION ALL
		SELECT
			@org_code,
			(SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE org_code = @org_code);

		-- 创建临时表 #s1
		SELECT
			t2.MANAGE_ORG_CODE,
			t2.MANAGE_ORG_name,
			t2.IDCARD,
						t1.cid,
						t1.CREATE_TIME as CREATE_DATE
		INTO #s11
		FROM
			(SELECT DISTINCT ZJHM, cid ,CREATE_TIME FROM TB_GXY_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND JKSJ <= @END_DATE) t1
		LEFT JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0'
		WHERE ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@org_code))  and t1.CID in (SELECT  CID from  TB_GXY_HZSFK WHERE SFRQ BETWEEN @START_DATE AND  @END_DATE and XGBZ='0') ;
		
		
		
		
		SELECT  cid  , (SELECT DATEDIFF(qq, iif(CREATE_date > @START_DATE,CREATE_date,@START_DATE),@END_DATE )+1) AS QuarterDifference   INTO #visit_num1    from #S11

		-- 创建临时表 #s2
		SELECT
			CID,
			CASE
			
			WHEN 
					 ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where CID=S2.CID ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID) and VALID_STATUS=1))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where CID=S2.CID )) and  DATEPART(QUARTER, @END_DATE) !=4 THEN 1
				ELSE 0
			END AS NUM2
		INTO #s22
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s11) AND SFRQ BETWEEN @START_DATE AND @END_DATE AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #s3
		SELECT
			CID,
			CASE
			when 
			 ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where CID=S2.CID ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_GXY_HZGLK WHERE CID = s2.CID) and VALID_STATUS=1))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where CID=S2.CID )) and  DATEPART(QUARTER, @END_DATE) !=4 THEN 1
				ELSE 0
			END AS NUM2
		INTO #s33
		FROM
			(SELECT CID, DATEPART(QUARTER, SFRQ) AS SFJD FROM TB_GXY_HZSFK WHERE CID IN (SELECT CID FROM #s11) AND SFRQ BETWEEN @START_DATE  AND @END_DATE  AND (SFFSDM = '1' OR SFFSDM = '2') AND xgbz = '0' GROUP BY CID, DATEPART(QUARTER, SFRQ)) s2
		GROUP BY s2.CID;

		-- 创建临时表 #max_sfrq
		SELECT CID, MAX(SFRQ) AS max_sfrq
		INTO #max_sfrq1
		FROM TB_GXY_HZSFK
		WHERE CID IN (SELECT CID FROM #s11)
		GROUP BY CID;

		-- 创建临时表 #filtered_data
		SELECT
			t.CID,
			t.SFRQ,
			t.SZY,
			t.ssy,
			s.IDCARD
		INTO #filtered_data1
		FROM TB_GXY_HZSFK t
		INNER JOIN #max_sfrq1 m ON t.CID = m.CID AND t.SFRQ = m.max_sfrq
		INNER JOIN #s11 s ON t.CID = s.CID;

		-- 创建临时表 #s4
		SELECT
			CID,
			IIF(
				(dbo.FN_GETAGE(IDCARD, SFRQ) < 65 AND SZY < 90 AND ssy < 140)
				OR (dbo.FN_GETAGE(idcard, SFRQ) >= 65 AND SZY < 90 AND ssy < 150),
				1,
				0
			) AS num
		INTO #s44
		FROM #filtered_data1;

		-- 创建临时表 #s6
		SELECT
			#s11.cid,
			IIF(SUM(#s22.num2) >= 1, 1, 0) AS NUM2,
			IIF(SUM(#s33.num2) >= 1, 1, 0) AS NUM3,
			IIF(SUM(#s44.num) >= 1, 1, 0) AS NUM4
		INTO #s66
		FROM #s11
		LEFT JOIN #s22 ON #s11.CID = #s22.CID
		LEFT JOIN #s33 ON #s11.CID = #s33.CID
		LEFT JOIN #s44 ON #s11.CID = #s44.CID
		GROUP BY #s11.cid;

		-- 创建临时表 #s5	
		SELECT
			#S00.ORG_sub_CODE AS ORG_CODE,
			#S00.ORG_SUB_NAME AS ORG_NAME,
			ISNULL((SELECT TOP 1 HTN_NUM FROM T_SUB_HOME WHERE ORG_SUB_CODE = #S00.ORG_sub_CODE AND YEAR = @YEAR) , 0) as shallManageNum,
			ISNULL(COUNT(#s66.cid), 0) AS managedNum,
			ISNULL(SUM(#s66.num2), 0) AS normManageNum2,
			ISNULL(SUM(#s66.num3), 0) AS normManageNum,
			ISNULL(SUM(#s66.num4), 0) AS lastBpStandardNum
		INTO #s55
		FROM #S00
		LEFT JOIN #s11 ON #S00.ORG_sub_CODE = #s11.MANAGE_ORG_CODE
		LEFT JOIN #s66 ON #s11.CID = #s66.CID
		GROUP BY #S00.ORG_sub_CODE, #S00.ORG_SUB_NAME;

		SELECT
			*,
			dbo.Fn_GetPercent(normManageNum, managedNum) AS normManageRate,
			dbo.Fn_GetPercent(lastBpStandardNum, managedNum) AS manageBpControlRate
		FROM #s55
		ORDER BY ORG_CODE DESC;

		-- 删除临时表
		DROP TABLE #S00, #s11, #s22, #s33, #max_sfrq1, #filtered_data1, #s44, #s66, #s55;
	END
END;
go

