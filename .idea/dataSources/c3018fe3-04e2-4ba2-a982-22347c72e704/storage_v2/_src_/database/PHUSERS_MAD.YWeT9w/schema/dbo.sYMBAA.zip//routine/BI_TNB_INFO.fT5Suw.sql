CREATE PROCEDURE [dbo].[BI_TNB_INFO]
    @ORG_CODE NVARCHAR(50),
   @START_DATE DATE ,
		@END_DATE DATE 
AS
BEGIN
DECLARE @YEAR   NVARCHAR(4);
		SET @YEAR =YEAR( @START_DATE)

    -- SQL注入检查
    IF @ORG_CODE LIKE '%select %' 
        OR @ORG_CODE LIKE '%update %' 
        OR @ORG_CODE LIKE '%insert %' 
        OR @ORG_CODE LIKE '%delete %' 
        OR @ORG_CODE LIKE '%truncate %' 
        OR @ORG_CODE LIKE '%drop %' 
        OR @ORG_CODE LIKE '%union %' 
        OR @ORG_CODE LIKE '%exec %' 
        OR @ORG_CODE LIKE '%xp_%'
    BEGIN
        RAISERROR ('输入变量值中包含SQL注入！', 16, 1);
        RETURN;
    END;

    -- 如果 @ORG_CODE 为 '370685'，执行以下逻辑
    IF @ORG_CODE = '370685'
    BEGIN
        -- 定义临时表 #S0
        SELECT ORG_CODE, ORG_NAME 
        INTO #S0
        FROM ZYCONFIG.DBO.SYS_HOSPITAL 
        UNION ALL 
        SELECT '370685', '招远卫健局';

        -- 定义临时表 #S1
        SELECT
            t2.MANAGE_ORG_CODE,
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
            t2.IDCARD,
            t1.GLKBH,
						t1.CREATE_TIME
        INTO #S1
        FROM
            (SELECT DISTINCT ZJHM, GLKBH ,CREATE_TIME FROM TB_TNB_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND QZRQ <= @END_DATE) t1
            INNER JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0' AND T1.GLKBH IN ( SELECT GLKBH FROM TB_TNB_HZSFK WHERE SFRQ BETWEEN @START_DATE 
						AND  @END_DATE   and xgbz='0'
						
						);
						
						-- 应查询随访次数
						SELECT  GLKBH,(SELECT DATEDIFF(qq, iif(CREATE_TIME> @START_DATE,CREATE_TIME,@START_DATE),@END_DATE )+1) AS QuarterDifference   INTO #visit_num    from #s1 ;
						
						
						

        -- 定义临时表 #S2
        SELECT
            GLKBH,
            CASE
						WHEN
             ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where GLKBH=S2.GLKBH ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_tnb_HZGLK WHERE GLKBH = s2.GLKBH)))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where GLKBH=S2.GLKBH)) THEN 1
				ELSE 0
			END AS NUM2
        INTO #S2
        FROM
            (SELECT
                GLKBH,
                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #S1)
                AND SFRQ BETWEEN @START_DATE AND @END_DATE
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
        GROUP BY s2.GLKBH;

        -- 定义临时表 #S3
        SELECT
            GLKBH,
            CASE
						WHEN
             ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where GLKBH=S2.GLKBH ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_tnb_HZGLK WHERE GLKBH = s2.GLKBH) and  VALID_STATUS=1))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num where GLKBH=S2.GLKBH)) and  DATEPART(QUARTER, @END_DATE) !=4 THEN 1
				ELSE 0
			END AS NUM2
        INTO #S3
        FROM
            (SELECT
                GLKBH,
                                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #S1)
                AND SFRQ BETWEEN @START_DATE AND @END_DATE
                AND (SFFSDM = '1' OR SFFSDM = '2')
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
 GROUP BY s2.GLKBH;

        -- 定义临时表 #max_sfrq
        SELECT GLKBH, MAX(SFRQ) AS max_sfrq
        INTO #max_sfrq
        FROM TB_TNB_HZSFK
        WHERE GLKBH IN (SELECT GLKBH FROM #S1)
        GROUP BY GLKBH;

        -- 定义临时表 #filtered_data
        SELECT
            t.GLKBH,
            t.SFRQ,
            t.FPG,
            s.IDCARD
        INTO #filtered_data
        FROM
            TB_TNB_HZSFK t
            INNER JOIN #max_sfrq m ON t.GLKBH = m.GLKBH AND t.SFRQ = m.max_sfrq
            INNER JOIN #S1 s ON t.GLKBH = s.GLKBH;

        -- 定义临时表 #S4
        SELECT
            GLKBH,
            IIF(TRY_CAST(FPG AS DECIMAL(10, 2)) < 7.00, 1, 0) AS num
        INTO #S4
 FROM #filtered_data
        WHERE ISNUMERIC(FPG) = 1;

        -- 定义临时表 #S6
        SELECT
            s1.GLKBH,
            IIF(SUM(s2.NUM2) >= 1, 1, 0) AS NUM2,
            IIF(SUM(s3.NUM2) >= 1, 1, 0) AS NUM3,
            IIF(SUM(s4.num) >= 1, 1, 0) AS NUM4
        INTO #S6
        FROM
            #S1 s1
            LEFT JOIN #S2 s2 ON s1.GLKBH = s2.GLKBH
            LEFT JOIN #S3 s3 ON s1.GLKBH = s3.GLKBH
            LEFT JOIN #S4 s4 ON s1.GLKBH = s4.GLKBH
        GROUP BY s1.GLKBH;

        -- 定义临时表 #S5
        SELECT
            S0.ORG_CODE,
            S0.ORG_NAME,
            ISNULL((SELECT DM_NUM FROM T_HOME WHERE ORG_CODE = S0.ORG_CODE AND YEAR = @YEAR) , 0) AS shallManageNum,
            COUNT(DISTINCT s1.GLKBH) AS managedNum,
            ISNULL(SUM(S6.NUM2), 0) AS normManageNum2,
            ISNULL(SUM(S6.NUM3), 0) AS normManageNum,
            ISNULL(SUM(S6.NUM4), 0) AS lastFbgStandardNum
        INTO #S5
        FROM
            #S0 S0
            LEFT JOIN #S1 s1 ON s1.UP_orgcode = S0.ORG_CODE
 LEFT JOIN #S6 s6 ON s1.GLKBH = s6.GLKBH
        GROUP BY
            S0.ORG_CODE,
            S0.ORG_NAME;

        -- 最终选择结果
        SELECT
            *,
            ISNULL(dbo.Fn_GetPercent(normManageNum, managedNum), 0.00) AS normManageRate,
            ISNULL(dbo.Fn_GetPercent(lastFbgStandardNum, managedNum), 0.00) AS manageBgControlRate
        FROM #S5
        ORDER BY org_code DESC;

        -- 删除临时表
        DROP TABLE #S0;
        DROP TABLE #S1;
        DROP TABLE #S2;
        DROP TABLE #S3;
        DROP TABLE #max_sfrq;
        DROP TABLE #filtered_data;
        DROP TABLE #S4;
        DROP TABLE #S6;
        DROP TABLE #S5;
    END
    ELSE
    BEGIN
        -- 定义临时表 #S0
        SELECT
            ORG_sub_CODE,
            ORG_SUB_NAME
        INTO #S00
        FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL
               WHERE org_code = @ORG_CODE
        UNION ALL
        SELECT
            @ORG_CODE,
            (SELECT org_name FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE org_code = @ORG_CODE);

        -- 定义临时表 #S1
        SELECT
            t2.MANAGE_ORG_CODE,
            t2.MANAGE_ORG_NAME,
            t2.IDCARD,
            t1.GLKBH,
						t1.CREATE_TIME 
						
        INTO #S11
        FROM
            (SELECT DISTINCT ZJHM, GLKBH,CREATE_TIME FROM TB_TNB_HZGLK WHERE XGBZ = '0' AND SFZZGL = '0' AND QZRQ <= @END_DATE) t1
            INNER JOIN T_EHR_INFO t2 ON t1.ZJHM = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0'  AND T1.GLKBH IN ( SELECT GLKBH FROM TB_TNB_HZSFK WHERE SFRQ BETWEEN @START_DATE 
						AND  @END_DATE   and  XGBZ='0'
						
						)
						
						
        WHERE
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = t2.MANAGE_ORG_CODE), MANAGE_ORG_CODE) = @ORG_CODE;

-- 应查询随访次数
						SELECT  GLKBH,(SELECT DATEDIFF(qq, iif(CREATE_TIME> @START_DATE,CREATE_TIME,@START_DATE),@END_DATE )+1) AS QuarterDifference   INTO #visit_num1    from #s11 ;



        -- 定义临时表 #S2
        SELECT
            GLKBH,
           CASE
						WHEN
             ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where GLKBH=S2.GLKBH ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_tnb_HZGLK WHERE GLKBH = s2.GLKBH) and  VALID_STATUS=1
						 ))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where GLKBH=S2.GLKBH))  and  DATEPART(QUARTER, @END_DATE) !=4 THEN 1
				ELSE 0
			END AS NUM2
        INTO #S22
        FROM
            (SELECT
                GLKBH,
                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #S11)
                AND SFRQ BETWEEN @START_DATE AND @END_DATE
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
        GROUP BY s2.GLKBH;

        -- 定义临时表 #S3
        SELECT
            GLKBH,
           CASE
						WHEN
             ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where GLKBH=S2.GLKBH ) AND DATEPART(QUARTER, @END_DATE) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT ZJHM FROM TB_tnb_HZGLK WHERE GLKBH = s2.GLKBH)and  VALID_STATUS=1))
					THEN 1
				WHEN ( count (SFJD) = (SELECT QuarterDifference  from #visit_num1 where GLKBH=S2.GLKBH)) and  DATEPART(QUARTER, @END_DATE) !=4 THEN 1
				ELSE 0
			END AS NUM2
        INTO #S33
        FROM
            (SELECT
                GLKBH,
                DATEPART(QUARTER, SFRQ) AS SFJD
            FROM
                TB_TNB_HZSFK
            WHERE
                GLKBH IN (SELECT GLKBH FROM #S11)
                AND SFRQ BETWEEN @START_DATE AND @END_DATE
                AND (SFFSDM = '1' OR SFFSDM = '2')
                AND xgbz = '0'
            GROUP BY
                GLKBH,
                DATEPART(QUARTER, SFRQ)) s2
        GROUP BY s2.GLKBH;

        -- 定义临时表 #max_sfrq
        SELECT GLKBH, MAX(SFRQ) AS max_sfrq
        INTO #max_sfrq1
        FROM TB_TNB_HZSFK
        WHERE GLKBH IN (SELECT GLKBH FROM #S11)
        GROUP BY GLKBH;

        -- 定义临时表 #
				        -- 定义临时表 #filtered_data
        SELECT
            t.GLKBH,
            t.SFRQ,
            t.FPG,
            s.IDCARD
        INTO #filtered_data1
        FROM
            TB_TNB_HZSFK t
            INNER JOIN #max_sfrq1 m ON t.GLKBH = m.GLKBH AND t.SFRQ = m.max_sfrq
            INNER JOIN #S11 s ON t.GLKBH = s.GLKBH;

        -- 定义临时表 #S4
        SELECT
            GLKBH,
            IIF(TRY_CAST(FPG AS DECIMAL(10, 2)) < 7.00, 1, 0) AS num
        INTO #S44
        FROM #filtered_data1
        WHERE ISNUMERIC(FPG) = 1;

        -- 定义临时表 #S6
        SELECT
            s1.GLKBH,
            IIF(SUM(s2.NUM2) >= 1, 1, 0) AS NUM2,
            IIF(SUM(s3.NUM2) >= 1, 1, 0) AS NUM3,
            IIF(SUM(s4.num) >= 1, 1, 0) AS NUM4
        INTO #S66
        FROM
            #S11 s1
            LEFT JOIN #S22 s2 ON s1.GLKBH = s2.GLKBH
            LEFT JOIN #S33 s3 ON s1.GLKBH = s3.GLKBH
            LEFT JOIN #S44 s4 ON s1.GLKBH = s4.GLKBH
        GROUP BY s1.GLKBH;

        -- 定义临时表 #S5
        SELECT
            S0.ORG_sub_CODE,
            S0.ORG_SUB_NAME,
            ISNULL((SELECT top 1 DM_NUM FROM T_SUB_HOME WHERE ORG_sub_CODE = S0.ORG_sub_CODE AND YEAR = @YEAR) , 0) AS xqngxyglrs,
            ISNULL(COUNT(s6.GLKBH), 0) AS yglgxyrs,
            ISNULL(SUM(S6.NUM2), 0) AS GXYGLRS,
            ISNULL(SUM(S6.NUM3), 0) AS GFGXYGLRS,
            ISNULL(SUM(S6.NUM4), 0) AS zjycdbrs
        INTO #S55
        FROM
            #S00 S0
            LEFT JOIN #S11 s1 ON S0.ORG_sub_CODE = s1.MANAGE_ORG_CODE
            LEFT JOIN #S66 s6 ON s1.GLKBH = s6.GLKBH
        GROUP BY
            S0.ORG_sub_CODE,
            S0.ORG_SUB_NAME;

        -- 最终选择结果
        SELECT
            S5.ORG_SUB_CODE AS ORG_CODE,
            S5.ORG_SUB_NAME AS ORG_NAME,
            ISNULL(xqngxyglrs, 0) AS shallManageNum,
            ISNULL(yglgxyrs, 0) AS managedNum,
            ISNULL(GXYGLRS, 0) AS normManageNum2,
            ISNULL(GFGXYGLRS, 0) AS normManageNum,
            ISNULL(zjycdbrs, 0) AS lastFbgStandardNum,
            ISNULL(dbo.Fn_GetPercent(GFGXYGLRS, yglgxyrs), 0) AS normManageRate,
            ISNULL(dbo.Fn_GetPercent(zjycdbrs, yglgxyrs), 0) AS manageBgControlRate
        FROM #S55 as s5
        ORDER BY ORG_CODE DESC;

        -- 删除临时表
        DROP TABLE #S00;
        DROP TABLE #S11;
        DROP TABLE #S22;
        DROP TABLE #S33;
        DROP TABLE #max_sfrq1;
        DROP TABLE #filtered_data1;
        DROP TABLE #S44;
        DROP TABLE #S66;
        DROP TABLE #S55;
    END
END;
go

