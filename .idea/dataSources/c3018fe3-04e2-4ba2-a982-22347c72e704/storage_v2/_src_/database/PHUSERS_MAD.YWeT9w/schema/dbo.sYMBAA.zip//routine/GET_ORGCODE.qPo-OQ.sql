CREATE FUNCTION [dbo].[GET_ORGCODE] (
    @ORG_CODE VARCHAR(50)
) 
RETURNS @orgcodes TABLE (
    ORG_CODE VARCHAR(50)
)
AS
BEGIN
    IF @ORG_CODE = '370685' 
    BEGIN
        INSERT INTO @orgcodes (ORG_CODE)
        SELECT ORG_CODE 
        FROM ZYCONFIG_MAD.dbo.SYS_HOSPITAL 
        UNION ALL
        SELECT code 
        FROM ZYCONFIG_MAD.dbo.sys_org;
    END 
    ELSE 
    BEGIN
        INSERT INTO @orgcodes (ORG_CODE)
        VALUES (@ORG_CODE);
    END;

    RETURN;
END;
go

