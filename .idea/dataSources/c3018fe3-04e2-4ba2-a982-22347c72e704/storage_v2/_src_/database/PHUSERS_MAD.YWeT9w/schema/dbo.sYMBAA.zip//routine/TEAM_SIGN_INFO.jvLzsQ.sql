CREATE PROCEDURE [dbo].[TEAM_SIGN_INFO]
  @YEAR NVARCHAR(4), @userId AS int
AS
BEGIN
	 -- 先查询所有的团队
	 WITH TEAM AS (SELECT t.ID as TEAM_ID FROM T_TEAM t LEFT JOIN T_TEAM_MEMBER m on t.ID = m.TEAM_ID WHERE t.IS_DELETE = 0 and m.USER_ID = @userId),
	S1 AS (
           SELECT
	         a.TEAM_ID,
	         COUNT(DISTINCT a.ID) AS total,
	         SUM( IIF ( a.PERFORM_STATUS = 2, 1, 0 ) ) as startPerformNum,
	         SUM( IIF ( a.PERFORM_STATUS = 3, 1, 0 ) ) as finishPerformNum
        FROM
	         T_SIGN_INFO a 
        WHERE
	a.SIGN_STATUS = 1 AND a.TEAM_ID IN (SELECT TEAM_ID FROM TEAM) AND YEAR(a.EFFECT_DATE) =  @YEAR AND YEAR(a.END_DATE) = @YEAR
	GROUP BY a.TEAM_ID),S2 AS (SELECT
	 a.TEAM_ID,
	COUNT(b.ITEM_ID) as serviceNum,
	SUM( IIF (per.ID is not NULL	, 1, 0 ) ) as finishServiceNum
FROM
	T_SIGN_INFO a LEFT JOIN T_SERVICE_PACKAGE_ITEM b ON a.SERVICE_ID = b.PACKAGE_ID
	LEFT JOIN T_SERVICE_ITEM it on b.ITEM_ID = it.Id
  LEFT JOIN (
                SELECT
                    *
                FROM
                    (
                        SELECT ID,
                            SIGN_INFO_ID,
                            SERVICE_ITEM_ID,
                            RESIDUAL_DEGREE,
                            IS_IMMUNITY,
                            row_number ( ) OVER ( partition BY SERVICE_ITEM_ID ORDER BY ID DESC) AS num
                        FROM
                            T_SIGN_PERFORM
                        WHERE
                            IS_DELETE = 0
                    ) t
                WHERE
                    t.num = 1
            ) per ON a.ID = per.SIGN_INFO_ID
WHERE
	a.SIGN_STATUS = 1 AND a.TEAM_ID IN (SELECT TEAM_ID FROM TEAM) AND YEAR(a.EFFECT_DATE) =  @YEAR AND YEAR(a.END_DATE) = @YEAR
	GROUP BY a.TEAM_ID)
	 SELECT S3.* FROM (SELECT S1.*,S2.serviceNum,S2.finishServiceNum,h.TEAM_NAME as orgName,h.ORG_CODE as orgCode FROM S1 LEFT JOIN S2 on S1.TEAM_ID = S2.TEAM_ID LEFT JOIN T_TEAM h on S1.TEAM_ID = h.ID) S3;
END
go

