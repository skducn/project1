CREATE PROCEDURE [dbo].[BI_JG_JSB_INFO]
    @ORG_CODE NVARCHAR (50),
    @YEAR NVARCHAR (4)
AS
BEGIN
    -- 设置事务隔离级别以允许脏读

    -- SQL注入检查
    IF @ORG_CODE LIKE '%select %' 
        OR @ORG_CODE LIKE '%update %' 
        OR @ORG_CODE LIKE '%insert %' 
        OR @ORG_CODE LIKE '%delete %' 
        OR @ORG_CODE LIKE '%truncate %' 
        OR @ORG_CODE LIKE '%drop %' 
        OR @ORG_CODE LIKE '%union %' 
        OR @ORG_CODE LIKE '%exec %' 
        OR @ORG_CODE LIKE '%xp_%' 
    BEGIN
        RAISERROR ( '输入变量值中包含SQL注入！', 16, 1 );
        RETURN;
    END;

    IF @ORG_CODE = '370685'
    BEGIN
        -- 定义临时表 s1
        SELECT
            t2.MANAGE_ORG_CODE,
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
            t2.IDCARD,
            t1.ID
        INTO #s1
        FROM
            (SELECT DISTINCT IDCARD, id FROM T_SMI_INFO WHERE CLOSED_STATUS = '0' AND IS_DELETE = '0' AND id IN (SELECT info_id FROM T_SMI_INFO_DETAIL WHERE FILL_FORM_DATE <= (@year + '-12-31'))) t1
            INNER JOIN T_EHR_INFO t2 ON t1.IDCARD = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0';

        -- 定义临时表 s2
        SELECT
            INFO_ID,
            CASE
                WHEN (@YEAR < YEAR(GETDATE()) AND COUNT(DISTINCT SFJD) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT DISTINCT IDCARD FROM T_SMI_INFO WHERE ID = S2.INFO_ID) AND INQUIRY_DATE BETWEEN  (@YEAR+'01-01')  AND (@YEAR+'12-31')))
                    OR (@YEAR = YEAR(GETDATE()) AND COUNT(DISTINCT SFJD) = 4 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT  DISTINCT IDCARD FROM T_SMI_VISIT WHERE INFO_ID = S2.INFO_ID) AND INQUIRY_DATE BETWEEN  (@YEAR+'01-01')  AND (@YEAR+'12-31'))) THEN
                    1
                WHEN @YEAR = YEAR(GETDATE()) AND COUNT(DISTINCT SFJD) >= DATEPART(QUARTER, GETDATE()) THEN
                    1
                ELSE
                    0
            END AS NUM2
        INTO #s2
        FROM
            (
                SELECT
                    INFO_ID,
                    DATEPART(QUARTER, VISIT_DATE) AS SFJD
                FROM
                    T_SMI_VISIT
                WHERE
                    INFO_ID IN (SELECT ID FROM #s1)
                    AND visit_date BETWEEN (@year + '-01-01') AND (@year + '-12-31')
                    AND IS_DELETE = '0'
                GROUP BY
                    INFO_ID,
                    DATEPART(QUARTER, VISIT_DATE)
            ) S2
        GROUP BY
            S2.INFO_ID;

        -- 定义临时表 s3
        SELECT
            id
        INTO #s3
        FROM #s1
        WHERE id IN (
            SELECT INFO_ID FROM T_SMI_VISIT
            WHERE VISIT_DATE BETWEEN (@year + '-01-01') AND (@year + '-12-31')
            AND (CAUSE_ACCIDENT != -1 OR CAUSE_DISASTER != -1)
        );

        -- 定义临时表 s44
        SELECT
            INFO_ID,
            MAX(VISIT_DATE) AS VISIT_DATE
        INTO #s44
        FROM T_SMI_VISIT
        WHERE VISIT_DATE BETWEEN (@year + '-01-01') AND (@year + '-12-31')
        GROUP BY INFO_ID;

        -- 定义临时表 s4
        SELECT
            id
        INTO #s4
        FROM #s1
        WHERE id IN (
            SELECT T_SMI_VISIT.INFO_ID FROM T_SMI_VISIT
            INNER JOIN #s44 ON T_SMI_VISIT.INFO_ID = #s44.INFO_ID AND T_SMI_VISIT.VISIT_DATE = #s44.VISIT_DATE
            AND T_SMI_VISIT.TREATMENT_EFFECT_CODE != ''
        );

        -- 定义临时表 s5
        SELECT
            S0.ORG_CODE,
            S0.ORG_NAME,
            ISNULL(SUM(IIF(S1.ID IS NOT NULL, 1, 0)), 0) AS registered,
            ISNULL(SUM(S2.NUM2), 0) AS standardizedManagement,
            SUM(IIF(S3.ID IS NOT NULL, 1, 0)) AS jsbtreatmentNum,
            SUM(IIF(S4.ID IS NOT NULL, 1, 0)) AS jsbtDangerNum
        INTO #s5
        FROM
            (SELECT ORG_CODE, ORG_NAME FROM ZYCONFIG.DBO.SYS_HOSPITAL UNION ALL SELECT '370685', '招远卫健局') S0
            LEFT JOIN #s1 S1 ON S0.ORG_CODE = S1.UP_orgcode
            LEFT JOIN #s2 S2 ON S1.id = S2.INFO_ID
            LEFT JOIN #s3 S3 ON S1.id = S3.id
            LEFT JOIN #s4 S4 ON S1.id = S4.id
        GROUP BY
            S0.ORG_CODE,
            S0.ORG_NAME;

        SELECT
            *,
            ISNULL(dbo.Fn_GetPercent(registered, (SELECT TOP 1 CAST(RESIDENT_NUM AS INT) * 10 AS num FROM T_HOME WHERE ORG_CODE = s5.org_code AND year = @year)), 0) AS reorrtManagementRate,
            ISNULL(dbo.Fn_GetPercent(standardizedManagement, registered), 0) AS standardizedManagementRate,
            ISNULL(dbo.Fn_GetPercent(jsbtreatmentNum, registered), 0) AS jsbtreatmentRate,
            ISNULL(dbo.Fn_GetPercent(jsbtDangerNum, registered), 0) AS jsbDangerRate,
            jsbtDangerNum AS jsbtDangerNum2
        FROM #s5 s5
        ORDER BY org_code DESC;

        -- 删除临时表
        DROP TABLE #s1;
        DROP TABLE #s2;
        DROP TABLE #s3;
        DROP TABLE #s4;
        DROP TABLE #s5;
        DROP TABLE #s44;

    END
    ELSE
    BEGIN
        -- 定义临时表 s1
        SELECT
            t2.MANAGE_ORG_CODE AS org_code,
            t2.manage_org_name AS org_name,
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) AS UP_orgcode,
            t2.IDCARD,
            t1.ID
        INTO #subs1
        FROM
            (SELECT DISTINCT idcard, id FROM T_SMI_INFO WHERE CLOSED_STATUS = '0' AND IS_DELETE = '0' AND id IN (SELECT info_id FROM T_SMI_INFO_DETAIL WHERE FILL_FORM_DATE <= (@year + '-12-31'))) t1
            INNER JOIN T_EHR_INFO t2 ON t1.iDCARD = t2.IDCARD AND t2.IS_DELETE = '0' AND t2.FINAL_STATUS = '0'
        WHERE
            ISNULL((SELECT ORG_CODE FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_SUB_CODE = MANAGE_ORG_CODE), MANAGE_ORG_CODE) IN (SELECT ORG_CODE FROM dbo.GET_ORGCODE(@org_code));

        -- 定义临时表 s2
        SELECT
            INFO_ID,
            CASE
                WHEN (@YEAR < YEAR(GETDATE()) AND COUNT(SFJD) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT DISTINCT  IDCARD FROM T_SMI_INFO WHERE ID = S2.INFO_ID) AND INQUIRY_DATE BETWEEN  (@YEAR+'01-01')  AND (@YEAR+'12-31')))
                    OR (@YEAR = YEAR(GETDATE()) AND COUNT(SFJD) = 4 AND DATEPART(QUARTER, GETDATE()) = 4 AND EXISTS (SELECT 1 FROM T_SNR_EXAMINATION_INFO WHERE IDCARD = (SELECT DISTINCT IDCARD FROM T_SMI_INFO WHERE ID = S2.INFO_ID) AND INQUIRY_DATE BETWEEN  (@YEAR+'01-01')  AND (@YEAR+'12-31'))) THEN
                    1
                WHEN @YEAR = YEAR(GETDATE()) AND COUNT(SFJD) >= DATEPART(QUARTER, GETDATE()) THEN
                    1
                ELSE
                    0
            END AS NUM2
        INTO #subs2
        FROM
            (
                SELECT
                    INFO_ID,
                    DATEPART(QUARTER, visit_date) AS SFJD
                FROM
                    T_SMI_VISIT
                WHERE
                    INFO_ID IN (SELECT ID FROM #subs1)
                    AND visit_date BETWEEN (@year + '-01-01') AND (@year + '-12-31')
                    AND IS_DELETE = '0'
                GROUP BY
                    INFO_ID,
                    DATEPART(QUARTER, VISIT_DATE)
                ) S2
            GROUP BY
                S2.INFO_ID;

        -- 定义临时表 s3
        SELECT
            id
        INTO #subs3
        FROM #subs1
        WHERE id IN (
            SELECT INFO_ID FROM T_SMI_VISIT
            WHERE VISIT_DATE BETWEEN (@year + '-01-01') AND (@year + '-12-31')
            AND (CAUSE_ACCIDENT != -1 OR CAUSE_DISASTER != -1)
        );

        -- 定义临时表 s44
        SELECT
            INFO_ID,
            MAX(VISIT_DATE) AS VISIT_DATE
        INTO #subs44
        FROM T_SMI_VISIT
        WHERE VISIT_DATE BETWEEN (@year + '-01-01') AND (@year + '-12-31')
        GROUP BY INFO_ID;

        -- 定义临时表 s4
        SELECT
            id
        INTO #subs4
        FROM #subs1
        WHERE id IN (
            SELECT T_SMI_VISIT.INFO_ID FROM T_SMI_VISIT
            INNER JOIN #subs44 ON T_SMI_VISIT.INFO_ID = #subs44.INFO_ID AND T_SMI_VISIT.VISIT_DATE = #subs44.VISIT_DATE
            AND T_SMI_VISIT.TREATMENT_EFFECT_CODE != ''
        );

        -- 定义临时表 s5
        SELECT
            S0.ORG_SUB_CODE AS ORG_CODE,
            S0.ORG_SUB_NAME AS ORG_NAME,
            SUM(IIF(S1.ID IS NOT NULL, 1, 0)) AS registered,
            ISNULL(SUM(S2.NUM2), 0) AS standardizedManagement,
            SUM(IIF(S3.ID IS NOT NULL, 1, 0)) AS jsbtreatmentNum,
            SUM(IIF(S4.ID IS NOT NULL, 1, 0)) AS jsbtDangerNum
        INTO #subs5
        FROM
            (SELECT ORG_SUB_CODE, ORG_SUB_NAME FROM ZYCONFIG.DBO.SYS_SUB_HOSPITAL WHERE ORG_CODE = @ORG_CODE
            UNION ALL
            SELECT @org_code, (SELECT ORG_NAME FROM ZYCONFIG.dbo.SYS_HOSPITAL WHERE ORG_CODE = @org_code)) S0
            LEFT JOIN #subs1 S1 ON S0.ORG_SUB_CODE = S1.org_code
            LEFT JOIN #subs2 S2 ON S1.id = S2.INFO_ID
            LEFT JOIN #subs3 S3 ON S1.id = S3.id
            LEFT JOIN #subs4 S4 ON S1.id = S4.id
        GROUP BY
            S0.ORG_SUB_CODE,
            S0.ORG_SUB_NAME;

        SELECT
            *,
            ISNULL(dbo.Fn_GetPercent(registered, (SELECT TOP 1 CAST(RESIDENT_NUM AS INT) * 10 FROM T_SUB_HOME WHERE ORG_SUB_CODE = s5.org_code AND year = @year)), 0) AS reorrtManagementRate,
            ISNULL(dbo.Fn_GetPercent(standardizedManagement, registered), 0) AS standardizedManagementRate,
            ISNULL(dbo.Fn_GetPercent(jsbtreatmentNum, registered), 0) AS jsbtreatmentRate,
            ISNULL(dbo.Fn_GetPercent(jsbtDangerNum, registered), 0) AS jsbDangerRate,
            jsbtDangerNum AS jsbtDangerNum2
        FROM #subs5 s5
        ORDER BY ORG_CODE DESC;

        -- 删除临时表
        DROP TABLE #subs1;
        DROP TABLE #subs2;
        DROP TABLE #subs3;
        DROP TABLE #subs4;
        DROP TABLE #subs5;
        DROP TABLE #subs44;
    END
END;
go

