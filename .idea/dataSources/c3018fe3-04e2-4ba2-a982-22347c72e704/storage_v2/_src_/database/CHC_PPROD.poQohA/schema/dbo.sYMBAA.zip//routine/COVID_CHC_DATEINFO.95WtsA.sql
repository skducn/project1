CREATE PROCEDURE [dbo].[COVID_CHC_DATEINFO]
AS
BEGIN
BEGIN
--封面
TRUNCATE TABLE HRCOVER;
	insert into  dbo.HRCOVER (
	 [ARCHIVENUM], [EHRNUM], [NAME], [PRESENTADDRESS], [PERMANENTADDRESS], [PHONE], [PROVINCE], [PROVINCECODE], [CITY], [CITYCODE], [DISTRICT], [DISTRICTCODE], [NEIGHBORHOOD], [NEIGHBORHOODCODE], [VILLAGENAME], [VILLAGECODE], [ARCHIVEUNIT], [ARCHIVEUNITCODE], [ARCHIVERID], [ARCHIVER], [RESPONSIBLEDOCTORID], [RESPONSIBLEDOCTOR], [DATEOFCREATEARCHIVE], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [DATASOURCES], [STATUS], [VERSION], [ISDELETED], [FIELDSOURCES], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [PERMANENTNEIGHBORHOODCODE], [PERMANENTNEIGHBORHOOD], [PERMANENTVILLAGECODE], [PERMANENTVILLAGENAME], [ISGOVERNANCE]) 
SELECT[ARCHIVENUM], [EHRNUM], [NAME], [PRESENTADDRESS], [PERMANENTADDRESS], [PHONE], [PROVINCE], [PROVINCECODE], [CITY], [CITYCODE], [DISTRICT], [DISTRICTCODE], [NEIGHBORHOOD], [NEIGHBORHOODCODE], [VILLAGENAME], [VILLAGECODE], [ARCHIVEUNIT], [ARCHIVEUNITCODE], [ARCHIVERID], [ARCHIVER], [RESPONSIBLEDOCTORID], [RESPONSIBLEDOCTOR], [DATEOFCREATEARCHIVE], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [DATASOURCES], [STATUS], [VERSION], [ISDELETED], [FIELDSOURCES], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [PERMANENTNEIGHBORHOODCODE], [PERMANENTNEIGHBORHOOD], [PERMANENTVILLAGECODE], [PERMANENTVILLAGENAME], [ISGOVERNANCE] from EHRDC.dbo.HrCover;
	PRINT '封面完成' 
END

BEGIN
--基本信息
TRUNCATE TABLE HRPERSONBASICINFO;
set  IDENTITY_INSERT HRPERSONBASICINFO on 
insert into HRPERSONBASICINFO(ID,
[ARCHIVENUM], [NAME], [SEX], [DATEOFBIRTH], [IDCARD], [WORKUNIT], [PHONE], [CONTACTSNAME], [CONTACTSPHONE], [RESIDENCETYPE], [NATIONCODE], [BLOODTYPE], [RHBLOODTYPE], [DEGREE], [OCCUPATION], [MARITALSTATUS], [HEREDITYHISTORYFLAG], [HEREDITYHISTORYCODE], [ENVIRONMENTKITCHENAERATION], [ENVIRONMENTFUELTYPE], [ENVIRONMENTWATER], [ENVIRONMENTTOILET], [ENVIRONMENTCORRAL], [DATASOURCES], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [STATUS], [ISDELETED], [VERSION], [WORKSTATUS], [TELEPHONE], [OCCUPATIONALDISEASESFLAG], [OCCUPATIONALDISEASESWORKTYPE], [OCCUPATIONALDISEASESWORKINGYEARS], [DUSTNAME], [DUSTFLAG], [RADIOACTIVEMATERIALNAME], [RADIOACTIVEMATERIALFLAG], [CHEMICALMATERIALNAME], [CHEMICALMATERIALFLAG], [OTHERNAME], [OTHERFLAG], [PHYSICSMATERIALNAME], [PHYSICSMATERIALFLAG], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [YLZFMC], [PERSONID], [MEDICAL_PAYMENTCODE], [KALEIDOSCOPE],  [ISGOVERNANCE]) 

SELECT id,[ARCHIVENUM], [NAME], [SEX], [DATEOFBIRTH], [IDCARD], [WORKUNIT], [PHONE], [CONTACTSNAME], [CONTACTSPHONE], [RESIDENCETYPE], [NATIONCODE], [BLOODTYPE], [RHBLOODTYPE], [DEGREE], [OCCUPATION], [MARITALSTATUS], [HEREDITYHISTORYFLAG], [HEREDITYHISTORYCODE], [ENVIRONMENTKITCHENAERATION], [ENVIRONMENTFUELTYPE], [ENVIRONMENTWATER], [ENVIRONMENTTOILET], [ENVIRONMENTCORRAL], [DATASOURCES], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [STATUS], [ISDELETED], [VERSION], [WORKSTATUS], [TELEPHONE], [OCCUPATIONALDISEASESFLAG], [OCCUPATIONALDISEASESWORKTYPE], [OCCUPATIONALDISEASESWORKINGYEARS], [DUSTNAME], [DUSTFLAG], [RADIOACTIVEMATERIALNAME], [RADIOACTIVEMATERIALFLAG], [CHEMICALMATERIALNAME], [CHEMICALMATERIALFLAG], [OTHERNAME], [OTHERFLAG], [PHYSICSMATERIALNAME], [PHYSICSMATERIALFLAG], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [YLZFMC], [PERSONID], [MEDICAL_PAYMENTCODE], [KALEIDOSCOPE],  [ISGOVERNANCE] from EHRDC.dbo.HrPersonBasicInfo;



PRINT '基本信息表完成' 
set  IDENTITY_INSERT HRPERSONBASICINFO off ;
END

BEGIN
-- 一对多选表
TRUNCATE TABLE HRASSOCIATIONINFO;
insert into  HRASSOCIATIONINFO (
 [TABLESOURCE], [PID], [ASSOCIATIONTYPE], [CODE], [MSG], [OCCURDATE], [ORDERS], [SOURCETYPE]

)SELECT  [TABLESOURCE], [PID], [ASSOCIATIONTYPE], [CODE], [MSG], [OCCURDATE], [ORDERS], [SOURCETYPE] from EHRDC.dbo.HrAssociationInfo;
PRINT '一对多选表完成' 

END ;
--糖尿病随访 

BEGIN
TRUNCATE TABLE TB_DC_DM_VISIT;

insert into  TB_DC_DM_VISIT (
GUID, [cardId], [name], ehrNum, [orgCode], [visitDate], [visitWayCode], [visitWayValue], [otherVisit], [visitDocNo], [visitDocName], [visitOrgCode], [visitOrgName], [vistStatusCode], [visitStatusValue], [nextVisiDate], [lostVisitCode], [lostVisitName], [lostVisitDate], [otherLostVIsitName], [deathReason], [targetDistrictCode], [targetDistrictName], [targetOrgCode], [targetOrgName], [moveProvinceCode], [moveProvinceValue], [moveCityCode], [moveCityValue], [moveDistrictCode], [moveDistrictValue], [moveStreetCode], [moveStreetValue], [moveNeighborhoodCode], [moveNeighborhoodValue], [moveVillageValue], [moveHouseNumber], [moveOrgCode], [moveOrgName], [hasPaperCard], [isAcceptHealthEdu], [healthEduType], [clinicalSymptomsCode], [clinicalSymptomsValue], [otherClinicalSymptoms], [symptomStatus], [clinicalInfo], [sbp], [dbp], [height], [weight], [waistline], [hipline], [targetWeight], [BMI], [targetBMI], [dorsalArteryOfFootLeftCode], [dorsalArteryOfFootLeftName], [dorsalArteryOfFootRightCode], [dorsalArteryOfFootRightName], [hypoglycemia], [familyHistory], [isLawSport], [sportTypeCode], [sportTypeName], [sportFrequence], [sportTimes], [dietCode], [dietName], [stapleFood], [targetStapleFood], [smokingVolume], [drinkingVolume], [targetSportFrequencyCode], [targetSportFrequencyName], [targetSportTimes], [smokingStatusCode], [smokingStatusName], [targetSmoke], [quitSmoking], [drinkingFrequencyCode], [drinkingFrequencyName], [targetDrink], [psychologyStatusCode], [psychologyStatusName], [complianceStatusCode], [complianceStatusName], [referralReason], [referralOrgDept], [visitType], [fastingBloodSugarCode], [fastingBloodSugarName], [fastingBloodSugarValue], [fastingBloodSugarGatherCode], [fastingBloodSugarGatherName], [randomBloodSugarCode], [randomBloodSugarName], [randomBloodSugarValue], [randomBloodSugarGatherCode], [randomBloodSugarGatherName], [fastingBloodSugarOGTTCode], [fastingBloodSugarOGTTName], [fastingBloodSugarOGTTValue], [fastingBloodSugarOGTTGatherCode], [fastingBloodSugarOGTTGatherName], [twoHBloodSugarOGTTCode], [twoHBloodSugarOGTTName], [twoHBloodSugarOGTTValue], [twoHBloodSugarOGTTGatherCode], [twoHBloodSugarOGTTGatherName], [hbAlc], [hbAlcDate], [cholesterol], [triglycerides], [highCholesterol], [lowCholesterol], [acr], [urineProtein], [ghGaterWayCode], [ghGaterWayName], [drugComplianceCode], [drugComplianceName], [useDrug], [hasUseDrugSideEffects], [UseDrugSideEffects], [interveneCount], [beforeInterveneDate], [isIntervene], [syndrome], [interveneMeasures], [measuresContent], [otherInterveneMeasures], [otherMeasuresContent], [proposal], [otherProposal], [synStatus], [age], [empiGuid], [isGovernance]

)SELECT GUID, [cardId], [name], CAST([ehrNum]as VARCHAR) as ehrNum, [orgCode], [visitDate], [visitWayCode], [visitWayValue], [otherVisit], [visitDocNo], [visitDocName], [visitOrgCode], [visitOrgName], [vistStatusCode], [visitStatusValue], [nextVisiDate], [lostVisitCode], [lostVisitName], [lostVisitDate], [otherLostVIsitName], [deathReason], [targetDistrictCode], [targetDistrictName], [targetOrgCode], [targetOrgName], [moveProvinceCode], [moveProvinceValue], [moveCityCode], [moveCityValue], [moveDistrictCode], [moveDistrictValue], [moveStreetCode], [moveStreetValue], [moveNeighborhoodCode], [moveNeighborhoodValue], [moveVillageValue], [moveHouseNumber], [moveOrgCode], [moveOrgName], [hasPaperCard], [isAcceptHealthEdu], [healthEduType], [clinicalSymptomsCode], [clinicalSymptomsValue], [otherClinicalSymptoms], [symptomStatus], [clinicalInfo], [sbp], [dbp], [height], [weight], [waistline], [hipline], [targetWeight], [BMI], [targetBMI], [dorsalArteryOfFootLeftCode], [dorsalArteryOfFootLeftName], [dorsalArteryOfFootRightCode], [dorsalArteryOfFootRightName], [hypoglycemia], [familyHistory], [isLawSport], [sportTypeCode], [sportTypeName], [sportFrequence], [sportTimes], [dietCode], [dietName], [stapleFood], [targetStapleFood], [smokingVolume], [drinkingVolume], [targetSportFrequencyCode], [targetSportFrequencyName], [targetSportTimes], [smokingStatusCode], [smokingStatusName], [targetSmoke], [quitSmoking], [drinkingFrequencyCode], [drinkingFrequencyName], [targetDrink], [psychologyStatusCode], [psychologyStatusName], [complianceStatusCode], [complianceStatusName], [referralReason], [referralOrgDept], [visitType], [fastingBloodSugarCode], [fastingBloodSugarName], [fastingBloodSugarValue], [fastingBloodSugarGatherCode], [fastingBloodSugarGatherName], [randomBloodSugarCode], [randomBloodSugarName], [randomBloodSugarValue], [randomBloodSugarGatherCode], [randomBloodSugarGatherName], [fastingBloodSugarOGTTCode], [fastingBloodSugarOGTTName], [fastingBloodSugarOGTTValue], [fastingBloodSugarOGTTGatherCode], [fastingBloodSugarOGTTGatherName], [twoHBloodSugarOGTTCode], [twoHBloodSugarOGTTName], [twoHBloodSugarOGTTValue], [twoHBloodSugarOGTTGatherCode], [twoHBloodSugarOGTTGatherName], [hbAlc], [hbAlcDate], [cholesterol], [triglycerides], [highCholesterol], [lowCholesterol], [acr], [urineProtein], [ghGaterWayCode], [ghGaterWayName], [drugComplianceCode], [drugComplianceName], [useDrug], [hasUseDrugSideEffects], [UseDrugSideEffects], [interveneCount], [beforeInterveneDate], [isIntervene], [syndrome], [interveneMeasures], [measuresContent], [otherInterveneMeasures], [otherMeasuresContent], [proposal], [otherProposal], [synStatus], [age], [empiGuid], [isGovernance]
 from EHRDC.dbo.tb_dc_dm_visit;
 PRINT '糖尿病随访表完成' 
 END;
 
 BEGIN
 -- 体检信息
TRUNCATE TABLE TB_DC_EXAMINATION_INFO;
insert into TB_DC_EXAMINATION_INFO SELECT * from EHRDC.dbo.tb_dc_examination_info;
PRINT '基本信息表完成' 
END;


BEGIN
-- 主索引
TRUNCATE TABLE TB_EMPI_INDEX_ROOT;
insert into TB_EMPI_INDEX_ROOT SELECT * from EHRDC.dbo.tb_empi_index_root;
PRINT '主索引表完成' 
END;


BEGIN
--慢病防治主表 
TRUNCATE TABLE TB_DC_CHRONIC_INFO;
	insert into TB_DC_CHRONIC_INFO SELECT * from EHRDC.dbo.tb_dc_chronic_info;
PRINT '慢病防治主表完成' 
END;

BEGIN 
 -- 住院信息表
TRUNCATE TABLE TB_HIS_IP_MEDICAL_RECORD;
	insert into TB_HIS_IP_MEDICAL_RECORD SELECT * from EHRDC.dbo.tb_his_ip_medical_record;
PRINT '住院信息表完成' 
END;

BEGIN
 --门诊就诊记录 
TRUNCATE TABLE TB_HIS_OP_MEDICAL_RECORD;
	insert into  TB_HIS_OP_MEDICAL_RECORD SELECT * from EHRDC.dbo.tb_his_op_medical_record;

PRINT '门诊就诊记录表完成' 
END;

BEGIN 

 -- 检验明细
TRUNCATE TABLE TB_LIS_REPORT_INDICATOR;
insert into TB_LIS_REPORT_INDICATOR 
SELECT 
t1.*,
t2.REPORTDATE
 from 
EHRDC.dbo.tb_lis_report_indicator t1  INNER JOIN EHRDC.dbo.TB_LIS_REPORT t2 ON t1.REPORTNO=t2.REPORTNO ;
PRINT '检验明细表完成' 
END;

BEGIN 
 -- 体检用药
TRUNCATE TABLE TB_DC_EXAMINATION_MEDICATE;
insert into TB_DC_EXAMINATION_MEDICATE  SELECT * from EHRDC.dbo.TB_DC_EXAMINATION_MEDICATE;
PRINT '体检用药表完成' 
END;
 BEGIN
--签约信息表
TRUNCATE TABLE QYYH ; 
INSERT INTO [dbo].[QYYH] ([CZRYBM], [CZRYXM], [JMXM], [SJHM], [SFZH], [JJDZ], [SFJD], [SIGNORGID], [ARCHIVEUNITCODE], [ARCHIVEUNITNAME], [DISTRICTORGCODE], [DISTRICTORGNAME], [TERTIARYORGCODE], [TERTIARYORGNAME], [PRESENTADDRDIVISIONCODE], [PRESENTADDRPROVCODE], [PRESENTADDRPROVVALUE], [PRESENTADDRCITYCODE], [PRESENTADDRCITYVALUE], [PRESENTADDRDISTCODE], [PRESENTADDDISTVALUE], [PRESENTADDRTOWNSHIPCODE], [PRESENTADDRTOWNSHIPVALUE], [PRESENTADDRNEIGHBORHOODCODE], [PRESENTADDRNEIGHBORHOODVALUE], [SIGNSTATUS], [SIGNDATE], [CATEGORY_CODE], [CATEGORY_NAME], [SEX_CODE], [SEX_NAME])




 SELECT  [CZRYBM], [CZRYXM], [JMXM], [SJHM], [SFZH], [JJDZ], [SFJD], [SIGNORGID], [ARCHIVEUNITCODE], [ARCHIVEUNITNAME], [DISTRICTORGCODE], [DISTRICTORGNAME], [TERTIARYORGCODE], [TERTIARYORGNAME], [PRESENTADDRDIVISIONCODE], [PRESENTADDRPROVCODE], [PRESENTADDRPROVVALUE], [PRESENTADDRCITYCODE], [PRESENTADDRCITYVALUE], [PRESENTADDRDISTCODE], [PRESENTADDDISTVALUE], [PRESENTADDRTOWNSHIPCODE], [PRESENTADDRTOWNSHIPVALUE], [PRESENTADDRNEIGHBORHOODCODE], [PRESENTADDRNEIGHBORHOODVALUE], [SIGNSTATUS], [SIGNDATE], 
	
	CASE 
	WHEN  dbo.FN_GETAGE(SFZH, GETDATE())>=0 AND dbo.FN_GETAGE(SFZH, GETDATE())<=6 THEN '1'
	when  dbo.FN_GETAGE(SFZH, GETDATE())>6 and dbo.FN_GETAGE(SFZH, GETDATE())<=17 THEN '2'
	when  dbo.FN_GETAGE(SFZH, GETDATE())>18 and dbo.FN_GETAGE(SFZH, GETDATE())<65 then '3'
	when  dbo.FN_GETAGE(SFZH, GETDATE())>=65  then '4'
	ELSE '5'
END as CATEGORY_CODE,
	CASE 
	WHEN  dbo.FN_GETAGE(SFZH, GETDATE())>=0 AND dbo.FN_GETAGE(SFZH, GETDATE())<=6 THEN '儿童'
	when  dbo.FN_GETAGE(SFZH, GETDATE())>6 and dbo.FN_GETAGE(SFZH, GETDATE())<=17 THEN '学生'
	when  dbo.FN_GETAGE(SFZH, GETDATE())>18 and dbo.FN_GETAGE(SFZH, GETDATE())<65 then '一般人群'
	when  dbo.FN_GETAGE(SFZH, GETDATE())>=65  then '老年人'
	ELSE '未分类'
END as CATEGORY_NAME,


Case when SUBSTRing(SFZH,17,1)%2='1' then '1'

when SUBSTRing(SFZH,17,1)%2='0' then '2'

else '' end  as SEX_CODE, 

Case when SUBSTRing(SFZH,17,1)%2='1' then '男'

when SUBSTRing(SFZH,17,1)%2='0' then '女'
else '未知' end  as SEX_NAME

from  EHRDC.dbo.QYYH;
PRINT '签约信息表完成' 
END;

BEGIN
 -- 检查报告表  
 TRUNCATE TABLE TB_LIS_REPORT;
insert into TB_LIS_REPORT SELECT * from EHRDC.dbo.TB_LIS_REPORT;

PRINT '检查报告表完成' 
end;

BEGIN
 -- 慢病随访主表
 TRUNCATE TABLE TB_DC_CHRONIC_MAIN;
insert into TB_DC_CHRONIC_MAIN SELECT * from EHRDC.dbo.TB_DC_CHRONIC_MAIN;
PRINT '慢病随访主表完成' 
END;

BEGIN
 -- 检验报告明细表
  TRUNCATE TABLE TB_RIS_REPORT;
insert into TB_RIS_REPORT SELECT * from EHRDC.dbo.TB_RIS_REPORT;
PRINT '检验报告明细表完成' 
END;
BEGIN
-- 高血压随访
  TRUNCATE TABLE TB_DC_HTN_VISIT;
insert into TB_DC_HTN_VISIT SELECT * from EHRDC.dbo.TB_DC_HTN_VISIT;
 PRINT '高血压随访表完成' 
END;
BEGIN
update  HRASSOCIATIONINFO 
set MSG =(
SELECT 
VALUE
FROM 
TB_CODE
WHERE 
TABLETYPE='HrPersonBasicInfo'
AND
TARGETTABLE='HrAssociationInfo'
AND 
TARGETFIELD='history_of_disease' 
AND 
 CODE=HRASSOCIATIONINFO.CODE
)
WHERE HRASSOCIATIONINFO.ASSOCIATIONTYPE  like '%family_history_of%';
  PRINT '一对多表更新完成' ;
	END;
	-- 更新  时间 
	
END
go

