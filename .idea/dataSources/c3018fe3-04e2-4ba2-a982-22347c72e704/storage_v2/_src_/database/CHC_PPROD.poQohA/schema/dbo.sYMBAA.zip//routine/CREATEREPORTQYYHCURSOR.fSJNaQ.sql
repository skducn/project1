
CREATE PROCEDURE [DBO].[CREATEREPORTQYYHCURSOR]
AS
BEGIN

  IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_高血压随访次数统计'
            AND TYPE = 'U')
    DROP TABLE TEMP_高血压随访次数统计;

IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_糖尿病随访次数统计'
            AND TYPE = 'U')
    DROP TABLE TEMP_糖尿病随访次数统计;


CREATE TABLE [DBO].[TEMP_高血压随访次数统计]
(
    [ID]                   BIGINT IDENTITY (1000,1)               NOT NULL,
    [ARCHIVE_NUM]          NVARCHAR(50) COLLATE CHINESE_PRC_CI_AS NULL,
    [TARGET_TIME]          INT                                    NULL,
    [VISIT_DATE]           DATETIME                               NULL,
    [IRREGULAR_VISIT_DATE] DATETIME                               NULL,
    [START_DATE]           DATETIME                               NULL,
    [END_DATE]             DATETIME                               NULL,
    [INDEX_TIME]           INT                                    NULL,
    CONSTRAINT [PK_TEMP_高血压随访] PRIMARY KEY CLUSTERED ([ID])
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
        ON [PRIMARY]
)
    ON [PRIMARY]


ALTER TABLE [DBO].[TEMP_高血压随访次数统计]
    SET (LOCK_ESCALATION = TABLE)


CREATE NONCLUSTERED INDEX [HTN_ARCHIVE_NUM_INDEX_TIME]
    ON [DBO].[TEMP_高血压随访次数统计] (
                               [ARCHIVE_NUM] ASC,
                               [INDEX_TIME] ASC
        )


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'档案编号',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_高血压随访次数统计',
     'COLUMN', N'ARCHIVE_NUM'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'理论随访次数',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_高血压随访次数统计',
     'COLUMN', N'TARGET_TIME'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'正确的随访时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_高血压随访次数统计',
     'COLUMN', N'VISIT_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'不规范的最新随访时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_高血压随访次数统计',
     'COLUMN', N'IRREGULAR_VISIT_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'随访范围开始时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_高血压随访次数统计',
     'COLUMN', N'START_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'随访范围结束时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_高血压随访次数统计',
     'COLUMN', N'END_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'本次随访次数',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_高血压随访次数统计',
     'COLUMN', N'INDEX_TIME'

CREATE TABLE [DBO].[TEMP_糖尿病随访次数统计] (
                                        [ID] BIGINT  IDENTITY(1000,1) NOT NULL,
                                        [ARCHIVE_NUM] NVARCHAR(50) COLLATE CHINESE_PRC_CI_AS  NULL,
                                        [TARGET_TIME] INT  NULL,
                                        [VISIT_DATE] DATETIME  NULL,
                                        [IRREGULAR_VISIT_DATE] DATETIME  NULL,
                                        [START_DATE] DATETIME  NULL,
                                        [END_DATE] DATETIME  NULL,
                                        [INDEX_TIME] INT  NULL,
                                        CONSTRAINT [PK_TEMP_高血压随访_COPY2] PRIMARY KEY CLUSTERED ([ID])
                                            WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
                                            ON [PRIMARY]
)
    ON [PRIMARY]


ALTER TABLE [DBO].[TEMP_糖尿病随访次数统计] SET (LOCK_ESCALATION = TABLE)


CREATE NONCLUSTERED INDEX [DM_ARCHIVE_NUM_INDEX_TIME]
    ON [DBO].[TEMP_糖尿病随访次数统计] (
                               [ARCHIVE_NUM] ASC,
                               [INDEX_TIME] ASC
        )


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'档案编号',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_糖尿病随访次数统计',
     'COLUMN', N'ARCHIVE_NUM'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'理论随访次数',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_糖尿病随访次数统计',
     'COLUMN', N'TARGET_TIME'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'正确的随访时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_糖尿病随访次数统计',
     'COLUMN', N'VISIT_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'不规范的最新随访时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_糖尿病随访次数统计',
     'COLUMN', N'IRREGULAR_VISIT_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'随访范围开始时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_糖尿病随访次数统计',
     'COLUMN', N'START_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'随访范围结束时间',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_糖尿病随访次数统计',
     'COLUMN', N'END_DATE'


EXEC SP_ADDEXTENDEDPROPERTY
     'MS_DESCRIPTION', N'本次随访次数',
     'SCHEMA', N'DBO',
     'TABLE', N'TEMP_糖尿病随访次数统计',
     'COLUMN', N'INDEX_TIME'

END
go

