CREATE PROCEDURE [dbo].[COVID_CHC_DATEINFO_patch]
@cnt INT=2000
AS
BEGIN
    CREATE TABLE #all_id (
        id INT
    );
    CREATE TABLE #patch_id (
        id INT
    );
    CREATE TABLE #all_guid (
        guid VARCHAR (200)
    );
    CREATE TABLE #patch_guid (
        guid VARCHAR (200)
    );
    INSERT INTO #all_id
    SELECT   id
    FROM     EHRDC.dbo.HrCover
    WHERE    id NOT IN (SELECT id
                        FROM   HrCover)
    ORDER BY id;
    WHILE EXISTS (SELECT *
                  FROM   #all_id)
        BEGIN
            TRUNCATE TABLE #patch_id;
            DELETE TOP (@cnt)
                   #all_id
            OUTPUT deleted.id INTO #patch_id (id);
            SET IDENTITY_INSERT HRCOVER ON;
						-- 封面表
            INSERT INTO HRCOVER ([ArchiveNum], [id], [ehrNum], [Name], [PresentAddress], [PermanentAddress], [Phone], [Province], [ProvinceCode], [City], [CityCode], [District], [DistrictCode], [Neighborhood], [NeighborhoodCode], [VillageName], [VillageCode], [ArchiveUnit], [ArchiveUnitCode], [ArchiverId], [Archiver], [ResponsibleDoctorId], [ResponsibleDoctor], [DateOfCreateArchive], [CreateId], [CreateName], [CreateTime], [UpdateId], [UpdateName], [UpdateTime], [DataSources], [Status], [Version], [IsDeleted], [FieldSources], [DownloadStatus], [NoNumberProvided], [permanentNeighborhoodCode], [permanentNeighborhood], [permanentVillageCode], [permanentVillageName], [isGovernance])
            SELECT *
            FROM   EHRDC.dbo.HrCover
            WHERE  id IN (SELECT id
                          FROM   #patch_id);
            SET IDENTITY_INSERT HRCOVER OFF;
        END
    INSERT INTO #all_id
    SELECT   id
    FROM     EHRDC.dbo.HRPERSONBASICINFO
    WHERE    id NOT IN (SELECT id
                        FROM   HRPERSONBASICINFO)
    ORDER BY id;
    WHILE EXISTS (SELECT *
                  FROM   #all_id)
        BEGIN
            TRUNCATE TABLE #patch_id;
            DELETE TOP (@cnt)
                   #all_id
            OUTPUT deleted.id INTO #patch_id (id);
            SET IDENTITY_INSERT HRPERSONBASICINFO ON;
						-- 基本信息表
            INSERT INTO HRPERSONBASICINFO ([ArchiveNum], [IdCard], [Name], [Sex], [DateOfBirth], [WorkUnit], [Phone], [ContactsName], [ContactsPhone], [ResidenceType], [NationCode], [BloodType], [RhBloodType], [Degree], [Occupation], [MaritalStatus], [HeredityHistoryFlag], [HeredityHistoryCode], [EnvironmentKitchenAeration], [EnvironmentFuelType], [EnvironmentWater], [EnvironmentToilet], [EnvironmentCorral], [DataSources], [CreateId], [CreateName], [CreateTime], [UpdateId], [UpdateName], [UpdateTime], [Status], [IsDeleted], [Version], [WorkStatus], [Telephone], [OccupationalDiseasesFlag], [OccupationalDiseasesWorkType], [OccupationalDiseasesWorkingYears], [DustName], [DustFlag], [RadioactiveMaterialName], [RadioactiveMaterialFlag], [ChemicalMaterialName], [ChemicalMaterialFlag], [OtherName], [OtherFlag], [PhysicsMaterialName], [PhysicsMaterialFlag], [DownloadStatus], [NoNumberProvided], [YLZFMC], [personid], [medical_paymentcode], [Kaleidoscope], [id], [isGovernance])
            SELECT *
            FROM   EHRDC.dbo.HRPERSONBASICINFO
            WHERE  id IN (SELECT id
                          FROM   #patch_id);
            SET IDENTITY_INSERT HRPERSONBASICINFO OFF;
        END
    INSERT INTO #all_id
    SELECT   id
    FROM     EHRDC.dbo.HRASSOCIATIONINFO
    WHERE    id NOT IN (SELECT id
                        FROM   HRASSOCIATIONINFO)
    ORDER BY id;
    WHILE EXISTS (SELECT *
                  FROM   #all_id)
        BEGIN
            TRUNCATE TABLE #patch_id;
            DELETE TOP (@cnt)
                   #all_id
            OUTPUT deleted.id INTO #patch_id (id);
						-- 一对多选表
            SET IDENTITY_INSERT HRASSOCIATIONINFO ON;
            INSERT INTO HRASSOCIATIONINFO ([id], [TableSource], [Pid], [AssociationType], [Code], [Msg], [OccurDate], [Orders], [sourceType])
            SELECT *
            FROM   EHRDC.dbo.HRASSOCIATIONINFO
            WHERE  id IN (SELECT id
                          FROM   #patch_id);
            SET IDENTITY_INSERT HRASSOCIATIONINFO OFF;
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.TB_DC_DM_VISIT
    WHERE    guid NOT IN (SELECT guid
                          FROM   TB_DC_DM_VISIT)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_DC_DM_VISIT ([GUID], [CARDID], [NAME], [AGE], [EHRNUM], [ORGCODE], [VISITDATE], [VISITWAYCODE], [VISITWAYVALUE], [OTHERVISIT], [VISITDOCNO], [VISITDOCNAME], [VISITORGCODE], [VISITORGNAME], [VISTSTATUSCODE], [VISITSTATUSVALUE], [NEXTVISIDATE], [LOSTVISITCODE], [LOSTVISITNAME], [LOSTVISITDATE], [OTHERLOSTVISITNAME], [DEATHREASON], [TARGETDISTRICTCODE], [TARGETDISTRICTNAME], [TARGETORGCODE], [TARGETORGNAME], [MOVEPROVINCECODE], [MOVEPROVINCEVALUE], [MOVECITYCODE], [MOVECITYVALUE], [MOVEDISTRICTCODE], [MOVEDISTRICTVALUE], [MOVESTREETCODE], [MOVESTREETVALUE], [MOVENEIGHBORHOODCODE], [MOVENEIGHBORHOODVALUE], [MOVEVILLAGEVALUE], [MOVEHOUSENUMBER], [MOVEORGCODE], [MOVEORGNAME], [HASPAPERCARD], [ISACCEPTHEALTHEDU], [HEALTHEDUTYPE], [CLINICALSYMPTOMSCODE], [CLINICALSYMPTOMSVALUE], [OTHERCLINICALSYMPTOMS], [SYMPTOMSTATUS], [CLINICALINFO], [SBP], [DBP], [HEIGHT], [WEIGHT], [WAISTLINE], [HIPLINE], [TARGETWEIGHT], [BMI], [TARGETBMI], [DORSALARTERYOFFOOTLEFTCODE], [DORSALARTERYOFFOOTLEFTNAME], [DORSALARTERYOFFOOTRIGHTCODE], [DORSALARTERYOFFOOTRIGHTNAME], [HYPOGLYCEMIA], [FAMILYHISTORY], [ISLAWSPORT], [SPORTTYPECODE], [SPORTTYPENAME], [SPORTFREQUENCE], [SPORTTIMES], [DIETCODE], [DIETNAME], [STAPLEFOOD], [TARGETSTAPLEFOOD], [SMOKINGVOLUME], [DRINKINGVOLUME], [TARGETSPORTFREQUENCYCODE], [TARGETSPORTFREQUENCYNAME], [TARGETSPORTTIMES], [SMOKINGSTATUSCODE], [SMOKINGSTATUSNAME], [TARGETSMOKE], [QUITSMOKING], [DRINKINGFREQUENCYCODE], [DRINKINGFREQUENCYNAME], [TARGETDRINK], [PSYCHOLOGYSTATUSCODE], [PSYCHOLOGYSTATUSNAME], [COMPLIANCESTATUSCODE], [COMPLIANCESTATUSNAME], [REFERRALREASON], [REFERRALORGDEPT], [VISITTYPE], [FASTINGBLOODSUGARCODE], [FASTINGBLOODSUGARNAME], [FASTINGBLOODSUGARVALUE], [FASTINGBLOODSUGARGATHERCODE], [FASTINGBLOODSUGARGATHERNAME], [RANDOMBLOODSUGARCODE], [RANDOMBLOODSUGARNAME], [RANDOMBLOODSUGARVALUE], [RANDOMBLOODSUGARGATHERCODE], [RANDOMBLOODSUGARGATHERNAME], [FASTINGBLOODSUGAROGTTCODE], [FASTINGBLOODSUGAROGTTNAME], [FASTINGBLOODSUGAROGTTVALUE], [FASTINGBLOODSUGAROGTTGATHERCODE], [FASTINGBLOODSUGAROGTTGATHERNAME], [TWOHBLOODSUGAROGTTCODE], [TWOHBLOODSUGAROGTTNAME], [TWOHBLOODSUGAROGTTVALUE], [TWOHBLOODSUGAROGTTGATHERCODE], [TWOHBLOODSUGAROGTTGATHERNAME], [HBALC], [HBALCDATE], [CHOLESTEROL], [TRIGLYCERIDES], [HIGHCHOLESTEROL], [LOWCHOLESTEROL], [ACR], [URINEPROTEIN], [GHGATERWAYCODE], [GHGATERWAYNAME], [DRUGCOMPLIANCECODE], [DRUGCOMPLIANCENAME], [USEDRUG], [HASUSEDRUGSIDEEFFECTS], [USEDRUGSIDEEFFECTS], [INTERVENECOUNT], [BEFOREINTERVENEDATE], [ISINTERVENE], [SYNDROME], [INTERVENEMEASURES], [MEASURESCONTENT], [OTHERINTERVENEMEASURES], [OTHERMEASURESCONTENT], [PROPOSAL], [OTHERPROPOSAL], [SYNSTATUS], [EMPIGUID], [ISGOVERNANCE])
            SELECT [GUID],
                   [CARDID],
                   [NAME],
                   [AGE],
                   [EHRNUM],
                   [ORGCODE],
                   [VISITDATE],
                   [VISITWAYCODE],
                   [VISITWAYVALUE],
                   [OTHERVISIT],
                   [VISITDOCNO],
                   [VISITDOCNAME],
                   [VISITORGCODE],
                   [VISITORGNAME],
                   [VISTSTATUSCODE],
                   [VISITSTATUSVALUE],
                   [NEXTVISIDATE],
                   [LOSTVISITCODE],
                   [LOSTVISITNAME],
                   [LOSTVISITDATE],
                   [OTHERLOSTVISITNAME],
                   [DEATHREASON],
                   [TARGETDISTRICTCODE],
                   [TARGETDISTRICTNAME],
                   [TARGETORGCODE],
                   [TARGETORGNAME],
                   [MOVEPROVINCECODE],
                   [MOVEPROVINCEVALUE],
                   [MOVECITYCODE],
                   [MOVECITYVALUE],
                   [MOVEDISTRICTCODE],
                   [MOVEDISTRICTVALUE],
                   [MOVESTREETCODE],
                   [MOVESTREETVALUE],
                   [MOVENEIGHBORHOODCODE],
                   [MOVENEIGHBORHOODVALUE],
                   [MOVEVILLAGEVALUE],
                   [MOVEHOUSENUMBER],
                   [MOVEORGCODE],
                   [MOVEORGNAME],
                   [HASPAPERCARD],
                   [ISACCEPTHEALTHEDU],
                   [HEALTHEDUTYPE],
                   [CLINICALSYMPTOMSCODE],
                   [CLINICALSYMPTOMSVALUE],
                   [OTHERCLINICALSYMPTOMS],
                   [SYMPTOMSTATUS],
                   [CLINICALINFO],
                   [SBP],
                   [DBP],
                   [HEIGHT],
                   [WEIGHT],
                   [WAISTLINE],
                   [HIPLINE],
                   [TARGETWEIGHT],
                   [BMI],
                   [TARGETBMI],
                   [DORSALARTERYOFFOOTLEFTCODE],
                   [DORSALARTERYOFFOOTLEFTNAME],
                   [DORSALARTERYOFFOOTRIGHTCODE],
                   [DORSALARTERYOFFOOTRIGHTNAME],
                   [HYPOGLYCEMIA],
                   [FAMILYHISTORY],
                   [ISLAWSPORT],
                   [SPORTTYPECODE],
                   [SPORTTYPENAME],
                   [SPORTFREQUENCE],
                   [SPORTTIMES],
                   [DIETCODE],
                   [DIETNAME],
                   [STAPLEFOOD],
                   [TARGETSTAPLEFOOD],
                   [SMOKINGVOLUME],
                   [DRINKINGVOLUME],
                   [TARGETSPORTFREQUENCYCODE],
                   [TARGETSPORTFREQUENCYNAME],
                   [TARGETSPORTTIMES],
                   [SMOKINGSTATUSCODE],
                   [SMOKINGSTATUSNAME],
                   [TARGETSMOKE],
                   [QUITSMOKING],
                   [DRINKINGFREQUENCYCODE],
                   [DRINKINGFREQUENCYNAME],
                   [TARGETDRINK],
                   [PSYCHOLOGYSTATUSCODE],
                   [PSYCHOLOGYSTATUSNAME],
                   [COMPLIANCESTATUSCODE],
                   [COMPLIANCESTATUSNAME],
                   [REFERRALREASON],
                   [REFERRALORGDEPT],
                   [VISITTYPE],
                   [FASTINGBLOODSUGARCODE],
                   [FASTINGBLOODSUGARNAME],
                   [FASTINGBLOODSUGARVALUE],
                   [FASTINGBLOODSUGARGATHERCODE],
                   [FASTINGBLOODSUGARGATHERNAME],
                   [RANDOMBLOODSUGARCODE],
                   [RANDOMBLOODSUGARNAME],
                   [RANDOMBLOODSUGARVALUE],
                   [RANDOMBLOODSUGARGATHERCODE],
                   [RANDOMBLOODSUGARGATHERNAME],
                   [FASTINGBLOODSUGAROGTTCODE],
                   [FASTINGBLOODSUGAROGTTNAME],
                   [FASTINGBLOODSUGAROGTTVALUE],
                   [FASTINGBLOODSUGAROGTTGATHERCODE],
                   [FASTINGBLOODSUGAROGTTGATHERNAME],
                   [TWOHBLOODSUGAROGTTCODE],
                   [TWOHBLOODSUGAROGTTNAME],
                   [TWOHBLOODSUGAROGTTVALUE],
                   [TWOHBLOODSUGAROGTTGATHERCODE],
                   [TWOHBLOODSUGAROGTTGATHERNAME],
                   [HBALC],
                   [HBALCDATE],
                   [CHOLESTEROL],
                   [TRIGLYCERIDES],
                   [HIGHCHOLESTEROL],
                   [LOWCHOLESTEROL],
                   [ACR],
                   [URINEPROTEIN],
                   [GHGATERWAYCODE],
                   [GHGATERWAYNAME],
                   [DRUGCOMPLIANCECODE],
                   [DRUGCOMPLIANCENAME],
                   [USEDRUG],
                   [HASUSEDRUGSIDEEFFECTS],
                   [USEDRUGSIDEEFFECTS],
                   [INTERVENECOUNT],
                   [BEFOREINTERVENEDATE],
                   [ISINTERVENE],
                   [SYNDROME],
                   [INTERVENEMEASURES],
                   [MEASURESCONTENT],
                   [OTHERINTERVENEMEASURES],
                   [OTHERMEASURESCONTENT],
                   [PROPOSAL],
                   [OTHERPROPOSAL],
                   [SYNSTATUS],
                   [EMPIGUID],
                   [ISGOVERNANCE]
            FROM   EHRDC.dbo.TB_DC_DM_VISIT
            WHERE  guid IN (SELECT guid
                            FROM   #patch_guid);
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.TB_DC_EXAMINATION_INFO
    WHERE    guid NOT IN (SELECT guid
                          FROM   TB_DC_EXAMINATION_INFO)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_DC_EXAMINATION_INFO
            SELECT *
            FROM   EHRDC.dbo.TB_DC_EXAMINATION_INFO
            WHERE  guid IN (SELECT guid
                            FROM   #patch_guid);
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.TB_EMPI_INDEX_ROOT
    WHERE    guid NOT IN (SELECT guid
                          FROM   TB_EMPI_INDEX_ROOT)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_EMPI_INDEX_ROOT
            SELECT *
            FROM   EHRDC.dbo.TB_EMPI_INDEX_ROOT
            WHERE  guid IN (SELECT guid
                            FROM   #patch_guid);
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.TB_DC_CHRONIC_INFO
    WHERE    guid NOT IN (SELECT guid
                          FROM   TB_DC_CHRONIC_INFO)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_DC_CHRONIC_INFO
            SELECT *
            FROM   EHRDC.dbo.TB_DC_CHRONIC_INFO
            WHERE  guid IN (SELECT guid
                            FROM   #patch_guid);
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.TB_HIS_IP_MEDICAL_RECORD
    WHERE    guid NOT IN (SELECT guid
                          FROM   TB_HIS_IP_MEDICAL_RECORD)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_HIS_IP_MEDICAL_RECORD
            SELECT *
            FROM   EHRDC.dbo.TB_HIS_IP_MEDICAL_RECORD
            WHERE  guid IN (SELECT guid
                            FROM   #patch_guid);
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.TB_HIS_OP_MEDICAL_RECORD
    WHERE    guid NOT IN (SELECT guid
                          FROM   TB_HIS_OP_MEDICAL_RECORD)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_HIS_OP_MEDICAL_RECORD
            SELECT *
            FROM   EHRDC.dbo.TB_HIS_OP_MEDICAL_RECORD
            WHERE  guid IN (SELECT guid
                            FROM   #patch_guid);
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.TB_DC_EXAMINATION_MEDICATE
    WHERE    guid NOT IN (SELECT guid
                          FROM   TB_DC_EXAMINATION_MEDICATE)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_DC_EXAMINATION_MEDICATE
            SELECT *
            FROM   EHRDC.dbo.TB_DC_EXAMINATION_MEDICATE
            WHERE  guid IN (SELECT guid
                            FROM   #patch_guid);
        END
    INSERT INTO #all_id
    SELECT   id
    FROM     EHRDC.dbo.QYYH
    WHERE    id NOT IN (SELECT id
                        FROM   QYYH)
    ORDER BY id;
    WHILE EXISTS (SELECT *
                  FROM   #all_id)
        BEGIN
            TRUNCATE TABLE #patch_id;
            DELETE TOP (@cnt)
                   #all_id
            OUTPUT deleted.id INTO #patch_id (id);
            SET IDENTITY_INSERT QYYH ON;
            INSERT INTO QYYH ([CZRYBM], [CZRYXM], [JMXM], [SJHM], [SFZH], [JJDZ], [SFJD], [SIGNORGID], [ARCHIVEUNITCODE], [ARCHIVEUNITNAME], [DISTRICTORGCODE], [DISTRICTORGNAME], [TERTIARYORGCODE], [TERTIARYORGNAME], [PRESENTADDRDIVISIONCODE], [PRESENTADDRPROVCODE], [PRESENTADDRPROVVALUE], [PRESENTADDRCITYCODE], [PRESENTADDRCITYVALUE], [PRESENTADDRDISTCODE], [PRESENTADDDISTVALUE], [PRESENTADDRTOWNSHIPCODE], [PRESENTADDRTOWNSHIPVALUE], [PRESENTADDRNEIGHBORHOODCODE], [PRESENTADDRNEIGHBORHOODVALUE], [SIGNSTATUS], [SIGNDATE], [ID], [CATEGORY_CODE], [CATEGORY_NAME], [SEX_CODE], [SEX_NAME])
            SELECT [CZRYBM],
                   [CZRYXM],
                   [JMXM],
                   [SJHM],
                   [SFZH],
                   [JJDZ],
                   [SFJD],
                   [SIGNORGID],
                   [ARCHIVEUNITCODE],
                   [ARCHIVEUNITNAME],
                   [DISTRICTORGCODE],
                   [DISTRICTORGNAME],
                   [TERTIARYORGCODE],
                   [TERTIARYORGNAME],
                   [PRESENTADDRDIVISIONCODE],
                   [PRESENTADDRPROVCODE],
                   [PRESENTADDRPROVVALUE],
                   [PRESENTADDRCITYCODE],
                   [PRESENTADDRCITYVALUE],
                   [PRESENTADDRDISTCODE],
                   [PRESENTADDDISTVALUE],
                   [PRESENTADDRTOWNSHIPCODE],
                   [PRESENTADDRTOWNSHIPVALUE],
                   [PRESENTADDRNEIGHBORHOODCODE],
                   [PRESENTADDRNEIGHBORHOODVALUE],
                   [SIGNSTATUS],
                   [SIGNDATE],
                   [ID],
                   CASE WHEN dbo.FN_GETAGE(SFZH, GETDATE()) >= 0
                             AND dbo.FN_GETAGE(SFZH, GETDATE()) <= 6 THEN '1' WHEN dbo.FN_GETAGE(SFZH, GETDATE()) > 6
                                                                                   AND dbo.FN_GETAGE(SFZH, GETDATE()) <= 17 THEN '2' WHEN dbo.FN_GETAGE(SFZH, GETDATE()) > 18
                                                                                                                                          AND dbo.FN_GETAGE(SFZH, GETDATE()) < 65 THEN '3' WHEN dbo.FN_GETAGE(SFZH, GETDATE()) >= 65 THEN '4' ELSE '5' END AS CATEGORY_CODE,
                   CASE WHEN dbo.FN_GETAGE(SFZH, GETDATE()) >= 0
                             AND dbo.FN_GETAGE(SFZH, GETDATE()) <= 6 THEN '儿童' WHEN dbo.FN_GETAGE(SFZH, GETDATE()) > 6
                                                                                    AND dbo.FN_GETAGE(SFZH, GETDATE()) <= 17 THEN '学生' WHEN dbo.FN_GETAGE(SFZH, GETDATE()) > 18
                                                                                                                                            AND dbo.FN_GETAGE(SFZH, GETDATE()) < 65 THEN '一般人群' WHEN dbo.FN_GETAGE(SFZH, GETDATE()) >= 65 THEN '老年人' ELSE '未分类' END AS CATEGORY_NAME,
                   CASE WHEN SUBSTRing(SFZH, 17, 1) % 2 = '1' THEN '1' WHEN SUBSTRing(SFZH, 17, 1) % 2 = '0' THEN '2' ELSE '' END AS SEX_CODE,
                   CASE WHEN SUBSTRing(SFZH, 17, 1) % 2 = '1' THEN '男' WHEN SUBSTRing(SFZH, 17, 1) % 2 = '0' THEN '女' ELSE '未知' END AS SEX_NAME
            FROM   EHRDC.dbo.QYYH
            WHERE  id IN (SELECT id
                          FROM   #patch_id);
            SET IDENTITY_INSERT QYYH OFF;
        END
    INSERT INTO #all_guid
    SELECT   guid
    FROM     EHRDC.dbo.tb_lis_report_indicator
    WHERE    guid NOT IN (SELECT guid
                          FROM   tb_lis_report_indicator)
    ORDER BY guid;
    WHILE EXISTS (SELECT *
                  FROM   #all_guid)
        BEGIN
            TRUNCATE TABLE #patch_guid;
            DELETE TOP (@cnt)
                   #all_guid
            OUTPUT deleted.guid INTO #patch_guid (guid);
            INSERT INTO TB_LIS_REPORT_INDICATOR
            SELECT t1.*,
                   t2.REPORTDATE
            FROM   EHRDC.dbo.tb_lis_report_indicator AS t1
                   INNER JOIN
                   EHRDC.dbo.TB_LIS_REPORT AS t2
                   ON t1.REPORTNO = t2.REPORTNO
            WHERE  t1.guid IN (SELECT guid
                               FROM   #patch_guid);
        END
    UPDATE HRASSOCIATIONINFO
    SET    MSG = (SELECT VALUE
                  FROM   TB_CODE
                  WHERE  TABLETYPE = 'HrPersonBasicInfo'
                         AND TARGETTABLE = 'HrAssociationInfo'
                         AND TARGETFIELD = 'history_of_disease'
                         AND CODE = HRASSOCIATIONINFO.CODE)
    WHERE  HRASSOCIATIONINFO.ASSOCIATIONTYPE LIKE '%family_history_of%';
   
END
go

