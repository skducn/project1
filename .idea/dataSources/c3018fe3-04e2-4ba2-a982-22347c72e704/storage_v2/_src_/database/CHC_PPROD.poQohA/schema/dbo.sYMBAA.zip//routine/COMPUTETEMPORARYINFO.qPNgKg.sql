
CREATE PROCEDURE [DBO].[COMPUTETEMPORARYINFO]
  @质控数据开始时间 VARCHAR(20),
  @质控数据截止时间 VARCHAR(20)
AS
BEGIN

IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_机构信息表'
            AND TYPE = 'U')
    DROP TABLE TEMP_机构信息表

IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_汇总表'
            AND TYPE = 'U')
    DROP TABLE TEMP_汇总表

IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_错误字段汇总表'
            AND TYPE = 'U')
    DROP TABLE TEMP_错误字段汇总表

IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_全部规则字段表'
            AND TYPE = 'U')
    DROP TABLE TEMP_全部规则字段表

IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_医生错误字段汇总表'
            AND TYPE = 'U')
    DROP TABLE TEMP_医生错误字段汇总表

IF EXISTS(SELECT *
          FROM SYSOBJECTS
          WHERE NAME = 'TEMP_医生汇总表'
            AND TYPE = 'U')
    DROP TABLE TEMP_医生汇总表


SELECT *
INTO TEMP_机构信息表
FROM (
         SELECT ORG_CODE,
                ORG_NAME,
                MAX(HR_SERVICE_CODE) HR_SERVICE_CODE
         FROM REPORT_QYYH
         GROUP BY ORG_CODE, ORG_NAME
     ) TEMP;
INSERT INTO
    TEMP_TABLES
VALUES(NEWID(),'TEMP_机构信息表',GETDATE());

WITH 封面汇总表 AS (
    SELECT ORG_CODE,
           ORG_NAME,
           -- 签约居民人数
           COUNT(*)           AS ALL_NUM,
           -- 签约未建档人数*(A+B)
           COUNT(*) - SUM(A4) AS LACK_NUM,
           'HRCOVER'             TARGETTABLE

    FROM REPORT_QYYH
    GROUP BY ORG_CODE, ORG_NAME
),
     基本信息汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,
                -- 签约居民人数
                COUNT(*)           AS ALL_NUM,
                -- 签约未建档人数*(A+B)
                COUNT(*) - SUM(A4) AS LACK_NUM,
                'HRPERSONBASICINFO'   TARGETTABLE

         FROM REPORT_QYYH
         GROUP BY ORG_CODE, ORG_NAME
     ),
     体检汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,
                -- 理论上总的体检表数量
                SUM(CASE WHEN B3 > B4 THEN B3 ELSE B4 END)     AS ALL_NUM,
                -- 实际缺少的体检表数量
                SUM(CASE WHEN B3 > B4 THEN B3 - B4 ELSE 0 END) AS LACK_NUM,
                'HRHEALTHCHECKUP'                                 TARGETTABLE

         FROM REPORT_QYYH
         WHERE R5 = 0
         GROUP BY ORG_CODE, ORG_NAME
     ),
     高血压汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,
                -- 理论上总的高血压表数量
                SUM(CASE WHEN B5 > B6 THEN B5 ELSE B6 END)     AS ALL_NUM,
                -- 实际缺少的高血压表数量
                SUM(CASE WHEN B5 > B6 THEN B5 - B6 ELSE 0 END) AS LACK_NUM,
                'HYPERTENSIONVISIT'                               TARGETTABLE
         FROM REPORT_QYYH
         WHERE R2 = 1
            OR R3 = 1
            OR R6 = 1
            OR R7 = 1
         GROUP BY ORG_CODE, ORG_NAME
     ),
     糖尿病汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,
                -- 理论上总的糖尿病表数量
                SUM(CASE WHEN B7 > B8 THEN B7 ELSE B8 END)     AS ALL_NUM,
                -- 实际缺少的糖尿病表数量
                SUM(CASE WHEN B7 > B8 THEN B7 - B8 ELSE 0 END) AS LACK_NUM,
                'DIABETESVISIT'                                   TARGETTABLE

         FROM REPORT_QYYH
         WHERE R2 = 1
            OR R4 = 1
            OR R6 = 1
            OR R8 = 1
         GROUP BY ORG_CODE, ORG_NAME
     )


SELECT *
INTO TEMP_汇总表
FROM (
         SELECT T1.ORG_CODE, T1.ORG_NAME, ISNULL(T2.ALL_NUM, 0) ALL_NUM, ISNULL(T2.LACK_NUM, 0) LACK_NUM, TARGETTABLE
         FROM TEMP_机构信息表 T1
                  LEFT JOIN (
             SELECT *
             FROM 高血压汇总表
             UNION ALL
             SELECT *
             FROM 糖尿病汇总表
             UNION ALL
             SELECT *
             FROM 体检汇总表
             UNION ALL
             SELECT *
             FROM 封面汇总表
             UNION ALL
             SELECT *
             FROM 基本信息汇总表
         ) T2 ON T1.ORG_CODE = T2.ORG_CODE
     ) TEMP
--给临时表添加索引
CREATE INDEX TEMP_汇总表_ORG_CODE_TARGETTABLE ON TEMP_汇总表 (ORG_CODE, TARGETTABLE);
INSERT INTO
    TEMP_TABLES
VALUES(NEWID(),'TEMP_汇总表',GETDATE());



WITH 封面错误字段统计表 AS (
    SELECT B.ORG_CODE,
           C.TARGETFIELD,
           C.TARGETFIELDCN,
           TARGETTABLE,
           COUNT(DISTINCT ARCHIVENUM + C.TARGETFIELD) ERROR_NUM
    FROM HRRULERECORD A,
         REPORT_QYYH B,
         HRRULE C,
         HRRULEPROPS D
    WHERE A.ARCHIVENUM = B.SFZH
      AND A.RULEID = C.RULEID
      AND C.TARGETTABLE = 'HRCOVER'
      AND C.RULEID = D.RULEID
      AND D.ENABLE = '1'
      AND A4 = 1
    GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE
),
     基本信息错误字段统计表 AS (
         SELECT B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT ARCHIVENUM + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'HRPERSONBASICINFO'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE
     ),
     体检错误字段统计表 AS (
         SELECT B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT IDOFTARGETTABLE + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D,
              TB_DC_EXAMINATION_INFO E
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'HRHEALTHCHECKUP'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
           AND R5 = 0
           AND E.ORGCODE = B.ORG_CODE
           AND A.IDOFTARGETTABLE = E.GUID
           AND E.EXAMINATIONDATE >= @质控数据开始时间
           AND E.EXAMINATIONDATE <= @质控数据截止时间
           -- AND C.TARGETFIELD != 'HRPERSONBASICINFO.ARCHIVENUM'
           -- AND C.TARGETFIELD != 'TB_EMPI_INDEX_ROOT.NAME'
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE
     ),
     高血压错误字段统计表 AS (
         SELECT B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT IDOFTARGETTABLE + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D,
              TB_DC_HTN_VISIT E
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'HYPERTENSIONVISIT'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
           AND E.ORGCODE = B.ORG_CODE
           AND (R2 = 1 OR R3 = 1 OR R6 = 1 OR R7 = 1)
           AND A.IDOFTARGETTABLE = E.GUID
           AND E.VISITDATE >= @质控数据开始时间
           AND E.VISITDATE <= @质控数据截止时间
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE
     ),
     糖尿病错误字段统计表 AS (
         SELECT B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT IDOFTARGETTABLE + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D,
              TB_DC_DM_VISIT E
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'DIABETESVISIT'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
           AND E.ORGCODE = B.ORG_CODE
           AND (R2 = 1 OR R4 = 1 OR R6 = 1 OR R8 = 1)
           AND A.IDOFTARGETTABLE = E.GUID
           AND E.VISITDATE >= @质控数据开始时间
           AND E.VISITDATE <= @质控数据截止时间
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE
     )
SELECT *
INTO TEMP_错误字段汇总表
FROM (
         SELECT *
         FROM 封面错误字段统计表
         UNION ALL
         SELECT *
         FROM 基本信息错误字段统计表
         UNION ALL
         SELECT *
         FROM 体检错误字段统计表
         UNION ALL
         SELECT *
         FROM 高血压错误字段统计表
         UNION ALL
         SELECT *
         FROM 糖尿病错误字段统计表
     ) TEMP
--给临时表添加索引
CREATE INDEX TEMP_错误字段汇总表_ORG_CODE_TARGETTABLE_TARGETFIELD ON TEMP_错误字段汇总表 (ORG_CODE, TARGETTABLE, TARGETFIELD);
INSERT INTO
    TEMP_TABLES
VALUES(NEWID(),'TEMP_错误字段汇总表',GETDATE());


WITH 医生封面错误字段统计表 AS (
    SELECT 
		       CZRYXM,
					 CZRYBM,
					 B.ORG_CODE,
           C.TARGETFIELD,
           C.TARGETFIELDCN,
           TARGETTABLE,
           COUNT(DISTINCT ARCHIVENUM + C.TARGETFIELD) ERROR_NUM
    FROM HRRULERECORD A,
         REPORT_QYYH B,
         HRRULE C,
         HRRULEPROPS D
    WHERE A.ARCHIVENUM = B.SFZH
      AND A.RULEID = C.RULEID
      AND C.TARGETTABLE = 'HRCOVER'
      AND C.RULEID = D.RULEID
      AND D.ENABLE = '1'
      AND A4 = 1
    GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE,CZRYXM,CZRYBM
),
     医生基本信息错误字段统计表 AS (
         SELECT 
				        CZRYXM,
					 CZRYBM,
				 B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT ARCHIVENUM + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'HRPERSONBASICINFO'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE,CZRYXM,CZRYBM
     ),
    医生体检错误字段统计表 AS (
         SELECT 
				        CZRYXM,
					 CZRYBM,
				 B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT IDOFTARGETTABLE + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D,
              TB_DC_EXAMINATION_INFO E
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'HRHEALTHCHECKUP'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
           AND R5 = 0
           AND E.ORGCODE = B.ORG_CODE
           AND A.IDOFTARGETTABLE = E.GUID
           AND E.EXAMINATIONDATE >= @质控数据开始时间
           AND E.EXAMINATIONDATE <= @质控数据截止时间
           -- AND C.TARGETFIELD != 'HRPERSONBASICINFO.ARCHIVENUM'
           -- AND C.TARGETFIELD != 'TB_EMPI_INDEX_ROOT.NAME'
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE,CZRYXM,
					 CZRYBM
     ),
     医生高血压错误字段统计表 AS (
         SELECT
				        CZRYXM,
					 CZRYBM,
				 B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT IDOFTARGETTABLE + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D,
              TB_DC_HTN_VISIT E
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'HYPERTENSIONVISIT'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
           AND E.ORGCODE = B.ORG_CODE
           AND (R2 = 1 OR R3 = 1 OR R6 = 1 OR R7 = 1)
           AND A.IDOFTARGETTABLE = E.GUID
           AND E.VISITDATE >= @质控数据开始时间
           AND E.VISITDATE <= @质控数据截止时间
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE,       CZRYXM,
					 CZRYBM
     ),
     医生糖尿病错误字段统计表 AS (
         SELECT 
				        CZRYXM,
					 CZRYBM,
				 B.ORG_CODE,
                C.TARGETFIELD,
                C.TARGETFIELDCN,
                TARGETTABLE,
                COUNT(DISTINCT IDOFTARGETTABLE + C.TARGETFIELD) ERROR_NUM
         FROM HRRULERECORD A,
              REPORT_QYYH B,
              HRRULE C,
              HRRULEPROPS D,
              TB_DC_DM_VISIT E
         WHERE A.ARCHIVENUM = B.SFZH
           AND A.RULEID = C.RULEID
           AND C.TARGETTABLE = 'DIABETESVISIT'
           AND C.RULEID = D.RULEID
           AND D.ENABLE = '1'
           AND A4 = 1
           AND E.ORGCODE = B.ORG_CODE
           AND (R2 = 1 OR R4 = 1 OR R6 = 1 OR R8 = 1)
           AND A.IDOFTARGETTABLE = E.GUID
           AND E.VISITDATE >= @质控数据开始时间
           AND E.VISITDATE <= @质控数据截止时间
         GROUP BY C.TARGETFIELD, C.TARGETFIELDCN, B.ORG_CODE, TARGETTABLE, CZRYXM,
					 CZRYBM
     )
SELECT *
INTO TEMP_医生错误字段汇总表
FROM (
         SELECT *
         FROM 医生封面错误字段统计表
         UNION ALL
         SELECT *
         FROM 医生基本信息错误字段统计表
         UNION ALL
         SELECT *
         FROM 医生体检错误字段统计表
         UNION ALL
         SELECT *
         FROM 医生高血压错误字段统计表
         UNION ALL
         SELECT *
         FROM 医生糖尿病错误字段统计表
     ) TEMP



--给临时表添加索引
CREATE INDEX TEMP_医生错误字段汇总表_ORG_CODE_TARGETTABLE_TARGETFIELD ON TEMP_医生错误字段汇总表 (ORG_CODE, TARGETTABLE, TARGETFIELD,CZRYXM,
					 CZRYBM );
INSERT INTO
    TEMP_TABLES
VALUES(NEWID(),'TEMP_医生错误字段汇总表',GETDATE());


WITH 医生封面汇总表 AS (
    SELECT ORG_CODE,
           ORG_NAME,
CZRYXM, CZRYBM,
           -- 签约居民人数
           COUNT(*)           AS ALL_NUM,
           -- 签约未建档人数*(A+B)
           COUNT(*) - SUM(A4) AS LACK_NUM,
           'HRCOVER'             TARGETTABLE

    FROM REPORT_QYYH
    GROUP BY ORG_CODE, ORG_NAME,CZRYXM,CZRYBM
),
     医生基本信息汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,
CZRYXM,
					 CZRYBM,
                -- 签约居民人数
                COUNT(*)           AS ALL_NUM,
                -- 签约未建档人数*(A+B)
                COUNT(*) - SUM(A4) AS LACK_NUM,
                'HRPERSONBASICINFO'   TARGETTABLE

         FROM REPORT_QYYH
         GROUP BY ORG_CODE, ORG_NAME,CZRYXM,
					 CZRYBM
     ),
     医生体检汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,
CZRYXM,
					 CZRYBM,
                -- 理论上总的体检表数量
                SUM(CASE WHEN B3 > B4 THEN B3 ELSE B4 END)     AS ALL_NUM,
                -- 实际缺少的体检表数量
                SUM(CASE WHEN B3 > B4 THEN B3 - B4 ELSE 0 END) AS LACK_NUM,
                'HRHEALTHCHECKUP'                                 TARGETTABLE

         FROM REPORT_QYYH
         WHERE R5 = 0
         GROUP BY ORG_CODE, ORG_NAME,CZRYXM,
					 CZRYBM
     ),
    医生高血压汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,CZRYXM,
					 CZRYBM,
                -- 理论上总的高血压表数量
                SUM(CASE WHEN B5 > B6 THEN B5 ELSE B6 END)     AS ALL_NUM,
                -- 实际缺少的高血压表数量
                SUM(CASE WHEN B5 > B6 THEN B5 - B6 ELSE 0 END) AS LACK_NUM,
                'HYPERTENSIONVISIT'                               TARGETTABLE
         FROM REPORT_QYYH
         WHERE R2 = 1
            OR R3 = 1
            OR R6 = 1
            OR R7 = 1
         GROUP BY ORG_CODE, ORG_NAME,CZRYXM,
					 CZRYBM
     ),
     医生糖尿病汇总表 AS (
         SELECT ORG_CODE,
                ORG_NAME,
CZRYXM,
					 CZRYBM,
                -- 理论上总的糖尿病表数量
                SUM(CASE WHEN B7 > B8 THEN B7 ELSE B8 END)     AS ALL_NUM,
                -- 实际缺少的糖尿病表数量
                SUM(CASE WHEN B7 > B8 THEN B7 - B8 ELSE 0 END) AS LACK_NUM,
                'DIABETESVISIT'                                   TARGETTABLE

         FROM REPORT_QYYH
         WHERE R2 = 1
            OR R4 = 1
            OR R6 = 1
            OR R8 = 1
         GROUP BY ORG_CODE, ORG_NAME,CZRYXM,CZRYBM
     )


SELECT *
INTO TEMP_医生汇总表
FROM (
         SELECT T1.ORG_CODE, T1.ORG_NAME,CZRYXM,
					 CZRYBM,ISNULL(T2.ALL_NUM, 0) ALL_NUM, ISNULL(T2.LACK_NUM, 0) LACK_NUM, TARGETTABLE
         FROM TEMP_机构信息表 T1
             LEFT JOIN (
             SELECT *
             FROM 医生高血压汇总表
             UNION ALL
             SELECT *
             FROM 医生糖尿病汇总表
             UNION ALL
             SELECT *
             FROM 医生体检汇总表
             UNION ALL
             SELECT *
             FROM 医生封面汇总表
             UNION ALL
             SELECT *
             FROM 医生基本信息汇总表
         ) T2 ON T1.ORG_CODE = T2.ORG_CODE
     ) TEMP
--给临时表添加索引
CREATE INDEX TEMP_医生汇总表_ORG_CODE_TARGETTABLE ON TEMP_医生汇总表 (ORG_CODE, TARGETTABLE,CZRYXM,
					 CZRYBM);
INSERT INTO
    TEMP_TABLES
VALUES(NEWID(),'TEMP_医生汇总表',GETDATE());


WITH 缺失规则质控字段 AS (
    SELECT *
    FROM (
             VALUES ('HRCOVER', 'HRCOVER.ARCHIVENUM', '档案编号'),
                    ('HRPERSONBASICINFO', 'HRASSOCIATIONINFO.ASSOCIATIONTYPE', '暴露史'),
                    ('HRPERSONBASICINFO', 'HRPERSONBASICINFO.ARCHIVENUM', '档案编号'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.B超—其他', 'B超—其他'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.肝功能—白蛋白', '肝功能—白蛋白'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.肝功能—结合胆红素', '肝功能—结合胆红素'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.口腔—龋齿', '口腔—龋齿'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.口腔—缺齿', '口腔—缺齿'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.口腔—义齿', '口腔—义齿'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.肾功能—血钾浓度', '肾功能—血钾浓度'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.肾功能—血钠浓度', '肾功能—血钠浓度'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—放射物质', '职业病危害因素接触史—放射物质'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—放射物质防护措施', '职业病危害因素接触史—放射物质防护措施'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—粉尘', '职业病危害因素接触史—粉尘'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—粉尘防护措施', '职业病危害因素接触史—粉尘防护措施'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—化学物质', '职业病危害因素接触史—化学物质'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—化学物质防护措施', '职业病危害因素接触史—化学物质防护措施'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—其他', '职业病危害因素接触史—其他'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—其他防护措施', '职业病危害因素接触史—其他防护措施'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—物理因素', '职业病危害因素接触史—物理因素'),
                    ('HRHEALTHCHECKUP', 'HRHEALTHCHECKUP.职业病危害因素接触史—物理因素防护措施', '职业病危害因素接触史—物理因素防护措施'),
                    ('HYPERTENSIONVISIT', 'HYPERTENSIONVISIT.年龄', '年龄'),
                    ('DIABETESVISIT', 'HYPERTENSIONVISIT.其他随访方式', '其他随访方式'),
                    ('DIABETESVISIT', 'HYPERTENSIONVISIT.糖尿病新诊断并发症—确诊日期', '糖尿病新诊断并发症—确诊日期'),
                    ('DIABETESVISIT', 'HYPERTENSIONVISIT.用药情况—服药量单位', '用药情况—服药量单位')
         )
             AS X(TARGETTABLE, TARGETFIELD, TARGETFIELDCN)
),
     全部规则字段表TEMP AS (
         SELECT DISTINCT TARGETTABLE,
                         TARGETFIELD,
                         TARGETFIELDCN
         FROM HRRULE T2,
              HRRULEPROPS T3
         WHERE T2.TARGETTABLE IN
               ('HRCOVER', 'HRPERSONBASICINFO', 'HRHEALTHCHECKUP', 'HYPERTENSIONVISIT', 'DIABETESVISIT')
           AND T2.RULEID = T3.RULEID
           AND T2.RULEID NOT IN (SELECT RULEID FROM HRRULE WHERE TARGETFIELD = 'HRPERSONBASICINFO.ARCHIVENUM')
           AND T2.RULEID NOT IN (SELECT RULEID FROM HRRULE WHERE TARGETFIELD = 'TB_EMPI_INDEX_ROOT.NAME')
           AND T2.RULEID NOT IN
               (SELECT RULEID FROM HRRULE WHERE TARGETFIELDCN IN ('职业病危害因素接触史—毒物种类', '职业病危害因素接触史—防护措施', '其他失访理由'))
           AND T3.ENABLE = '1'

         UNION ALL
         SELECT *
         FROM 缺失规则质控字段
     )

SELECT *
INTO TEMP_全部规则字段表
FROM (
         SELECT A.ORG_CODE, A.ORG_NAME, A.HR_SERVICE_CODE, B.TARGETFIELD, B.TARGETFIELDCN, B.TARGETTABLE
         FROM TEMP_机构信息表 A,
              全部规则字段表TEMP B
     ) TEMP
--给临时表添加索引
CREATE INDEX TEMP_全部规则字段表_ORG_CODE_TARGETTABLE_TARGETFIELD ON TEMP_全部规则字段表 (ORG_CODE, TARGETTABLE, TARGETFIELD)
INSERT INTO
    TEMP_TABLES
VALUES(NEWID(),'TEMP_全部规则字段表',GETDATE());


END
go

