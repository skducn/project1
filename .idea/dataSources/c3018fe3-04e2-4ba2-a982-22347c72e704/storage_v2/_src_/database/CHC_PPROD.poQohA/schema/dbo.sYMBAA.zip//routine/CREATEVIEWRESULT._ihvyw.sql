
CREATE PROCEDURE [DBO].[CREATEVIEWRESULT]
@BATCHNUM VARCHAR(50)
AS
BEGIN
    -- 根据批次号进行相关结果数据的生成

--如果没有该表 需要先创建视图
--CREATE VIEW SPECIALCROWD AS  (
--SELECT * FROM HEALTHRECORD.DBO.SPECIALCROWD )

--     DECLARE @CONTROL_BASIC_FULLTABLENAME VARCHAR(100)
--     DECLARE @CONTROL_RESULT_FULLTABLENAME VARCHAR(100)
--     DECLARE @PROBLEMARCHIVEVIEW_FULLTABLENAME VARCHAR(100)
    DECLARE @EXECSQL VARCHAR(MAX)
--     SET @CONTROL_BASIC_FULLTABLENAME='CONTROL_BASIC'
--     SET @CONTROL_RESULT_FULLTABLENAME='CONTROL_RESULT'
--     SET @PROBLEMARCHIVEVIEW_FULLTABLENAME='PROBLEMARCHIVEVIEW'


    --需要先行删除视图  @PROBLEMARCHIVEVIEW_FULLTABLENAME
--删除表  @CONTROL_BASIC_FULLTABLENAME  @CONTROL_RESULT_FULLTABLENAME
--删除数据  ZKTYPETREND ZKBM 为 @BATCHNUM
    SELECT @EXECSQL =
            '
--             IF EXISTS (SELECT * FROM SYS.ALL_OBJECTS WHERE OBJECT_ID = OBJECT_ID(N''[DBO].[PROBLEMARCHIVEVIEW]'') AND TYPE IN (''V''))
--                 DROP VIEW [DBO].[PROBLEMARCHIVEVIEW]
-- 

            IF EXISTS (SELECT * FROM SYS.ALL_OBJECTS WHERE OBJECT_ID = OBJECT_ID(N''[DBO].[CONTROL_BASIC]'') AND TYPE IN (''U''))
                DROP TABLE [DBO].[CONTROL_BASIC]


            IF EXISTS (SELECT * FROM SYS.ALL_OBJECTS WHERE OBJECT_ID = OBJECT_ID(N''[DBO].[CONTROL_RESULT]'') AND TYPE IN (''U''))
                DROP TABLE [DBO].[CONTROL_RESULT]

            DELETE FROM ZKTYPETREND WHERE ZKBM =''@BATCHNUM'';
            DELETE FROM CONTROLERROR WHERE CONTROLID =''@BATCHNUM'';

            '
    EXEC(@EXECSQL)


    PRINT '--------------------------------清除设置批次的表----------------------------------------------'


    --人员基本信息表(相对质控结果表,多了质控通过的人员)

--质控结果信息
    SELECT @EXECSQL =
            '
            CREATE TABLE CONTROL_BASIC(
            ROWNUMBER INT,
            IDCARD VARCHAR(50),
            ARCHIVENUM VARCHAR(70),
            NAME VARCHAR(50),
            ARCHIVEUNIT VARCHAR(100),
            ARCHIVEUNITCODE VARCHAR(32),
            AGE INT DEFAULT 0, --年龄
            JB_GXY INT DEFAULT 0, --高血压
            JB_TNB INT DEFAULT 0, --糖尿病
            JB_NCZ INT DEFAULT 0, --脑卒中
            JB_ZL INT DEFAULT 0, --肿瘤
            JB_FJH INT DEFAULT 0, --肺结核
            JB_JSB INT DEFAULT 0, --精神病
            JB_OTHER INT DEFAULT 0,--其他
            TS_YUNFU INT DEFAULT 0,--特殊人群-孕妇
            TS_JIHUA_JIATING INT DEFAULT 0, --计划生育特殊家庭
            TS_PINKUN INT DEFAULT 0, --贫困家庭
            TS_CANJI INT DEFAULT 0, --是否是残疾
            TS_OTHER INT DEFAULT 0, --是否是其他特殊人群
            JTYS_TD_NAME VARCHAR(100),--家庭医生团队名称
            SIGN_DOCTOR_NAME VARCHAR(100),--签约医生姓名
            SIGN_DOCTOR_NO VARCHAR(100),--签约医生工号
            YEARS VARCHAR(10), --年份
            ISSIGNED VARCHAR(2), --是否签约
            ISERROR INT, --档案是否通过 1为有错

            ISCOVERBAISC INT, --属于封面基本 1为属于
            ISCHECKUP INT, --健康体检表分值  1为属于
            ISHYPERTENSION INT, --属于高血压随访表 1为属于
            ISDIABETES INT, --属于糖尿病随访表 1为属于

            COVERBAISCSCORE INT, --封面基本信息表分值
            CHECKUPSCORE INT, --健康体检表分值
            HYPERTENSIONSCORE INT, --高血压随访表分值
            DIABETESSCORE INT, --糖尿病随访表分值

             ISERRORCOVERBASIC INT, --封面表
             ISERRORCHECKUP INT--, --体检表
             --ISERRORHYPERTENSION INT,--高血压随访表
             --ISERRORDIABETES INT --糖尿病随访表

            )
            '

    EXEC(@EXECSQL)

    PRINT '------------------------------------创建质控结果记录表-------------------------------------'

    --基本信息居民档案分数表

--基本信息表插入数据

    SELECT @EXECSQL =  '
                                      INSERT INTO CONTROL_BASIC(ROWNUMBER,IDCARD,ARCHIVENUM,NAME,ARCHIVEUNIT,ARCHIVEUNITCODE,ISERROR)
                                      SELECT  ROW_NUMBER() OVER( ORDER BY(B.IDCARD)) ROWNUMBER,B.IDCARD,B.ARCHIVENUM,B.NAME,A.ARCHIVEUNIT,A.ARCHIVEUNITCODE,
                                      ISNULL(C.FLAG,0) AS ISERROR
                                      FROM HRCOVER A
                                      INNER JOIN DBO.HRPERSONBASICINFO B
                                      ON A.ARCHIVENUM = B.ARCHIVENUM
                                      LEFT JOIN (SELECT ARCHIVENUM,1 AS FLAG FROM HRARCHIVESRESULT WHERE ISPASS=0 GROUP BY ARCHIVENUM ) C
                                      ON A.ARCHIVENUM = C.ARCHIVENUM
                                      '

    EXEC(@EXECSQL)

    PRINT '-----------------------------------------插入基本信息表--------------------------------------------------'

--质控结果表

    SELECT @EXECSQL =
            '
            CREATE TABLE CONTROL_RESULT(
            ID INT IDENTITY(1,1) PRIMARY KEY,
            ARCHIVENUM VARCHAR(70),
            TABLENAME VARCHAR(100),
            FIELDNAME VARCHAR(100),
            RULETYPE VARCHAR(100),
            COMMENT VARCHAR(200),
            STRENGTHNAME VARCHAR(10)
            )
            '
    EXEC(@EXECSQL)

    PRINT '-----------------------------------------创建质控结果表------------------------------------------------------------------'
    --质控结果数据插入
--SELECT @EXECSQL = REPLACE(REPLACE(
--'
--INSERT INTO @CONTROL_RESULT_FULLTABLENAME(ARCHIVENUM,TABLENAME,FIELDNAME,RULETYPE,COMMENT,STRENGTHNAME)
--SELECT  A.ARCHIVENUM,C.FORMNAME,C.FIELDNAME,B.CATEGORIES AS RULETYPE,B.COMMENT,C.STRENGTHNAME  FROM HRRULERECORD_@BATCHNUM A
--INNER JOIN DBO.HRRULE B
--ON A.RULEID = B.RULEID
--LEFT JOIN DBO.DIMFORM C
--ON B.TARGETTABLE = C.FORMTYPE AND B.TARGETFIELD = C.FIELDTYPE
--
--','@CONTROL_RESULT_FULLTABLENAME',@CONTROL_RESULT_FULLTABLENAME),'@BATCHNUM',@BATCHNUM)

    SELECT @EXECSQL =
                                      '
                                      INSERT INTO CONTROL_RESULT(ARCHIVENUM,TABLENAME,FIELDNAME,RULETYPE,COMMENT,STRENGTHNAME)

                                      SELECT   A.ARCHIVENUM,

                                       CASE B.TARGETTABLE
                                       WHEN ''HRHEALTHCHECKUP'' THEN ''健康体检表''
                                       WHEN ''HYPERTENSIONVISIT'' THEN ''高血压随访表''
                                       WHEN ''HRCOVER'' THEN ''封面表''
                                        WHEN ''DIABETESVISIT'' THEN ''糖尿病随访表''
                                         WHEN ''HRPERSONBASICINFO'' THEN ''基本信息表''
                                         END AS TABLENAME,
                                      B.TARGETFIELDCN AS FIELDNAME,
                                      B.CATEGORIES AS RULETYPE,B.COMMENT,
                                      CASE  B.INDEXLEVEL
                                      WHEN 1 THEN ''核心''
                                      WHEN 2 THEN ''重要''
                                      WHEN 3 THEN ''中等''
                                      WHEN 4 THEN ''普通'' END AS STRENGTHNAME
                                      FROM HRRULERECORD A
                                      INNER JOIN DBO.HRRULE B
                                      ON A.RULEID = B.RULEID

                                      '

    EXEC(@EXECSQL)

    PRINT '---------------------------------插入质控结果----------------------------------------------'

---质控基本信息创建索引


    SELECT @EXECSQL = 
            '
            CREATE NONCLUSTERED INDEX CONTROL_BASIC_IDCARD ON CONTROL_BASIC (IDCARD);  --身份证号
            CREATE NONCLUSTERED INDEX CONTROL_BASIC_ARCHIVENUM ON CONTROL_BASIC (ARCHIVENUM);  --档案编号
            CREATE NONCLUSTERED INDEX CONTROL_BASIC_ISSIGNED_AGE_ARCHIVENUM ON CONTROL_BASIC (ISSIGNED,AGE,ARCHIVENUM); --年龄
            CREATE NONCLUSTERED INDEX CONTROL_BASIC_SIGNDOCTORNAME_ARCHIVENUM ON CONTROL_BASIC (SIGN_DOCTOR_NAME,ARCHIVENUM); --签约医生
            '
    EXEC(@EXECSQL)


    PRINT '--------------------------------------质控基本信息创建索引-----------------------------------------------------------'
---质控结果创建索引

    SELECT @EXECSQL = 
            '
            CREATE NONCLUSTERED INDEX CONTROL_RESULT_ARCHIVENUM ON CONTROL_RESULT (ARCHIVENUM);  --档案编号
            CREATE NONCLUSTERED INDEX CONTROL_RESULT_RULETYPE_TABLENAME_FIELDNAME_ARCHIVENUM ON CONTROL_RESULT (RULETYPE,TABLENAME,FIELDNAME,ARCHIVENUM);  --规则类型
            CREATE NONCLUSTERED INDEX CONTROL_RESULT_STRENGTHNAME_TABLENAME_FIELDNAME_ARCHIVENUM ON CONTROL_RESULT (STRENGTHNAME,TABLENAME,FIELDNAME,ARCHIVENUM);  --指标强度
            '
    EXEC(@EXECSQL)

    PRINT '--------------------------------------------质控结果创建索引------------------------------------------------------------------------'
---创建视图
-- 
--     SELECT @EXECSQL = 
--                                       '
--                                       CREATE VIEW PROBLEMARCHIVEVIEW AS (
--                                       SELECT
--                                       A.ROWNUMBER,
--                                       A.IDCARD,
--                                       A.ARCHIVENUM,
--                                       A.NAME,
--                                       A.ARCHIVEUNIT,
--                                       A.ARCHIVEUNITCODE,
--                                       A.AGE,
--                                       A.JB_GXY,
--                                       A.JB_TNB,
--                                       A.JB_NCZ,
--                                       A.JB_ZL,
--                                       A.JB_FJH,
--                                       A.JB_JSB,
--                                       A.JB_OTHER,
--                                       A.TS_YUNFU,
--                                       A.TS_JIHUA_JIATING,
--                                       A.TS_PINKUN,
--                                       A.TS_CANJI,
--                                       A.TS_OTHER,
--                                       A.JTYS_TD_NAME,
--                                       A.SIGN_DOCTOR_NAME,
--                                       A.SIGN_DOCTOR_NO,
--                                       A.YEARS,
--                                       A.ISSIGNED,
--                                       A.ISERROR,
--                                       B.TABLENAME,
--                                       B.FIELDNAME,
--                                       B.RULETYPE,
--                                       B.COMMENT,
--                                       '''' AS RULELEVEL,
--                                       B.STRENGTHNAME
--                                       FROM CONTROL_BASIC A
--                                           INNER JOIN CONTROL_RESULT B
--                                           ON A.ARCHIVENUM = B.ARCHIVENUM
--                                           WHERE ISERROR=1
--                                       )
--                                       '
-- 
--     EXEC(@EXECSQL)

    PRINT '--------------------------------------创建视图-------------------------------------------------'

    -------------------------------------------更新脚本



--年龄更新
--SELECT @EXECSQL = REPLACE(
--'
--UPDATE A SET AGE=DATENAME(YEAR,GETDATE())- CAST(SUBSTRING(IDCARD,7,4) AS INT) FROM CONTROL_BASIC_@BATCHNUM A
--WHERE ISNUMERIC(SUBSTRING(IDCARD,7,4))=1;
--','@BATCHNUM',@BATCHNUM
--)
    SELECT @EXECSQL = 
            '
            UPDATE A SET AGE =
            (
            CASE  LEN(A.IDCARD)
            WHEN 18 THEN DATENAME(YEAR,GETDATE())- CAST(SUBSTRING(IDCARD,7,4) AS INT)
            WHEN 15 THEN DATENAME(YEAR,GETDATE())- CAST(''19''+SUBSTRING(IDCARD,7,2) AS INT)
            ELSE -1 END )
            FROM CONTROL_BASIC A
            WHERE ISNUMERIC(SUBSTRING(IDCARD,7,4))=1;
            UPDATE  CONTROL_BASIC SET AGE =-1 WHERE DBO.ISVALIDIDCARD(IDCARD) =0;
            '
    EXEC(@EXECSQL)

    PRINT '----------------------------更新年龄--------------------------------------------------'
    ----------------------------------------------------
--高血压
    SELECT @EXECSQL = 
            '
            UPDATE A SET JB_GXY=ISNULL(GXY,0) FROM CONTROL_BASIC A
             LEFT JOIN (
            SELECT IDCARD,1 AS GXY FROM HRASSOCIATIONINFO T1
                    LEFT JOIN  HRPERSONBASICINFO T2 ON T1.PID = T2.ID
                    WHERE ASSOCIATIONTYPE = ''HISTORY_OF_DISEASE''
                    AND CODE = ''I10.X00'')B
                    ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------更新高血压------------------------------------------------'
    ----------------------------------------------------
--糖尿病
    SELECT @EXECSQL = 
            '
                UPDATE A SET JB_TNB=ISNULL(TNB,0) FROM CONTROL_BASIC A
             LEFT JOIN (
            SELECT IDCARD,1 AS TNB FROM HRASSOCIATIONINFO T1
                    LEFT JOIN  HRPERSONBASICINFO T2 ON T1.PID = T2.ID
                    WHERE ASSOCIATIONTYPE = ''HISTORY_OF_DISEASE''
                    AND CODE = ''E14.900'')B
                    ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)

    PRINT '------------------------------------更新糖尿病--------------------------------------------------------'
    ------------------------------------------------------
---脑卒中 I64.X00
    SELECT @EXECSQL = 
            '
                    UPDATE A SET JB_NCZ=ISNULL(NCZ,0) FROM CONTROL_BASIC A
             LEFT JOIN (
            SELECT IDCARD,1 AS NCZ FROM HRASSOCIATIONINFO T1
                    LEFT JOIN  HRPERSONBASICINFO T2 ON T1.PID = T2.ID
                    WHERE ASSOCIATIONTYPE = ''HISTORY_OF_DISEASE''
                    AND CODE = ''I64.X00'')B
                    ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)

    PRINT '--------------------------------------脑卒中------------------------------------------------------------'
    -----------------------------------------------------
---肿瘤  10
    SELECT @EXECSQL = 
            '
            UPDATE A SET JB_ZL=ISNULL(ZL,0) FROM CONTROL_BASIC A
             LEFT JOIN (
            SELECT IDCARD,1 AS ZL FROM HRASSOCIATIONINFO T1
                    LEFT JOIN  HRPERSONBASICINFO T2 ON T1.PID = T2.ID
                    WHERE ASSOCIATIONTYPE = ''HISTORY_OF_DISEASE''
                    AND CODE = ''10'')B
                    ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)

    PRINT '------------------------------------------肿瘤----------------------------------------------------------'
    -----------------------------------------------------


--肺结核 1004
    SELECT @EXECSQL = 
            '
                UPDATE A SET JB_FJH=ISNULL(FJH,0) FROM CONTROL_BASIC A
             LEFT JOIN (
            SELECT IDCARD,1 AS FJH FROM HRASSOCIATIONINFO T1
                    LEFT JOIN  HRPERSONBASICINFO T2 ON T1.PID = T2.ID
                    WHERE ASSOCIATIONTYPE = ''HISTORY_OF_DISEASE''
                    AND CODE = ''1004'')B
                    ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------------------肺结核--------------------------------------------------------------'
    -----------------------------------------------------
--精神病 1003
    SELECT @EXECSQL =
            '
            UPDATE A SET JB_JSB=ISNULL(JSB,0) FROM CONTROL_BASIC A
             LEFT JOIN (
            SELECT IDCARD,1 AS JSB FROM HRASSOCIATIONINFO T1
                    LEFT JOIN  HRPERSONBASICINFO T2 ON T1.PID = T2.ID
                    WHERE ASSOCIATIONTYPE = ''HISTORY_OF_DISEASE''
                    AND CODE = ''1003'')B
                    ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------------------精神病-----------------------------------------------------------------'
    -----------------------------------------------------
----其他  NOT IN ('I10.X00','E14.900','I64.X00','10','1004','1003','0000') AND T1.MSG !='无'
    SELECT @EXECSQL = 
            '
            UPDATE A SET JB_OTHER=ISNULL(OTHER,0) FROM CONTROL_BASIC A
             LEFT JOIN (
            SELECT IDCARD,1 AS OTHER FROM HRASSOCIATIONINFO T1
                    LEFT JOIN  HRPERSONBASICINFO T2 ON T1.PID = T2.ID
                    WHERE ASSOCIATIONTYPE = ''HISTORY_OF_DISEASE''
                    AND CODE NOT IN (''I10.X00'',''E14.900'',''I64.X00'',''10'',''1004'',''1003'',''0000'') AND T1.MSG !=''无'')B
                    ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)
    PRINT '---------------------------------------------其他--------------------------------------------------------'
    -------------------------------------------------
--孕妇等更新
    SELECT @EXECSQL = 
            '
            UPDATE A SET TS_YUNFU =ISNULL(B.ISYUN,0),TS_JIHUA_JIATING = ISNULL(B.ISJIHUA,0),
            TS_PINKUN = ISNULL(B.ISPIN,0),TS_CANJI =ISNULL(B.ISCAN,0),
            TS_OTHER=ISNULL(B.OTHER,0)
             FROM CONTROL_BASIC A
            LEFT JOIN SPECIALCROWD B
            ON A.IDCARD = B.IDCARD;
            '
    EXEC(@EXECSQL)

    PRINT '--------------------------------------孕妇等更新--------------------------------------------------'
    -------------------------------------------------
----------家庭医生团队
    SELECT @EXECSQL = 
            '
                UPDATE A SET A.JTYS_TD_NAME= D.TEAMNAME FROM CONTROL_BASIC A
                LEFT JOIN DBO.HRPERSONBASICINFO B
                ON A.IDCARD = B.IDCARD
                LEFT JOIN HRCOVER C
                ON A.ARCHIVENUM =C.ARCHIVENUM
                LEFT JOIN DBO.TEAM D
                ON C.VILLAGECODE = D.VILLAGECODE
                WHERE ISNULL(C.VILLAGECODE,'''') !='''';
            '
    EXEC(@EXECSQL)

    PRINT '----------------------------------------家庭医生团队------------------------------------------------------------------'
    -------------------------------------------------
--	责任医生姓名,责任医生编码
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.SIGN_DOCTOR_NAME=B.CZRYXM,A.SIGN_DOCTOR_NO=B.CZRYBM FROM CONTROL_BASIC A
                LEFT JOIN QYYH B
                ON A.IDCARD = B.SFZH;
            '
    EXEC(@EXECSQL)

    PRINT '-------------------------------------------责任医生姓名,责任医生编码--------------------------------------------------------'
    -------------------------------------------------
--年更新
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.YEARS =CONVERT(VARCHAR(4),ISNULL(B.UPDATETIME,B.CREATETIME),23) FROM
             CONTROL_BASIC A
            LEFT JOIN HRCOVER B
            ON A.ARCHIVENUM = B.ARCHIVENUM;
            '
    EXEC(@EXECSQL)

    PRINT '--------------------------------------------------更新------------------------------------------------------------'
    -------------------------------------------------
--是否签约更新
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.ISSIGNED =ISNULL(B.ISSIGNED,0)
             FROM
             CONTROL_BASIC A
            LEFT JOIN (SELECT *,1 AS ISSIGNED FROM QYYH) B
            ON A.IDCARD = B.SFZH;
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------------------------是否签约更新------------------------------------------------------'

--封面基本信息表
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.ISCOVERBAISC=1
            FROM CONTROL_BASIC A
            '
    EXEC(@EXECSQL)

    PRINT '--------------------------------------封面基本信息表---------------------------------------------'

    --ISCHECKUP
--体检表
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.ISCHECKUP=(CASE WHEN B.IDCARDNO IS NOT NULL THEN ''1'' ELSE ''0'' END)
            FROM CONTROL_BASIC A
            LEFT JOIN (SELECT DISTINCT(T.IDCARDNO) FROM TB_EMPI_PAT_INFO T INNER JOIN TB_DC_EXAMINATION_INFO T1 ON T.GUID=T1.EMPIGUID WHERE SYSTEMCODE=''JKTJ_MAIN'') B
            ON A.IDCARD=B.IDCARDNO
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------------------体检表---------------------------------------------------------'

    --ISHYPERTENSION
--高血压随访表
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.ISHYPERTENSION=(CASE WHEN B.IDCARDNO IS NOT NULL THEN ''1'' ELSE ''0'' END)
            FROM CONTROL_BASIC A
            LEFT JOIN (SELECT DISTINCT(IDCARDNO) FROM TB_EMPI_PAT_INFO T
            INNER JOIN TB_DC_CHRONIC_INFO T1 ON T.GUID=T1.EMPIGUID
            INNER JOIN TB_DC_CHRONIC_MAIN T2 ON T1.MANAGENUM=T2.MANAGENUM AND T1.ORGCODE=T2.ORGCODE
            INNER JOIN TB_DC_HTN_VISIT T3 ON T2.VISITNUM=T3.CARDID WHERE SYSTEMCODE=''MXB_MAIN'') B
            ON A.IDCARD=B.IDCARDNO
            '
    EXEC(@EXECSQL)

    PRINT '------------------------------------------高血压随访表--------------------------------------------------------------------'
    --ISDIABETES
--糖尿病随访表
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.ISDIABETES=(CASE WHEN B.IDCARDNO IS NOT NULL THEN ''1'' ELSE ''0'' END)
            FROM CONTROL_BASIC A
            LEFT JOIN (SELECT DISTINCT(IDCARDNO) FROM TB_EMPI_PAT_INFO T
            INNER JOIN TB_DC_CHRONIC_INFO T1 ON T.GUID=T1.EMPIGUID
            INNER JOIN TB_DC_CHRONIC_MAIN T2 ON T1.MANAGENUM=T2.MANAGENUM AND T1.ORGCODE=T2.ORGCODE
            INNER JOIN TB_DC_DM_VISIT T3 ON T2.VISITNUM=T3.CARDID WHERE SYSTEMCODE=''MXB_MAIN'') B
            ON A.IDCARD=B.IDCARDNO
            '
    EXEC(@EXECSQL)

    PRINT '-----------------------------------------------糖尿病随访表---------------------------------------------------------------'

--ISCOVERBAISC INT, --属于封面基本 1为属于
    SELECT @EXECSQL = 
            '
            UPDATE CONTROL_BASIC SET ISCOVERBAISC=1
            '
    EXEC(@EXECSQL)


    PRINT '--------------------------------------------------属于封面基本 1为属于------------------------------------------------------------------'
    --ISCHECKUP INT, --健康体检表分值  1为属于
--ISHYPERTENSION INT, --属于高血压随访表 1为属于
--ISDIABETES INT, --属于糖尿病随访表 1为属于
--

--CHECKUPSCORE INT, --健康体检表分值
--HYPERTENSIONSCORE INT, --高血压随访表分值
--DIABETESSCORE INT --糖尿病随访表分值

--COVERBAISCSCORE INT, --封面基本信息表分值
--封面基本信息表分值 --非核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM,(107-SUM(B.SCORE))*100/107 AS SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN (
            SELECT ARCHIVENUM,
            CASE STRENGTHNAME
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS SCORE
             FROM CONTROL_RESULT WHERE STRENGTHNAME !=''核心'' AND TABLENAME IN (''封面表'',''基本信息表'')
            ) B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISCOVERBAISC =1
            GROUP BY A.ARCHIVENUM)

            UPDATE A SET A.COVERBAISCSCORE = T.SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------------封面基本信息表分值 --非核心--------------------------------------------------------------'

    --CHECKUPSCORE  ISCHECKUP
--健康体检表分值 --非核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM,(337-SUM(B.SCORE))*100/337 AS SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN (
            SELECT ARCHIVENUM,TABLENAME,
            CASE STRENGTHNAME
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS SCORE
             FROM CONTROL_RESULT WHERE STRENGTHNAME !=''核心'' AND TABLENAME IN (''健康体检表'')
            ) B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISCHECKUP =1
            GROUP BY A.ARCHIVENUM)

            UPDATE A SET A.CHECKUPSCORE = T.SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)

    PRINT '-------------------------------------------健康体检表分值 --非核心--------------------------------------------------------------'
    --ISDIABETES DIABETESSCORE
--糖尿病随访表 --非核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM,(141-SUM(B.SCORE))*100/141 AS SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN (
            SELECT ARCHIVENUM,
            CASE STRENGTHNAME
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS SCORE
             FROM CONTROL_RESULT WHERE STRENGTHNAME !=''核心'' AND TABLENAME IN (''糖尿病随访表'')
            ) B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISDIABETES =1
            GROUP BY A.ARCHIVENUM)

            UPDATE A SET A.DIABETESSCORE = T.SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)
    PRINT '--------------------------------------------------糖尿病随访表 --非核心--------------------------------------------------------------------------------------'
    --ISHYPERTENSION HYPERTENSIONSCORE
--高血压随访表 --非核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM,(140-SUM(B.SCORE))*100/140 AS SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN (
            SELECT ARCHIVENUM,
            CASE STRENGTHNAME
            WHEN ''重要'' THEN  3.0
            WHEN ''中等'' THEN 2.0
            WHEN ''普通'' THEN 1.0
            ELSE 0 END AS SCORE
             FROM CONTROL_RESULT WHERE STRENGTHNAME !=''核心''  AND TABLENAME IN (''高血压随访表'')
            ) B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISHYPERTENSION =1
            GROUP BY A.ARCHIVENUM)

            UPDATE A SET A.HYPERTENSIONSCORE = T.SCORE
            FROM DBO.CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)

    PRINT '----------------------------------------------高血压随访表 --非核心-----------------------------------------------------'
    --ISCOVERBAISC
--封面基本信息表分值 --核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM FROM CONTROL_BASIC A
            INNER JOIN CONTROL_RESULT B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISCOVERBAISC =1 AND B.TABLENAME IN (''封面表'',''基本信息表'') AND B.STRENGTHNAME =''核心''
            GROUP BY A.ARCHIVENUM
            )
            UPDATE A SET A.COVERBAISCSCORE=0
             FROM CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------------------封面基本信息表分值 --核心----------------------------------------------------------------------------'
    --ISCHECKUP
--健康体检表表分值 --核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM FROM CONTROL_BASIC A
            INNER JOIN CONTROL_RESULT B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISCHECKUP =1 AND B.TABLENAME IN (''健康体检表'') AND B.STRENGTHNAME =''核心''
            GROUP BY A.ARCHIVENUM
            )
            UPDATE A SET A.CHECKUPSCORE=0
             FROM CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)

    PRINT '----------------------------------------------------健康体检表表分值 --核心------------------------------------------------------------------------------'
    --ISDIABETES
--糖尿病随访表分值 --核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM FROM CONTROL_BASIC A
            INNER JOIN CONTROL_RESULT B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISDIABETES =1 AND B.TABLENAME IN (''糖尿病随访表'') AND B.STRENGTHNAME =''核心''
            GROUP BY A.ARCHIVENUM
            )
            UPDATE A SET A.DIABETESSCORE=0
             FROM CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)

    PRINT '----------------------------------------------糖尿病随访表分值 --核心------------------------------------------------------------------------'
    --ISHYPERTENSION
--高血压随访表分值 --核心
    SELECT @EXECSQL = 
            '
            WITH T AS (
            SELECT A.ARCHIVENUM FROM CONTROL_BASIC A
            INNER JOIN CONTROL_RESULT B
            ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISHYPERTENSION =1 AND B.TABLENAME IN (''高血压随访表'') AND B.STRENGTHNAME =''核心''
            GROUP BY A.ARCHIVENUM
            )
            UPDATE A SET A.HYPERTENSIONSCORE=0
             FROM CONTROL_BASIC A
            INNER JOIN T
            ON A.ARCHIVENUM = T.ARCHIVENUM
            '
    EXEC(@EXECSQL)

    PRINT '---------------------------------------------高血压随访表分值 --核心----------------------------------------------------------------------------'

    --添加 规则类型索引  签约医生



----------------------ZKTYPETREND 表数据维护------------------------

-----------ZKTYPETREND  标志位（ 0-字段质控，1-错误总数量，2-签约数量标志，3-年份标志）


------ 0-字段质控
---    SELECT @EXECSQL = REPLACE(
---            '
---            INSERT INTO ZKTYPETREND(CONTROLTIME,CONTROLFIELDS,WRONGNUM,CREATETIME,SYMBOL,ZKBM)
---            SELECT ---(SUBSTRING(''@BATCHNUM'',1,4)+''-''+SUBSTRING(''@BATCHNUM'',5,2)+''-''+SUBSTRING(''@BATCHNUM'',7,2)) AS ---CONTROLTIME,
---            RULETYPE AS CONTROLFIELDS,
---            COUNT(RULETYPE) AS WRONGNUM,GETDATE() AS CREATETIME,0 AS SYMBOL,
--            ''@BATCHNUM'' AS ZKBM
--            FROM (
 ---           SELECT ARCHIVENUM,RULETYPE FROM DBO.CONTROL_RESULT_@BATCHNUM GROUP BY ARCHIVENUM,RULETYPE)A
---           GROUP BY RULETYPE
--            ','@BATCHNUM',@BATCHNUM
--        )
--PRINT @EXECSQL
  --  EXEC(@EXECSQL)

   -- PRINT '-------------------------------------------- 0-字段质控----------------------------------------------------'

----   1-错误总数量
--     SELECT @EXECSQL = REPLACE(
--             '
--             INSERT INTO ZKTYPETREND(CONTROLTIME,WRONGNUM,CREATETIME,SYMBOL,ZKBM)
--             VALUES (SUBSTRING(''@BATCHNUM'',1,4)+''-''+SUBSTRING(''@BATCHNUM'',5,2)+''-''+SUBSTRING(''@BATCHNUM'',7,2),(SELECT COUNT(*) FROM DBO.CONTROL_BASIC_@BATCHNUM WHERE ISERROR=1),GETDATE(),1,''@BATCHNUM'');
--             ','@BATCHNUM',@BATCHNUM
--         )
-- --PRINT @EXECSQL
--     EXEC(@EXECSQL)
-- 
--     PRINT '--------------------------------------------   1-错误总数量----------------------------------------------------------------'
-- 
-- ----- 2 签约数量标志
--     SELECT @EXECSQL = REPLACE(
--             '
--             INSERT INTO  DBO.ZKTYPETREND
--             (CONTROLTIME, WRONGNUM,CREATETIME,SYMBOL,ZKBM)
--             VALUES(SUBSTRING(''@BATCHNUM'',1,4)+''-''+SUBSTRING(''@BATCHNUM'',5,2)+''-''+SUBSTRING(''@BATCHNUM'',7,2),(SELECT COUNT(*) FROM DBO.CONTROL_BASIC_@BATCHNUM WHERE ISSIGNED=1 AND ISERROR=1),GETDATE(),2,''@BATCHNUM'')
--             ','@BATCHNUM',@BATCHNUM
--         )
-- --PRINT @EXECSQL
--     EXEC(@EXECSQL)
-- 
--     PRINT '------------------------------------------------2 签约数量标志-------------------------------------------------------------------------------'
-- ----- 3-年份标志
--     SELECT @EXECSQL = REPLACE(
--             '
--             INSERT INTO  DBO.ZKTYPETREND
--             (CONTROLTIME, WRONGNUM,CREATETIME,SYMBOL,ZKBM,YEAR)
--             SELECT (SUBSTRING(''@BATCHNUM'',1,4)+''-''+SUBSTRING(''@BATCHNUM'',5,2)+''-''+SUBSTRING(''@BATCHNUM'',7,2)) AS CONTROLTIME,
--             COUNT(YEARS) AS WRONGNUM,GETDATE() AS CREATETIME,3 AS SYMBOL,
--             ''@BATCHNUM'' AS ZKBM,
--             YEARS AS YEAR FROM CONTROL_BASIC_@BATCHNUM WHERE ISERROR =1 GROUP BY YEARS
--             ','@BATCHNUM',@BATCHNUM
--         )
-- --PRINT @EXECSQL
--     EXEC(@EXECSQL)
-- 
--     PRINT '---------------------------------------------------3-年份标志---------------------------------------------------------------------------------------'
----------------CONTROLERROR 表更新
--     SELECT @EXECSQL = REPLACE(
--             '
--             INSERT INTO DBO.CONTROLERROR(CONTROLID,YEARS,YEARSNUM)
--             SELECT ''@BATCHNUM'' AS CONTROLID,YEARS,COUNT(YEARS) AS YEARSNUM   FROM DBO.CONTROL_BASIC_@BATCHNUM WHERE ISNULL(YEARS,'''') !='''' GROUP BY YEARS
--             ','@BATCHNUM',@BATCHNUM
--         )
--     EXEC(@EXECSQL)
-- 
--     PRINT '--------------------------------------------------CONTROLERROR 表更新------------------------------------------------------------------------------------'
-- 
-- -----------------------ZKJLB 签约人群更新
--     SELECT @EXECSQL = REPLACE(
--             '
--             UPDATE ZKJLB SET QYNUM =(SELECT COUNT(*) FROM DBO.CONTROL_BASIC_@BATCHNUM  WHERE ISSIGNED=1) WHERE ZKBM =''@BATCHNUM''
--             ','@BATCHNUM',@BATCHNUM
--         )
--     EXEC(@EXECSQL)
-- 
--     PRINT '-------------------------------------------------------ZKJLB 签约人群更新--------------------------------------------------------------------------------------------'

----------如果质控没有错 给100分
    SELECT @EXECSQL = 
            '
            UPDATE 	CONTROL_BASIC SET COVERBAISCSCORE=100 WHERE ISCOVERBAISC=1 AND COVERBAISCSCORE IS NULL;
            UPDATE 	CONTROL_BASIC SET CHECKUPSCORE=100 WHERE ISCHECKUP =1 AND CHECKUPSCORE IS NULL;
            UPDATE 	CONTROL_BASIC SET HYPERTENSIONSCORE=100 WHERE ISHYPERTENSION =1 AND HYPERTENSIONSCORE IS NULL;
            UPDATE 	CONTROL_BASIC SET DIABETESSCORE=100 WHERE ISDIABETES=1 AND DIABETESSCORE IS NULL;
            '
    EXEC(@EXECSQL)

    PRINT '----------------------------------------------------------如果质控没有错 给100分------------------------------------------------------------------------------------'

--封面基本信息表是否错误
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.ISERRORCOVERBASIC = ISNULL(B.FLAG,0)
            FROM DBO.CONTROL_BASIC A
            LEFT JOIN (
            SELECT ARCHIVENUM,1 AS FLAG
            FROM DBO.CONTROL_RESULT
            WHERE TABLENAME IN (''封面表'',''基本信息表'')
            GROUP BY ARCHIVENUM
            )B ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISCOVERBAISC =1
            '
    EXEC(@EXECSQL)

    PRINT '-----------------------------------------------------------封面基本信息表是否错误---------------------------------------------------------------------------'

--体检表是否错误
    SELECT @EXECSQL = 
            '
            UPDATE A SET A.ISERRORCHECKUP = ISNULL(B.FLAG,0)
            FROM DBO.CONTROL_BASIC A
            LEFT JOIN (
            SELECT ARCHIVENUM,1 AS FLAG
            FROM DBO.CONTROL_RESULT
            WHERE TABLENAME IN (''健康体检表'')
            GROUP BY ARCHIVENUM
            )B ON A.ARCHIVENUM = B.ARCHIVENUM
            WHERE A.ISCHECKUP =1
            '
    EXEC(@EXECSQL)

    PRINT '--------------------------------------------体检表是否错误-------------------------------------------------------------------------------------'

--高血压随访表是否错误
--     SELECT @EXECSQL = 
--             '
--             UPDATE A SET A.ISERRORHYPERTENSION = ISNULL(B.FLAG,0)
--             FROM DBO.CONTROL_BASIC A
--             LEFT JOIN (
--             SELECT ARCHIVENUM,1 AS FLAG
--             FROM DBO.CONTROL_RESULT
--             WHERE TABLENAME IN (''高血压随访表'')
--             GROUP BY ARCHIVENUM
--             )B ON A.ARCHIVENUM = B.ARCHIVENUM
--             WHERE A.ISHYPERTENSION =1
--             '
--EXEC(@EXECSQL)

-- 
--     PRINT '---------------------------------------------------高血压随访表是否错误--------------------------------------------------------------------------'
--糖尿病随访表是否错误
--     SELECT @EXECSQL = 
--             '
--             UPDATE A SET A.ISERRORDIABETES = ISNULL(B.FLAG,0)
--             FROM DBO.CONTROL_BASIC A
--             LEFT JOIN (
--             SELECT ARCHIVENUM,1 AS FLAG
--             FROM DBO.CONTROL_RESULT
--             WHERE TABLENAME IN (''糖尿病随访表'')
--             GROUP BY ARCHIVENUM
--             )B ON A.ARCHIVENUM = B.ARCHIVENUM
--             WHERE A.ISDIABETES =1
--             '
--EXEC(@EXECSQL)
-- 
--     PRINT '---------------------------------------------------------糖尿病随访表是否错误-----------------------------------------------------------------------------------------------'

END
go

