

CREATE procedure [dbo].[check_block] --with encryption 
(
@kill varchar(4)=null
)
as 

--调试时使用
---------------------------------------------
if object_id('tempdb.dbo.#temp') is not null
	drop table #temp
if object_id('tempdb.dbo.#temp1') is not null
	drop table #temp1
if object_id('tempdb.dbo.#temp2') is not null
	drop table #temp2
if object_id('tempdb.dbo.#temp3') is not null
	drop table #temp3
----------------------------------------------

begin 
 set nocount on 
 declare @spid smallint 
 declare @c_SQL varchar(500) 
 declare @id int 
 --保存 Sysprocesses 的内容 
 create table #Temp(spid smallint,status nchar(30),lastwaittype varchar(1000),waitresource varchar(1000),hostname nchar(1000),program_name nchar(1000) 
   ,cmd nchar(200),cpu int,physical_io int,blocked smallint,dbid smallint 
   ,loginame nchar(200),last_batch datetime 
   ,SQLBuffer varchar(8000)) 

 --保存 DBCC InputBuffer 的结果 
 create table #Temp1(id int identity(1,1),eventtype varchar(20),parameters int,eventinfo nvarchar(4000)) 
 select * into #Temp2 
  from master..sysprocesses (nolock) 

 --保存被阻塞的进程信息 
 insert into #Temp(spid ,status,lastwaittype,waitresource,hostname ,program_name ,cmd ,cpu ,physical_io ,blocked ,dbid  
   ,loginame ,last_batch ) 
  SELECT spid ,status ,lastwaittype,waitresource,hostname ,program_name ,cmd ,cpu ,physical_io ,blocked ,dbid 
     ,convert(sysname, rtrim(loginame)) ,last_batch 
   from #Temp2 
   where blocked > 0 

 --保存阻塞的源头 
 insert into #Temp(spid ,status ,lastwaittype,waitresource,hostname ,program_name ,cmd ,cpu ,physical_io ,blocked ,dbid  
   ,loginame ,last_batch ) 
  SELECT spid ,status ,lastwaittype,waitresource,hostname ,program_name ,cmd ,cpu ,physical_io ,blocked ,dbid 
     ,convert(sysname, rtrim(loginame)) ,last_batch 
   from #Temp2 
   where spid in (select blocked from #Temp) 
    and spid not in (select spid from #Temp) 
 select count(#Temp2.spid) '当前数据库连接数' 
  from #Temp2 
 select count(#Temp.spid) '存在阻塞的连接数' 
  from #Temp 
 select @spid = min(spid) from #Temp 
 while @spid is not null 
 begin 
  set @c_SQL = 'dbcc inputbuffer(' + convert(varchar(5), @spid) + ')' 
  insert into #Temp1 
   exec (@c_SQL) 
  select @id = @@identity 
   update #Temp 
    set SQLBuffer = #Temp1.eventinfo 
   from #Temp,#Temp1 
   where #Temp1.id = @id 
    and #Temp.spid = @spid 
  select @spid = min(spid) from #Temp where spid > @spid 
 end 
 SELECT convert(char(5),spid) SPID,CASE lower(status) When 'sleeping' Then lower(status) Else upper(status) END Status 
   ,SQLBuffer 
   , CASE hostname When Null  Then '  .' When ' ' Then '  .' Else hostname END HostName 
   ,CASE isnull(convert(char(5),blocked),'0') When '0' Then '  .' 
                       Else isnull(convert(char(5),blocked),'0') END BlkBy
   ,lastwaittype
   ,waitresource 
   ,loginame Login 
   ,db_name(dbid) DBName,convert(varchar,cpu) CPUTime 
   ,convert(varchar,physical_io) DiskIO,Last_Batch LastBatch 
   ,program_name ProgramName, cmd Command into #temp3
  from #Temp 
  order by BlkBy, spid 

--真正的阻塞源头
-----------------------------------

if exists(select * from #temp3)
	SELECT case blkby when '  .' then ' kill '+spid else '' end as [kill_Blocker],* from #Temp3 order by [kill_Blocker] desc,BlkBy, spid 

--kill真正的阻塞源头
if @kill = 'kill'
begin
	declare @str varchar(100)
	declare c cursor fast_forward for SELECT 'kill '+spid [kill] from #Temp3 where blkby not in (select spid from #temp3)
	open c
	fetch next from c into @str
	while @@fetch_status=0
	begin
	--select @str [kill_blocker]
	exec(@str)
	fetch next from c into @str
	end
	close c
	deallocate c
end
-----------------------------------
end

go

