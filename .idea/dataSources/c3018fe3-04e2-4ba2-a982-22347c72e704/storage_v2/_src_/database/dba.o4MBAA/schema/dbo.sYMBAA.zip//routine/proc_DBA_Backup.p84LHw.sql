
CREATE PROCEDURE [dbo].[proc_DBA_Backup]
(
 @database varchar(100)    --数据库名称
,@dir varchar(200) = '/opt/Backup/' --备份目录，默认'/opt/Backup/'
,@filename varchar(500) = NULL output --备份文件名，默认null
,@backup_type varchar(10)  --备份类型，full或者log
)
as
/*
-- 调用方法
exec dba..proc_DBA_Backup @database='???',@backup_type='full'
exec dba..proc_DBA_Backup @database='???',@backup_type='log'
*/
if @database is null or @backup_type is null
	return

declare @subdir        varchar(200)
	   ,@full_filename varchar(500)

--目录要以'/'结尾
if right(@dir,1) !='/'
	set @dir=@dir+'/'
set @subdir   = @dir+@database+'/'
if @filename is null
	begin
		if @backup_type='FULL'
			set @filename = @database+'_backup_full_'+replace(replace(replace(convert(nvarchar(20),getdate(),20),':',''),' ','_'),'-','_')+'.bak'
		if @backup_type='LOG'
			set @filename = @database+'_backup_log_'+replace(replace(replace(convert(nvarchar(20),getdate(),20),':',''),' ','_'),'-','_')+'.trn'
	end
set @full_filename = @subdir+@filename
EXECUTE master.dbo.xp_create_subdir @subdir
if @backup_type = 'FULL'
	BACKUP DATABASE @database TO  DISK = @full_filename  WITH  NOFORMAT, INIT,  NAME = @filename, SKIP, NOREWIND, NOUNLOAD,  STATS = 10
if @backup_type = 'LOG'
	BACKUP LOG      @database TO  DISK = @full_filename  WITH  NOFORMAT, INIT,  NAME = @filename, SKIP, NOREWIND, NOUNLOAD,  STATS = 10

go

