CREATE FUNCTION [dbo].[rpad]
(
    -- Add the parameters for the function here
    @str nvarchar(100),@len INT,@fix NVARCHAR(1)
)
RETURNS nvarchar(100)
AS
BEGIN
    -- Declare the return variable here
    DECLARE @res nvarchar(100)
    -- Add the T-SQL statements to compute the return value here
    SELECT @res = @str+replicate(@fix,@len-len(@str))
    -- Return the result of the function
    RETURN @res
END
go

