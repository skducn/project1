------存储----------------
CREATE PROCEDURE [dbo].[T_ASSESS_INFO_THREE] ( @IDCARD NVARCHAR ( 18 ),@ID INT,@guid VARCHAR ( 36 ),@START_TIME datetime,@END_TIME datetime ) AS BEGIN
	WITH b1 AS (
		SELECT
			*
		FROM
			(
			SELECT DISTINCT
				'01' AS tesp1,

				s1.num1  as code ,

			 (SELECT  DISEASES_NAME  from DISEASE_MAPPING WHERE DISEASES_CODE= s1.num1 ) AS num1,

				@END_TIME AS DATENAME
			FROM
				(
				SELECT
				CASE

					WHEN
						t2.MSG LIKE '%高血压%' THEN
							'JB001'
							WHEN t2.MSG LIKE '%糖尿病%' THEN
							'JB002'
							WHEN t2.MSG LIKE '%脑卒中%' THEN
							'JB003'
							WHEN t2.MSG LIKE '%慢阻肺%' THEN
							'JB005'
							WHEN t2.MSG LIKE '%冠心病%' THEN
							'JB013'
							WHEN t2.MSG LIKE '%肝炎%' THEN
							'JB015'
							WHEN t2.MSG LIKE '%结核病%' THEN
							'JB016'
							WHEN t2.MSG LIKE '%白血病%' THEN
							'JB018'
							WHEN t2.MSG LIKE '%前列腺癌%' THEN
							'JB019' ELSE NULL
						END AS num1
					FROM
						( SELECT id FROM HRPERSONBASICINFO WHERE ARCHIVENUM = @IDCARD ) t1
						INNER JOIN HRASSOCIATIONINFO t2 ON t1.id= t2.pid
					WHERE
						t2.ASSOCIATIONTYPE = 'history_of_disease'
						AND t2.MSG IS NOT NULL UNION ALL
					SELECT
						'JB001' AS num1
					FROM
						TB_DC_CHRONIC_MAIN
					WHERE
						EMPIGUID = @guid
						AND visitTypeCode LIKE '%31%' UNION ALL
					SELECT
						'JB002' AS num1
					FROM
						TB_DC_CHRONIC_MAIN
					WHERE
						EMPIGUID = @guid
						AND visitTypeCode LIKE '%33%' UNION ALL
					SELECT
					CASE

						WHEN
							DIAGNOSIS_CODE LIKE 'I10%'
							OR DIAGNOSIS_CODE LIKE 'I11%'
							OR DIAGNOSIS_CODE LIKE 'I12%'
							OR DIAGNOSIS_CODE LIKE 'I13%'
							OR DIAGNOSIS_CODE LIKE 'I14%'
							OR DIAGNOSIS_CODE LIKE 'I15%' THEN
								'JB001'
								WHEN DIAGNOSIS_CODE LIKE 'E10%'
								OR DIAGNOSIS_CODE LIKE 'E11%'
								OR DIAGNOSIS_CODE LIKE 'E12%'
								OR DIAGNOSIS_CODE LIKE 'E13%'
								OR DIAGNOSIS_CODE LIKE 'E14%' THEN
									'JB002'
									WHEN DIAGNOSIS_CODE LIKE 'I60%'
									OR DIAGNOSIS_CODE LIKE 'I61%'
									OR DIAGNOSIS_CODE LIKE 'I62%'
									OR DIAGNOSIS_CODE LIKE 'I63%'
									OR DIAGNOSIS_CODE LIKE 'I64%'
									OR DIAGNOSIS_CODE LIKE 'I69.0%'
									OR DIAGNOSIS_CODE LIKE 'I69.1%'
									OR DIAGNOSIS_CODE LIKE 'I69.2%'
									OR DIAGNOSIS_CODE LIKE 'I69.3%'
									OR DIAGNOSIS_CODE LIKE 'I69.4%' THEN
										'JB003'
										WHEN DIAGNOSIS_CODE LIKE 'N03%'
										OR DIAGNOSIS_CODE LIKE 'N11%'
										OR DIAGNOSIS_CODE LIKE 'N18%' THEN
											'JB004'
											WHEN DIAGNOSIS_CODE LIKE 'J44.9%' THEN
											'JB005'
											WHEN DIAGNOSIS_CODE LIKE 'C34%' THEN
											'JB006'
											WHEN DIAGNOSIS_CODE LIKE 'C18%'
											OR DIAGNOSIS_CODE LIKE 'C19%'
											OR DIAGNOSIS_CODE LIKE 'C20%'
											OR DIAGNOSIS_CODE LIKE 'C21%' THEN
												'JB007'
												WHEN DIAGNOSIS_CODE LIKE 'C50%' THEN
												'JB008'
												WHEN DIAGNOSIS_CODE LIKE 'C22%' THEN
												'JB009'
												WHEN DIAGNOSIS_CODE LIKE 'C16%' THEN
												'JB010'
												WHEN DIAGNOSIS_CODE LIKE 'C53%' THEN
												'JB011'
												WHEN DIAGNOSIS_CODE LIKE 'E34.902%'
												OR DIAGNOSIS_CODE LIKE 'M80.%'
												OR DIAGNOSIS_CODE LIKE 'M81.%'
												OR DIAGNOSIS_CODE LIKE 'M82.%' THEN
													'JB012'
													WHEN DIAGNOSIS_CODE LIKE 'I25.1%' THEN
													'JB013'
													WHEN DIAGNOSIS_CODE LIKE 'I50%' THEN
													'JB014'
													WHEN DIAGNOSIS_CODE LIKE 'B16%'
													OR DIAGNOSIS_CODE LIKE 'B18.0%'
													OR DIAGNOSIS_CODE LIKE 'B18.1%'
													OR DIAGNOSIS_CODE LIKE 'B17.1%'
													OR DIAGNOSIS_CODE LIKE 'B18.2%' THEN
														'JB015'
														WHEN DIAGNOSIS_CODE LIKE 'A15%'
														OR DIAGNOSIS_CODE LIKE 'A16%' THEN
															'JB016'
															WHEN DIAGNOSIS_CODE LIKE 'M05.3%'
															OR DIAGNOSIS_CODE LIKE 'M05.8%'
															OR DIAGNOSIS_CODE LIKE 'M05.9%'
															OR DIAGNOSIS_CODE LIKE 'M06%' THEN
																'JB017'
																WHEN DIAGNOSIS_CODE LIKE 'C90.1%'
																OR DIAGNOSIS_CODE LIKE 'C91%'
																OR DIAGNOSIS_CODE LIKE 'C92%'
																OR DIAGNOSIS_CODE LIKE 'C93%'
																OR DIAGNOSIS_CODE LIKE 'C94%'
																OR DIAGNOSIS_CODE LIKE 'C95%' THEN
																	'JB018'
																	WHEN DIAGNOSIS_CODE LIKE 'C61%' THEN
																	'JB019'
																	WHEN DIAGNOSIS_CODE LIKE 'J41%'
																	OR DIAGNOSIS_CODE LIKE 'J42%' THEN
																		'JB020'
																		WHEN DIAGNOSIS_CODE LIKE 'E02%'
																		OR DIAGNOSIS_CODE LIKE 'E03%' THEN
																			'JB021'
																			WHEN DIAGNOSIS_CODE LIKE 'J31.2%' THEN
																			'JB022'
																			WHEN DIAGNOSIS_CODE LIKE 'I44%'
																			OR DIAGNOSIS_CODE LIKE 'I45%'
																			OR DIAGNOSIS_CODE LIKE 'I46%'
																			OR DIAGNOSIS_CODE LIKE 'I47%'
																			OR DIAGNOSIS_CODE LIKE 'I48%'
																			OR DIAGNOSIS_CODE LIKE 'I49%' THEN
																				'JB023'
																				WHEN DIAGNOSIS_CODE LIKE 'K21%' THEN
																				'JB024'
																				WHEN DIAGNOSIS_CODE LIKE 'M47.001%'
																				OR DIAGNOSIS_CODE LIKE 'M47.101%'
																				OR DIAGNOSIS_CODE LIKE 'M47.201%'
																				OR DIAGNOSIS_CODE LIKE 'M47.202%'
																				OR DIAGNOSIS_CODE LIKE 'M47.800x024%'
																				OR DIAGNOSIS_CODE LIKE 'M47.802%'
																				OR DIAGNOSIS_CODE LIKE 'M47.900x021%' THEN
																					'JB025'
																					WHEN DIAGNOSIS_CODE LIKE 'G20%' THEN
																					'JB026'
																					WHEN DIAGNOSIS_CODE LIKE 'M10%' THEN
																					'JB027'
																					WHEN DIAGNOSIS_CODE LIKE 'J45%'
																					OR DIAGNOSIS_CODE LIKE 'J46%' THEN
																						'JB028'
																						WHEN DIAGNOSIS_CODE LIKE 'N20%' THEN
																						'JB029'
																						WHEN DIAGNOSIS_CODE LIKE 'K50%' THEN
																						'JB030'
																						WHEN DIAGNOSIS_CODE LIKE 'K29.3%'
																						OR DIAGNOSIS_CODE LIKE 'K29.4%'
																						OR DIAGNOSIS_CODE LIKE 'K29.5%'
																						OR DIAGNOSIS_CODE LIKE 'K29.6%'
																						OR DIAGNOSIS_CODE LIKE 'K29.7%' THEN
																							'JB031'
																							WHEN DIAGNOSIS_CODE LIKE 'J31.0%' THEN
																							'JB032'
																							WHEN DIAGNOSIS_CODE LIKE 'M15%'
																							OR DIAGNOSIS_CODE LIKE 'M16%'
																							OR DIAGNOSIS_CODE LIKE 'M17%'
																							OR DIAGNOSIS_CODE LIKE 'M18%'
																							OR DIAGNOSIS_CODE LIKE 'M19%' THEN
																								'JB033'
																								WHEN DIAGNOSIS_CODE LIKE 'G40%'
																								OR DIAGNOSIS_CODE LIKE 'G41%' THEN
																									'JB034'
																									WHEN DIAGNOSIS_CODE LIKE 'E05%' THEN
																									'JB035'
																									WHEN DIAGNOSIS_CODE LIKE 'M51.202%'
																									OR DIAGNOSIS_CODE LIKE 'M51.200x003%'
																									OR DIAGNOSIS_CODE LIKE 'M51.003%'
																									OR DIAGNOSIS_CODE LIKE 'M51.100x001%'
																									OR DIAGNOSIS_CODE LIKE 'M51.100x003%'
																									OR DIAGNOSIS_CODE LIKE 'M51.101%' THEN
																										'JB036'
																										WHEN DIAGNOSIS_CODE LIKE 'D25%' THEN
																										'JB037'
																										WHEN DIAGNOSIS_CODE LIKE 'H25%' THEN
																										'JB038'
																										WHEN DIAGNOSIS_CODE LIKE 'I20.800x012%' THEN
																										'JB039'
																										WHEN DIAGNOSIS_CODE LIKE 'K51%' THEN
																										'JB040'
																										WHEN DIAGNOSIS_CODE LIKE 'I83%' THEN
																										'JB041'
																										WHEN DIAGNOSIS_CODE LIKE 'M45%' THEN
																										'JB042'
																										WHEN DIAGNOSIS_CODE LIKE 'J32%' THEN
																										'JB043'
																										WHEN DIAGNOSIS_CODE LIKE 'K25%'
																										OR DIAGNOSIS_CODE LIKE 'K26%'
																										OR DIAGNOSIS_CODE LIKE 'K27%'
																										OR DIAGNOSIS_CODE LIKE 'K28%' THEN
																											'JB044'
																											WHEN DIAGNOSIS_CODE LIKE 'G30%'
																											OR DIAGNOSIS_CODE LIKE 'F00%' THEN
																												'JB045'
																												WHEN DIAGNOSIS_CODE LIKE 'K74.1%'
																												OR DIAGNOSIS_CODE LIKE 'K74.2%'
																												OR DIAGNOSIS_CODE LIKE 'K74.3%'
																												OR DIAGNOSIS_CODE LIKE 'K74.4%'
																												OR DIAGNOSIS_CODE LIKE 'K74.5%'
																												OR DIAGNOSIS_CODE LIKE 'K74.6%' THEN
																													'JB046'
																													WHEN DIAGNOSIS_CODE LIKE 'H40%'
																													OR DIAGNOSIS_CODE LIKE 'H41%'
																													OR DIAGNOSIS_CODE LIKE 'H42%' THEN
																														'JB047'
																														WHEN DIAGNOSIS_CODE LIKE 'L40%' THEN
																														'JB048'
																														WHEN DIAGNOSIS_CODE LIKE 'L80%' THEN
																														'JB049'
																														WHEN DIAGNOSIS_CODE LIKE 'M32%' THEN
																														'JB050'
																														WHEN DIAGNOSIS_CODE LIKE 'O24%' THEN
																														'YCFJB001'
																														WHEN DIAGNOSIS_CODE LIKE 'O34.2%' THEN
																														'YCFJB002'
																														WHEN DIAGNOSIS_CODE LIKE 'O99.215%' THEN
																														'YCFJB003'
																														WHEN DIAGNOSIS_CODE LIKE 'O25%' THEN
																														'YCFJB004'
																														WHEN DIAGNOSIS_CODE LIKE 'O99.0%' THEN
																														'YCFJB005'
																														WHEN DIAGNOSIS_CODE LIKE 'O23.506%'
																														OR DIAGNOSIS_CODE LIKE 'O98.806%'
																														OR DIAGNOSIS_CODE LIKE 'O98.808%'
																														OR DIAGNOSIS_CODE LIKE 'O98.301%'
																														OR DIAGNOSIS_CODE LIKE 'O23.500x011%'
																														OR DIAGNOSIS_CODE LIKE 'O23.500x007%' THEN
																															'YCFJB006'
																															WHEN DIAGNOSIS_CODE LIKE 'O21%' THEN
																															'YCFJB007'
																															WHEN DIAGNOSIS_CODE LIKE 'O10%'
																															OR DIAGNOSIS_CODE LIKE 'O13%'
																															OR DIAGNOSIS_CODE LIKE 'O16%' THEN
																																'YCFJB008'
																																WHEN DIAGNOSIS_CODE LIKE 'O98.4%'
																																OR DIAGNOSIS_CODE LIKE 'O26.6%' THEN
																																	'YCFJB009' ELSE NULL
																																	END AS num1
																															FROM
																																( SELECT DIAGNOSIS_CODE FROM T_HIS_DIAGNOSIS WHERE IDCARD = @IDCARD AND DIAGNOSIS_TYPE = '1' AND DIAGNOSIS_DATE BETWEEN @START_TIME AND @END_TIME UNION ALL SELECT ICDO FROM TB_TUMOR_MAIN_INFO WHERE ZJHM = @IDCARD ) k1
																															) s1
																														WHERE
																															s1.num1 IS NOT NULL UNION ALL
																														SELECT
																															'02' AS tesp1,
																															q1.*
																														FROM
																															(
																															SELECT
																																t2.CODE,
																																t2.MSG,
																																t2.OCCURDATE
																															FROM
																																( SELECT id FROM HRPERSONBASICINFO WHERE ARCHIVENUM =@IDCARD ) t1
																																INNER JOIN HRASSOCIATIONINFO t2 ON t1.id= t2.pid
																															WHERE
																																t2.ASSOCIATIONTYPE = 'history_of_operation'
																																AND OCCURDATE BETWEEN  @START_TIME
																																	AND @END_TIME
																																UNION ALL
																															SELECT
																																t2.OPERCODE AS CODE,
																																t2.OPERNAME AS MSG,
																																t2.OPERSTARTDATE AS OCCURDATE
																															FROM
																																( SELECT OPVISITSTRNO, ORGCODE FROM TB_HIS_OP_MEDICAL_RECORD WHERE EMPIGUID = @guid ) AS t1
																																LEFT JOIN ( SELECT * FROM TB_HIS_OPERATION WHERE OPERSTARTDATE BETWEEN @START_TIME AND @END_TIME ) t2 ON t1.OPVISITSTRNO= t2.VISITSTRNO
																																AND t1.ORGCODE= t2.ORGCODE
																																LEFT JOIN ( SELECT iPVISITSTRNO, ORGCODE FROM TB_HIS_IP_MEDICAL_RECORD WHERE EMPIGUID = @guid ) t3 ON t3.iPVISITSTRNO= t2.VISITSTRNO
																																AND t2.ORGCODE= t3.orgcode
																															) q1
																														WHERE
																															q1.MSG IS NOT NULL
																															AND q1.MSG != '' UNION ALL
																														SELECT
																															'03' AS tesp1,
																															s1.*
																														FROM
																															(
																															SELECT
																																'' AS code,
																																s2.DRUGNAME AS MSG,
																																s2.MEDICATIONTIME AS OCCURDATE
																															FROM
																																( SELECT * FROM TB_DC_EXAMINATION_INFO WHERE EMPIGUID = @guid ) s1
																																INNER JOIN TB_DC_EXAMINATION_MEDICATE s2 ON s1.EXAMINATIONID= s2.EXAMINATIONID
																																AND s1.ORGCODE= s2.ORGCODE UNION ALL
																															SELECT
																																itemCode AS CODE,
																																itemName AS MSG,
																																RXDATE AS OCCURDATE
																															FROM
																																(
																																SELECT
																																	t2.itemCode,
																																	t2.itemName,
																																	t2.RXDATE,
																																	ROW_NUMBER ( ) OVER ( partition BY t2.itemName, t2.itemCode ORDER BY t2.RXDATE DESC ) b
																																FROM
																																	( SELECT * FROM TB_HIS_OP_MEDICAL_RECORD WHERE EMPIGUID = @guid ) t1
																																	INNER JOIN TB_HIS_OP_PERSCRIPTION t2 ON t1.OPVISITSTRNO= t2.OPVISITSTRNO
																																	AND t1.ORGCODE= t2.ORGCODE
																																WHERE
																																	t2.RXDATE BETWEEN @START_TIME
																																	AND @END_TIME
																																) b11
																															WHERE
																																b11.b= 1
																															) s1
																														WHERE
																															s1.msg IS NOT NULL
																															AND s1.msg != ''
																															union ALL

																																SELECT
																																	'04' AS tesp1,
																																t2.CODE,
																																t2.MSG,
																																t2.OCCURDATE
																															FROM
																																( SELECT id FROM HRPERSONBASICINFO WHERE ARCHIVENUM =@IDCARD ) t1
																																INNER JOIN HRASSOCIATIONINFO t2 ON t1.id= t2.pid
																															WHERE
																																t2.ASSOCIATIONTYPE = 'HISTORY_OF_DRUG_ALLERGY'
																																and t2.CODE !=''
																																and t2.CODE is not null

																														) B
																													) SELECT
                                                                                                                                                                                                                                                                          @IDCARD AS IDCARD,@ID AS ASSESS_ID,
                                                                                                                                                                                                                                                                          b1.tesp1 AS ASSOCIATION_TYPE,
                                                                                                                                                                                                                                                                          b1.code AS MSG_CODE,
                                                                                                                                                                                                                                                                          b1.num1 AS MSG_NAME,
                                                                                                                                                                                                                                                                          b1.DATENAME AS OCCUR_DATE
                                                                                                                      FROM
                                                                                                                                                                                                                                                                          b1;

END
go

