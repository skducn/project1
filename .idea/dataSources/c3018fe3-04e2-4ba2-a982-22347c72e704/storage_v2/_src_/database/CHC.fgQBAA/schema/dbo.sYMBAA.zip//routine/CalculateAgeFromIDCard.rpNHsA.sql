CREATE FUNCTION [dbo].[CalculateAgeFromIDCard]
(
    @idCard VARCHAR(18)
)
RETURNS DECIMAL(5,1)
AS
BEGIN
    DECLARE @birthDate AS DATE;
    DECLARE @length INT = LEN(@idCard);

    IF @length = 15
        SET @birthDate = TRY_CONVERT(DATE, '19' + SUBSTRING(@idCard, 7, 6), 112); -- 前两位默认补足'19'
    ELSE IF @length = 18
        SET @birthDate = TRY_CONVERT(DATE, SUBSTRING(@idCard, 7, 8), 112);

    IF @birthDate IS NULL
        RETURN NULL; -- 如果转换失败，说明身份证号码的生日部分可能无效，返回NULL

    DECLARE @currentDate AS DATETIME = GETUTCDATE();
    DECLARE @ageYears INT;
    DECLARE @ageDays INT;

    SET @ageYears = DATEDIFF(year, @birthDate, @currentDate);
    SET @ageDays = DATEDIFF(day, DATEADD(year, @ageYears, @birthDate), @currentDate);

    -- 处理闰年引起的生日过后但不满一年的情况
    IF (@ageDays > 0 AND MONTH(@birthDate) > MONTH(@currentDate)) 
       OR (MONTH(@birthDate) = MONTH(@currentDate) AND DAY(@birthDate) > DAY(@currentDate))
        SET @ageYears -= 1;

    RETURN ROUND((@ageYears + @ageDays / 365.2425), 1); -- 近似计算年龄并保留一位小数
END;
go

