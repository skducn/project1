CREATE FUNCTION dbo.IsNumber(@Value VARCHAR(100))
RETURNS BIT
AS
BEGIN
    SET @Value = REPLACE(REPLACE(@Value, ',', ''), '-', '')

    -- Check if the remaining characters are numeric
    RETURN CASE 
               WHEN @Value NOT LIKE '%[^0-9]%' AND @Value <> '' THEN 1
               ELSE 0
           END
END;
go

