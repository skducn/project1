
CREATE PROCEDURE [DBO].[SP_WHO_LOCK]
AS
BEGIN
    DECLARE @SPID INT,@BL INT,
        @INTTRANSACTIONCOUNTONENTRY INT,
        @INTROWCOUNT INT,
        @INTCOUNTPROPERTIES INT,
        @INTCOUNTER INT
    CREATE TABLE #TMP_LOCK_WHO (
                                   ID INT IDENTITY(1,1),
                                   SPID SMALLINT,
                                   BL SMALLINT)
    IF @@ERROR<>0 RETURN @@ERROR
    INSERT INTO #TMP_LOCK_WHO(SPID,BL) SELECT 0 ,BLOCKED
    FROM (SELECT * FROM SYSPROCESSES WHERE BLOCKED>0 ) A
    WHERE NOT EXISTS(SELECT * FROM (SELECT * FROM SYSPROCESSES WHERE BLOCKED>0 ) B
                     WHERE A.BLOCKED=SPID)
    UNION SELECT SPID,BLOCKED FROM SYSPROCESSES WHERE BLOCKED>0
    IF @@ERROR<>0 RETURN @@ERROR
-- 找到临时表的记录数
    SELECT @INTCOUNTPROPERTIES = COUNT(*),@INTCOUNTER = 1
    FROM #TMP_LOCK_WHO
    IF @@ERROR<>0 RETURN @@ERROR
    IF @INTCOUNTPROPERTIES=0
        SELECT '现在没有阻塞和死锁信息' AS MESSAGE
-- 循环开始
    WHILE @INTCOUNTER <= @INTCOUNTPROPERTIES
        BEGIN
            -- 取第一条记录
            SELECT @SPID = SPID,@BL = BL
            FROM #TMP_LOCK_WHO WHERE ID = @INTCOUNTER
            BEGIN
                IF @SPID =0
                    SELECT '引起数据库死锁的是: '+ CAST(@BL AS VARCHAR(10)) + '进程号,其执行的SQL语法如下'
                ELSE
                    SELECT '进程号SPID：'+ CAST(@SPID AS VARCHAR(10))+ '被' + '进程号SPID：'+ CAST(@BL AS VARCHAR(10)) +'阻塞,其当前进程执行的SQL语法如下'
                DBCC INPUTBUFFER (@BL )
            END
-- 循环指针下移
            SET @INTCOUNTER = @INTCOUNTER + 1
        END
    DROP TABLE #TMP_LOCK_WHO
    RETURN 0
END
--杀死锁和进程
--如何去手动的杀死进程和锁？最简单的办法，重新启动服务。但是这里要介绍一个存储过程，通过显式的调用，可以杀死进程和锁。
go

