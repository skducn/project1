
CREATE PROCEDURE [DBO].[COMPUTEDMVISIT]
  @质控数据开始时间 AS VARCHAR(20), 
  @质控数据截止时间 AS VARCHAR(20)
AS
BEGIN

/**
  1. 理论随访次数
  2. 实际随访次数
  3. 实际有效随访次数
  4. 第1次随访标志
  5. 第1次随访时间范围
  6. 第2次随访标志
  7. 第2次随访时间范围
  8. 第3次随访标志
  9. 第3次随访时间范围
  10. 第4次随访标志
  11. 第4次随访时间范围
 */

--  5005672691  310110193604010010  左*煦


TRUNCATE TABLE TEMP_糖尿病随访次数统计

INSERT INTO TEMP_糖尿病随访次数统计(ARCHIVE_NUM, TARGET_TIME, INDEX_TIME)
SELECT SFZH, B7 '糖尿病理论张数', 0
FROM REPORT_QYYH
WHERE A7 = 1
-- AND SFZH = '310110193604010010'


-- 随访信息临时表
-- 糖尿病的登记机构 必须是在 签约机构
IF OBJECT_ID('TEMPDB..##糖尿病随访信息') IS NOT NULL
    DROP TABLE ##糖尿病随访信息
SELECT *
INTO ##糖尿病随访信息
FROM (
         SELECT A.ARCHIVENUM, E.VISITDATE, D.REGISTTIME
         FROM HRCOVER A
              INNER JOIN TB_EMPI_INDEX_ROOT B ON A.ARCHIVENUM = B.IDCARDNO
              INNER JOIN TB_DC_CHRONIC_INFO C ON B.GUID = C.EMPIGUID
              INNER JOIN TB_DC_CHRONIC_MAIN D ON C.MANAGENUM = D.MANAGENUM
              INNER JOIN TB_DC_DM_VISIT E ON D.VISITNUM = E.CARDID
              INNER JOIN REPORT_QYYH F ON F.SFZH = B.IDCARDNO
         WHERE -- A.ARCHIVEUNITCODE = F.ORG_CODE AND 
           C.ORGCODE = F.ORG_CODE
           AND D.ORGCODE = F.ORG_CODE
					 AND E.ORGCODE = F.ORG_CODE
           AND D.VISITTYPECODE LIKE '%33%'
           AND A4 = 1
         -- AND SFZH = '310110193604010010'
     ) TEMP


/**
  计算第1次随访
 */

-- 插入第1次随访基础数据
INSERT INTO TEMP_糖尿病随访次数统计(ARCHIVE_NUM, TARGET_TIME, VISIT_DATE, IRREGULAR_VISIT_DATE, START_DATE, END_DATE, INDEX_TIME)
SELECT ARCHIVE_NUM, TARGET_TIME, NULL, NULL, NULL START_DATE, NULL END_DATE, 1 INDEX_TIME
FROM TEMP_糖尿病随访次数统计 A
WHERE A.INDEX_TIME = 0


-- 更新 第1次有随访的开始时间、截止时间
UPDATE TEMP_糖尿病随访次数统计
SET START_DATE = (CASE
                      WHEN B.REGISTTIME < @质控数据开始时间 OR B.REGISTTIME IS NULL 
											THEN @质控数据开始时间
                      ELSE B.REGISTTIME 
									END),
    END_DATE = DATEADD(DD, 90 + 14, (CASE
                                           WHEN B.REGISTTIME < @质控数据开始时间 OR B.REGISTTIME IS NULL 
																					 THEN @质控数据开始时间
                                           ELSE B.REGISTTIME 
																			 END))
FROM TEMP_糖尿病随访次数统计 A
     INNER JOIN ##糖尿病随访信息 B ON A.ARCHIVE_NUM = B.ARCHIVENUM
WHERE A.INDEX_TIME = 1


-- 更新 第1次 实际随访时间
UPDATE TEMP_糖尿病随访次数统计
SET VISIT_DATE= A.VISITDATE
FROM (SELECT A.ARCHIVENUM     ARCHIVENUM,
             MAX(A.VISITDATE) VISITDATE
      FROM ##糖尿病随访信息 A
           INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
      WHERE B.INDEX_TIME = 1
        AND A.VISITDATE >= B.START_DATE
        AND A.VISITDATE <= B.END_DATE
      GROUP BY A.ARCHIVENUM
     ) A
     INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
WHERE B.INDEX_TIME = 1


-- 更新第一次 无随访的时候，预计的开始时间 和截止时间
-- VISIT_DATE_1 IS NULL,就是没有匹配到第一次随访记录

UPDATE TEMP_糖尿病随访次数统计
SET START_DATE= (CASE
                     WHEN B.REGISTTIME < @质控数据开始时间 OR B.REGISTTIME IS NULL 
										 THEN @质控数据开始时间
                     ELSE B.REGISTTIME 
								END),
    END_DATE=DATEADD(DD, 90, (CASE
                                  WHEN B.REGISTTIME < @质控数据开始时间 OR B.REGISTTIME IS NULL 
																	THEN @质控数据开始时间
                                  ELSE B.REGISTTIME 
															END))
FROM TEMP_糖尿病随访次数统计 A
     INNER JOIN ##糖尿病随访信息 B ON A.ARCHIVE_NUM = B.ARCHIVENUM
WHERE VISIT_DATE IS NULL
  AND A.INDEX_TIME = 1


/**
  计算第2次随访
 */

/**
 先计算第二次有效随访的开始时间  和 结束 时间
  情况1： 第一次无随访，开始时间=END_DATE_1  结束时间=END_DATE_1+90
  情况2： 第一次有随访，开始时间要从实际随访时间开始计算，开始时间= VISIT_DATE_1+90-14,结束时间=VISIT_DATE_1+90+14
*/


-- 插入第二次随访基础数据
INSERT INTO TEMP_糖尿病随访次数统计(ARCHIVE_NUM, TARGET_TIME, VISIT_DATE, IRREGULAR_VISIT_DATE, START_DATE, END_DATE, INDEX_TIME)
SELECT ARCHIVE_NUM, TARGET_TIME, NULL, NULL, NULL START_DATE, NULL END_DATE, 2 INDEX_TIME
FROM TEMP_糖尿病随访次数统计 A
WHERE A.INDEX_TIME = 0


-- 情况1： 第一次无随访

/*
UPDATE TEMP_糖尿病随访次数统计
SET START_DATE_2=END_DATE_1,
    END_DATE_2=DATEADD(DD, 90, END_DATE_1)
WHERE VISIT_DATE_1 IS NULL
*/

UPDATE NOW
SET NOW.START_DATE=LAST.END_DATE,
    NOW.END_DATE=DATEADD(DD, 90, LAST.END_DATE)
FROM TEMP_糖尿病随访次数统计 LAST
     INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
WHERE LAST.INDEX_TIME = 1
  AND NOW.INDEX_TIME = 2
  AND LAST.VISIT_DATE IS NULL


-- 情况2： 第一次有随访
/*
UPDATE TEMP_糖尿病随访次数统计
SET START_DATE_2=DATEADD(DD, 90 - 14, VISIT_DATE_1),
    END_DATE_2=DATEADD(DD, 90 + 14, VISIT_DATE_1)
WHERE VISIT_DATE_1 IS NOT NULL
*/

UPDATE NOW
SET NOW.START_DATE=DATEADD(DD, 90 - 14, LAST.VISIT_DATE),
    NOW.END_DATE=DATEADD(DD, 90 + 14, LAST.VISIT_DATE)
FROM TEMP_糖尿病随访次数统计 LAST
     INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
WHERE LAST.INDEX_TIME = 1
  AND NOW.INDEX_TIME = 2
  AND LAST.VISIT_DATE IS NOT NULL


/**
 更新 第2次有效随访的随访时间
 */

UPDATE TEMP_糖尿病随访次数统计
SET VISIT_DATE= A.VISITDATE
FROM (SELECT A.ARCHIVENUM     ARCHIVENUM,
             MAX(A.VISITDATE) VISITDATE
      FROM ##糖尿病随访信息 A
           INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
      WHERE A.VISITDATE >= B.START_DATE
        AND A.VISITDATE <= B.END_DATE
        AND B.INDEX_TIME = 2
      GROUP BY A.ARCHIVENUM
     ) A
     INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
WHERE B.INDEX_TIME = 2

/**
 更新 第2次无效随访的随访时间
  时间范围  开始时间=END_DATE_1   结束时间=START_DATE_2
 */

UPDATE TEMP_糖尿病随访次数统计
SET IRREGULAR_VISIT_DATE= A.VISITDATE
FROM (SELECT A.ARCHIVENUM     ARCHIVENUM,
             MAX(A.VISITDATE) VISITDATE
      FROM ##糖尿病随访信息 A
           INNER JOIN TEMP_糖尿病随访次数统计 LAST ON LAST.ARCHIVE_NUM = A.ARCHIVENUM 
           INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
      WHERE LAST.INDEX_TIME = 1
        AND NOW.INDEX_TIME = 2
        AND A.VISITDATE >= LAST.END_DATE
        AND A.VISITDATE <= NOW.START_DATE
      GROUP BY A.ARCHIVENUM
     ) A
     INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
WHERE B.INDEX_TIME = 2


/**
  计算第3次随访
 */

/**
 先计算第3次有效随访的开始时间  和 结束 时间
  情况1： 上一次无随访， 开始时间=END_DATE_2  结束时间=END_DATE_2+90
  情况2： 第一次有随访（包括有效随访和 无效随访），开始时间要从实际随访时间开始计算，开始时间= VISIT_DATE_1+90-14,结束时间=VISIT_DATE_1+90+14
*/

-- 插入第3次随访基础数据
INSERT INTO TEMP_糖尿病随访次数统计(ARCHIVE_NUM, TARGET_TIME, VISIT_DATE, IRREGULAR_VISIT_DATE, START_DATE, END_DATE, INDEX_TIME)
SELECT ARCHIVE_NUM, TARGET_TIME, NULL, NULL, NULL START_DATE, NULL END_DATE, 3 INDEX_TIME
FROM TEMP_糖尿病随访次数统计 A
WHERE A.INDEX_TIME = 0


-- 情况1： 上次无随访

UPDATE NOW
SET NOW.START_DATE=LAST.END_DATE,
    NOW.END_DATE=DATEADD(DD, 90, LAST.END_DATE)
FROM TEMP_糖尿病随访次数统计 LAST
     INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
WHERE LAST.INDEX_TIME = 2
  AND NOW.INDEX_TIME = 3
  AND LAST.VISIT_DATE IS NULL


-- 情况2： 上次有随访（包括有效随访和 无效随访）

UPDATE NOW
SET NOW.START_DATE=DATEADD(DD, 90 - 14, CASE
                                            WHEN LAST.VISIT_DATE IS NOT NULL THEN LAST.VISIT_DATE
                                            WHEN LAST.IRREGULAR_VISIT_DATE IS NOT NULL
                                            THEN LAST.IRREGULAR_VISIT_DATE 
																				END),
    NOW.END_DATE=DATEADD(DD, 90 + 14, CASE
                                          WHEN LAST.VISIT_DATE IS NOT NULL THEN LAST.VISIT_DATE
                                          WHEN LAST.IRREGULAR_VISIT_DATE IS NOT NULL 
																					THEN LAST.IRREGULAR_VISIT_DATE 
																			END)
FROM TEMP_糖尿病随访次数统计 LAST
     INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
WHERE LAST.INDEX_TIME = 2
  AND NOW.INDEX_TIME = 3
  AND (LAST.VISIT_DATE IS NOT NULL OR LAST.IRREGULAR_VISIT_DATE IS NOT NULL)


/**
 更新 第3次有效随访的随访时间
 */


UPDATE TEMP_糖尿病随访次数统计
SET VISIT_DATE= A.VISITDATE
FROM (SELECT A.ARCHIVENUM     ARCHIVENUM,
             MAX(A.VISITDATE) VISITDATE
      FROM ##糖尿病随访信息 A
           INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
      WHERE A.VISITDATE >= B.START_DATE
        AND A.VISITDATE <= B.END_DATE
        AND B.INDEX_TIME = 3
      GROUP BY A.ARCHIVENUM
     ) A
     INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
WHERE B.INDEX_TIME = 3


/**
 更新 第3次无效随访的随访时间
  时间范围  开始时间=END_DATE_2   结束时间=START_DATE_3
 */

UPDATE TEMP_糖尿病随访次数统计
SET IRREGULAR_VISIT_DATE= A.VISITDATE
FROM (SELECT A.ARCHIVENUM     ARCHIVENUM,
             MAX(A.VISITDATE) VISITDATE
      FROM ##糖尿病随访信息 A
           INNER JOIN TEMP_糖尿病随访次数统计 LAST ON LAST.ARCHIVE_NUM = A.ARCHIVENUM
           INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
      WHERE LAST.INDEX_TIME = 2
        AND NOW.INDEX_TIME = 3
        AND A.VISITDATE >= LAST.END_DATE
        AND A.VISITDATE <= NOW.START_DATE
      GROUP BY A.ARCHIVENUM
     ) A
     INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
WHERE B.INDEX_TIME = 3

/*
 第四次随访
 从第3次 开始  后面都是循环
 */
DECLARE @最大随访次数 INT=(SELECT MAX(TARGET_TIME) FROM TEMP_糖尿病随访次数统计)
PRINT ('当前最大随访次数:' + CAST(@最大随访次数 AS VARCHAR))
--  执行循环逻辑
-- 当前随访次数
DECLARE @当前随访次数 INT
SET @当前随访次数 = 4
WHILE @当前随访次数 <= @最大随访次数
    BEGIN
        --  循环执行语句开始
        PRINT ('当前随访次数:' + CAST(@当前随访次数 AS VARCHAR))
        --------- 步骤1.插入基础数据开始
        DECLARE @插入基础数据SQL VARCHAR(1000)='INSERT INTO TEMP_糖尿病随访次数统计(ARCHIVE_NUM, TARGET_TIME, VISIT_DATE, IRREGULAR_VISIT_DATE,' +
                                         ' START_DATE, END_DATE, INDEX_TIME) ' +
                                         'SELECT  ARCHIVE_NUM, TARGET_TIME, NULL, NULL, NULL START_DATE, NULL END_DATE, ' +
                                         CAST(@当前随访次数 AS VARCHAR) + ' INDEX_TIME' +
                                         ' FROM TEMP_糖尿病随访次数统计 A WHERE A.INDEX_TIME = 0 AND A.TARGET_TIME>=' +
                                         CAST(@当前随访次数 AS VARCHAR)
        PRINT (@插入基础数据SQL)
        EXEC ( @插入基础数据SQL)
        --------- 步骤1.插入基础数据结束


        --------- 步骤2.更新情况1： 上次无随访时，START_DATE 和  END_DATE   开始
        DECLARE @更新情况1SQL VARCHAR(1000)='UPDATE NOW SET ' +
                                        'NOW.START_DATE=LAST.END_DATE,' +
                                        'NOW.END_DATE=DATEADD(DD, 90, LAST.END_DATE) ' +
                                        'FROM TEMP_糖尿病随访次数统计 LAST INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM ' +
                                        'WHERE LAST.INDEX_TIME =' +
                                        CAST(@当前随访次数 - 1 AS VARCHAR) +
                                        'AND NOW.INDEX_TIME = ' + CAST(@当前随访次数 AS VARCHAR) +
                                        ' AND LAST.VISIT_DATE IS NULL'
        PRINT (@更新情况1SQL)
        EXEC ( @更新情况1SQL)
        --------- 步骤2.更新情况2： 第一次有随访时，START_DATE 和  END_DATE   结束


        --------- 步骤2.更新情况2： 上次有随访时，START_DATE 和  END_DATE   开始
        DECLARE @更新情况2SQL VARCHAR(1000)='UPDATE NOW
SET NOW.START_DATE=DATEADD(DD, 90 - 14, CASE
                                            WHEN LAST.VISIT_DATE IS NOT NULL THEN LAST.VISIT_DATE
                                            WHEN LAST.IRREGULAR_VISIT_DATE IS NOT NULL
                                                THEN LAST.IRREGULAR_VISIT_DATE END),
    NOW.END_DATE=DATEADD(DD, 90 + 14, CASE
                                          WHEN LAST.VISIT_DATE IS NOT NULL THEN LAST.VISIT_DATE
                                          WHEN LAST.IRREGULAR_VISIT_DATE IS NOT NULL THEN LAST.IRREGULAR_VISIT_DATE END)
FROM TEMP_糖尿病随访次数统计 LAST
     INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
WHERE LAST.INDEX_TIME =' + CAST(@当前随访次数 - 1 AS VARCHAR) + '
  AND NOW.INDEX_TIME =' + CAST(@当前随访次数 AS VARCHAR) + '
  AND (LAST.VISIT_DATE IS NOT NULL OR LAST.IRREGULAR_VISIT_DATE IS NOT NULL)'
        PRINT (@更新情况2SQL)
        EXEC ( @更新情况2SQL)
        --------- 步骤2.更新情况2： 第一次有随访时，START_DATE 和  END_DATE   结束


        --------- 步骤3.更新 本次有效随访的随访时间  开始
        DECLARE @更新有效随访时间SQL VARCHAR(1000)='UPDATE TEMP_糖尿病随访次数统计
SET VISIT_DATE= A.VISITDATE
FROM (SELECT A.ARCHIVENUM     ARCHIVENUM,
             MAX(A.VISITDATE) VISITDATE
      FROM ##糖尿病随访信息 A
           INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
      WHERE A.VISITDATE >= B.START_DATE
        AND A.VISITDATE <= B.END_DATE
        AND B.INDEX_TIME =' + CAST(@当前随访次数 AS VARCHAR) + '
      GROUP BY A.ARCHIVENUM
     ) A
     INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
WHERE B.INDEX_TIME =' + CAST(@当前随访次数 AS VARCHAR)
        PRINT (@更新有效随访时间SQL)
        EXEC ( @更新有效随访时间SQL)
        --------- 步骤3.更新 本次有效随访的随访时间  结束


        --------- 步骤4.更新 本次无效随访的随访时间  开始
        DECLARE @更新无效随访时间SQL VARCHAR(1000)='UPDATE TEMP_糖尿病随访次数统计
SET IRREGULAR_VISIT_DATE= A.VISITDATE
FROM (SELECT A.ARCHIVENUM     ARCHIVENUM,
             MAX(A.VISITDATE) VISITDATE
      FROM ##糖尿病随访信息 A
           INNER JOIN TEMP_糖尿病随访次数统计 LAST ON LAST.ARCHIVE_NUM = A.ARCHIVENUM
           INNER JOIN TEMP_糖尿病随访次数统计 NOW ON LAST.ARCHIVE_NUM = NOW.ARCHIVE_NUM
      WHERE LAST.INDEX_TIME = ' + CAST(@当前随访次数 - 1 AS VARCHAR) + '
        AND NOW.INDEX_TIME = ' + CAST(@当前随访次数 AS VARCHAR) + '
        AND A.VISITDATE >= LAST.END_DATE
        AND A.VISITDATE <= NOW.START_DATE
      GROUP BY A.ARCHIVENUM
     ) A
     INNER JOIN TEMP_糖尿病随访次数统计 B ON B.ARCHIVE_NUM = A.ARCHIVENUM
WHERE B.INDEX_TIME = ' + CAST(@当前随访次数 AS VARCHAR)
        PRINT (@更新无效随访时间SQL)
        EXEC ( @更新无效随访时间SQL)
        --------- 步骤4.更新 本次无效随访的随访时间  结束


        -- 循环执行语句结束
        SET @当前随访次数 = @当前随访次数 + 1
    END


--  清除 1 2 3 次随访多余数据，因为部分人随访次数小于3次

DELETE
FROM TEMP_糖尿病随访次数统计
WHERE INDEX_TIME > TARGET_TIME


-- 更新REPORT_QYYH 表
-- B811	糖尿病随访表实际有效张数


UPDATE REPORT_QYYH
SET B811=(SELECT COUNT(*)
          FROM TEMP_糖尿病随访次数统计 A
          WHERE A.ARCHIVE_NUM = SFZH
            AND A.INDEX_TIME > 0
            AND A.VISIT_DATE IS NOT NULL)

-- B812	糖尿病随访表实际有效张数
UPDATE REPORT_QYYH
SET B812=(SELECT COUNT(*)
          FROM TEMP_糖尿病随访次数统计 A
          WHERE A.ARCHIVE_NUM = SFZH
            AND A.INDEX_TIME > 0
            AND A.VISIT_DATE IS  NULL)


-- B813	糖尿病随访表计算用总张数= 实际张数B8+实际无效张数B812
UPDATE REPORT_QYYH
SET B813=B8+B812

END
go

