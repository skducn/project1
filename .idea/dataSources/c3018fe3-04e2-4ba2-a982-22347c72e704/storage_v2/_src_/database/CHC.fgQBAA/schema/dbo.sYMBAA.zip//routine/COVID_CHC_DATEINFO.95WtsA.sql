CREATE PROCEDURE [dbo].[COVID_CHC_DATEINFO]
AS
BEGIN
BEGIN


--封面
TRUNCATE TABLE HRCOVER;
	insert into  dbo.HRCOVER (
	 [ARCHIVENUM], [EHRNUM], [NAME], [PRESENTADDRESS], [PERMANENTADDRESS], [PHONE], [PROVINCE], [PROVINCECODE], [CITY], [CITYCODE], [DISTRICT], [DISTRICTCODE], [NEIGHBORHOOD], [NEIGHBORHOODCODE], [VILLAGENAME], [VILLAGECODE], [ARCHIVEUNIT], [ARCHIVEUNITCODE], [ARCHIVERID], [ARCHIVER], [RESPONSIBLEDOCTORID], [RESPONSIBLEDOCTOR], [DATEOFCREATEARCHIVE], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [DATASOURCES], [STATUS], [VERSION], [ISDELETED], [FIELDSOURCES], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [PERMANENTNEIGHBORHOODCODE], [PERMANENTNEIGHBORHOOD], [PERMANENTVILLAGECODE], [PERMANENTVILLAGENAME], [ISGOVERNANCE]) 
SELECT[ARCHIVENUM], [EHRNUM], [NAME], [PRESENTADDRESS], [PERMANENTADDRESS], [PHONE], [PROVINCE], [PROVINCECODE], [CITY], [CITYCODE], [DISTRICT], [DISTRICTCODE], [NEIGHBORHOOD], [NEIGHBORHOODCODE], [VILLAGENAME], [VILLAGECODE], [ARCHIVEUNIT], [ARCHIVEUNITCODE], [ARCHIVERID], [ARCHIVER], [RESPONSIBLEDOCTORID], [RESPONSIBLEDOCTOR], [DATEOFCREATEARCHIVE], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [DATASOURCES], [STATUS], [VERSION], [ISDELETED], [FIELDSOURCES], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [PERMANENTNEIGHBORHOODCODE], [PERMANENTNEIGHBORHOOD], [PERMANENTVILLAGECODE], [PERMANENTVILLAGENAME], [ISGOVERNANCE] from ITSV.EHRDC.dbo.HrCover;
	PRINT '封面完成' 
END

BEGIN
--基本信息
TRUNCATE TABLE HRPERSONBASICINFO;
set  IDENTITY_INSERT HRPERSONBASICINFO on 
insert into HRPERSONBASICINFO(ID,
[ARCHIVENUM], [NAME], [SEX], [DATEOFBIRTH], [IDCARD], [WORKUNIT], [PHONE], [CONTACTSNAME], [CONTACTSPHONE], [RESIDENCETYPE], [NATIONCODE], [BLOODTYPE], [RHBLOODTYPE], [DEGREE], [OCCUPATION], [MARITALSTATUS], [HEREDITYHISTORYFLAG], [HEREDITYHISTORYCODE], [ENVIRONMENTKITCHENAERATION], [ENVIRONMENTFUELTYPE], [ENVIRONMENTWATER], [ENVIRONMENTTOILET], [ENVIRONMENTCORRAL], [DATASOURCES], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [STATUS], [ISDELETED], [VERSION], [WORKSTATUS], [TELEPHONE], [OCCUPATIONALDISEASESFLAG], [OCCUPATIONALDISEASESWORKTYPE], [OCCUPATIONALDISEASESWORKINGYEARS], [DUSTNAME], [DUSTFLAG], [RADIOACTIVEMATERIALNAME], [RADIOACTIVEMATERIALFLAG], [CHEMICALMATERIALNAME], [CHEMICALMATERIALFLAG], [OTHERNAME], [OTHERFLAG], [PHYSICSMATERIALNAME], [PHYSICSMATERIALFLAG], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [YLZFMC], [PERSONID], [MEDICAL_PAYMENTCODE], [KALEIDOSCOPE],  [ISGOVERNANCE]) 

SELECT id,[ARCHIVENUM], [NAME], [SEX], [DATEOFBIRTH], [IDCARD], [WORKUNIT], [PHONE], [CONTACTSNAME], [CONTACTSPHONE], [RESIDENCETYPE], [NATIONCODE], [BLOODTYPE], [RHBLOODTYPE], [DEGREE], [OCCUPATION], [MARITALSTATUS], [HEREDITYHISTORYFLAG], [HEREDITYHISTORYCODE], [ENVIRONMENTKITCHENAERATION], [ENVIRONMENTFUELTYPE], [ENVIRONMENTWATER], [ENVIRONMENTTOILET], [ENVIRONMENTCORRAL], [DATASOURCES], [CREATEID], [CREATENAME], [CREATETIME], [UPDATEID], [UPDATENAME], [UPDATETIME], [STATUS], [ISDELETED], [VERSION], [WORKSTATUS], [TELEPHONE], [OCCUPATIONALDISEASESFLAG], [OCCUPATIONALDISEASESWORKTYPE], [OCCUPATIONALDISEASESWORKINGYEARS], [DUSTNAME], [DUSTFLAG], [RADIOACTIVEMATERIALNAME], [RADIOACTIVEMATERIALFLAG], [CHEMICALMATERIALNAME], [CHEMICALMATERIALFLAG], [OTHERNAME], [OTHERFLAG], [PHYSICSMATERIALNAME], [PHYSICSMATERIALFLAG], [DOWNLOADSTATUS], [NONUMBERPROVIDED], [YLZFMC], [PERSONID], [MEDICAL_PAYMENTCODE], [KALEIDOSCOPE],  [ISGOVERNANCE] from ITSV.EHRDC.dbo.HrPersonBasicInfo;



PRINT '基本信息表完成' 
set  IDENTITY_INSERT HRPERSONBASICINFO off ;
END

BEGIN
-- 一对多选表
TRUNCATE TABLE HRASSOCIATIONINFO;
insert into  HRASSOCIATIONINFO (
 [TABLESOURCE], [PID], [ASSOCIATIONTYPE], [CODE], [MSG], [OCCURDATE], [ORDERS], [SOURCETYPE]

)SELECT  [TABLESOURCE], [PID], [ASSOCIATIONTYPE], [CODE], [MSG], [OCCURDATE], [ORDERS], [SOURCETYPE] from ITSV.EHRDC.dbo.HrAssociationInfo;
PRINT '一对多选表完成' 

END ;
--糖尿病随访 

BEGIN
TRUNCATE TABLE TB_DC_DM_VISIT;

insert into  TB_DC_DM_VISIT (
GUID, [cardId], [name], ehrNum, [orgCode], [visitDate], [visitWayCode], [visitWayValue], [otherVisit], [visitDocNo], [visitDocName], [visitOrgCode], [visitOrgName], [vistStatusCode], [visitStatusValue], [nextVisiDate], [lostVisitCode], [lostVisitName], [lostVisitDate], [otherLostVIsitName], [deathReason], [targetDistrictCode], [targetDistrictName], [targetOrgCode], [targetOrgName], [moveProvinceCode], [moveProvinceValue], [moveCityCode], [moveCityValue], [moveDistrictCode], [moveDistrictValue], [moveStreetCode], [moveStreetValue], [moveNeighborhoodCode], [moveNeighborhoodValue], [moveVillageValue], [moveHouseNumber], [moveOrgCode], [moveOrgName], [hasPaperCard], [isAcceptHealthEdu], [healthEduType], [clinicalSymptomsCode], [clinicalSymptomsValue], [otherClinicalSymptoms], [symptomStatus], [clinicalInfo], [sbp], [dbp], [height], [weight], [waistline], [hipline], [targetWeight], [BMI], [targetBMI], [dorsalArteryOfFootLeftCode], [dorsalArteryOfFootLeftName], [dorsalArteryOfFootRightCode], [dorsalArteryOfFootRightName], [hypoglycemia], [familyHistory], [isLawSport], [sportTypeCode], [sportTypeName], [sportFrequence], [sportTimes], [dietCode], [dietName], [stapleFood], [targetStapleFood], [smokingVolume], [drinkingVolume], [targetSportFrequencyCode], [targetSportFrequencyName], [targetSportTimes], [smokingStatusCode], [smokingStatusName], [targetSmoke], [quitSmoking], [drinkingFrequencyCode], [drinkingFrequencyName], [targetDrink], [psychologyStatusCode], [psychologyStatusName], [complianceStatusCode], [complianceStatusName], [referralReason], [referralOrgDept], [visitType], [fastingBloodSugarCode], [fastingBloodSugarName], [fastingBloodSugarValue], [fastingBloodSugarGatherCode], [fastingBloodSugarGatherName], [randomBloodSugarCode], [randomBloodSugarName], [randomBloodSugarValue], [randomBloodSugarGatherCode], [randomBloodSugarGatherName], [fastingBloodSugarOGTTCode], [fastingBloodSugarOGTTName], [fastingBloodSugarOGTTValue], [fastingBloodSugarOGTTGatherCode], [fastingBloodSugarOGTTGatherName], [twoHBloodSugarOGTTCode], [twoHBloodSugarOGTTName], [twoHBloodSugarOGTTValue], [twoHBloodSugarOGTTGatherCode], [twoHBloodSugarOGTTGatherName], [hbAlc], [hbAlcDate], [cholesterol], [triglycerides], [highCholesterol], [lowCholesterol], [acr], [urineProtein], [ghGaterWayCode], [ghGaterWayName], [drugComplianceCode], [drugComplianceName], [useDrug], [hasUseDrugSideEffects], [UseDrugSideEffects], [interveneCount], [beforeInterveneDate], [isIntervene], [syndrome], [interveneMeasures], [measuresContent], [otherInterveneMeasures], [otherMeasuresContent], [proposal], [otherProposal], [synStatus], [age], [empiGuid], [isGovernance]

)SELECT GUID, [cardId], [name], CAST([ehrNum]as VARCHAR) as ehrNum, [orgCode], [visitDate], [visitWayCode], [visitWayValue], [otherVisit], [visitDocNo], [visitDocName], [visitOrgCode], [visitOrgName], [vistStatusCode], [visitStatusValue], [nextVisiDate], [lostVisitCode], [lostVisitName], [lostVisitDate], [otherLostVIsitName], [deathReason], [targetDistrictCode], [targetDistrictName], [targetOrgCode], [targetOrgName], [moveProvinceCode], [moveProvinceValue], [moveCityCode], [moveCityValue], [moveDistrictCode], [moveDistrictValue], [moveStreetCode], [moveStreetValue], [moveNeighborhoodCode], [moveNeighborhoodValue], [moveVillageValue], [moveHouseNumber], [moveOrgCode], [moveOrgName], [hasPaperCard], [isAcceptHealthEdu], [healthEduType], [clinicalSymptomsCode], [clinicalSymptomsValue], [otherClinicalSymptoms], [symptomStatus], [clinicalInfo], [sbp], [dbp], [height], [weight], [waistline], [hipline], [targetWeight], [BMI], [targetBMI], [dorsalArteryOfFootLeftCode], [dorsalArteryOfFootLeftName], [dorsalArteryOfFootRightCode], [dorsalArteryOfFootRightName], [hypoglycemia], [familyHistory], [isLawSport], [sportTypeCode], [sportTypeName], [sportFrequence], [sportTimes], [dietCode], [dietName], [stapleFood], [targetStapleFood], [smokingVolume], [drinkingVolume], [targetSportFrequencyCode], [targetSportFrequencyName], [targetSportTimes], [smokingStatusCode], [smokingStatusName], [targetSmoke], [quitSmoking], [drinkingFrequencyCode], [drinkingFrequencyName], [targetDrink], [psychologyStatusCode], [psychologyStatusName], [complianceStatusCode], [complianceStatusName], [referralReason], [referralOrgDept], [visitType], [fastingBloodSugarCode], [fastingBloodSugarName], [fastingBloodSugarValue], [fastingBloodSugarGatherCode], [fastingBloodSugarGatherName], [randomBloodSugarCode], [randomBloodSugarName], [randomBloodSugarValue], [randomBloodSugarGatherCode], [randomBloodSugarGatherName], [fastingBloodSugarOGTTCode], [fastingBloodSugarOGTTName], [fastingBloodSugarOGTTValue], [fastingBloodSugarOGTTGatherCode], [fastingBloodSugarOGTTGatherName], [twoHBloodSugarOGTTCode], [twoHBloodSugarOGTTName], [twoHBloodSugarOGTTValue], [twoHBloodSugarOGTTGatherCode], [twoHBloodSugarOGTTGatherName], [hbAlc], [hbAlcDate], [cholesterol], [triglycerides], [highCholesterol], [lowCholesterol], [acr], [urineProtein], [ghGaterWayCode], [ghGaterWayName], [drugComplianceCode], [drugComplianceName], [useDrug], [hasUseDrugSideEffects], [UseDrugSideEffects], [interveneCount], [beforeInterveneDate], [isIntervene], [syndrome], [interveneMeasures], [measuresContent], [otherInterveneMeasures], [otherMeasuresContent], [proposal], [otherProposal], [synStatus], [age], [empiGuid], [isGovernance]
 from ITSV.EHRDC.dbo.tb_dc_dm_visit;
 PRINT '糖尿病随访表完成' 
 END;
 
 BEGIN
 -- 体检信息
TRUNCATE TABLE TB_DC_EXAMINATION_INFO;
insert into TB_DC_EXAMINATION_INFO SELECT * from ITSV.EHRDC.dbo.tb_dc_examination_info;
PRINT '体检信息表完成' 
END;


BEGIN
-- 主索引
TRUNCATE TABLE TB_EMPI_INDEX_ROOT;
insert into TB_EMPI_INDEX_ROOT SELECT * from ITSV.EHRDC.dbo.tb_empi_index_root;
PRINT '主索引表完成' 
END;


BEGIN
--慢病防治主表 
TRUNCATE TABLE TB_DC_CHRONIC_INFO;
	insert into TB_DC_CHRONIC_INFO (guid	,
manageNum	,
orgCode	,
empiGuid	,
name	,
dateOfBirth	,
sexCode	,
sexName	,
phone	,
livePlaceDetailAddress	,
insuranceTypeCodeSystem	,
insuranceTypeCode	,
insuranceTypeName	,
smokingCodeSystem	,
smokingCode	,
smokingName	,
drinkingFrequencyCodeSystem	,
drinkingFrequencyCode	,
drinkingFrequencyName	,
eatingHabitsCodeSystem	,
eatingHabitsCode	,
eatingHabitsName	,
isLawSport	,
sportTypeCodeSystem	,
sportTypeCode	,
sportTypeName	,
sportFrequenceCodeSystem	,
sportFrequenceCode	,
sportFrequenceName	,
weeklyFrequence	,
sportTimes	,
restLifestyle	,
isRarelySport	,
isPsychotropicDrug	,
isHealthBloodPressure	,
isDyslipidemia	,
isOverweight	,
isCentralObesity	,
CTMCategoryCodeSystem	,
CTMCategoryCode	,
CTMCategoryName	,
height	,
weight	,
BMI	,
waistline	,
sbp	,
dbp	,
fastingBloodSugar	,
randomBloodSugar	,
twoHBloodSugarOGTT	,
cholesterol	,
highDensityLipoprotein	,
lowDensityLipoprotein	,
triglyceride	,
isHaveHealthRisks	,
healthRisksName	,
manageSortCodeSystem	,
manageSortCode	,
manageSortName	,
creatDate	,
registTime) SELECT guid	,
manageNum	,
orgCode	,
empiGuid	,
name	,
dateOfBirth	,
sexCode	,
sexName	,
phone	,
livePlaceDetailAddress	,
insuranceTypeCodeSystem	,
insuranceTypeCode	,
insuranceTypeName	,
smokingCodeSystem	,
smokingCode	,
smokingName	,
drinkingFrequencyCodeSystem	,
drinkingFrequencyCode	,
drinkingFrequencyName	,
eatingHabitsCodeSystem	,
eatingHabitsCode	,
eatingHabitsName	,
isLawSport	,
sportTypeCodeSystem	,
sportTypeCode	,
sportTypeName	,
sportFrequenceCodeSystem	,
sportFrequenceCode	,
sportFrequenceName	,
weeklyFrequence	,
sportTimes	,
restLifestyle	,
isRarelySport	,
isPsychotropicDrug	,
isHealthBloodPressure	,
isDyslipidemia	,
isOverweight	,
isCentralObesity	,
CTMCategoryCodeSystem	,
CTMCategoryCode	,
CTMCategoryName	,
height	,
weight	,
BMI	,
waistline	,
sbp	,
dbp	,
fastingBloodSugar	,
randomBloodSugar	,
twoHBloodSugarOGTT	,
cholesterol	,
highDensityLipoprotein	,
lowDensityLipoprotein	,
triglyceride	,
isHaveHealthRisks	,
healthRisksName	,
manageSortCodeSystem	,
manageSortCode	,
manageSortName	,
creatDate	,
registTime	 from ITSV.EHRDC.dbo.tb_dc_chronic_info;
PRINT '慢病防治主表完成' 
END;

BEGIN 
 -- 住院信息表
TRUNCATE TABLE TB_HIS_IP_MEDICAL_RECORD;
	insert into TB_HIS_IP_MEDICAL_RECORD SELECT * from ITSV.EHRDC.dbo.tb_his_ip_medical_record;
PRINT '住院信息表完成' 
END;

BEGIN
 --门诊就诊记录 
TRUNCATE TABLE TB_HIS_OP_MEDICAL_RECORD;
	insert into  TB_HIS_OP_MEDICAL_RECORD SELECT * from ITSV.EHRDC.dbo.tb_his_op_medical_record;

PRINT '门诊就诊记录表完成' 
END;

BEGIN-- 检验明细
	TRUNCATE TABLE TB_LIS_REPORT_INDICATOR;
	INSERT INTO TB_LIS_REPORT_INDICATOR (
		[GUID],
		[VISITSTRNO],
		[ORGCODE],
		[ORGNAME],
		[VISITTYPE],
		[REPORTNO],
		[INSITEMCODE],
		[ITEMCODESYSTEM],
		[ITEMCODE],
		[ITEMNAME],
		[RESULTVALUE],
		[RESULTUNIT],
		[RESULTFLAGCODESYSTEM],
		[RESULTFLAGCODE],
		[RESULTFLAGNAME],
		[REFQUALITY],
		[REFQUANTIFYLOWER],
		[REFQUANTIFYUPPER],
		[ORDER],
		[STATUS],
		[CREATEDATE],
		[ISCURRENT],
		[EMPIGUID] ,
		REPORTDATE
	) SELECT
	[GUID],
		[VISITSTRNO],
		[ORGCODE],
		[ORGNAME],
		[VISITTYPE],
		[REPORTNO],
		[INSITEMCODE],
		[ITEMCODESYSTEM],
		[ITEMCODE],
		[ITEMNAME],
		[RESULTVALUE],
		[RESULTUNIT],
		[RESULTFLAGCODESYSTEM],
		[RESULTFLAGCODE],
		[RESULTFLAGNAME],
		[REFQUALITY],
		[REFQUANTIFYLOWER],
		[REFQUANTIFYUPPER],
		[ORDER],
		[STATUS],
		[CREATEDATE],
		[ISCURRENT],
		[EMPIGUID] ,
		REPORTDATE
	FROM
	ITSV.EHRDC.dbo.tb_lis_report_indicator  ;
PRINT '检验明细表完成' END;

BEGIN 
 -- 体检用药
TRUNCATE TABLE TB_DC_EXAMINATION_MEDICATE;
insert into TB_DC_EXAMINATION_MEDICATE  SELECT * from ITSV.EHRDC.dbo.TB_DC_EXAMINATION_MEDICATE;
PRINT '体检用药表完成' 
END;
BEGIN
INSERT INTO [dbo].[QYYH] (
	[CZRYBM],
	[CZRYXM],
	[JMXM],
	[SJHM],
	[SFZH],
	[JJDZ],
	[SFJD],
	[SIGNORGID],
	[ARCHIVEUNITCODE],
	[ARCHIVEUNITNAME],
	[DISTRICTORGCODE],
	[DISTRICTORGNAME],
	[TERTIARYORGCODE],
	[TERTIARYORGNAME],
	[PRESENTADDRDIVISIONCODE],
	[PRESENTADDRPROVCODE],
	[PRESENTADDRPROVVALUE],
	[PRESENTADDRCITYCODE],
	[PRESENTADDRCITYVALUE],
	[PRESENTADDRDISTCODE],
	[PRESENTADDRTOWNSHIPCODE],
	[PRESENTADDRTOWNSHIPVALUE],
	[PRESENTADDRNEIGHBORHOODCODE],
	[PRESENTADDRNEIGHBORHOODVALUE],
	[SIGNSTATUS],
	[SIGNDATE],
	[CATEGORY_CODE],
	[CATEGORY_NAME],
	[SEX_CODE],
	[SEX_NAME] 
) SELECT
[CZRYBM],
[CZRYXM],
[JMXM],
[SJHM],
[SFZH],
[JJDZ],
[SFJD],
[SIGNORGID],
[ARCHIVEUNITCODE],
[ARCHIVEUNITNAME],
[DISTRICTORGCODE],
[DISTRICTORGNAME],
[TERTIARYORGCODE],
[TERTIARYORGNAME],
[PRESENTADDRDIVISIONCODE],
[PRESENTADDRPROVCODE],
[PRESENTADDRPROVVALUE],
[PRESENTADDRCITYCODE],
[PRESENTADDRCITYVALUE],
[PRESENTADDRDISTCODE],
[PRESENTADDRTOWNSHIPCODE],
[PRESENTADDRTOWNSHIPVALUE],
[PRESENTADDRNEIGHBORHOODCODE],
[PRESENTADDRNEIGHBORHOODVALUE],
[SIGNSTATUS],
[SIGNDATE],
CASE
		
		WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 0 
		AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 6 THEN
			'1' 
			WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > 6 
			AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 17 THEN
				'2' 
				WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > =18 
				AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) < 65 THEN
					'3' 
					WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 65 THEN
					'4' ELSE '5' 
				END AS CATEGORY_CODE,
			CASE
					
					WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 0 
					AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 6 THEN
						'儿童' 
						WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > 6 
						AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 17 THEN
							'学生' 
							WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > =18 
							AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) < 65 THEN
								'一般人群' 
								WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 65 THEN
								'老年人' ELSE '未分类' 
							END AS CATEGORY_NAME,
						CASE
								
								WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '1' THEN
								'1' 
								WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '0' THEN
								'2' ELSE '' 
							END AS SEX_CODE,
						CASE
								
								WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '1' THEN
								'男' 
								WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '0' THEN
								'女' ELSE '未知' 
							END AS SEX_NAME 
						FROM
							ITSV.EHRDC.dbo.QYYH
						WHERE
							SFZH NOT IN ( SELECT SFZH FROM QYYH );
						PRINT '签约信息表完成' 
					END;
					
													BEGIN
										WITH t15 AS (
							SELECT
								[CZRYBM],
								[CZRYXM],
								[JMXM],
								[SJHM],
								[SFZH],
								[JJDZ],
								[SFJD],
								[SIGNORGID],
								[ARCHIVEUNITCODE],
								[ARCHIVEUNITNAME],
								[DISTRICTORGCODE],
								[DISTRICTORGNAME],
								[TERTIARYORGCODE],
								[TERTIARYORGNAME],
								[PRESENTADDRDIVISIONCODE],
								[PRESENTADDRPROVCODE],
								[PRESENTADDRPROVVALUE],
								[PRESENTADDRCITYCODE],
								[PRESENTADDRCITYVALUE],
								[PRESENTADDRDISTCODE],
								[PRESENTADDRTOWNSHIPCODE],
								[PRESENTADDRTOWNSHIPVALUE],
								[PRESENTADDRNEIGHBORHOODCODE],
								[PRESENTADDRNEIGHBORHOODVALUE],
								[SIGNSTATUS],
								[SIGNDATE],
							CASE
									
									WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 0 
									AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 6 THEN
										'1' 
										WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > 6 
										AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 17 THEN
											'2' 
											WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > =18 
											AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) < 65 THEN
												'3' 
												WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 65 THEN
												'4' ELSE '5' 
											END AS CATEGORY_CODE,
										CASE
												
												WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 0 
												AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 6 THEN
													'儿童' 
													WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > 6 
													AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) <= 17 THEN
														'学生' 
														WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) > =18 
														AND dbo.FN_GETAGE ( SFZH, GETDATE( ) ) < 65 THEN
															'一般人群' 
															WHEN dbo.FN_GETAGE ( SFZH, GETDATE( ) ) >= 65 THEN
															'老年人' ELSE '未分类' 
														END AS CATEGORY_NAME,
													CASE
															
															WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '1' THEN
															'1' 
															WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '0' THEN
															'2' ELSE '' 
														END AS SEX_CODE,
													CASE
															
															WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '1' THEN
															'男' 
															WHEN SUBSTRING ( SFZH, 17, 1 ) % 2 = '0' THEN
															'女' ELSE '未知' 
														END AS SEX_NAME 
													FROM
														ITSV.EHRDC.dbo.QYYH
													WHERE
														SFZH IN ( SELECT SFZH FROM QYYH ) 
													)
												UPDATE QYYH 
												SET [CZRYBM] = t15.CZRYBM,
												[CZRYXM] = t15.CZRYXM,
												[JMXM] = t15.JMXM,
												[SJHM] = t15.SJHM,
												[SFZH] = t15.SFZH,
												[JJDZ] = t15.JJDZ,
												[SFJD] = t15.SFJD,
												[SIGNORGID] = t15.SIGNORGID,
												[ARCHIVEUNITCODE] = t15.ARCHIVEUNITCODE,
												[ARCHIVEUNITNAME] = t15.ARCHIVEUNITNAME,
												[DISTRICTORGCODE] = t15.DISTRICTORGCODE,
												[DISTRICTORGNAME] = t15.DISTRICTORGNAME,
												[TERTIARYORGCODE] = t15.TERTIARYORGCODE,
												[TERTIARYORGNAME] = t15.TERTIARYORGNAME,
												[PRESENTADDRDIVISIONCODE] = t15.PRESENTADDRDIVISIONCODE,
												[PRESENTADDRPROVCODE] = t15.PRESENTADDRPROVCODE,
												[PRESENTADDRPROVVALUE] = t15.PRESENTADDRPROVVALUE,
												[PRESENTADDRCITYCODE] = t15.PRESENTADDRCITYCODE,
												[PRESENTADDRCITYVALUE] = t15.PRESENTADDRCITYVALUE,
												[PRESENTADDRDISTCODE] = t15.PRESENTADDRDISTCODE,
												[PRESENTADDRTOWNSHIPCODE] = t15.PRESENTADDRTOWNSHIPCODE,
												[PRESENTADDRTOWNSHIPVALUE] = t15.PRESENTADDRTOWNSHIPVALUE,
												[PRESENTADDRNEIGHBORHOODCODE] = t15.PRESENTADDRNEIGHBORHOODCODE,
												[PRESENTADDRNEIGHBORHOODVALUE] = t15.PRESENTADDRNEIGHBORHOODVALUE,
												[SIGNSTATUS] = t15.SIGNSTATUS,
												[SIGNDATE] = t15.SIGNDATE,
												CATEGORY_CODE = t15.CATEGORY_CODE,
												CATEGORY_NAME = t15.CATEGORY_NAME,
												SEX_CODE = t15.SEX_CODE,
												SEX_NAME = t15.SEX_NAME 
										FROM 
										t15 
											WHERE
	QYYH.SFZH = t15.SFZH END;







BEGIN
 -- 检查报告表  
 TRUNCATE TABLE TB_LIS_REPORT;
insert into TB_LIS_REPORT SELECT * from ITSV.EHRDC.dbo.TB_LIS_REPORT;

PRINT '检查报告表完成' 
end;

BEGIN

 TRUNCATE TABLE TB_DC_CHRONIC_MAIN;
insert into TB_DC_CHRONIC_MAIN SELECT * from ITSV.EHRDC.dbo.TB_DC_CHRONIC_MAIN;
PRINT '门诊记录表完成' 
END;

BEGIN
 -- 门诊记录表完成

 TRUNCATE TABLE TB_HIS_DIAGNOSIS;
 insert into TB_HIS_DIAGNOSIS SELECT * from ITSV.EHRDC.dbo.TB_HIS_DIAGNOSIS;
PRINT '门诊记录表完成'
END;


BEGIN
 -- 门诊处方表

 TRUNCATE TABLE TB_HIS_OP_PERSCRIPTION;
 insert into TB_HIS_OP_PERSCRIPTION SELECT * from ITSV.EHRDC.dbo.TB_HIS_OP_PERSCRIPTION;
PRINT '门诊处方表完成' 
END;


BEGIN
 -- 检验报告明细表
  TRUNCATE TABLE TB_RIS_REPORT;
insert into TB_RIS_REPORT SELECT * from ITSV.EHRDC.dbo.TB_RIS_REPORT;
PRINT '检查报告明细表完成' 
END;
BEGIN
-- 高血压随访
  TRUNCATE TABLE TB_DC_HTN_VISIT;
insert into TB_DC_HTN_VISIT SELECT * from ITSV.EHRDC.dbo.TB_DC_HTN_VISIT;
 PRINT '高血压随访表完成' 
END;
BEGIN
update  HRASSOCIATIONINFO 
set MSG =(
SELECT 
VALUE
FROM 
TB_CODE
WHERE 
TABLETYPE='HrPersonBasicInfo'
AND
TARGETTABLE='HrAssociationInfo'
AND 
TARGETFIELD='history_of_disease' 
AND 
 CODE=HRASSOCIATIONINFO.CODE
)
WHERE HRASSOCIATIONINFO.ASSOCIATIONTYPE  like '%family_history_of%';
  PRINT '一对多表更新完成' ;
	END;
	
	
	-- 更新  时间 
	
	update  HRASSOCIATIONINFO 
set MSG =(
SELECT 
VALUE
FROM 
TB_CODE
WHERE 
TABLETYPE='HrPersonBasicInfo'
AND
TARGETTABLE='HrAssociationInfo'
AND 
TARGETFIELD='history_of_disease' 
AND 
 CODE=HRASSOCIATIONINFO.CODE
)
WHERE HRASSOCIATIONINFO.ASSOCIATIONTYPE  = '%history_of_disease%';

UPDATE  QYYH 
SET KEY_POPULATION= t100.A8
FROM
ITSV.EHRDC.dbo.report_qyyh t100 
WHERE QYYH.SFZH=t100.SFZH;
 PRINT ' 签约表人群分类更新完成' ;
 
 
 UPDATE  TB_DC_CHRONIC_INFO 
 SET REGISTTIME = t1.REGISTTIME
 
 FROM TB_DC_CHRONIC_MAIN t1 
 WHERE TB_DC_CHRONIC_INFO.MANAGENUM=t1.MANAGENUM
 AND TB_DC_CHRONIC_INFO.ORGCODE=t1.ORGCODE;
 
 
 BEGIN
	TRUNCATE TABLE T_HIS_DIAGNOSIS;
	-- 更新诊断疾病
	INSERT into T_HIS_DIAGNOSIS( IDCARD,DIAGNOSIS_CODE,DIAGNOSIS_NAME,DIAGNOSIS_DATE,DIAGNOSIS_TYPE
	)
	
	SELECT
	DISTINCT
IDCARDNO,
DIAGNOSISCODE,
diagnosisDesc,
DIAGNOSISDATE,
DIAGNOSISTYPE
FROM
(SELECT *,
ROW_NUMBER ( ) OVER ( partition BY IDCARDNO, DIAGNOSISCODE,diagnosisDesc ORDER BY DIAGNOSISDATE DESC ) t1
from 
(
SELECT  
 t1.IDCARDNO,t3.DIAGNOSISCODE,
 t3.diagnosisDesc,
 DIAGNOSISDATE,
 t3.DIAGNOSISTYPE
FROM 
TB_EMPI_INDEX_ROOT  T1 LEFT JOIN 
TB_HIS_OP_MEDICAL_RECORD T2 
on  t1.guid=t2.empiGuid
LEFT JOIN  TB_HIS_DIAGNOSIS T3 
ON T2.opVisitStrNo=t3.visitStrNo
AND T2.ORGCODE=T3.ORGCODE 
WHERE t3.DIAGNOSISCODE is not NULL
AND t3.diagnosisDesc is not null 
UNION 
SELECT 
t1.IDCARDNO,t3.DIAGNOSISCODE,
 t3.diagnosisDesc,
 DIAGNOSISDATE,
 t3.DIAGNOSISTYPE
FROM 
TB_EMPI_INDEX_ROOT  T1
LEFT JOIN 
TB_HIS_IP_MEDICAL_RECORD T2
ON T1.GUID =T2.EMPIGUID
LEFT JOIN 
TB_HIS_DIAGNOSIS T3 
ON T2.IPVISITSTRNO=t3.VISITSTRNO 
AND T2.ORGCODE=T3.ORGCODE 
WHERE t3.DIAGNOSISCODE is not NULL
AND t3.diagnosisDesc is not null ) a1 )a2 
WHERE a2.t1=1;
END;
	
	


TRUNCATE table  T_EHR_CATEGORY;
insert T_EHR_CATEGORY 
select idcard,code,name,GETDATE() date from (
select r.IDCARDNO as idcard,1 code,'高血压' name from  TB_DC_CHRONIC_MAIN  main
 inner join TB_EMPI_INDEX_ROOT r  on  main.EMPIGUID = r.GUID where VISITTYPECODE  like '%31%'
 union  all
select r.IDCARDNO,2,'糖尿病' from  TB_DC_CHRONIC_MAIN  main
 inner join TB_EMPI_INDEX_ROOT r  on  main.EMPIGUID = r.GUID where VISITTYPECODE  like '%33%') a
  group by idcard,code,name
 
 

 
END
go

