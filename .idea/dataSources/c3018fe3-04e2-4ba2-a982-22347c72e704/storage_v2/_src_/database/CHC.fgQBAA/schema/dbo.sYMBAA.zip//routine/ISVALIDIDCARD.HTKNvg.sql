
CREATE FUNCTION [DBO].[ISVALIDIDCARD] ( @IDCARDNO VARCHAR(50) )
    RETURNS BIT
AS
BEGIN


    DECLARE @LENGTH INT ,
        @LOOP INT ,
        @SUM INT
    DECLARE @SINGLECHAR CHAR


    SET @SUM = 0
    IF @IDCARDNO IS NULL
        OR @IDCARDNO = NULL
        OR LTRIM(RTRIM(@IDCARDNO)) = ''
        BEGIN
            RETURN 0
        END


    SET @LENGTH = LEN(@IDCARDNO)
    --判断位数
    IF @LENGTH < > 18
        AND @LENGTH < > 15
        BEGIN
            RETURN 0
        END
    IF @LENGTH = 18
        BEGIN
            IF ISNUMERIC(LEFT(@IDCARDNO, 17)) = 0
                BEGIN
                    RETURN 0
                END
            IF ISDATE(SUBSTRING(@IDCARDNO, 7, 4) + ' - '
                + SUBSTRING(@IDCARDNO, 11, 2) + ' - '
                + SUBSTRING(@IDCARDNO, 13, 2)) = 0
                BEGIN
                    RETURN 0
                END
            SET @LOOP = 17
            WHILE ( @LOOP >= 1 )
                BEGIN
                    SET @SUM = @SUM
                        + CONVERT(INT, REPLACE(SUBSTRING(@IDCARDNO, @LOOP,
                                                         1), '.', ''))
                                   * ( POWER(2, ( 18 - @LOOP )) % 11 )
                    SET @LOOP = @LOOP - 1
                END
            SET @LOOP = @SUM % 11
            IF @LOOP = 0
                BEGIN
                    SET @SINGLECHAR = '1'
                END
            ELSE
                IF @LOOP = 1
                    BEGIN
                        SET @SINGLECHAR = '0'
                    END
                ELSE
                    IF @LOOP = 2
                        BEGIN
                            SET @SINGLECHAR = 'X'
                        END
                    ELSE
                        BEGIN
                            SET @SINGLECHAR = CONVERT(VARCHAR(2), ( 12
                                - @LOOP ))
                        END
            IF LOWER(RIGHT(@IDCARDNO, 1)) < > LOWER(@SINGLECHAR)
                BEGIN
                    RETURN 0
                END
        END
    ELSE
        IF @LENGTH = 15
            BEGIN
                IF ISNUMERIC(@IDCARDNO) = 0
                    BEGIN
                        RETURN 0
                    END
                IF ISDATE('19' + SUBSTRING(@IDCARDNO, 7, 2) + ' - '
                    + SUBSTRING(@IDCARDNO, 9, 2) + ' - '
                    + SUBSTRING(@IDCARDNO, 11, 2)) = 0
                    BEGIN
                        RETURN 0
                    END
                IF LEFT(@IDCARDNO, 1)=0
                    BEGIN
                        RETURN 0
                    END
            END

    RETURN 1

END
go

