CREATE PROCEDURE [dbo].[T_ASSESS_INFO_ONE] (@IDCARD NVARCHAR(18),@ID int,@guid VARCHAR(36),@START_TIME datetime,@END_TIME datetime)
as
BEGIN

if OBJECT_ID('tempdb..#ASS_INFO') is not null
drop table #ASS_INFO;

CREATE TABLE [dbo].#ASS_INFO (
    [ID] int   ,
    [ID_CARD] varchar(20)  COLLATE Chinese_PRC_CI_AS,
    [AGE] int ,
    [AGE_FLOAT] decimal(5,1),
    [SEX_CODE] varchar(20) ,
    [SEX_NAME] nvarchar(50) COLLATE Chinese_PRC_CI_AS,
    [OCCUPATION_CODE] varchar(20) ,
    [OCCUPATION_NAME] nvarchar(100) COLLATE Chinese_PRC_CI_AS ,
    [HEIGHT] decimal(10,1) ,
    [WEIGHT] decimal(10,1) ,
    [BMI] decimal(10,1) ,
    [WAISTLINE] decimal(10,1) ,
    [HIPLINE] decimal(10,1) ,
    [DBP] int  ,
    [SBP] int  ,
    [DRINKING_FREQUENCY_CODE] varchar(50) COLLATE Chinese_PRC_CI_AS ,
    [DRINKING_FREQUENCY_NAME] varchar (200) COLLATE Chinese_PRC_CI_AS,
    [SMOKING_STATUS_CODE] varchar(50) ,
    [SMOKING_STATUS_NAME] varchar(200)COLLATE Chinese_PRC_CI_AS ,
    [HALOPHILIA_CODE] varchar(10) ,
    [HALOPHILIA_NAME] varchar(100)COLLATE Chinese_PRC_CI_AS ,
    [EATING_HABITS_CODE] varchar(20),
    [EATING_HABITS_NAME] varchar(100)COLLATE Chinese_PRC_CI_AS ,
    [SPORT_FREQUENCE] varchar(10) ,
    [EXERCISE_FREQUENCY_CODE] varchar(10),
    [EXERCISE_FREQUENCY_NAME] varchar(100)COLLATE Chinese_PRC_CI_AS,
    [IS_EXPOSURE] int ,
    [IS_EXPOSURE_RISK] int ,
    [FASTING_BLOOD_SUGAR] decimal(10,2) ,
    [RANDOM_BLOOD_SUGAR] decimal(10,2) ,
    [SERUM_LOW_DENSITY] decimal(10,2) ,
    [SERUM_HIGH_DENSITY] decimal(10,2) ,
    [TRIGLYCERIDE] decimal(10,2) ,
    [CHOLESTEROL_TOTAL] decimal(10,2) ,
    [URINE_PROTEIN] varchar(50) COLLATE Chinese_PRC_CI_AS ,
    [URINARY_ERYTHROCYTE] decimal(10,2) ,
    [SCR] decimal(10,2) ,
    [ACR] decimal(10,2),
    [HELICOBACTER_PYLORI] varchar(50) COLLATE Chinese_PRC_CI_AS,
    [GLYCOSYLATED_HEMOGLOBIN] decimal(10,2) ,
    [TCM_CONSTITUTION] varchar(100) COLLATE Chinese_PRC_CI_AS,
    [VISIT_MANAGE_CODE] varchar(20) COLLATE Chinese_PRC_CI_AS,
    [VISIT_MANAGE_NAME] varchar(100)COLLATE Chinese_PRC_CI_AS ,
    [CREATE_DATE] datetime2(7) ,
    [ASSESS_DATE] date ,
    [IS_DELETE] bit ,
    [ASSESS_DOC_ID] int ,
    [ASSESS_DOC_NAME] nvarchar(50)  ,
    [ASSESS_THIRD_NO] varchar(20) ,
    [REPORT_STATUS] int ,
    [ORG_CODE] varchar(50),
    [DRUG] nvarchar(4000),
    LIMB_EDEMA_FLAG varchar(20),
    PSYCHOLOGY_CODE VARCHAR(20),
    PSYCHOLOGY_NAME nvarchar(50),
    HR int,
    VISIT_NUM int ,
    EXAMINATION_NUM int ,
    CATEGORY_CODE varchar(20)COLLATE Chinese_PRC_CI_AS,
    CATEGORY_name varchar(10)COLLATE Chinese_PRC_CI_AS

    )
;
INSERT INTO #ASS_INFO (ID) VALUES(@ID);



-- 年龄   性别 职业代码
WITH a1 AS (
    SELECT
        VISITDATE,
        HEIGHT,
        WEIGHT,
        WAISTLINE,
        HIPLINE,
        SBP,
        DBP,
        SMOKINGSTATUSCODE,
        DRINKINGFREQUENCYCODE,
        NULL AS saltUptakeStatus,
        NULL AS EATINGHABITSCODE,
        sportFrequence,
        CASE
            WHEN ISLAWSPORT = '0' THEN '4'
            WHEN  ISLAWSPORT = '1' AND SPORTFREQUENCE >=7
                THEN '1'
            WHEN  ISLAWSPORT = '1' AND SPORTFREQUENCE <7
                AND SPORTFREQUENCE >0
                then   '2'
            ELSE '' END

             AS EXERCISEFREQUENCYCODE,
        null as HEARTRATE,
        1 type_info
    FROM
        TB_DC_DM_VISIT
    WHERE
            EMPIGUID = @guid
      AND VISITDATE BETWEEN @START_TIME
        AND @END_TIME UNION ALL
    SELECT
        VISITDATE,
        HEIGHT,
        WEIGHT,
        WAISTLINE,
        NULL,
        SBP,
        DBP,
        SMOKINGSTATUSCODE,
        DRINKINGFREQUENCYCODE,
        SALTUPTAKESTATUS,
        NULL AS EATINGHABITSCODE,
        sportFrequence,
        NULL AS EXERCISEFREQUENCYCODE,
        HEARTRATE,
        2
    FROM
        TB_DC_HTN_VISIT
    WHERE
            EMPIGUID = @guid
      AND VISITDATE BETWEEN @START_TIME
        AND @END_TIME UNION ALL
    SELECT
        EXAMINATIONDATE,
        HEIGHT,
        WEIGHT,

        WAISTLINE,
        HIPS,
        IIF ( LEFTSBP IS NOT NULL, LEFTSBP, RIGHTSBP ),
        IIF ( LEFTDBP IS NOT NULL, LEFTDBP, RIGHTDBP ),
        SMOKINGCODE,
        DRINKINGFREQUENCYCODE,
        NULL AS saltUptakeStatusCODE,
        EATINGHABITSCODE,
        NULL AS SPORTFREQUENCECODE,
        EXERCISEFREQUENCYCODE,
        HEARTRATE,
        3
    FROM
        TB_DC_EXAMINATION_INFO
    WHERE
            EMPIGUID = @guid
      AND EXAMINATIONDATE BETWEEN @START_TIME
        AND @END_TIME



),

     yf as (
         SELECT

             t2.XUEYA1 as SSY,
             t2. XUEYA2 as SZY,
             t2.INTERVIEWDATE  as VISITDATE
         from
             (SELECT
                  YCFID
              from
                  TB_PREGNANT_MAIN_INFO
              WHERE ZJHM= @idcard) t1 INNER JOIN
             TB_POSTPARTUM_VISIT_RECORD  t2
             ON t1.YCFID=t2.YCFID
         WHERE t2.INTERVIEWDATE BETWEEN @START_TIME
                   AND @END_TIME
     ),

     b1 AS (
         SELECT
             *
         FROM
             (
                 SELECT
                     fastingBloodGlucose1,
                     serumLowDensity,
                     serumHighDensity,
                     triglyceride,
                     cholesterolTotal,
                     scr,
                     glycosylatedHemoglobin,
                     urineProtein,
                     NULL as URBC,
                     ExaminationDate
                 FROM
                     TB_DC_EXAMINATION_INFO
                 WHERE
                         EMPIGUID = @guid
                   AND ExaminationDate BETWEEN @START_TIME
                     AND @END_TIME UNION ALL
                 SELECT
                     fastingBloodSugarValue AS fastingBloodGlucose1,
                     lowCholesterol AS serumLowDensity,
                     highCholesterol AS serumHighDensity,
                     triglycerides AS triglyceride,
                     cholesterol AS cholesterolTotal,
                     creatinine AS scr,
                     glycosylatedHemoglobin AS glycosylatedHemoglobin,
                     urineProtein,
                     NULL as URINE_PROTEIN,
                     visitDate
                 FROM
                     TB_DC_HTN_VISIT
                 WHERE
                         EMPIGUID = @guid
                   AND visitdate BETWEEN @START_TIME
                     AND @END_TIME UNION ALL
                 SELECT
                     FASTINGBLOODSUGARVALUE,
                     lowCholesterol,
                     highCholesterol,
                     triglycerides,
                     cholesterol,
                     NULL AS creatinine,
                     HBALC,
                     urineProtein,
                     NULL as URINE_PROTEIN,
                     visitDate
                 FROM
                     TB_DC_DM_VISIT
                 WHERE
                         EMPIGUID = @guid
                   AND VISITDATE BETWEEN @START_TIME
                     AND @END_TIME UNION ALL
                 SELECT
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='GLU') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='GLU') , RESULTVALUE, NULL ) AS fastingBloodGlucose1,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='LDL') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='LDL') , RESULTVALUE, NULL ) AS serumLowDensity,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='HDL') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='HDL') , RESULTVALUE, NULL ) as highCholesterol,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='TG') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='TG') , RESULTVALUE, NULL ) AS triglyceride,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='TC') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='TC') , RESULTVALUE, NULL ) AS cholesterolTotal,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='CRE') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='CRE') , RESULTVALUE, NULL ) AS scr,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='HbA1c') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='HbA1c') , RESULTVALUE, NULL ) AS glycosylatedHemoglobin,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='PRO') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='PRO') , RESULTVALUE, NULL ) AS urineProtein,
                     iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='URBC') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='URBC') , RESULTVALUE, NULL ) AS URINE_PROTEIN,

                     REPORTDATE AS ExaminationDate

                 FROM
                     (SELECT
                          ITEMCODE,
                          ITEMNAME,
                          RESULTVALUE,
                          REPORTDATE


                      FROM
                          TB_LIS_REPORT_INDICATOR
                      WHERE
                              EMPIGUID = @guid
                        and
                              reportNo in (

                              SELECT

                                  reportNo
                              from


                                  (SELECT
                                       OPVISITSTRNO,
                                       ORGCODE

                                   FROM
                                       TB_HIS_OP_MEDICAL_RECORD
                                   WHERE EMPIGUID=@guid
                                     and VISITTIME BETWEEN  @START_TIME
                                       AND @END_TIME
                                   union ALL

                                   SELECT
                                       IPVISITSTRNO,
                                       orgcode
                                   FROM
                                       TB_HIS_IP_MEDICAL_RECORD
                                   WHERE
                                           EMPIGUID=@guid
                                     and REGDATE
                                       BETWEEN  @START_TIME
                                       AND @END_TIME )swb1 INNER JOIN TB_LIS_REPORT swb2
                                                                      ON swb1.OPVISITSTRNO=swb2.VISITSTRNO
                                                                          and swb1.orgcode=swb2.orgcode )
                      UNION ALL

                      SELECT
                          YBSFDM,
                          JCZBMC,
                          JCZBJG,
                          BGRQ
                      FROM
                          TB_DC_EXAMINATION_LIS
                      WHERE
                              EMPIGUID = @guid
                        AND BGRQ  BETWEEN @START_TIME
                          AND @END_TIME


                     ) THESHY2
             ) s1
     )
        ,
     b2 AS (
         SELECT
             iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='RGLU') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='RGLU') , RESULTVALUE, NULL ) AS RANDOM_BLOOD_SUGAR,

             iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='ACR') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='ACR') , RESULTVALUE, NULL ) AS ACR,
             iif ( ITEMCODE in (SELECT SOURCE_ITEM_CODE from SOURCE_ITEM_CODE WHERE ITEM_CODE='HP') AND ITEMNAME in (SELECT  SOURCE_ITEM_NAME from SOURCE_ITEM_CODE WHERE ITEM_CODE='HP') , RESULTVALUE, NULL ) AS HELICOBACTER_PYLORI,
             REPORTDATE AS ExaminationDate
         FROM

             (SELECT
                  ITEMCODE,
                  ITEMNAME,
                  RESULTVALUE,
                  REPORTDATE


              FROM
                  TB_LIS_REPORT_INDICATOR
              WHERE
                      EMPIGUID = @guid
                and
                      reportNo in (

                      SELECT

                          reportNo
                      from


                          (SELECT
                               OPVISITSTRNO,
                               ORGCODE

                           FROM
                               TB_HIS_OP_MEDICAL_RECORD
                           WHERE EMPIGUID=@guid
                             and VISITTIME BETWEEN  @START_TIME
                               AND @END_TIME



                           union

                           SELECT
                               IPVISITSTRNO,
                               orgcode
                           FROM
                               TB_HIS_IP_MEDICAL_RECORD
                           WHERE
                                   EMPIGUID=@guid
                             and REGDATE
                               BETWEEN  @START_TIME
                               AND @END_TIME )swb1 INNER JOIN TB_LIS_REPORT swb2
                                                              ON swb1.OPVISITSTRNO=swb2.VISITSTRNO
                                                                  and swb1.orgcode=swb2.orgcode )


                 --UNION ALL

                 --SELECT
                 --YBSFDM,
                 --JCZBMC,
                 --JCZBJG,
                 --BGRQ
                 --FROM
                 -- TB_DC_EXAMINATION_LIS
                 --WHERE
                 --EMPIGUID = @guid
                 --AND BGRQ  BETWEEN @START_TIME
                 --AND @END_TIME


             ) THESHY1
         union all

         SELECT
             null,
             UACR ,
             null,
             visitDate
         FROM
             TB_DC_HTN_VISIT
         WHERE
                 EMPIGUID = @guid
           AND visitdate BETWEEN @START_TIME
             AND @END_TIME UNION ALL
         SELECT
             RANDOMBLOODSUGARVALUE,
             ACR,
             NULL,
             visitDate
         FROM
             TB_DC_DM_VISIT
         WHERE
                 EMPIGUID = @guid
           AND VISITDATE BETWEEN @START_TIME
             AND @END_TIME
     ),
	height  as 	 (
SELECT SG as height, TZ as WEIGHT,SCRQ from  TB_DM_EARLY_VISIT WHERE ZJHM=@idcard AND SCRQ BETWEEN @START_TIME AND @END_TIME and XGBZ=0
UNION ALL 
SELECT  height, WEIGHT, measure_time FROM TB_PATIENT_HEIGHT WHERE  personcard=@idcard AND  measure_time BETWEEN @START_TIME AND @END_TIME
 and del_flag=0


),
	
HIPLINE AS (
SELECT  hipratio as HIPLINE, measure_time as SCRQ  FROM TB_PATIENT_WAIST WHERE personcard =@IDCARD AND measure_time BETWEEN @START_TIME AND @END_TIME AND del_flag=0),

WAISTLINE AS (SELECT YW  as WAISTLINE  ,SCRQ from  TB_DM_EARLY_VISIT WHERE ZJHM=@idcard AND SCRQ BETWEEN @START_TIME AND @END_TIME and XGBZ=0
UNION ALL
SELECT waist ,measure_time FROM TB_PATIENT_WAIST WHERE personcard=@IDCARD AND measure_time BETWEEN @START_TIME AND @END_TIME and del_flag=0),
SSY AS (

SELECT SSY,SZY,SCRQ  FROM TB_HTN_EASILY_VISIT WHERE ZJHM=@IDCARD AND SCRQ BETWEEN @START_TIME AND  @END_TIME AND XGBZ=0
UNION ALL
SELECT PJSSY,PJSZY,SCRQ  FROM TB_DM_EARLY_VISIT WHERE ZJHM=@IDCARD AND SCRQ BETWEEN @START_TIME AND  @END_TIME AND XGBZ=0
UNION ALL
SELECT SSY,SZY,BGRQ  FROM TB_HTN_MEASUREMENT_RECORD WHERE ZJHM=@IDCARD AND BGRQ BETWEEN @START_TIME AND  @END_TIME AND XGBZ=0
UNION ALL
SELECT SSY,SZY,BGRQ  FROM TB_35_FIRSTBP WHERE ZJHM=@IDCARD AND BGRQ BETWEEN @START_TIME AND  @END_TIME AND XGBZ<>3 
UNION ALL
SELECT systolic,diastolic,measure_time  FROM TB_PATIENT_BLD_PRESSURE WHERE personcard=@IDCARD AND measure_time BETWEEN @START_TIME AND  @END_TIME AND del_flag=0
),

 GLU as (
 
 SELECT CAST (FPG as NUMERIC) as FPG, cast (SJXT as  NUMERIC  ) as SJXT ,SCRQ from  TB_DM_EARLY_VISIT WHERE ZJHM=@IDCARD AND SCRQ BETWEEN @START_TIME AND @END_TIME AND XGBZ=0 
 UNION ALL 
  SELECT GLU, NULL,SC_RQ from  TB_DM_SCREENING WHERE ZJHM=@IDCARD AND SC_RQ BETWEEN @START_TIME AND @END_TIME AND STATUS=0
	UNION ALL 
	
	SELECT  (CASE 
	WHEN glu_type=1 THEN cast ( lis_item_result as NUMERIC ) 
	ELSE null END ) as fpg, (CASE 
	WHEN glu_type=3 THEN cast (lis_item_result as NUMERIC ) 
	ELSE null END  ) as SJXT

,measure_time FROM TB_PATIENT_BLD_GLUCOSE WHERE personcard=@IDCARD AND measure_time BETWEEN @START_TIME AND @END_TIME AND del_flag=0
and ISNUMERIC(lis_item_result)=1
 )

UPDATE  #ASS_INFO
SET AGE= (SELECT  dbo.FN_GETAGE( SFZH, @END_TIME ) FROM QYYH  WHERE SFZH = @IDCARD),
    AGE_FLOAT= (SELECT  dbo.CalculateAgeFromIDCard( SFZH) FROM QYYH  WHERE SFZH = @IDCARD),
    SEX_CODE =(SELECT SEX_CODE FROM QYYH  WHERE SFZH = @IDCARD),
    SEX_NAME=(SELECT SEX_NAME FROM QYYH  WHERE SFZH = @IDCARD),
    OCCUPATION_CODE=  (SELECT ISNULL( Occupation,'') as OCCUPATION_CODE   FROM HRPERSONBASICINFO WHERE ARCHIVENUM =@IDCARD),
    IS_EXPOSURE=(SELECT TOP 1 0 AS IS_EXPOSURE FROM HrPersonBasicInfo WHERE IdCard =@IDCARD),
    IS_EXPOSURE_RISK=	(SELECT TOP 1  0 AS IS_EXPOSURE_RISK FROM HrPersonBasicInfo WHERE ArchiveNum = @IDCARD ),
    VISIT_MANAGE_CODE= (SELECT TOP 1 	ISNULL(VISITTYPECODE,-1 )  as VISIT_MANAGE_CODE  FROM TB_DC_CHRONIC_MAIN  WHERE EMPIGUID = @guid AND VISITTYPEVALUE  IS NOT NULL AND VISITTYPECODE IS NOT NULL  AND VISITTYPECODE !=''	ORDER BY REGISTTIME DESC),
    VISIT_MANAGE_NAME=(SELECT TOP 1 	ISNULL(VISITTYPEVALUE,-1 )  as VISIT_MANAGE_NAME  FROM TB_DC_CHRONIC_MAIN  WHERE EMPIGUID = @guid AND VISITTYPEVALUE  IS NOT NULL AND VISITTYPECODE IS NOT NULL  AND VISITTYPEVALUE !=''	ORDER BY REGISTTIME DESC),
    HEIGHT=
    (
SELECT TOP 1

    ISNULL (HEIGHT,-1.0)AS  HEIGHT

FROM
  ( SELECT  height , VISITDATE FROM  a1 where ISNUMERIC(HEIGHT) = 1  and ISNUMERIC(WEIGHT)=1
	
	 UNION all 
	 SELECT height, SCRQ  from HEIGHT where ISNUMERIC(WEIGHT) = 1 and ISNUMERIC(HEIGHT)=1 ) as b1 

ORDER BY
    VISITDATE DESC
    ) ,
    WEIGHT=
    (
SELECT TOP 1


    ISNULL (WEIGHT,-1.0) AS WEIGHT

FROM
  ( SELECT  WEIGHT , VISITDATE FROM  a1 WHERE  ISNUMERIC(WEIGHT) = 1 and ISNUMERIC(HEIGHT)=1
	
	 UNION all 
	 SELECT WEIGHT, SCRQ  from height  WHERE  ISNUMERIC(WEIGHT) = 1 and ISNUMERIC(HEIGHT)=1 ) as b1 



ORDER BY
    VISITDATE DESC
    )

        ,
    WAISTLINE= ( SELECT TOP 1   ISNULL (WAISTLINE,-1.0) FROM  ( SELECT  WAISTLINE , VISITDATE FROM  a1 WHERE ISNUMERIC(WAISTLINE) = 1
	
	 UNION all 
	 SELECT WAISTLINE, SCRQ  from WAISTLINE) as b1  WHERE  ISNUMERIC(WAISTLINE) = 1 ORDER BY VISITDATE DESC ) ,
    HIPLINE =( SELECT TOP 1  isnull(HIPLINE,-1.0) FROM  ( SELECT  HIPLINE , VISITDATE FROM   a1 WHERE ISNUMERIC(HIPLINE) = 1 
	 
	 UNION all 
	 SELECT HIPLINE, SCRQ  from HIPLINE WHERE ISNUMERIC(HIPLINE) = 1 ) as b1   WHERE  HIPLINE!=0 ORDER BY VISITDATE DESC  ) ,
    SBP=( SELECT TOP 1 SBP
FROM (
    SELECT SBP, VISITDATE
    FROM a1
    WHERE SBP IS NOT NULL AND ISNUMERIC(SBP) = 1 AND ISNUMERIC(DBP)=1
    UNION ALL
    SELECT SBP, VISITDATE
    FROM yf
    WHERE SBP IS NOT NULL AND ISNUMERIC(SBP) = 1 AND ISNUMERIC(DBP)=1
		 UNION ALL
    SELECT SSY, SCRQ
    FROM ssy
    WHERE ssy IS NOT NULL AND ISNUMERIC(ssy) = 1 AND  ISNUMERIC(SZY)=1
    ) AS combined
ORDER BY VISITDATE DESC
    ),
    DBP=IIF((  SELECT TOP 1 DBP
FROM (
    SELECT DBP, VISITDATE
    FROM a1
    WHERE DBP IS NOT NULL AND ISNUMERIC(DBP) = 1 AND ISNUMERIC(SBP) = 1
    UNION ALL
    SELECT DBP, VISITDATE
    FROM yf
    WHERE DBP IS NOT NULL AND ISNUMERIC(DBP) = 1 AND ISNUMERIC(SBP) = 1
		UNION ALL
		  SELECT szy, SCRQ
    FROM SSY
    WHERE szy IS NOT NULL AND ISNUMERIC(szy) = 1 AND ISNUMERIC(ssy)=1
    ) AS combined
ORDER BY VISITDATE DESC) IS NULL ,-1 ,(  SELECT TOP 1 DBP
FROM (
    SELECT DBP, VISITDATE
    FROM a1
    WHERE DBP IS NOT NULL AND ISNUMERIC(DBP) = 1
    UNION ALL
    SELECT DBP, VISITDATE
    FROM yf
    WHERE DBP IS NOT NULL AND ISNUMERIC(DBP) = 1
		UNION ALL
		  SELECT szy, SCRQ
    FROM SSY
    WHERE szy IS NOT NULL AND ISNUMERIC(szy) = 1 AND ISNUMERIC(ssy)=1
    ) AS combined
ORDER BY VISITDATE DESC)),
    HR=(SELECT  TOP 1 HEARTRATE   from a1 WHERE ISNUMERIC(HEARTRATE)=1 and HEARTRATE is not null ORDER BY VISITDATE DESC),

    SMOKING_STATUS_CODE=( SELECT TOP 1 SMOKINGSTATUSCODE as SMOKING_STATUS_CODE FROM a1 WHERE SMOKINGSTATUSCODE IS NOT NULL  AND SMOKINGSTATUSCODE !=''  ORDER BY VISITDATE DESC ) ,
    DRINKING_FREQUENCY_CODE=( SELECT TOP 1 DRINKINGFREQUENCYCODE as  DRINKING_FREQUENCY_CODE FROM a1 WHERE DRINKINGFREQUENCYCODE IS NOT NULL AND DRINKINGFREQUENCYCODE !='' ORDER BY VISITDATE DESC ),
    HALOPHILIA_CODE=( SELECT TOP 1 saltUptakeStatus as HALOPHILIA_CODE FROM a1 WHERE saltUptakeStatus IS NOT NULL AND saltUptakeStatus !='' ORDER BY VISITDATE DESC ),
    EATING_HABITS_CODE=( SELECT TOP 1 EATINGHABITSCODE  as  EATING_HABITS_CODE FROM a1 WHERE EATINGHABITSCODE IS NOT NULL AND EATINGHABITSCODE !='' ORDER BY VISITDATE DESC ) ,
    SPORT_FREQUENCE=( SELECT TOP 1 sportFrequence as SPORT_FREQUENCE  FROM a1 WHERE sportFrequence IS NOT NULL AND sportFrequence !='' ORDER BY VISITDATE DESC ) ,
    EXERCISE_FREQUENCY_CODE=( SELECT TOP 1 EXERCISEFREQUENCYCODE  as EXERCISE_FREQUENCY_CODE  FROM a1 WHERE EXERCISEFREQUENCYCODE IS NOT NULL AND EXERCISEFREQUENCYCODE !='' ORDER BY VISITDATE DESC )   ,

    FASTING_BLOOD_SUGAR=( SELECT TOP 1  iif(ISNUMERIC(fastingBloodGlucose1)=1,convert(DECIMAL(10,2),fastingBloodGlucose1),-1.00) as FASTING_BLOOD_SUGAR  FROM(SELECT fastingBloodGlucose1,ExaminationDate FROM  b1  where  ISNUMERIC(fastingBloodGlucose1)=1 UNION all SELECT FPG, SCRQ FROM  GLU WHERE ISNUMERIC(FPG)=1) as b1  ORDER BY ExaminationDate DESC ),
    SERUM_LOW_DENSITY=	( SELECT TOP 1 iif(ISNUMERIC(serumLowDensity)=1 ,convert(DECIMAL(10,2),serumLowDensity),-1.00) as SERUM_LOW_DENSITY  FROM b1 WHERE serumLowDensity IS NOT NULL AND serumLowDensity != '' ORDER BY ExaminationDate DESC ) ,
    SERUM_HIGH_DENSITY=	( SELECT TOP 1 iif(ISNUMERIC(serumHighDensity)=1 ,convert(DECIMAL(10,2),serumHighDensity),-1.00)as SERUM_HIGH_DENSITY FROM b1 WHERE serumHighDensity IS NOT NULL AND serumHighDensity != '' ORDER BY ExaminationDate DESC ),
    TRIGLYCERIDE=	( SELECT TOP 1 iif(ISNUMERIC(triglyceride)=1 ,convert(DECIMAL(10,2),triglyceride),-1.00) as TRIGLYCERIDE FROM b1 WHERE triglyceride IS NOT NULL AND triglyceride != '' ORDER BY ExaminationDate DESC ) ,
    CHOLESTEROL_TOTAL=	( SELECT TOP 1 iif(ISNUMERIC(cholesterolTotal)=1 ,convert(DECIMAL(10,2),cholesterolTotal),-1.00) as CHOLESTEROL_TOTAL FROM b1 WHERE cholesterolTotal IS NOT NULL AND cholesterolTotal != '' ORDER BY ExaminationDate DESC ) ,
    SCR=	( SELECT TOP 1 iif(ISNUMERIC(scr)=1 ,convert(DECIMAL(10,1),scr),-1.00)   as SCR FROM b1 WHERE scr IS NOT NULL AND scr != '' ORDER BY ExaminationDate DESC ) ,
    GLYCOSYLATED_HEMOGLOBIN=	( SELECT TOP 1 iif(ISNUMERIC(glycosylatedHemoglobin)=1 ,convert(DECIMAL(10,2),glycosylatedHemoglobin),-1.00) as GLYCOSYLATED_HEMOGLOBIN FROM b1 WHERE glycosylatedHemoglobin IS NOT NULL AND glycosylatedHemoglobin != '' ORDER BY ExaminationDate DESC ) ,
    URINE_PROTEIN=( SELECT TOP 1  urineProtein as URINE_PROTEIN FROM b1 WHERE urineProtein IS NOT NULL AND urineProtein != '' ORDER BY ExaminationDate DESC )  ,
    RANDOM_BLOOD_SUGAR=( SELECT TOP 1 iif(ISNUMERIC(RANDOM_BLOOD_SUGAR)=1 ,convert(DECIMAL(10,2),RANDOM_BLOOD_SUGAR),-1.00)  as RANDOM_BLOOD_SUGAR FROM (SELECT RANDOM_BLOOD_SUGAR,ExaminationDate FROM  b1  WHERE ISNUMERIC(RANDOM_BLOOD_SUGAR)=1 UNION all SELECT SJXT, SCRQ FROM  GLU  WHERE ISNUMERIC(SJXT)=1) as b2   ORDER BY ExaminationDate DESC ) ,
    URINARY_ERYTHROCYTE=( SELECT TOP 1 ISNULL(TRY_CAST(URBC AS DECIMAL(10, 2)),-1.00) as URINARY_ERYTHROCYTE FROM b1 WHERE URBC IS NOT NULL AND URBC != '' ORDER BY ExaminationDate DESC ),
    ACR=	( SELECT TOP 1 iif(ISNUMERIC(ACR)=1 ,convert(DECIMAL(10,2),ACR),-1.00) FROM b2 WHERE ACR IS NOT NULL AND ACR != '' ORDER BY ExaminationDate DESC ) ,
    HELICOBACTER_PYLORI=	( SELECT TOP 1 HELICOBACTER_PYLORI FROM b2 WHERE HELICOBACTER_PYLORI IS NOT NULL AND HELICOBACTER_PYLORI != '' ORDER BY ExaminationDate DESC ) ,
    [ID_CARD]=@IDCARD,
    TCM_CONSTITUTION=ISNULL((
    SELECT  TOP 1  MEDICINE_NAME from
    TB_DC_MEDICIANE
    WHERE   IDCARD= @IDCARD
    ORDER BY FROM_DATE DESC
    ), ' '),
    LIMB_EDEMA_FLAG = (select max(flag) from (
    select top 1 IIF(LIMBEDEMACODE<>1,1,0) flag from [TB_DC_EXAMINATION_INFO] where EMPIGUID =@guid order by EXAMINATIONDATE desc
    union
    select top 1 IIF(SYMPTOMCODE like 12,1,0) flag from TB_DC_HTN_VISIT where EMPIGUID = @guid order by VISITDATE desc
    union
    select top 1 IIF(CLINICALSYMPTOMSCODE like 8,1,0) flag from TB_DC_DM_VISIT where EMPIGUID = @guid order by VISITDATE desc
    ) a),
    VISIT_NUM=(
SELECT
    COUNT(visitdate)
FROM

    (SELECT visitdate from TB_DC_DM_VISIT  WHERE EMPIGUID=@guid
    AND visitdate BETWEEN @START_TIME
    AND @END_TIME
    UNION  SELECT visitdate from TB_DC_HTN_VISIT WHERE EMPIGUID=@guid
    AND visitdate BETWEEN @START_TIME
    AND @END_TIME ) k1
    ),

    EXAMINATION_NUM=(
SELECT
    COUNT(GUID)
FROM
    TB_DC_EXAMINATION_INFO
WHERE
    EMPIGUID = @guid
  AND ExaminationDate BETWEEN @START_TIME
  AND @END_TIME
    ),

    CATEGORY_CODE=(SELECT CATEGORY_CODE from QYYH WHERE SFZH=@idcard ),
    CATEGORY_name=(SELECT CATEGORY_name from QYYH WHERE SFZH=@idcard ),
    PSYCHOLOGY_CODE=
                                                      (SELECT
    top 1 PSYCHOLOGYSTATUSCODE
from
    (  SELECT PSYCHOLOGYSTATUSCODE ,visitdate from TB_DC_DM_VISIT  WHERE EMPIGUID=@guid
    AND visitdate BETWEEN @START_TIME
    AND @END_TIME
    UNION all SELECT PSYCHOLOGYSTATUS ,visitdate from TB_DC_HTN_VISIT WHERE EMPIGUID=@guid
    AND visitdate BETWEEN @START_TIME
    AND @END_TIME ) b1
WHERE  PSYCHOLOGYSTATUSCODE !=''
  and PSYCHOLOGYSTATUSCODE is not null
ORDER BY visitdate  DESC
    ),
    PSYCHOLOGY_NAME = (
SELECT
    top 1  case PSYCHOLOGYSTATUSCODE

    WHEN '1'  THEN  '良好'
    WHEN '2'  THEN  '一般'
    WHEN '3'  THEN  '差'
    WHEN '4'  THEN '其他' ELSE '' end  PSYCHOLOGY_NAME

from
    (  SELECT PSYCHOLOGYSTATUSCODE ,visitdate from TB_DC_DM_VISIT  WHERE EMPIGUID=@guid
    AND visitdate BETWEEN @START_TIME
    AND @END_TIME
    UNION all SELECT PSYCHOLOGYSTATUS ,visitdate from TB_DC_HTN_VISIT WHERE EMPIGUID=@guid
    AND visitdate BETWEEN @START_TIME
    AND @END_TIME ) b1
WHERE  PSYCHOLOGYSTATUSCODE !=''
  and PSYCHOLOGYSTATUSCODE is not null
ORDER BY visitdate  DESC
    )



WHERE ID=@id



UPDATE #ASS_INFO
SET
    DRINKING_FREQUENCY_NAME=( SELECT
                                  CASE  DRINKING_FREQUENCY_CODE
                                      WHEN '1'  THEN  '从不'
                                      WHEN '2'  THEN  '偶尔'
                                      WHEN '3'  THEN  '经常'
                                      WHEN '4'  THEN  '每天'

                                      ELSE ''
                                      END
                              FROM #ASS_INFO ),
    SMOKING_STATUS_NAME=(

        SELECT
            CASE  SMOKING_STATUS_CODE
                WHEN '1'  THEN  '现在每天吸'
                WHEN '2'  THEN  '现在吸，但不是每天吸'
                WHEN '3'  THEN  '过去吸，现在不吸'
                WHEN '4'  THEN '从不吸'

                ELSE ''
                END
        FROM #ASS_INFO

    )

        ,
    HALOPHILIA_NAME=(

        SELECT
            CASE  HALOPHILIA_CODE
                WHEN '1'  THEN  '轻'
                WHEN '2'  THEN  '中'
                WHEN '3'  THEN  '重'


                ELSE ''
                END
        FROM #ASS_INFO

    )
        ,
    EATING_HABITS_NAME=(

        SELECT
            CASE  EATING_HABITS_CODE
                WHEN '1'  THEN  '荤素均衡 '
                WHEN '2'  THEN  '荤食为主'
                WHEN '3'  THEN  '素食为主'
                WHEN '4'  THEN  '嗜盐'
                WHEN '5'  THEN  '嗜油'
                WHEN '6'  THEN  '嗜糖'
                ELSE ''
                END
        FROM #ASS_INFO

    )

        ,
    EXERCISE_FREQUENCY_NAME=(

        SELECT
            CASE  EXERCISE_FREQUENCY_CODE
                WHEN '1'  THEN  '每天 '
                WHEN '2'  THEN  '每周一次以上'
                WHEN '3'  THEN  '偶尔'
                WHEN '4'  THEN  '不运动'

                ELSE ''
                END
        FROM #ASS_INFO

    ),
    OCCUPATION_NAME= (
        SELECT  top 1 TB_CODE.[value]  FROM  (SELECT OCCUPATION_CODE FROM  #ASS_INFO  WHERE ID= @ID ) T1 INNER JOIN
                                             TB_CODE	ON T1.OCCUPATION_CODE=TB_CODE.code
        WHERE targetField='Occupation'
          and targetTable='HrPersonBasicInfo'

    ),

    BMI=(SELECT   iif(HEIGHT is null ,null ,convert(decimal(10,1),WEIGHT/HEIGHT/HEIGHT*10000)) FROM #ASS_INFO  WHERE ID= @ID AND WEIGHT is not null and  HEIGHT is not null),
    DRUG=

        (SELECT
             STUFF((
                 SELECT ', ' + t3.drug_name
                 FROM
                     (SELECT
                          CASE t2.DRUG_TYPE
                              WHEN '1' THEN '高血压用药'
                              when '2' THEN '糖尿病用药'
                              ELSE NULL
                              END AS drug_name
                      FROM

                          (SELECT
                               s1.*
                           FROM
                               (
                                   SELECT
                                       s2.DRUGNAME AS MSG_name

                                   FROM
                                       ( SELECT * FROM TB_DC_EXAMINATION_INFO WHERE EMPIGUID = @guid) s1
                                           INNER JOIN TB_DC_EXAMINATION_MEDICATE s2 ON s1.EXAMINATIONID= s2.EXAMINATIONID
                                           AND s1.ORGCODE= s2.ORGCODE
                                   UNION ALL
                                   SELECT DRUGNAME FROM [dbo].[TB_DC_HTN_USEDRUG]  d
                                       inner join TB_DC_HTN_VISIT  t ON  d.VISITID = t.CARDID and d.ORGCODE=t.ORGCODE
                                   where t.EMPIGUID =@guid  and visitDate BETWEEN  @START_TIME
                                     AND @END_TIME

                                   union all

                                   SELECT DRUGNAME FROM [dbo].[TB_DC_DM_USEDRUG]  d
                                       inner join TB_DC_DM_VISIT  t ON  d.VISITID = t.CARDID and d.ORGCODE=t.ORGCODE
                                   where t.EMPIGUID =@guid  and visitDate BETWEEN  @START_TIME
                                     AND @END_TIME


                                   UNION ALL
                                   SELECT
                                       itemName AS MSG_name
                                   FROM
                                       (
                                       SELECT

                                       t2.itemName,

                                       ROW_NUMBER ( ) OVER ( partition BY t2.itemName,t2.itemCode ORDER BY t2.RXDATE DESC ) b
                                       FROM
                                       ( SELECT * FROM TB_HIS_OP_MEDICAL_RECORD WHERE EMPIGUID = @guid ) t1
                                       INNER JOIN TB_HIS_OP_PERSCRIPTION t2 ON t1.OPVISITSTRNO= t2.OPVISITSTRNO
                                       AND t1.ORGCODE= t2.ORGCODE
                                       WHERE
                                       t2.RXDATE BETWEEN @START_TIME
                                       AND @END_TIME
                                       ) b11
                                   WHERE
                                       b11.b= 1
                               ) s1
                           WHERE
                               s1.MSG_name IS NOT NULL
                             AND s1.MSG_name != ''

                          ) t1
                              INNER  JOIN
                          t_drug  t2
                          ON t1.MSG_NAME=t2.DRUG_NAME
                      GROUP BY
                          t2.DRUG_TYPE) t3
                 GROUP BY t3.drug_name
                 FOR XML PATH('')
                 ), 1, 2, '') AS ConcatenatedDrugs)
WHERE ID=@ID






SELECT * FROM  #ASS_INFO














END
go

