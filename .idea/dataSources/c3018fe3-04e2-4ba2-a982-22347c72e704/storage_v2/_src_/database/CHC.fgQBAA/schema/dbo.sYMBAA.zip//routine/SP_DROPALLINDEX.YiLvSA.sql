
CREATE PROCEDURE [DBO].[SP_DROPALLINDEX] @TABNAME NVARCHAR(150) -- 需要删除统计或索引的表

AS

BEGIN

    DECLARE @DROP_IDX_STRING NVARCHAR(4000) -- 存放动态组织而成的DROPS  INDEX/STATS 语法

    SET NOCOUNT ON

    --  CHECK TABLE

    IF NOT EXISTS(SELECT 1

                  FROM INFORMATION_SCHEMA.TABLES

                  WHERE TABLE_TYPE = 'BASE TABLE'
                    AND TABLE_NAME = @TABNAME)
        BEGIN

            RAISERROR (N'------当前表：''%S'' 不存在!',16, 1, @TABNAME)

            RETURN (1)

        END


    SET @TABNAME = OBJECT_ID(@TABNAME)

    IF EXISTS(SELECT 1

              FROM SYSINDEXES

              WHERE ID = @TABNAME
                AND INDID BETWEEN 1 AND 254

                AND STATUS IN (96, 10485856, 8388704))
        BEGIN

            SELECT @DROP_IDX_STRING = ISNULL(@DROP_IDX_STRING + ';', '')
                + ('DROP STATISTICS ' + OBJECT_NAME(@TABNAME) + '.' + NAME)

            FROM SYSINDEXES

            WHERE ID = @TABNAME
              AND INDID BETWEEN 1 AND 254

              AND STATUS IN (96, 10485856, 8388704)

        END

    IF LEN(@DROP_IDX_STRING) > 0
        BEGIN

            PRINT N'------统计删除列表------'

            PRINT @DROP_IDX_STRING + ';'

            EXECUTE (@DROP_IDX_STRING+';')

            PRINT N'------统计删除结束------'

        END

    IF EXISTS(SELECT 1
              FROM SYSINDEXES

              WHERE ID = @TABNAME
                AND INDID BETWEEN 1 AND 254

                AND STATUS NOT IN (96, 10485856, 8388704))
        BEGIN

            SET @DROP_IDX_STRING = NULL

            SELECT @DROP_IDX_STRING = ISNULL(@DROP_IDX_STRING + ';' + CHAR(13) + CHAR(10), '')
                + ('DROP INDEX ' + OBJECT_NAME(@TABNAME) + '.' + NAME)

            FROM SYSINDEXES

            WHERE ID = @TABNAME
              AND INDID BETWEEN 1 AND 254
              AND NAME NOT LIKE 'IDX#%'
              AND STATUS NOT IN (96, 10485856, 8388704)

              AND OBJECTPROPERTY(OBJECT_ID(NAME), 'ISCONSTRAINT') IS NULL--过程不处理CONSTRAINTS

        END

    PRINT N'------索引删除列表------'

    PRINT (@DROP_IDX_STRING + ';')

    EXEC ( @DROP_IDX_STRING+';')

    PRINT ('......' + CHAR(13) + CHAR(10) + '......')

    PRINT N'------索引删除结束------'

END
go

