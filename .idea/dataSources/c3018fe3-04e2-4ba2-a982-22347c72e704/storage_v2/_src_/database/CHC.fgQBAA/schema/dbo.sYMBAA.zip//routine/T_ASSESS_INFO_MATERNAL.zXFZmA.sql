CREATE PROCEDURE [dbo].[T_ASSESS_INFO_MATERNAL]
(@IDCARD NVARCHAR(18),@ID int,@guid VARCHAR(36),@START_TIME datetime,@END_TIME datetime)
as 
BEGIN


					 
					if OBJECT_ID('tempdb..#ASSESS_INFO_MATERNAL') is not null
    drop table #ASSESS_INFO_MATERNAL;
		
 CREATE TABLE [dbo].#ASSESS_INFO_MATERNAL (
 
 
  [ASSESS_ID] int  ,
  [LMP] date ,
  [gestational_weeks] nvarchar(2) COLLATE Chinese_PRC_CI_AS,
  [Delivery_date] date ,
  [postpartum_Health] nvarchar(255) COLLATE Chinese_PRC_CI_AS ,
  [postpartum_psychology] nvarchar(255) COLLATE Chinese_PRC_CI_AS ,
  [postpartum_SBP] nvarchar(3) COLLATE Chinese_PRC_CI_AS ,
  [postpartum_DBP] nvarchar(3) COLLATE Chinese_PRC_CI_AS ,
  [postpartum_milk_left] nvarchar(10) COLLATE Chinese_PRC_CI_AS ,
  [postpartum_milk_right] nvarchar(10) COLLATE Chinese_PRC_CI_AS ,
  [postpartum_lochia] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
  [postpartum_uterus] nvarchar(255) COLLATE Chinese_PRC_CI_AS 
 
  );
	
	-- 先检查是否有符合条件的数据
    DECLARE @HasData BIT;
    SELECT @HasData = CASE WHEN EXISTS (
        SELECT 1 FROM TB_PREGNANT_MAIN_INFO
        WHERE ZJHM = @IDCARD
        AND JCRQ BETWEEN @START_TIME AND @END_TIME
    ) THEN 1 ELSE 0 END;

    -- 如果没有数据，直接返回空表
    IF @HasData = 0
    BEGIN
        SELECT * FROM #ASSESS_INFO_MATERNAL WHERE 1 = 0;
        RETURN;
    END
	
	iNSERT INTO #ASSESS_INFO_MATERNAL (ASSESS_ID) VALUES(@ID);
	
	WITH t1 as (
    SELECT
        t1.MCYJ as gestational_weeks,
        t1.JCRQ as JCRQ,
        CASE WHEN t3.FMRQ IS NOT NULL THEN t3.FMRQ
             ELSE t2.FMRQ END AS Delivery_date,
        t2.JIANKANGINFO as postpartum_Health,
        t2.XINLIINFO  as postpartum_psychology,
        t2.XUEYA1 as postpartum_SBP,
        t2.XUEYA2 as postpartum_DBP,
        t2.RUZHI as postpartum_milk_left,
        t2.YRUZHI as postpartum_milk_right,
        t2.ELOU as postpartum_lochia,
        t2.ZIGONG as postpartum_uterus

    FROM

        (SELECT YCFID,MCYJ,JCRQ

         from
             TB_PREGNANT_MAIN_INFO WHERE ZJHM=@idcard and

             JCRQ BETWEEN @START_TIME and
                 @END_TIME) t1 LEFT JOIN
        TB_POSTPARTUM_VISIT_RECORD  t2
        ON t1.YCFID=t2.YCFID
                               LEFT JOIN TB_CHILDBIRTH_RECORD t3
                                         ON t1.YCFID = t3.YCFID
)
		
	UPDATE 		#ASSESS_INFO_MATERNAL
	SET 
	LMP =(SELECT top 1  gestational_weeks FROM  t1  ORDER BY  JCRQ desc),
	gestational_weeks=(DATEDIFF(week,(SELECT top 1 gestational_weeks from t1  ORDER BY  JCRQ desc ) , GETDATE())),
  Delivery_date = (SELECT top 1   Delivery_date FROM  t1  ORDER BY  JCRQ desc),
	postpartum_Health=(SELECT top 1   postpartum_Health FROM  t1  ORDER BY  JCRQ desc),
postpartum_psychology=(SELECT top 1   postpartum_psychology FROM  t1  ORDER BY  JCRQ desc),
postpartum_SBP=(SELECT top 1   postpartum_SBP FROM  t1  ORDER BY  JCRQ desc),
postpartum_DBP=(SELECT top 1   postpartum_DBP FROM  t1  ORDER BY  JCRQ desc),
postpartum_milk_left=(SELECT top 1   postpartum_milk_left FROM  t1  ORDER BY  JCRQ desc),
postpartum_milk_right=(SELECT top 1   postpartum_milk_right FROM  t1  ORDER BY  JCRQ desc),
postpartum_lochia=(SELECT top 1   postpartum_lochia FROM  t1  ORDER BY  JCRQ desc),
postpartum_uterus=(SELECT top 1  postpartum_uterus FROM  t1  ORDER BY  JCRQ desc)

	
	WHERE ASSESS_ID=@ID
	
	;
	



  SELECT * FROM  #ASSESS_INFO_MATERNAL
						
			
			END
go

