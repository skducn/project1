CREATE PROCEDURE [dbo].[T_ASSESS_INFO_DIOPTOMETRY]
(@IDCARD NVARCHAR(18),@ID int,@guid VARCHAR(36),@START_TIME datetime,@END_TIME datetime)
as
BEGIN

				if OBJECT_ID('tempdb..#ASSESS_INFO_DIOPTOMETRY') is not null
drop table #ASSESS_INFO_DIOPTOMETRY;

CREATE TABLE [dbo].#ASSESS_INFO_DIOPTOMETRY (


    [ASSESS_ID] int  ,
    [examinationDate] date DEFAULT getdate() NOT NULL,
    [ODvision] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [OSvision] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [ODglasses] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [OSglasses] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [ODsphere] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [OSsphere] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [ODcylinder] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [OScylinder] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [ODastigmatism] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [OSastigmatism] nvarchar(20) COLLATE Chinese_PRC_CI_AS ,
    [other_information] nvarchar(200) COLLATE Chinese_PRC_CI_AS ,
    [suggestion] nvarchar(300) COLLATE Chinese_PRC_CI_AS

    );

iNSERT INTO #ASSESS_INFO_DIOPTOMETRY (ASSESS_ID) VALUES(@ID);


UPDATE 		#ASSESS_INFO_DIOPTOMETRY
SET ODvision=(SELECT top 1 ODvision from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    OSvision=(SELECT top 1 OSvision from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    ODglasses=(SELECT top 1 ODglasses from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    OSglasses=(SELECT top 1 OSglasses from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    ODsphere=(SELECT top 1 ODsphere from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    OSsphere=(SELECT top 1 OSsphere from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    ODcylinder=(SELECT top 1 ODcylinder from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    OScylinder=(SELECT top 1 OScylinder from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    ODastigmatism=(SELECT top 1 ODastigmatism from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    OSastigmatism=(SELECT top 1 OSastigmatism from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    other_information=(SELECT top 1 other_information from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  ),
    suggestion=(SELECT top 1 suggestion from TB_DIOPTOMETRY WHERE idCardNo =@idcard and examinationDate BETWEEN @START_TIME and @END_TIME ORDER BY examinationDate desc  )



WHERE ASSESS_ID=@ID

;




SELECT * FROM  #ASSESS_INFO_DIOPTOMETRY

END
go

