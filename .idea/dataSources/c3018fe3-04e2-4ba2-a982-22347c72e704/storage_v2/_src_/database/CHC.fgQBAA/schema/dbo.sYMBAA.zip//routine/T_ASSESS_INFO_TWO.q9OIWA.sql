CREATE PROCEDURE [dbo].[T_ASSESS_INFO_TWO] (@IDCARD NVARCHAR(18),@ID int,@guid VARCHAR(36),@START_TIME datetime,@END_TIME datetime)
as 
BEGIN


		;
	SELECT
	@IDCARD as  IDCARD,
	@ID as ASSESS_ID,
	 t2.MSG as DISEASE_NAME,
					CASE
							t2.ASSOCIATIONTYPE 
							WHEN 'family_history_of_children' THEN
							'儿子' 
							WHEN 'family_history_of_daughter' THEN
							'女儿' 
							WHEN 'family_history_of_father' THEN
							'父亲' 
							WHEN 'family_history_of_mother' THEN
							'母亲' 
							WHEN 'family_history_of_grandpas' THEN
							'爷爷' 
							WHEN 'family_history_of_siblings' THEN
							'兄弟姐妹' 
							WHEN 'family_history_of_child' THEN
							'子女' 
							
							ELSE '' 
						END AS FAMILY_TIES,
						
						t2.OCCURDATE as SERVER_DATE 
					FROM
						( SELECT * FROM HRPERSONBASICINFO WHERE ARCHIVENUM = @IDCARD ) t1
						INNER JOIN HRASSOCIATIONINFO t2 ON t1.id= t2.pid 
					WHERE
						t2.ASSOCIATIONTYPE LIKE '%family_history_of_%'
						AND t2.MSG is not NULL ;
						
					
						

						
						
	
	END
go

