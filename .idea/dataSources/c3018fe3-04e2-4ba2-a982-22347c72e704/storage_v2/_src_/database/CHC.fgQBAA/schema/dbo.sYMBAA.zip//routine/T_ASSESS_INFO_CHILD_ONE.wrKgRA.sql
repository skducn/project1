CREATE PROCEDURE [dbo].[T_ASSESS_INFO_CHILD_ONE] (@IDCARD NVARCHAR(18),@ID int,@START_TIME datetime,@END_TIME datetime)
as 
BEGIN



if OBJECT_ID('tempdb..#ASS_INFO_CHILD') is not null
    drop table #ASS_INFO_CHILD;
		
 CREATE TABLE [dbo].#ASS_INFO_CHILD (
  [ID] int   ,
  [ID_CARD] varchar(20)  COLLATE Chinese_PRC_CI_AS,
  [AGE] int ,
  [SEX_CODE] varchar(20) ,
  [SEX_NAME] nvarchar(50) COLLATE Chinese_PRC_CI_AS,
  [OCCUPATION_CODE] varchar(20) ,
  [OCCUPATION_NAME] nvarchar(100) COLLATE Chinese_PRC_CI_AS ,
  [HEIGHT] decimal(10,1) ,
  [WEIGHT] decimal(10,1) ,
  [BMI] decimal(10,1) ,
  [WAISTLINE] decimal(10,1) ,
  [HIPLINE] decimal(10,1) ,
  [DBP] int  ,
  [SBP] int  ,
  [DRINKING_FREQUENCY_CODE] varchar(50) COLLATE Chinese_PRC_CI_AS ,
  [DRINKING_FREQUENCY_NAME] varchar (200) COLLATE Chinese_PRC_CI_AS,
  [SMOKING_STATUS_CODE] varchar(50) ,
  [SMOKING_STATUS_NAME] varchar(200)COLLATE Chinese_PRC_CI_AS ,
  [HALOPHILIA_CODE] varchar(10) ,
  [HALOPHILIA_NAME] varchar(100)COLLATE Chinese_PRC_CI_AS ,
  [EATING_HABITS_CODE] varchar(20),
  [EATING_HABITS_NAME] varchar(100)COLLATE Chinese_PRC_CI_AS ,
  [SPORT_FREQUENCE] varchar(10) ,
  [EXERCISE_FREQUENCY_CODE] varchar(10),
  [EXERCISE_FREQUENCY_NAME] varchar(10)COLLATE Chinese_PRC_CI_AS,
  [IS_EXPOSURE] int ,
  [IS_EXPOSURE_RISK] int ,
  [FASTING_BLOOD_SUGAR] decimal(10,2) ,
  [RANDOM_BLOOD_SUGAR] decimal(10,2) ,
  [SERUM_LOW_DENSITY] decimal(10,2) ,
  [SERUM_HIGH_DENSITY] decimal(10,2) ,
  [TRIGLYCERIDE] decimal(10,2) ,
  [CHOLESTEROL_TOTAL] decimal(10,2) ,
  [URINE_PROTEIN] varchar(50) COLLATE Chinese_PRC_CI_AS ,
  [URINARY_ERYTHROCYTE] decimal(10,2) ,
  [SCR] decimal(10,2) ,
  [ACR] decimal(10,2),
  [HELICOBACTER_PYLORI] varchar(50) COLLATE Chinese_PRC_CI_AS,
  [GLYCOSYLATED_HEMOGLOBIN] decimal(10,2) ,
  [TCM_CONSTITUTION] varchar(100) COLLATE Chinese_PRC_CI_AS,
  [VISIT_MANAGE_CODE] varchar(20) COLLATE Chinese_PRC_CI_AS,
  [VISIT_MANAGE_NAME] varchar(100)COLLATE Chinese_PRC_CI_AS ,
  [CREATE_DATE] datetime2(7) ,
  [ASSESS_DATE] date ,
  [IS_DELETE] bit ,
  [ASSESS_DOC_ID] int ,
  [ASSESS_DOC_NAME] nvarchar(50)  ,
  [ASSESS_THIRD_NO] varchar(20) ,
  [REPORT_STATUS] int ,
  [ORG_CODE] varchar(50),
	[DRUG] nvarchar(4000),
  [EXAMINATION_AGE] int
)
;
INSERT INTO #ASS_INFO_CHILD (ID) VALUES(@ID);

UPDATE  #ASS_INFO_CHILD SET AGE=(SELECT  dbo.FN_GETAGE( @IDCARD, @END_TIME )),
EXAMINATION_AGE= (
SELECT  DATEDIFF(DAY, CONVERT(DATE, SUBSTRING(@IDCARD, 7, 8), 112), @END_TIME)/30
)

WHERE ID=@ID;
SELECT * FROM #ASS_INFO_CHILD ;


END
go

