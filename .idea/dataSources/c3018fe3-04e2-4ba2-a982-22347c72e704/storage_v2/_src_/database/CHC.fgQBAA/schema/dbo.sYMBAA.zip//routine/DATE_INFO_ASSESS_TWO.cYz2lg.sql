CREATE  PROCEDURE  [dbo].[DATE_INFO_ASSESS_TWO] (@IDCARD NVARCHAR(18),@ID int)
as 
BEGIN

--检测@IDCARD是否有sql注入
declare @inputcheck Nvarchar(20)=''

declare @guid Nvarchar(80)=''
SET @guid=  (SELECT  guid FROM  TB_EMPI_INDEX_ROOT WHERE IDCARDNO=@IDCARD )
set @inputcheck=@IDCARD
  
 if @inputcheck like '%select %' 
 or @inputcheck like '%update %'
 or @inputcheck like '%insert %'
 or @inputcheck like '%delete %'
 or @inputcheck like '%truncate %'
 or @inputcheck like '%drop %'
 or @inputcheck like '%union %'
 or @inputcheck like '%exec  %'
 or @inputcheck like '%xp_ %'
        begin
		  raiserror('输入变量值中包含sql注入！',16,1)
		  return
		end
;


	
	

	
	

END
go

