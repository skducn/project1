CREATE FUNCTION [dbo].[SplitStr]
(
    @strInfo NVARCHAR(MAX),
    @sign NVARCHAR(10),
    @field_name NVARCHAR(10)
)
RETURNS NVARCHAR(MAX) -- Adjusted return type
AS
BEGIN
    DECLARE @array TABLE (Item NVARCHAR(MAX))
    DECLARE @index INT, @item NVARCHAR(MAX), @values NVARCHAR(MAX)

    SET @index = CHARINDEX(@sign, @strInfo)
    
    WHILE (@index <> 0)
    BEGIN
        SET @item = SUBSTRING(@strInfo, 1, @index - 1)
        SET @values = (SELECT NAME FROM CODE_INFO WHERE CODE_INFO_ID = @field_name AND CODE = @item)
        IF @values IS NOT NULL
            INSERT INTO @array (Item) VALUES (@values)

        SET @strInfo = SUBSTRING(@strInfo, @index + 1, LEN(@strInfo) - @index)
        SET @index = CHARINDEX(@sign, @strInfo)
    END

    SET @item = @strInfo
    SET @values = (SELECT name FROM CODE_INFO WHERE CODE_INFO_ID = @field_name AND CODE = @item)
    IF (LEN(@item) > 0 AND @values IS NOT NULL)
        INSERT INTO @array (Item) VALUES (@values)

    DECLARE @code_name NVARCHAR(MAX) -- Define variable to hold concatenated string

    SELECT @code_name = STUFF(
                            (SELECT ',' + Item FROM @array FOR XML PATH ('')), 
                            1, 
                            1, 
                            ''
                        )

    RETURN @code_name -- Return the concatenated string
END
go

