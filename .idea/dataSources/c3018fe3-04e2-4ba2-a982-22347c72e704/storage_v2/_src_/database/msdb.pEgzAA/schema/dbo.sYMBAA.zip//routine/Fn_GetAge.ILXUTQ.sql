CREATE FUNCTION [dbo].[Fn_GetAge](@IdCard NVARCHAR(18),@LimitdDate DATETIME)
RETURNS INT AS
BEGIN
    DECLARE @BirthYear VARCHAR(4)
    DECLARE @BirthMonth VARCHAR(2)
    DECLARE @BirthDay VARCHAR(2)
    DECLARE @BirthDate DATETIME
    DECLARE @BirthDateStr NVARCHAR(10)
    DECLARE @Age INT
    DECLARE @Length INT
    SET @Age = 0
    BEGIN
        SET @BirthDateStr = ''
        SET @BirthDate = NULL
        SET @Length = LEN(@IdCard)
        IF(@Length = 15)
        BEGIN
            SET @BirthYear = ('19' + SUBSTRING(@IdCard,7,2))
            SET @BirthMonth = SUBSTRING(@IdCard,9,2)
            SET @BirthDay = SUBSTRING(@IdCard,11,2)
        END
        ELSE IF(@Length = 18)
        BEGIN
            SET @BirthYear = SUBSTRING(@IdCard,7,4)
            SET @BirthMonth = SUBSTRING(@IdCard,11,2)
            SET @BirthDay = SUBSTRING(@IdCard,13,2)
        END
        IF(@BirthYear > 1919)
        BEGIN
            --2月份的时间
            IF((@BirthYear % 4 = 0 OR @BirthYear % 100 != 0) OR (@BirthYear % 400 = 0)) --闰年
            BEGIN
                IF(@BirthMonth = 2)
                BEGIN
                    IF(@BirthDay > 0 AND @BirthDay <= 29)
                    BEGIN
                        SET @BirthDateStr = @BirthYear + '-' + @BirthMonth + '-'+ @BirthDay
                    END
                END
            END
            ELSE
            BEGIN
                IF(@BirthMonth = 2)
                BEGIN
                   IF(@BirthDay > 0 AND @BirthDay <= 28)
                   BEGIN
                       SET @BirthDateStr = @BirthYear + '-' + @BirthMonth + '-'+ @BirthDay
                   END
                END
            END
            --1 3 5 7 8 10 12月份的处理
            IF(@BirthMonth = 1 OR @BirthMonth = 3 OR @BirthMonth = 5 OR @BirthMonth = 7 OR @BirthMonth = 8 OR @BirthMonth = 10 OR @BirthMonth = 12)
            BEGIN
                IF(@BirthDay > 0 AND @BirthDay <= 31)
                BEGIN
                    SET @BirthDateStr = @BirthYear + '-' + @BirthMonth + '-'+ @BirthDay
                END
            END
            ELSE IF(@BirthMonth = 4 OR @BirthMonth = 6 OR @BirthMonth = 9 OR @BirthMonth = 11) --4 6 9 11月份的处理
            BEGIN
                IF(@BirthDay > 0 AND @BirthDay <= 30)
                BEGIN
                    SET @BirthDateStr = @BirthYear + '-' + @BirthMonth + '-'+ @BirthDay
                END
            END
            IF(@BirthDateStr != '')
            BEGIN
                SET @BirthDate = CONVERT(DATETIME,@BirthDateStr)
                SET @Age = DATEDIFF(YEAR,@BirthDate,@LimitdDate)
                IF(DATEPART(MONTH,@BirthDate) > DATEPART(MONTH,@LimitdDate))
                BEGIN
                    SET @Age = @Age - 1
                END
                ELSE IF(DATEPART(MONTH,@BirthDate) = DATEPART(MONTH,@LimitdDate))
                BEGIN
                    IF(DATEPART(DAY,@BirthDate) > DATEPART(DAY,@LimitdDate))
                    BEGIN
                        SET @Age = @Age - 1
                    END
                END
            END
        END
    END
    RETURN @Age
END
go

