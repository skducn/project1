	create procedure sp_DTA_view_table_helper_relational
						@SessionID		int
						as
						begin  select "视图 ID" =T2.TableID, "数据库名称" =D.DatabaseName, "架构名称" =T2.SchemaName, "视图名称" =T2.TableName, "数据库名称" =D.DatabaseName, "架构名称" =T1.SchemaName, "表名" =T1.TableName 	from 
					[msdb].[dbo].[DTA_reports_database] D, 
					[msdb].[dbo].[DTA_reports_tableview] TV, 
					[msdb].[dbo].[DTA_reports_table] T1,
					[msdb].[dbo].[DTA_reports_table] T2
					where 
						D.DatabaseID=T1.DatabaseID and 
						D.DatabaseID=T2.DatabaseID and
						T1.TableID=TV.TableID and 
						T2.TableID=TV.ViewID and
						D.SessionID=@SessionID
						order by TV.ViewID  end
    go

