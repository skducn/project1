 create procedure sp_DTA_query_detail_helper_relational
			@SessionID		int
			as
			begin select "语句 ID" =QueryID, "语句字符串" =StatementString, "语句类型" = CASE 
					WHEN StatementType = 0 THEN 'Select'
					WHEN StatementType = 1 THEN 'Update'
					WHEN StatementType = 2 THEN 'Insert'
					WHEN StatementType = 3 THEN 'Delete'
					WHEN StatementType = 4 THEN 'Merge'
					end,"当前的语句开销" =CAST(CurrentCost as decimal(38,7)), "建议的语句开销" =CAST(RecommendedCost as decimal(38,7)), "事件字符串" =EventString	from [msdb].[dbo].[DTA_reports_query]
						where SessionID=@SessionID  order by QueryID ASC end
 go

