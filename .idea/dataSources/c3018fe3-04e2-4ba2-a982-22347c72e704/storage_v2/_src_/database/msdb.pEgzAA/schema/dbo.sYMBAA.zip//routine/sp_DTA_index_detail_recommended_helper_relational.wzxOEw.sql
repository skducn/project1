	create procedure sp_DTA_index_detail_recommended_helper_relational
						@SessionID		int
						as
						begin	select "数据库名称" = D.DatabaseName, "架构名称" = T.SchemaName, "表/视图名称" = T.TableName, "索引名称" = I.IndexName, "聚集" =	CASE
						WHEN I.IsClustered = 1 THEN 'Yes'	
						WHEN I.IsClustered = 0 THEN 'No'
						end, "唯一" =	CASE
						WHEN I.IsUnique = 1 THEN 'Yes'		
						WHEN I.IsUnique = 0 THEN 'No'
						end	, "堆" =	CASE
						WHEN I.IsHeap = 1 THEN 'Yes'		
						WHEN I.IsHeap = 0 THEN 'No'
						end	, "已筛选" =	CASE
						WHEN I.IsFiltered = 1 THEN 'Yes'		
						WHEN I.IsFiltered = 0 THEN 'No'
						end	, "索引大小(MB)"= CAST(I.RecommendedStorage as decimal(38,2)) , "行数"= NumRows , "筛选器定义"= I.FilterDefinition 	from 
					DTA_reports_database  D,
					DTA_reports_table T,
					DTA_reports_index as I
					where
					D.SessionID = @SessionID and
					D.DatabaseID = T.DatabaseID and
					T.TableID = I.TableID and
					I.IsRecommended = 1  end
    go

