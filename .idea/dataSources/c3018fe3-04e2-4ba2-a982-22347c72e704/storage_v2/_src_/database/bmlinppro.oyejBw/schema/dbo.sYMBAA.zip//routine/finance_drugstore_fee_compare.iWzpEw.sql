CREATE PROCEDURE [dbo].[finance_drugstore_fee_compare](
@beginTime nvarchar(30) = '2021-09-01',
@endTime nvarchar(30) = '2021-09-30 23:59:59',
@dateType nvarchar(30) = 'bml'
)
AS
BEGIN
declare @BEGINDATE varchar(30)
declare @ENDDATE varchar(30)
declare @inp varchar(30)
declare @pim varchar(30)
SET @BEGINDATE = @beginTime
SET @ENDDATE = @endTime
SET @inp = @dateType+'inpprotest'
SET @pim = @dateType + 'pimprotest'

EXEC('SELECT * FROM
(
-- 费用流水
	SELECT
	id, inPId, feeId, foreignId,itemType, feeTime, price, amount AS number, fee, status FROM
	'+@inp+'.dbo.t_inpatient_patient_fee_serial_account a
	WHERE
	a.feeTime >= '''+@BEGINDATE+''' AND a.feeTime <=  '''+@ENDDATE+''' AND
	a.itemType in (''03'',''06'',''09'')
) fee
FULL JOIN
(
-- 药品配药
	SELECT id, inPId, tallyId,
	(CASE state WHEN ''22'' THEN -pleaseReturnNumber ELSE pleaseNumber END) AS number,
	price,
	(CASE state WHEN ''22'' THEN -pleaseReturnNumber ELSE pleaseNumber END) * price AS amount,
	itemType,
	state,
	agoPreparingUserTime,
	checkUserTime
	from '+@pim+'.dbo.t_drug_arrange_info where
	(state = ''2'' AND agoPreparingUserTime >= '''+@BEGINDATE+''' AND agoPreparingUserTime <= '''+@ENDDATE+''')
	 OR
	(state = ''22'' AND checkUserTime >= '''+@BEGINDATE+''' AND checkUserTime <='''+@ENDDATE+''')
) drug ON fee.id = drug.tallyId
-- 筛选不同
WHERE
fee.feeId IS NULL
OR drug.id IS NULL
OR fee.fee <> drug.amount')
END
go

