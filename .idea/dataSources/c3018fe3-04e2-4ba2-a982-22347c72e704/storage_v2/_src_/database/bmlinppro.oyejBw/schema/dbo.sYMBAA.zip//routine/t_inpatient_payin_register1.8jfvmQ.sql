CREATE PROCEDURE [dbo].[t_inpatient_payin_register1]
AS
BEGIN
SELECT
 CONVERT(VARCHAR(100),B.name) AS property,
 CONVERT(VARCHAR(100),C.value) AS name
 FROM sys.objects AS A
 INNER JOIN sys.columns AS B ON B.object_id = A.object_id
 LEFT JOIN sys.extended_properties AS C ON C.major_id = B.object_id AND C.minor_id = B.column_id
 WHERE A.name = 't_inpatient_payin_register'
 AND B.column_id in (26,27,29,74,75,76,17,18,20,68,69,70,71,15,9,31)
END
go

exec sp_addextendedproperty 'MS_Description', '动态返回缴款预交金统计字段', 'SCHEMA', 'dbo', 'PROCEDURE',
     't_inpatient_payin_register1'
go

