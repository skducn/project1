CREATE PROCEDURE [dbo].[ward_income_detail]
 
 @startTime varchar(50),
 @endTime varchar(50)
 as 
 begin
SELECT
fee.feeTime AS 费用时间,
 regis.inPNo AS 住院号,
  regis.bedNo AS 床位号,
 regis.name AS 姓名,
 fee.[西药费用] AS 西药收入,
 0 AS 西药支出,
 0 AS 西药差额,
 fee.[中成药费用] AS 中成药收入,
 0 AS 中成药支出,
 0 AS 中成药差额,
 fee.[中草药费用],
 0 AS 中草药支出,
 0 AS 中草药差额
FROM
 t_inpatient_register regis
 RIGHT JOIN (
 SELECT
  account.inPId,
  times.feeTime AS feeTime,
  SUM ( CASE account.itemType WHEN '03' THEN fee ELSE 0 END ) AS 西药费用,
  SUM ( CASE account.itemType WHEN '06' THEN fee ELSE 0 END ) AS 中成药费用,
  SUM ( CASE account.itemType WHEN '09' THEN fee ELSE 0 END ) AS 中草药费用
 FROM
  t_inpatient_patient_fee_serial_account account
  RIGHT JOIN (
  SELECT CONVERT
   ( VARCHAR ( 100 ), feeTime, 23 ) AS feeTime
  FROM
   t_inpatient_patient_fee_serial_account acc
  WHERE
   acc.feeTime >= @startTime
   AND acc.feeTime < @endTime
   AND acc.itemType IN ( '03', '06', '09' )
  GROUP BY
   CONVERT ( VARCHAR ( 100 ), feeTime, 23 )
  ) times ON times.feeTime = CONVERT ( VARCHAR ( 100 ), account.feeTime, 23 )
 GROUP BY
  account.inPId,
  times.feeTime
 ) fee ON fee.inPId = regis.inPId
WHERE
 fee.[西药费用] > 0
 OR fee.[中成药费用] > 0
 OR fee.[中草药费用] > 0
ORDER BY
 fee.inPId,
 fee.feeTime end;
go

