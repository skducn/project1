CREATE PROCEDURE [dbo].[entry_account_getItemTypeSet]
@itemTypeSet nvarchar(200) OUTPUT
AS
BEGIN
	SET @itemTypeSet = '18-住院费;19-诊疗费;10-治疗费;32-理疗费;13-护理费;08-材料费;07-检查费;05-化验费;22-摄片费;24-输氧费;03-西药费;06-中成药费;34-注射费'
	SELECT @itemTypeSet
END
go

exec sp_addextendedproperty 'MS_Description', '住院缴款入账-获取项目类别', 'SCHEMA', 'dbo', 'PROCEDURE',
     'entry_account_getItemTypeSet'
go

